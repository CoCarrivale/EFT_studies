# This file was automatically created by FeynRules 2.3.49
# Mathematica version: 13.1.0 for Mac OS X ARM (64-bit) (June 16, 2022)
# Date: Tue 7 Nov 2023 22:05:13



from object_library import all_parameters, Parameter


from function_library import complexconjugate, re, im, csc, sec, acsc, asec, cot

# This is a default parameter object representing 0.
ZERO = Parameter(name = 'ZERO',
                 nature = 'internal',
                 type = 'real',
                 value = '0.0',
                 texname = '0')

# User-defined parameters.
alphas = Parameter(name = 'alphas',
                   nature = 'external',
                   type = 'real',
                   value = 0.1176,
                   texname = '\\alpha _s',
                   lhablock = 'FRBlock',
                   lhacode = [ 1 ])

Gf = Parameter(name = 'Gf',
               nature = 'external',
               type = 'real',
               value = 0.000011638081097590524,
               texname = 'G_F',
               lhablock = 'FRBlock',
               lhacode = [ 2 ])

AEM = Parameter(name = 'AEM',
                nature = 'external',
                type = 'real',
                value = 0.0072973525692838015,
                texname = '\\alpha _{\\text{em}}',
                lhablock = 'FRBlock',
                lhacode = [ 3 ])

Zmass = Parameter(name = 'Zmass',
                  nature = 'external',
                  type = 'real',
                  value = 91.1876,
                  texname = 'M_Z',
                  lhablock = 'FRBlock',
                  lhacode = [ 4 ])

Wmass = Parameter(name = 'Wmass',
                  nature = 'external',
                  type = 'real',
                  value = 80.379,
                  texname = 'M_W',
                  lhablock = 'FRBlock',
                  lhacode = [ 5 ])

Hmass = Parameter(name = 'Hmass',
                  nature = 'external',
                  type = 'real',
                  value = 125.35,
                  texname = 'M_H',
                  lhablock = 'FRBlock',
                  lhacode = [ 6 ])

tmass = Parameter(name = 'tmass',
                  nature = 'external',
                  type = 'real',
                  value = 172.76,
                  texname = 'm_t',
                  lhablock = 'FRBlock',
                  lhacode = [ 7 ])

cmass = Parameter(name = 'cmass',
                  nature = 'external',
                  type = 'real',
                  value = 1.27,
                  texname = 'm_c',
                  lhablock = 'FRBlock',
                  lhacode = [ 8 ])

umass = Parameter(name = 'umass',
                  nature = 'external',
                  type = 'real',
                  value = 0.0025499999999999997,
                  texname = 'm_u',
                  lhablock = 'FRBlock',
                  lhacode = [ 9 ])

bmass = Parameter(name = 'bmass',
                  nature = 'external',
                  type = 'real',
                  value = 4.7,
                  texname = 'm_b',
                  lhablock = 'FRBlock',
                  lhacode = [ 10 ])

smass = Parameter(name = 'smass',
                  nature = 'external',
                  type = 'real',
                  value = 0.101,
                  texname = 'm_s',
                  lhablock = 'FRBlock',
                  lhacode = [ 11 ])

dmass = Parameter(name = 'dmass',
                  nature = 'external',
                  type = 'real',
                  value = 0.00504,
                  texname = 'm_d',
                  lhablock = 'FRBlock',
                  lhacode = [ 12 ])

taumass = Parameter(name = 'taumass',
                    nature = 'external',
                    type = 'real',
                    value = 1.77686,
                    texname = 'm_{\\tau }',
                    lhablock = 'FRBlock',
                    lhacode = [ 13 ])

mumass = Parameter(name = 'mumass',
                   nature = 'external',
                   type = 'real',
                   value = 0.1056583755,
                   texname = 'm_{\\mu }',
                   lhablock = 'FRBlock',
                   lhacode = [ 14 ])

emass = Parameter(name = 'emass',
                  nature = 'external',
                  type = 'real',
                  value = 0.00051099895,
                  texname = 'm_e',
                  lhablock = 'FRBlock',
                  lhacode = [ 15 ])

lamT = Parameter(name = 'lamT',
                 nature = 'external',
                 type = 'real',
                 value = 0.22537,
                 texname = '\\lambda _T',
                 lhablock = 'FRBlock',
                 lhacode = [ 16 ])

AT = Parameter(name = 'AT',
               nature = 'external',
               type = 'real',
               value = 0.828,
               texname = 'A_T',
               lhablock = 'FRBlock',
               lhacode = [ 17 ])

rhoT = Parameter(name = 'rhoT',
                 nature = 'external',
                 type = 'real',
                 value = 0.194,
                 texname = '\\rho _T',
                 lhablock = 'FRBlock',
                 lhacode = [ 18 ])

etaT = Parameter(name = 'etaT',
                 nature = 'external',
                 type = 'real',
                 value = 0.391,
                 texname = '\\eta _T',
                 lhablock = 'FRBlock',
                 lhacode = [ 19 ])

theta12 = Parameter(name = 'theta12',
                    nature = 'external',
                    type = 'real',
                    value = 0.5836381018669038,
                    texname = '\\theta _{12}',
                    lhablock = 'FRBlock',
                    lhacode = [ 20 ])

theta13 = Parameter(name = 'theta13',
                    nature = 'external',
                    type = 'real',
                    value = 0.14957471689591406,
                    texname = '\\theta _{13}',
                    lhablock = 'FRBlock',
                    lhacode = [ 21 ])

theta23 = Parameter(name = 'theta23',
                    nature = 'external',
                    type = 'real',
                    value = 0.8587019919812102,
                    texname = '\\theta _{23}',
                    lhablock = 'FRBlock',
                    lhacode = [ 22 ])

delta = Parameter(name = 'delta',
                  nature = 'external',
                  type = 'real',
                  value = 3.3859562021615193,
                  texname = '\\delta',
                  lhablock = 'FRBlock',
                  lhacode = [ 23 ])

taumu = Parameter(name = 'taumu',
                  nature = 'external',
                  type = 'real',
                  value = 3.337862504e18,
                  texname = '\\tau _{\\mu }',
                  lhablock = 'FRBlock',
                  lhacode = [ 24 ])

mB = Parameter(name = 'mB',
               nature = 'external',
               type = 'real',
               value = 5.27932,
               texname = 'm^{\\text{B+}}',
               lhablock = 'FRBlock',
               lhacode = [ 25 ])

mBs = Parameter(name = 'mBs',
                nature = 'external',
                type = 'real',
                value = 5.36689,
                texname = 'm_{\\text{Bs}}',
                lhablock = 'FRBlock',
                lhacode = [ 26 ])

mBd = Parameter(name = 'mBd',
                nature = 'external',
                type = 'real',
                value = 5.27963,
                texname = 'm_{\\text{Bd}}',
                lhablock = 'FRBlock',
                lhacode = [ 27 ])

mK = Parameter(name = 'mK',
               nature = 'external',
               type = 'real',
               value = 0.493677,
               texname = 'm^{\\text{K+}}',
               lhablock = 'FRBlock',
               lhacode = [ 28 ])

mPi = Parameter(name = 'mPi',
                nature = 'external',
                type = 'real',
                value = 0.13957061,
                texname = 'm^{\\text{$\\pi $+}}',
                lhablock = 'FRBlock',
                lhacode = [ 29 ])

S1 = Parameter(name = 'S1',
               nature = 'external',
               type = 'real',
               value = 2.3124,
               texname = 'S_1\\left(m_W\\right)',
               lhablock = 'FRBlock',
               lhacode = [ 30 ])

aEWM1 = Parameter(name = 'aEWM1',
                  nature = 'external',
                  type = 'real',
                  value = 0.007460203686184244,
                  texname = '\\alpha _{\\text{em}}',
                  lhablock = 'FRBlock',
                  lhacode = [ 31 ])

G1 = Parameter(name = 'G1',
               nature = 'external',
               type = 'real',
               value = 0.3468809186612817,
               texname = 'G_1',
               lhablock = 'FRBlock',
               lhacode = [ 32 ])

GW = Parameter(name = 'GW',
               nature = 'external',
               type = 'real',
               value = 0.6521849654370863,
               texname = 'G_W',
               lhablock = 'FRBlock',
               lhacode = [ 33 ])

aS = Parameter(name = 'aS',
               nature = 'external',
               type = 'real',
               value = 0.1176,
               texname = '\\alpha _s',
               lhablock = 'FRBlock',
               lhacode = [ 34 ])

vev = Parameter(name = 'vev',
                nature = 'external',
                type = 'real',
                value = 246.49142270898864,
                texname = 'v',
                lhablock = 'FRBlock',
                lhacode = [ 35 ])

hlambda = Parameter(name = 'hlambda',
                    nature = 'external',
                    type = 'real',
                    value = 0.2594104631067388,
                    texname = '\\lambda',
                    lhablock = 'FRBlock',
                    lhacode = [ 36 ])

mz = Parameter(name = 'mz',
               nature = 'external',
               type = 'real',
               value = 91.1876,
               texname = 'M_Z',
               lhablock = 'FRBlock',
               lhacode = [ 37 ])

mw = Parameter(name = 'mw',
               nature = 'external',
               type = 'real',
               value = 80.379,
               texname = 'M_W',
               lhablock = 'FRBlock',
               lhacode = [ 38 ])

mh = Parameter(name = 'mh',
               nature = 'external',
               type = 'real',
               value = 125.35,
               texname = 'M_H',
               lhablock = 'FRBlock',
               lhacode = [ 39 ])

mqt = Parameter(name = 'mqt',
                nature = 'external',
                type = 'real',
                value = 172.76,
                texname = 'm_t',
                lhablock = 'FRBlock',
                lhacode = [ 40 ])

mqc = Parameter(name = 'mqc',
                nature = 'external',
                type = 'real',
                value = 1.27,
                texname = 'm_c',
                lhablock = 'FRBlock',
                lhacode = [ 41 ])

mqu = Parameter(name = 'mqu',
                nature = 'external',
                type = 'real',
                value = 0.0025499999999999997,
                texname = 'm_u',
                lhablock = 'FRBlock',
                lhacode = [ 42 ])

mqb = Parameter(name = 'mqb',
                nature = 'external',
                type = 'real',
                value = 4.7,
                texname = 'm_b',
                lhablock = 'FRBlock',
                lhacode = [ 43 ])

mqs = Parameter(name = 'mqs',
                nature = 'external',
                type = 'real',
                value = 0.101,
                texname = 'm_s',
                lhablock = 'FRBlock',
                lhacode = [ 44 ])

mqd = Parameter(name = 'mqd',
                nature = 'external',
                type = 'real',
                value = 0.00504,
                texname = 'm_d',
                lhablock = 'FRBlock',
                lhacode = [ 45 ])

mlt = Parameter(name = 'mlt',
                nature = 'external',
                type = 'real',
                value = 1.77686,
                texname = 'm_{\\tau }',
                lhablock = 'FRBlock',
                lhacode = [ 46 ])

mlm = Parameter(name = 'mlm',
                nature = 'external',
                type = 'real',
                value = 0.1056583755,
                texname = 'm_{\\mu }',
                lhablock = 'FRBlock',
                lhacode = [ 47 ])

mle = Parameter(name = 'mle',
                nature = 'external',
                type = 'real',
                value = 0.00051099895,
                texname = 'm_e',
                lhablock = 'FRBlock',
                lhacode = [ 48 ])

mve = Parameter(name = 'mve',
                nature = 'external',
                type = 'real',
                value = 0,
                texname = 'm_{\\text{$\\nu $e}}',
                lhablock = 'FRBlock',
                lhacode = [ 49 ])

mvm = Parameter(name = 'mvm',
                nature = 'external',
                type = 'real',
                value = 0,
                texname = 'm_{\\nu \\mu }',
                lhablock = 'FRBlock',
                lhacode = [ 50 ])

mvt = Parameter(name = 'mvt',
                nature = 'external',
                type = 'real',
                value = 0,
                texname = 'm_{\\nu \\tau }',
                lhablock = 'FRBlock',
                lhacode = [ 51 ])

MG0 = Parameter(name = 'MG0',
                nature = 'external',
                type = 'real',
                value = 91.1876,
                texname = 'M_{\\text{G0}}',
                lhablock = 'FRBlock',
                lhacode = [ 52 ])

MGP = Parameter(name = 'MGP',
                nature = 'external',
                type = 'real',
                value = 80.379,
                texname = 'M_{\\text{GP}}',
                lhablock = 'FRBlock',
                lhacode = [ 53 ])

MgZ = Parameter(name = 'MgZ',
                nature = 'external',
                type = 'real',
                value = 91.1876,
                texname = 'M_{\\text{etaZ}}',
                lhablock = 'FRBlock',
                lhacode = [ 54 ])

MgW = Parameter(name = 'MgW',
                nature = 'external',
                type = 'real',
                value = 80.379,
                texname = 'M_{\\text{etaW}}',
                lhablock = 'FRBlock',
                lhacode = [ 55 ])

xiW = Parameter(name = 'xiW',
                nature = 'external',
                type = 'real',
                value = 1,
                texname = '\\xi _W',
                lhablock = 'FRBlock',
                lhacode = [ 56 ])

xiZ = Parameter(name = 'xiZ',
                nature = 'external',
                type = 'real',
                value = 1,
                texname = '\\xi _Z',
                lhablock = 'FRBlock',
                lhacode = [ 57 ])

xiA = Parameter(name = 'xiA',
                nature = 'external',
                type = 'real',
                value = 1,
                texname = '\\xi _A',
                lhablock = 'FRBlock',
                lhacode = [ 58 ])

xiG = Parameter(name = 'xiG',
                nature = 'external',
                type = 'real',
                value = 1,
                texname = '\\xi _G',
                lhablock = 'FRBlock',
                lhacode = [ 59 ])

g1norm = Parameter(name = 'g1norm',
                   nature = 'external',
                   type = 'real',
                   value = 0.9995742535080346,
                   texname = 'Z_{\\text{g\'}}',
                   lhablock = 'FRBlock',
                   lhacode = [ 60 ])

gwnorm = Parameter(name = 'gwnorm',
                   nature = 'external',
                   type = 'real',
                   value = 0.9989773806886596,
                   texname = 'Z_g',
                   lhablock = 'FRBlock',
                   lhacode = [ 61 ])

gsnorm = Parameter(name = 'gsnorm',
                   nature = 'external',
                   type = 'real',
                   value = 1,
                   texname = 'Z_{\\text{gs}}',
                   lhablock = 'FRBlock',
                   lhacode = [ 62 ])

Hnorm = Parameter(name = 'Hnorm',
                  nature = 'external',
                  type = 'real',
                  value = 0.998447656104409,
                  texname = 'Z_h',
                  lhablock = 'FRBlock',
                  lhacode = [ 63 ])

G0norm = Parameter(name = 'G0norm',
                   nature = 'external',
                   type = 'real',
                   value = 1.0004559074586816,
                   texname = 'Z_{\\text{G0}}',
                   lhablock = 'FRBlock',
                   lhacode = [ 64 ])

GPnorm = Parameter(name = 'GPnorm',
                   nature = 'external',
                   type = 'real',
                   value = 1,
                   texname = 'Z_{\\text{G+}}',
                   lhablock = 'FRBlock',
                   lhacode = [ 65 ])

Wnorm = Parameter(name = 'Wnorm',
                  nature = 'external',
                  type = 'real',
                  value = 1.0010226834454976,
                  texname = 'Z_W',
                  lhablock = 'FRBlock',
                  lhacode = [ 66 ])

Gnorm = Parameter(name = 'Gnorm',
                  nature = 'external',
                  type = 'real',
                  value = 1,
                  texname = 'Z_{\\text{gl}}',
                  lhablock = 'FRBlock',
                  lhacode = [ 67 ])

AZnorm11 = Parameter(name = 'AZnorm11',
                     nature = 'external',
                     type = 'real',
                     value = 0.8851237575350185,
                     texname = 'Z_{\\text{$\\gamma $Z}}^{11}',
                     lhablock = 'FRBlock',
                     lhacode = [ 68 ])

AZnorm12 = Parameter(name = 'AZnorm12',
                     nature = 'external',
                     type = 'real',
                     value = 0.4700871955405533,
                     texname = 'Z_{\\text{$\\gamma $Z}}^{12}',
                     lhablock = 'FRBlock',
                     lhacode = [ 69 ])

AZnorm21 = Parameter(name = 'AZnorm21',
                     nature = 'external',
                     type = 'real',
                     value = -0.4697499628203064,
                     texname = 'Z_{\\text{$\\gamma $Z}}^{21}',
                     lhablock = 'FRBlock',
                     lhacode = [ 70 ])

AZnorm22 = Parameter(name = 'AZnorm22',
                     nature = 'external',
                     type = 'real',
                     value = 0.8832870099254924,
                     texname = 'Z_{\\text{$\\gamma $Z}}^{22}',
                     lhablock = 'FRBlock',
                     lhacode = [ 71 ])

CB2phi2D2n1 = Parameter(name = 'CB2phi2D2n1',
                        nature = 'external',
                        type = 'real',
                        value = 0,
                        texname = 'C^{\\text{B2$\\phi $2D2n1}}',
                        lhablock = 'FRBlock',
                        lhacode = [ 72 ])

CB2phi2D2n2 = Parameter(name = 'CB2phi2D2n2',
                        nature = 'external',
                        type = 'real',
                        value = 0,
                        texname = 'C^{\\text{B2$\\phi $2D2n2}}',
                        lhablock = 'FRBlock',
                        lhacode = [ 73 ])

CB2phi2D2n3 = Parameter(name = 'CB2phi2D2n3',
                        nature = 'external',
                        type = 'real',
                        value = 0,
                        texname = 'C^{\\text{B2$\\phi $2D2n3}}',
                        lhablock = 'FRBlock',
                        lhacode = [ 74 ])

CB2phi4n1 = Parameter(name = 'CB2phi4n1',
                      nature = 'external',
                      type = 'real',
                      value = 2.30661e-13,
                      texname = 'C^{\\text{B2$\\phi $4n1}}',
                      lhablock = 'FRBlock',
                      lhacode = [ 75 ])

CB2phi4n2 = Parameter(name = 'CB2phi4n2',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = 'C^{\\text{B2$\\phi $4n2}}',
                      lhablock = 'FRBlock',
                      lhacode = [ 76 ])

CB4n1 = Parameter(name = 'CB4n1',
                  nature = 'external',
                  type = 'real',
                  value = 0,
                  texname = 'C^{\\text{B4n1}}',
                  lhablock = 'FRBlock',
                  lhacode = [ 77 ])

CB4n2 = Parameter(name = 'CB4n2',
                  nature = 'external',
                  type = 'real',
                  value = 0,
                  texname = 'C^{\\text{B4n2}}',
                  lhablock = 'FRBlock',
                  lhacode = [ 78 ])

CB4n3 = Parameter(name = 'CB4n3',
                  nature = 'external',
                  type = 'real',
                  value = 0,
                  texname = 'C^{\\text{B4n3}}',
                  lhablock = 'FRBlock',
                  lhacode = [ 79 ])

CBphi4D2n1 = Parameter(name = 'CBphi4D2n1',
                       nature = 'external',
                       type = 'real',
                       value = 0,
                       texname = 'C^{\\text{B$\\phi $4D2n1}}',
                       lhablock = 'FRBlock',
                       lhacode = [ 80 ])

CBphi4D2n2 = Parameter(name = 'CBphi4D2n2',
                       nature = 'external',
                       type = 'real',
                       value = 0,
                       texname = 'C^{\\text{B$\\phi $4D2n2}}',
                       lhablock = 'FRBlock',
                       lhacode = [ 81 ])

Cphi = Parameter(name = 'Cphi',
                 nature = 'external',
                 type = 'real',
                 value = 1.04352e-11,
                 texname = 'C^{\\phi }',
                 lhablock = 'FRBlock',
                 lhacode = [ 82 ])

Cphi4D4n1 = Parameter(name = 'Cphi4D4n1',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = 'C^{\\text{$\\phi $4D4n1}}',
                      lhablock = 'FRBlock',
                      lhacode = [ 83 ])

Cphi4D4n2 = Parameter(name = 'Cphi4D4n2',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = 'C^{\\text{$\\phi $4D4n2}}',
                      lhablock = 'FRBlock',
                      lhacode = [ 84 ])

Cphi4D4n3 = Parameter(name = 'Cphi4D4n3',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = 'C^{\\text{$\\phi $4D4n3}}',
                      lhablock = 'FRBlock',
                      lhacode = [ 85 ])

Cphi6Box = Parameter(name = 'Cphi6Box',
                     nature = 'external',
                     type = 'real',
                     value = 4.67129e-13,
                     texname = 'C^{\\text{$\\phi $6Box}}',
                     lhablock = 'FRBlock',
                     lhacode = [ 86 ])

Cphi6D2 = Parameter(name = 'Cphi6D2',
                    nature = 'external',
                    type = 'real',
                    value = 7.43333e-13,
                    texname = 'C^{\\text{$\\phi $6D2}}',
                    lhablock = 'FRBlock',
                    lhacode = [ 87 ])

Cphi8 = Parameter(name = 'Cphi8',
                  nature = 'external',
                  type = 'real',
                  value = 1.04352e-13,
                  texname = 'C^{\\text{$\\phi $8}}',
                  lhablock = 'FRBlock',
                  lhacode = [ 88 ])

CphiBox = Parameter(name = 'CphiBox',
                    nature = 'external',
                    type = 'real',
                    value = 4.67129e-9,
                    texname = 'C^{\\text{$\\phi $Box}}',
                    lhablock = 'FRBlock',
                    lhacode = [ 89 ])

CphiBtilde = Parameter(name = 'CphiBtilde',
                       nature = 'external',
                       type = 'real',
                       value = 6.51045e-9,
                       texname = 'C^{\\text{$\\phi $Btilde}}',
                       lhablock = 'FRBlock',
                       lhacode = [ 90 ])

CphiD = Parameter(name = 'CphiD',
                  nature = 'external',
                  type = 'real',
                  value = 7.43333e-9,
                  texname = 'C^{\\text{$\\phi $D}}',
                  lhablock = 'FRBlock',
                  lhacode = [ 91 ])

CphiW = Parameter(name = 'CphiW',
                  nature = 'external',
                  type = 'real',
                  value = 4.16813e-9,
                  texname = 'C^{\\text{$\\phi $W}}',
                  lhablock = 'FRBlock',
                  lhacode = [ 92 ])

CphiWB = Parameter(name = 'CphiWB',
                   nature = 'external',
                   type = 'real',
                   value = 3.07843e-11,
                   texname = 'C^{\\text{$\\phi $WB}}',
                   lhablock = 'FRBlock',
                   lhacode = [ 93 ])

CphiWtilde = Parameter(name = 'CphiWtilde',
                       nature = 'external',
                       type = 'real',
                       value = 8.96156e-9,
                       texname = 'C^{\\text{$\\phi $Wtilde}}',
                       lhablock = 'FRBlock',
                       lhacode = [ 94 ])

CphiWtildeB = Parameter(name = 'CphiWtildeB',
                        nature = 'external',
                        type = 'real',
                        value = 8.40034e-9,
                        texname = 'C^{\\text{$\\phi $WtildeB}}',
                        lhablock = 'FRBlock',
                        lhacode = [ 95 ])

CW = Parameter(name = 'CW',
               nature = 'external',
               type = 'real',
               value = 3.81851e-9,
               texname = 'C^W',
               lhablock = 'FRBlock',
               lhacode = [ 96 ])

CW2B2n1 = Parameter(name = 'CW2B2n1',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = 'C^{\\text{W2B2n1}}',
                    lhablock = 'FRBlock',
                    lhacode = [ 97 ])

CW2B2n2 = Parameter(name = 'CW2B2n2',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = 'C^{\\text{W2B2n2}}',
                    lhablock = 'FRBlock',
                    lhacode = [ 98 ])

CW2B2n3 = Parameter(name = 'CW2B2n3',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = 'C^{\\text{W2B2n3}}',
                    lhablock = 'FRBlock',
                    lhacode = [ 99 ])

CW2B2n4 = Parameter(name = 'CW2B2n4',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = 'C^{\\text{W2B2n4}}',
                    lhablock = 'FRBlock',
                    lhacode = [ 100 ])

CW2B2n5 = Parameter(name = 'CW2B2n5',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = 'C^{\\text{W2B2n5}}',
                    lhablock = 'FRBlock',
                    lhacode = [ 101 ])

CW2B2n6 = Parameter(name = 'CW2B2n6',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = 'C^{\\text{W2B2n6}}',
                    lhablock = 'FRBlock',
                    lhacode = [ 102 ])

CW2B2n7 = Parameter(name = 'CW2B2n7',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = 'C^{\\text{W2B2n7}}',
                    lhablock = 'FRBlock',
                    lhacode = [ 103 ])

CW2Bphi2n1 = Parameter(name = 'CW2Bphi2n1',
                       nature = 'external',
                       type = 'real',
                       value = 0,
                       texname = 'C^{\\text{W2B$\\phi $2n1}}',
                       lhablock = 'FRBlock',
                       lhacode = [ 104 ])

CW2Bphi2n2 = Parameter(name = 'CW2Bphi2n2',
                       nature = 'external',
                       type = 'real',
                       value = 0,
                       texname = 'C^{\\text{W2B$\\phi $2n2}}',
                       lhablock = 'FRBlock',
                       lhacode = [ 105 ])

CW2phi2D2n1 = Parameter(name = 'CW2phi2D2n1',
                        nature = 'external',
                        type = 'real',
                        value = 0,
                        texname = 'C^{\\text{W2$\\phi $2D2n1}}',
                        lhablock = 'FRBlock',
                        lhacode = [ 106 ])

CW2phi2D2n2 = Parameter(name = 'CW2phi2D2n2',
                        nature = 'external',
                        type = 'real',
                        value = 0,
                        texname = 'C^{\\text{W2$\\phi $2D2n2}}',
                        lhablock = 'FRBlock',
                        lhacode = [ 107 ])

CW2phi2D2n3 = Parameter(name = 'CW2phi2D2n3',
                        nature = 'external',
                        type = 'real',
                        value = 0,
                        texname = 'C^{\\text{W2$\\phi $2D2n3}}',
                        lhablock = 'FRBlock',
                        lhacode = [ 108 ])

CW2phi2D2n4 = Parameter(name = 'CW2phi2D2n4',
                        nature = 'external',
                        type = 'real',
                        value = 0,
                        texname = 'C^{\\text{W2$\\phi $2D2n4}}',
                        lhablock = 'FRBlock',
                        lhacode = [ 109 ])

CW2phi2D2n5 = Parameter(name = 'CW2phi2D2n5',
                        nature = 'external',
                        type = 'real',
                        value = 0,
                        texname = 'C^{\\text{W2$\\phi $2D2n5}}',
                        lhablock = 'FRBlock',
                        lhacode = [ 110 ])

CW2phi2D2n6 = Parameter(name = 'CW2phi2D2n6',
                        nature = 'external',
                        type = 'real',
                        value = 0,
                        texname = 'C^{\\text{W2$\\phi $2D2n6}}',
                        lhablock = 'FRBlock',
                        lhacode = [ 111 ])

CW2phi4n1 = Parameter(name = 'CW2phi4n1',
                      nature = 'external',
                      type = 'real',
                      value = 4.16813e-13,
                      texname = 'C^{\\text{W2$\\phi $4n1}}',
                      lhablock = 'FRBlock',
                      lhacode = [ 112 ])

CW2phi4n2 = Parameter(name = 'CW2phi4n2',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = 'C^{\\text{W2$\\phi $4n2}}',
                      lhablock = 'FRBlock',
                      lhacode = [ 113 ])

CW2phi4n3 = Parameter(name = 'CW2phi4n3',
                      nature = 'external',
                      type = 'real',
                      value = 6.40034e-13,
                      texname = 'C^{\\text{W2$\\phi $4n3}}',
                      lhablock = 'FRBlock',
                      lhacode = [ 114 ])

CW2phi4n4 = Parameter(name = 'CW2phi4n4',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = 'C^{\\text{W2$\\phi $4n4}}',
                      lhablock = 'FRBlock',
                      lhacode = [ 115 ])

CW3phi2n1 = Parameter(name = 'CW3phi2n1',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = 'C^{\\text{W3$\\phi $2n1}}',
                      lhablock = 'FRBlock',
                      lhacode = [ 116 ])

CW3phi2n2 = Parameter(name = 'CW3phi2n2',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = 'C^{\\text{W3$\\phi $2n2}}',
                      lhablock = 'FRBlock',
                      lhacode = [ 117 ])

CW4n1 = Parameter(name = 'CW4n1',
                  nature = 'external',
                  type = 'real',
                  value = 0,
                  texname = 'C^{\\text{W4n1}}',
                  lhablock = 'FRBlock',
                  lhacode = [ 118 ])

CW4n2 = Parameter(name = 'CW4n2',
                  nature = 'external',
                  type = 'real',
                  value = 0,
                  texname = 'C^{\\text{W4n2}}',
                  lhablock = 'FRBlock',
                  lhacode = [ 119 ])

CW4n3 = Parameter(name = 'CW4n3',
                  nature = 'external',
                  type = 'real',
                  value = 0,
                  texname = 'C^{\\text{W4n3}}',
                  lhablock = 'FRBlock',
                  lhacode = [ 120 ])

CW4n4 = Parameter(name = 'CW4n4',
                  nature = 'external',
                  type = 'real',
                  value = 0,
                  texname = 'C^{\\text{W4n4}}',
                  lhablock = 'FRBlock',
                  lhacode = [ 121 ])

CW4n5 = Parameter(name = 'CW4n5',
                  nature = 'external',
                  type = 'real',
                  value = 0,
                  texname = 'C^{\\text{W4n5}}',
                  lhablock = 'FRBlock',
                  lhacode = [ 122 ])

CW4n6 = Parameter(name = 'CW4n6',
                  nature = 'external',
                  type = 'real',
                  value = 0,
                  texname = 'C^{\\text{W4n6}}',
                  lhablock = 'FRBlock',
                  lhacode = [ 123 ])

CWBphi2D2n1 = Parameter(name = 'CWBphi2D2n1',
                        nature = 'external',
                        type = 'real',
                        value = 0,
                        texname = 'C^{\\text{WB$\\phi $2D2n1}}',
                        lhablock = 'FRBlock',
                        lhacode = [ 124 ])

CWBphi2D2n2 = Parameter(name = 'CWBphi2D2n2',
                        nature = 'external',
                        type = 'real',
                        value = 0,
                        texname = 'C^{\\text{WB$\\phi $2D2n2}}',
                        lhablock = 'FRBlock',
                        lhacode = [ 125 ])

CWBphi2D2n3 = Parameter(name = 'CWBphi2D2n3',
                        nature = 'external',
                        type = 'real',
                        value = 0,
                        texname = 'C^{\\text{WB$\\phi $2D2n3}}',
                        lhablock = 'FRBlock',
                        lhacode = [ 126 ])

CWBphi2D2n4 = Parameter(name = 'CWBphi2D2n4',
                        nature = 'external',
                        type = 'real',
                        value = 0,
                        texname = 'C^{\\text{WB$\\phi $2D2n4}}',
                        lhablock = 'FRBlock',
                        lhacode = [ 127 ])

CWBphi2D2n5 = Parameter(name = 'CWBphi2D2n5',
                        nature = 'external',
                        type = 'real',
                        value = 0,
                        texname = 'C^{\\text{WB$\\phi $2D2n5}}',
                        lhablock = 'FRBlock',
                        lhacode = [ 128 ])

CWBphi2D2n6 = Parameter(name = 'CWBphi2D2n6',
                        nature = 'external',
                        type = 'real',
                        value = 0,
                        texname = 'C^{\\text{WB$\\phi $2D2n6}}',
                        lhablock = 'FRBlock',
                        lhacode = [ 129 ])

CWBphi4n1 = Parameter(name = 'CWBphi4n1',
                      nature = 'external',
                      type = 'real',
                      value = 3.07843e-13,
                      texname = 'C^{\\text{WB$\\phi $4n1}}',
                      lhablock = 'FRBlock',
                      lhacode = [ 130 ])

CWBphi4n2 = Parameter(name = 'CWBphi4n2',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = 'C^{\\text{WB$\\phi $4n2}}',
                      lhablock = 'FRBlock',
                      lhacode = [ 131 ])

CWphi4D2n1 = Parameter(name = 'CWphi4D2n1',
                       nature = 'external',
                       type = 'real',
                       value = 0,
                       texname = 'C^{\\text{W$\\phi $4D2n1}}',
                       lhablock = 'FRBlock',
                       lhacode = [ 132 ])

CWphi4D2n2 = Parameter(name = 'CWphi4D2n2',
                       nature = 'external',
                       type = 'real',
                       value = 0,
                       texname = 'C^{\\text{W$\\phi $4D2n2}}',
                       lhablock = 'FRBlock',
                       lhacode = [ 133 ])

CWphi4D2n3 = Parameter(name = 'CWphi4D2n3',
                       nature = 'external',
                       type = 'real',
                       value = 0,
                       texname = 'C^{\\text{W$\\phi $4D2n3}}',
                       lhablock = 'FRBlock',
                       lhacode = [ 134 ])

CWphi4D2n4 = Parameter(name = 'CWphi4D2n4',
                       nature = 'external',
                       type = 'real',
                       value = 0,
                       texname = 'C^{\\text{W$\\phi $4D2n4}}',
                       lhablock = 'FRBlock',
                       lhacode = [ 135 ])

CWtilde = Parameter(name = 'CWtilde',
                    nature = 'external',
                    type = 'real',
                    value = 9.00584e-9,
                    texname = 'C^{\\text{Wtilde}}',
                    lhablock = 'FRBlock',
                    lhacode = [ 136 ])

Lam = Parameter(name = 'Lam',
                nature = 'external',
                type = 'real',
                value = 1,
                texname = '\\frac{1}{\\Lambda ^2}',
                lhablock = 'FRBlock',
                lhacode = [ 137 ])

fmv1x1 = Parameter(name = 'fmv1x1',
                   nature = 'external',
                   type = 'complex',
                   value = 0,
                   texname = '\\text{fmv1x1}',
                   lhablock = 'FRBlock2',
                   lhacode = [ 1, 1 ])

fmv1x2 = Parameter(name = 'fmv1x2',
                   nature = 'external',
                   type = 'complex',
                   value = 0,
                   texname = '\\text{fmv1x2}',
                   lhablock = 'FRBlock2',
                   lhacode = [ 1, 2 ])

fmv1x3 = Parameter(name = 'fmv1x3',
                   nature = 'external',
                   type = 'complex',
                   value = 0,
                   texname = '\\text{fmv1x3}',
                   lhablock = 'FRBlock2',
                   lhacode = [ 1, 3 ])

fmv2x1 = Parameter(name = 'fmv2x1',
                   nature = 'external',
                   type = 'complex',
                   value = 0,
                   texname = '\\text{fmv2x1}',
                   lhablock = 'FRBlock2',
                   lhacode = [ 2, 1 ])

fmv2x2 = Parameter(name = 'fmv2x2',
                   nature = 'external',
                   type = 'complex',
                   value = 0,
                   texname = '\\text{fmv2x2}',
                   lhablock = 'FRBlock2',
                   lhacode = [ 2, 2 ])

fmv2x3 = Parameter(name = 'fmv2x3',
                   nature = 'external',
                   type = 'complex',
                   value = 0,
                   texname = '\\text{fmv2x3}',
                   lhablock = 'FRBlock2',
                   lhacode = [ 2, 3 ])

fmv3x1 = Parameter(name = 'fmv3x1',
                   nature = 'external',
                   type = 'complex',
                   value = 0,
                   texname = '\\text{fmv3x1}',
                   lhablock = 'FRBlock2',
                   lhacode = [ 3, 1 ])

fmv3x2 = Parameter(name = 'fmv3x2',
                   nature = 'external',
                   type = 'complex',
                   value = 0,
                   texname = '\\text{fmv3x2}',
                   lhablock = 'FRBlock2',
                   lhacode = [ 3, 2 ])

fmv3x3 = Parameter(name = 'fmv3x3',
                   nature = 'external',
                   type = 'complex',
                   value = 0,
                   texname = '\\text{fmv3x3}',
                   lhablock = 'FRBlock2',
                   lhacode = [ 3, 3 ])

fml1x1 = Parameter(name = 'fml1x1',
                   nature = 'external',
                   type = 'complex',
                   value = 0.00051099895,
                   texname = '\\text{fml1x1}',
                   lhablock = 'FRBlock3',
                   lhacode = [ 1, 1 ])

fml1x2 = Parameter(name = 'fml1x2',
                   nature = 'external',
                   type = 'complex',
                   value = 0,
                   texname = '\\text{fml1x2}',
                   lhablock = 'FRBlock3',
                   lhacode = [ 1, 2 ])

fml1x3 = Parameter(name = 'fml1x3',
                   nature = 'external',
                   type = 'complex',
                   value = 0,
                   texname = '\\text{fml1x3}',
                   lhablock = 'FRBlock3',
                   lhacode = [ 1, 3 ])

fml2x1 = Parameter(name = 'fml2x1',
                   nature = 'external',
                   type = 'complex',
                   value = 0,
                   texname = '\\text{fml2x1}',
                   lhablock = 'FRBlock3',
                   lhacode = [ 2, 1 ])

fml2x2 = Parameter(name = 'fml2x2',
                   nature = 'external',
                   type = 'complex',
                   value = 0.1056583755,
                   texname = '\\text{fml2x2}',
                   lhablock = 'FRBlock3',
                   lhacode = [ 2, 2 ])

fml2x3 = Parameter(name = 'fml2x3',
                   nature = 'external',
                   type = 'complex',
                   value = 0,
                   texname = '\\text{fml2x3}',
                   lhablock = 'FRBlock3',
                   lhacode = [ 2, 3 ])

fml3x1 = Parameter(name = 'fml3x1',
                   nature = 'external',
                   type = 'complex',
                   value = 0,
                   texname = '\\text{fml3x1}',
                   lhablock = 'FRBlock3',
                   lhacode = [ 3, 1 ])

fml3x2 = Parameter(name = 'fml3x2',
                   nature = 'external',
                   type = 'complex',
                   value = 0,
                   texname = '\\text{fml3x2}',
                   lhablock = 'FRBlock3',
                   lhacode = [ 3, 2 ])

fml3x3 = Parameter(name = 'fml3x3',
                   nature = 'external',
                   type = 'complex',
                   value = 1.77686,
                   texname = '\\text{fml3x3}',
                   lhablock = 'FRBlock3',
                   lhacode = [ 3, 3 ])

fmd1x1 = Parameter(name = 'fmd1x1',
                   nature = 'external',
                   type = 'complex',
                   value = 0.00504,
                   texname = '\\text{fmd1x1}',
                   lhablock = 'FRBlock4',
                   lhacode = [ 1, 1 ])

fmd1x2 = Parameter(name = 'fmd1x2',
                   nature = 'external',
                   type = 'complex',
                   value = 0,
                   texname = '\\text{fmd1x2}',
                   lhablock = 'FRBlock4',
                   lhacode = [ 1, 2 ])

fmd1x3 = Parameter(name = 'fmd1x3',
                   nature = 'external',
                   type = 'complex',
                   value = 0,
                   texname = '\\text{fmd1x3}',
                   lhablock = 'FRBlock4',
                   lhacode = [ 1, 3 ])

fmd2x1 = Parameter(name = 'fmd2x1',
                   nature = 'external',
                   type = 'complex',
                   value = 0,
                   texname = '\\text{fmd2x1}',
                   lhablock = 'FRBlock4',
                   lhacode = [ 2, 1 ])

fmd2x2 = Parameter(name = 'fmd2x2',
                   nature = 'external',
                   type = 'complex',
                   value = 0.101,
                   texname = '\\text{fmd2x2}',
                   lhablock = 'FRBlock4',
                   lhacode = [ 2, 2 ])

fmd2x3 = Parameter(name = 'fmd2x3',
                   nature = 'external',
                   type = 'complex',
                   value = 0,
                   texname = '\\text{fmd2x3}',
                   lhablock = 'FRBlock4',
                   lhacode = [ 2, 3 ])

fmd3x1 = Parameter(name = 'fmd3x1',
                   nature = 'external',
                   type = 'complex',
                   value = 0,
                   texname = '\\text{fmd3x1}',
                   lhablock = 'FRBlock4',
                   lhacode = [ 3, 1 ])

fmd3x2 = Parameter(name = 'fmd3x2',
                   nature = 'external',
                   type = 'complex',
                   value = 0,
                   texname = '\\text{fmd3x2}',
                   lhablock = 'FRBlock4',
                   lhacode = [ 3, 2 ])

fmd3x3 = Parameter(name = 'fmd3x3',
                   nature = 'external',
                   type = 'complex',
                   value = 4.7,
                   texname = '\\text{fmd3x3}',
                   lhablock = 'FRBlock4',
                   lhacode = [ 3, 3 ])

fmu1x1 = Parameter(name = 'fmu1x1',
                   nature = 'external',
                   type = 'complex',
                   value = 0.0025499999999999997,
                   texname = '\\text{fmu1x1}',
                   lhablock = 'FRBlock5',
                   lhacode = [ 1, 1 ])

fmu1x2 = Parameter(name = 'fmu1x2',
                   nature = 'external',
                   type = 'complex',
                   value = 0,
                   texname = '\\text{fmu1x2}',
                   lhablock = 'FRBlock5',
                   lhacode = [ 1, 2 ])

fmu1x3 = Parameter(name = 'fmu1x3',
                   nature = 'external',
                   type = 'complex',
                   value = 0,
                   texname = '\\text{fmu1x3}',
                   lhablock = 'FRBlock5',
                   lhacode = [ 1, 3 ])

fmu2x1 = Parameter(name = 'fmu2x1',
                   nature = 'external',
                   type = 'complex',
                   value = 0,
                   texname = '\\text{fmu2x1}',
                   lhablock = 'FRBlock5',
                   lhacode = [ 2, 1 ])

fmu2x2 = Parameter(name = 'fmu2x2',
                   nature = 'external',
                   type = 'complex',
                   value = 1.27,
                   texname = '\\text{fmu2x2}',
                   lhablock = 'FRBlock5',
                   lhacode = [ 2, 2 ])

fmu2x3 = Parameter(name = 'fmu2x3',
                   nature = 'external',
                   type = 'complex',
                   value = 0,
                   texname = '\\text{fmu2x3}',
                   lhablock = 'FRBlock5',
                   lhacode = [ 2, 3 ])

fmu3x1 = Parameter(name = 'fmu3x1',
                   nature = 'external',
                   type = 'complex',
                   value = 0,
                   texname = '\\text{fmu3x1}',
                   lhablock = 'FRBlock5',
                   lhacode = [ 3, 1 ])

fmu3x2 = Parameter(name = 'fmu3x2',
                   nature = 'external',
                   type = 'complex',
                   value = 0,
                   texname = '\\text{fmu3x2}',
                   lhablock = 'FRBlock5',
                   lhacode = [ 3, 2 ])

fmu3x3 = Parameter(name = 'fmu3x3',
                   nature = 'external',
                   type = 'complex',
                   value = 172.76,
                   texname = '\\text{fmu3x3}',
                   lhablock = 'FRBlock5',
                   lhacode = [ 3, 3 ])

Kq1x1 = Parameter(name = 'Kq1x1',
                  nature = 'external',
                  type = 'complex',
                  value = 0.9742817077526272,
                  texname = '\\text{Kq1x1}',
                  lhablock = 'FRBlock6',
                  lhacode = [ 1, 1 ])

Kq1x2 = Parameter(name = 'Kq1x2',
                  nature = 'external',
                  type = 'complex',
                  value = 0.22537,
                  texname = '\\text{Kq1x2}',
                  lhablock = 'FRBlock6',
                  lhacode = [ 1, 2 ])

Kq1x3 = Parameter(name = 'Kq1x3',
                  nature = 'external',
                  type = 'complex',
                  value = 0.0018854365545299529,
                  texname = '\\text{Kq1x3}',
                  lhablock = 'FRBlock6',
                  lhacode = [ 1, 3 ])

Kq2x1 = Parameter(name = 'Kq2x1',
                  nature = 'external',
                  type = 'complex',
                  value = -0.22524802730392973,
                  texname = '\\text{Kq2x1}',
                  lhablock = 'FRBlock6',
                  lhacode = [ 2, 1 ])

Kq2x2 = Parameter(name = 'Kq2x2',
                  nature = 'external',
                  type = 'complex',
                  value = 0.9733973762490354,
                  texname = '\\text{Kq2x2}',
                  lhablock = 'FRBlock6',
                  lhacode = [ 2, 2 ])

Kq2x3 = Parameter(name = 'Kq2x3',
                  nature = 'external',
                  type = 'complex',
                  value = 0.04205547535319999,
                  texname = '\\text{Kq2x3}',
                  lhablock = 'FRBlock6',
                  lhacode = [ 2, 3 ])

Kq3x1 = Parameter(name = 'Kq3x1',
                  nature = 'external',
                  type = 'complex',
                  value = 0.00763930223916265,
                  texname = '\\text{Kq3x1}',
                  lhablock = 'FRBlock6',
                  lhacode = [ 3, 1 ])

Kq3x2 = Parameter(name = 'Kq3x2',
                  nature = 'external',
                  type = 'complex',
                  value = -0.04140183902445822,
                  texname = '\\text{Kq3x2}',
                  lhablock = 'FRBlock6',
                  lhacode = [ 3, 2 ])

Kq3x3 = Parameter(name = 'Kq3x3',
                  nature = 'external',
                  type = 'complex',
                  value = 0.9991156684964082,
                  texname = '\\text{Kq3x3}',
                  lhablock = 'FRBlock6',
                  lhacode = [ 3, 3 ])

Ul1x1 = Parameter(name = 'Ul1x1',
                  nature = 'external',
                  type = 'complex',
                  value = 0.8251461863096498,
                  texname = '\\text{Ul1x1}',
                  lhablock = 'FRBlock7',
                  lhacode = [ 1, 1 ])

Ul1x2 = Parameter(name = 'Ul1x2',
                  nature = 'external',
                  type = 'complex',
                  value = 0.544910563973106,
                  texname = '\\text{Ul1x2}',
                  lhablock = 'FRBlock7',
                  lhacode = [ 1, 2 ])

Ul1x3 = Parameter(name = 'Ul1x3',
                  nature = 'external',
                  type = 'complex',
                  value = -0.14459052219790333,
                  texname = '\\text{Ul1x3}',
                  lhablock = 'FRBlock7',
                  lhacode = [ 1, 3 ])

Ul2x1 = Parameter(name = 'Ul2x1',
                  nature = 'external',
                  type = 'complex',
                  value = -0.2687405948486291,
                  texname = '\\text{Ul2x1}',
                  lhablock = 'FRBlock7',
                  lhacode = [ 2, 1 ])

Ul2x2 = Parameter(name = 'Ul2x2',
                  nature = 'external',
                  type = 'complex',
                  value = 0.6055718161076215,
                  texname = '\\text{Ul2x2}',
                  lhablock = 'FRBlock7',
                  lhacode = [ 2, 2 ])

Ul2x3 = Parameter(name = 'Ul2x3',
                  nature = 'external',
                  type = 'complex',
                  value = 0.7485428591740604,
                  texname = '\\text{Ul2x3}',
                  lhablock = 'FRBlock7',
                  lhacode = [ 2, 3 ])

Ul3x1 = Parameter(name = 'Ul3x1',
                  nature = 'external',
                  type = 'complex',
                  value = 0.4959910834841702,
                  texname = '\\text{Ul3x1}',
                  lhablock = 'FRBlock7',
                  lhacode = [ 3, 1 ])

Ul3x2 = Parameter(name = 'Ul3x2',
                  nature = 'external',
                  type = 'complex',
                  value = -0.5796210248344889,
                  texname = '\\text{Ul3x2}',
                  lhablock = 'FRBlock7',
                  lhacode = [ 3, 2 ])

Ul3x3 = Parameter(name = 'Ul3x3',
                  nature = 'external',
                  type = 'complex',
                  value = 0.6461248636992469,
                  texname = '\\text{Ul3x3}',
                  lhablock = 'FRBlock7',
                  lhacode = [ 3, 3 ])

AZnorm1x1 = Parameter(name = 'AZnorm1x1',
                      nature = 'external',
                      type = 'real',
                      value = 0.8851237575350185,
                      texname = '\\text{AZnorm1x1}',
                      lhablock = 'FRBlock8',
                      lhacode = [ 1, 1 ])

MZ = Parameter(name = 'MZ',
               nature = 'external',
               type = 'real',
               value = 91.1876,
               texname = '\\text{MZ}',
               lhablock = 'MASS',
               lhacode = [ 23 ])

MW = Parameter(name = 'MW',
               nature = 'external',
               type = 'real',
               value = 80.379,
               texname = '\\text{MW}',
               lhablock = 'MASS',
               lhacode = [ 24 ])

MLE = Parameter(name = 'MLE',
                nature = 'external',
                type = 'real',
                value = 0.00051099895,
                texname = '\\text{MLE}',
                lhablock = 'MASS',
                lhacode = [ 11 ])

MLM = Parameter(name = 'MLM',
                nature = 'external',
                type = 'real',
                value = 0.1056583755,
                texname = '\\text{MLM}',
                lhablock = 'MASS',
                lhacode = [ 13 ])

MLT = Parameter(name = 'MLT',
                nature = 'external',
                type = 'real',
                value = 1.77686,
                texname = '\\text{MLT}',
                lhablock = 'MASS',
                lhacode = [ 15 ])

MQU = Parameter(name = 'MQU',
                nature = 'external',
                type = 'real',
                value = 0.0025499999999999997,
                texname = '\\text{MQU}',
                lhablock = 'MASS',
                lhacode = [ 2 ])

MQC = Parameter(name = 'MQC',
                nature = 'external',
                type = 'real',
                value = 1.27,
                texname = '\\text{MQC}',
                lhablock = 'MASS',
                lhacode = [ 4 ])

MQT = Parameter(name = 'MQT',
                nature = 'external',
                type = 'real',
                value = 172.76,
                texname = '\\text{MQT}',
                lhablock = 'MASS',
                lhacode = [ 6 ])

MQD = Parameter(name = 'MQD',
                nature = 'external',
                type = 'real',
                value = 0.00504,
                texname = '\\text{MQD}',
                lhablock = 'MASS',
                lhacode = [ 1 ])

MQS = Parameter(name = 'MQS',
                nature = 'external',
                type = 'real',
                value = 0.101,
                texname = '\\text{MQS}',
                lhablock = 'MASS',
                lhacode = [ 3 ])

MQB = Parameter(name = 'MQB',
                nature = 'external',
                type = 'real',
                value = 4.7,
                texname = '\\text{MQB}',
                lhablock = 'MASS',
                lhacode = [ 5 ])

MH = Parameter(name = 'MH',
               nature = 'external',
               type = 'real',
               value = 125.35,
               texname = '\\text{MH}',
               lhablock = 'MASS',
               lhacode = [ 25 ])

GAMZ = Parameter(name = 'GAMZ',
                 nature = 'external',
                 type = 'real',
                 value = 2.4952,
                 texname = '\\text{GAMZ}',
                 lhablock = 'DECAY',
                 lhacode = [ 23 ])

GAMW = Parameter(name = 'GAMW',
                 nature = 'external',
                 type = 'real',
                 value = 2.085,
                 texname = '\\text{GAMW}',
                 lhablock = 'DECAY',
                 lhacode = [ 24 ])

WLT = Parameter(name = 'WLT',
                nature = 'external',
                type = 'real',
                value = 2.25e-12,
                texname = '\\text{WLT}',
                lhablock = 'DECAY',
                lhacode = [ 15 ])

WQT = Parameter(name = 'WQT',
                nature = 'external',
                type = 'real',
                value = 1.35,
                texname = '\\text{WQT}',
                lhablock = 'DECAY',
                lhacode = [ 6 ])

GAMH = Parameter(name = 'GAMH',
                 nature = 'external',
                 type = 'real',
                 value = 0.00575,
                 texname = '\\text{GAMH}',
                 lhablock = 'DECAY',
                 lhacode = [ 25 ])

ee = Parameter(name = 'ee',
               nature = 'internal',
               type = 'real',
               value = '2*cmath.sqrt(aEWM1)*cmath.sqrt(cmath.pi)',
               texname = 'q_e')

GS = Parameter(name = 'GS',
               nature = 'internal',
               type = 'real',
               value = '2*cmath.sqrt(aS)*cmath.sqrt(cmath.pi)',
               texname = 'G_s')

I1a11 = Parameter(name = 'I1a11',
                  nature = 'internal',
                  type = 'complex',
                  value = 'fmd1x1*complexconjugate(Kq1x1) + fmd1x2*complexconjugate(Kq1x2) + fmd1x3*complexconjugate(Kq1x3)',
                  texname = '\\text{I1a11}')

I1a12 = Parameter(name = 'I1a12',
                  nature = 'internal',
                  type = 'complex',
                  value = 'fmd1x1*complexconjugate(Kq2x1) + fmd1x2*complexconjugate(Kq2x2) + fmd1x3*complexconjugate(Kq2x3)',
                  texname = '\\text{I1a12}')

I1a13 = Parameter(name = 'I1a13',
                  nature = 'internal',
                  type = 'complex',
                  value = 'fmd1x1*complexconjugate(Kq3x1) + fmd1x2*complexconjugate(Kq3x2) + fmd1x3*complexconjugate(Kq3x3)',
                  texname = '\\text{I1a13}')

I1a21 = Parameter(name = 'I1a21',
                  nature = 'internal',
                  type = 'complex',
                  value = 'fmd2x1*complexconjugate(Kq1x1) + fmd2x2*complexconjugate(Kq1x2) + fmd2x3*complexconjugate(Kq1x3)',
                  texname = '\\text{I1a21}')

I1a22 = Parameter(name = 'I1a22',
                  nature = 'internal',
                  type = 'complex',
                  value = 'fmd2x1*complexconjugate(Kq2x1) + fmd2x2*complexconjugate(Kq2x2) + fmd2x3*complexconjugate(Kq2x3)',
                  texname = '\\text{I1a22}')

I1a23 = Parameter(name = 'I1a23',
                  nature = 'internal',
                  type = 'complex',
                  value = 'fmd2x1*complexconjugate(Kq3x1) + fmd2x2*complexconjugate(Kq3x2) + fmd2x3*complexconjugate(Kq3x3)',
                  texname = '\\text{I1a23}')

I1a31 = Parameter(name = 'I1a31',
                  nature = 'internal',
                  type = 'complex',
                  value = 'fmd3x1*complexconjugate(Kq1x1) + fmd3x2*complexconjugate(Kq1x2) + fmd3x3*complexconjugate(Kq1x3)',
                  texname = '\\text{I1a31}')

I1a32 = Parameter(name = 'I1a32',
                  nature = 'internal',
                  type = 'complex',
                  value = 'fmd3x1*complexconjugate(Kq2x1) + fmd3x2*complexconjugate(Kq2x2) + fmd3x3*complexconjugate(Kq2x3)',
                  texname = '\\text{I1a32}')

I1a33 = Parameter(name = 'I1a33',
                  nature = 'internal',
                  type = 'complex',
                  value = 'fmd3x1*complexconjugate(Kq3x1) + fmd3x2*complexconjugate(Kq3x2) + fmd3x3*complexconjugate(Kq3x3)',
                  texname = '\\text{I1a33}')

I2a11 = Parameter(name = 'I2a11',
                  nature = 'internal',
                  type = 'complex',
                  value = 'fmu1x1*complexconjugate(Kq1x1) + fmu2x1*complexconjugate(Kq2x1) + fmu3x1*complexconjugate(Kq3x1)',
                  texname = '\\text{I2a11}')

I2a12 = Parameter(name = 'I2a12',
                  nature = 'internal',
                  type = 'complex',
                  value = 'fmu1x2*complexconjugate(Kq1x1) + fmu2x2*complexconjugate(Kq2x1) + fmu3x2*complexconjugate(Kq3x1)',
                  texname = '\\text{I2a12}')

I2a13 = Parameter(name = 'I2a13',
                  nature = 'internal',
                  type = 'complex',
                  value = 'fmu1x3*complexconjugate(Kq1x1) + fmu2x3*complexconjugate(Kq2x1) + fmu3x3*complexconjugate(Kq3x1)',
                  texname = '\\text{I2a13}')

I2a21 = Parameter(name = 'I2a21',
                  nature = 'internal',
                  type = 'complex',
                  value = 'fmu1x1*complexconjugate(Kq1x2) + fmu2x1*complexconjugate(Kq2x2) + fmu3x1*complexconjugate(Kq3x2)',
                  texname = '\\text{I2a21}')

I2a22 = Parameter(name = 'I2a22',
                  nature = 'internal',
                  type = 'complex',
                  value = 'fmu1x2*complexconjugate(Kq1x2) + fmu2x2*complexconjugate(Kq2x2) + fmu3x2*complexconjugate(Kq3x2)',
                  texname = '\\text{I2a22}')

I2a23 = Parameter(name = 'I2a23',
                  nature = 'internal',
                  type = 'complex',
                  value = 'fmu1x3*complexconjugate(Kq1x2) + fmu2x3*complexconjugate(Kq2x2) + fmu3x3*complexconjugate(Kq3x2)',
                  texname = '\\text{I2a23}')

I2a31 = Parameter(name = 'I2a31',
                  nature = 'internal',
                  type = 'complex',
                  value = 'fmu1x1*complexconjugate(Kq1x3) + fmu2x1*complexconjugate(Kq2x3) + fmu3x1*complexconjugate(Kq3x3)',
                  texname = '\\text{I2a31}')

I2a32 = Parameter(name = 'I2a32',
                  nature = 'internal',
                  type = 'complex',
                  value = 'fmu1x2*complexconjugate(Kq1x3) + fmu2x2*complexconjugate(Kq2x3) + fmu3x2*complexconjugate(Kq3x3)',
                  texname = '\\text{I2a32}')

I2a33 = Parameter(name = 'I2a33',
                  nature = 'internal',
                  type = 'complex',
                  value = 'fmu1x3*complexconjugate(Kq1x3) + fmu2x3*complexconjugate(Kq2x3) + fmu3x3*complexconjugate(Kq3x3)',
                  texname = '\\text{I2a33}')

I3a11 = Parameter(name = 'I3a11',
                  nature = 'internal',
                  type = 'complex',
                  value = 'fmu1x1*Kq1x1 + fmu1x2*Kq2x1 + fmu1x3*Kq3x1',
                  texname = '\\text{I3a11}')

I3a12 = Parameter(name = 'I3a12',
                  nature = 'internal',
                  type = 'complex',
                  value = 'fmu1x1*Kq1x2 + fmu1x2*Kq2x2 + fmu1x3*Kq3x2',
                  texname = '\\text{I3a12}')

I3a13 = Parameter(name = 'I3a13',
                  nature = 'internal',
                  type = 'complex',
                  value = 'fmu1x1*Kq1x3 + fmu1x2*Kq2x3 + fmu1x3*Kq3x3',
                  texname = '\\text{I3a13}')

I3a21 = Parameter(name = 'I3a21',
                  nature = 'internal',
                  type = 'complex',
                  value = 'fmu2x1*Kq1x1 + fmu2x2*Kq2x1 + fmu2x3*Kq3x1',
                  texname = '\\text{I3a21}')

I3a22 = Parameter(name = 'I3a22',
                  nature = 'internal',
                  type = 'complex',
                  value = 'fmu2x1*Kq1x2 + fmu2x2*Kq2x2 + fmu2x3*Kq3x2',
                  texname = '\\text{I3a22}')

I3a23 = Parameter(name = 'I3a23',
                  nature = 'internal',
                  type = 'complex',
                  value = 'fmu2x1*Kq1x3 + fmu2x2*Kq2x3 + fmu2x3*Kq3x3',
                  texname = '\\text{I3a23}')

I3a31 = Parameter(name = 'I3a31',
                  nature = 'internal',
                  type = 'complex',
                  value = 'fmu3x1*Kq1x1 + fmu3x2*Kq2x1 + fmu3x3*Kq3x1',
                  texname = '\\text{I3a31}')

I3a32 = Parameter(name = 'I3a32',
                  nature = 'internal',
                  type = 'complex',
                  value = 'fmu3x1*Kq1x2 + fmu3x2*Kq2x2 + fmu3x3*Kq3x2',
                  texname = '\\text{I3a32}')

I3a33 = Parameter(name = 'I3a33',
                  nature = 'internal',
                  type = 'complex',
                  value = 'fmu3x1*Kq1x3 + fmu3x2*Kq2x3 + fmu3x3*Kq3x3',
                  texname = '\\text{I3a33}')

I4a11 = Parameter(name = 'I4a11',
                  nature = 'internal',
                  type = 'complex',
                  value = 'fmd1x1*Kq1x1 + fmd2x1*Kq1x2 + fmd3x1*Kq1x3',
                  texname = '\\text{I4a11}')

I4a12 = Parameter(name = 'I4a12',
                  nature = 'internal',
                  type = 'complex',
                  value = 'fmd1x2*Kq1x1 + fmd2x2*Kq1x2 + fmd3x2*Kq1x3',
                  texname = '\\text{I4a12}')

I4a13 = Parameter(name = 'I4a13',
                  nature = 'internal',
                  type = 'complex',
                  value = 'fmd1x3*Kq1x1 + fmd2x3*Kq1x2 + fmd3x3*Kq1x3',
                  texname = '\\text{I4a13}')

I4a21 = Parameter(name = 'I4a21',
                  nature = 'internal',
                  type = 'complex',
                  value = 'fmd1x1*Kq2x1 + fmd2x1*Kq2x2 + fmd3x1*Kq2x3',
                  texname = '\\text{I4a21}')

I4a22 = Parameter(name = 'I4a22',
                  nature = 'internal',
                  type = 'complex',
                  value = 'fmd1x2*Kq2x1 + fmd2x2*Kq2x2 + fmd3x2*Kq2x3',
                  texname = '\\text{I4a22}')

I4a23 = Parameter(name = 'I4a23',
                  nature = 'internal',
                  type = 'complex',
                  value = 'fmd1x3*Kq2x1 + fmd2x3*Kq2x2 + fmd3x3*Kq2x3',
                  texname = '\\text{I4a23}')

I4a31 = Parameter(name = 'I4a31',
                  nature = 'internal',
                  type = 'complex',
                  value = 'fmd1x1*Kq3x1 + fmd2x1*Kq3x2 + fmd3x1*Kq3x3',
                  texname = '\\text{I4a31}')

I4a32 = Parameter(name = 'I4a32',
                  nature = 'internal',
                  type = 'complex',
                  value = 'fmd1x2*Kq3x1 + fmd2x2*Kq3x2 + fmd3x2*Kq3x3',
                  texname = '\\text{I4a32}')

I4a33 = Parameter(name = 'I4a33',
                  nature = 'internal',
                  type = 'complex',
                  value = 'fmd1x3*Kq3x1 + fmd2x3*Kq3x2 + fmd3x3*Kq3x3',
                  texname = '\\text{I4a33}')

I5a11 = Parameter(name = 'I5a11',
                  nature = 'internal',
                  type = 'complex',
                  value = 'fml1x1*complexconjugate(Ul1x1) + fml2x1*complexconjugate(Ul2x1) + fml3x1*complexconjugate(Ul3x1)',
                  texname = '\\text{I5a11}')

I5a12 = Parameter(name = 'I5a12',
                  nature = 'internal',
                  type = 'complex',
                  value = 'fml1x2*complexconjugate(Ul1x1) + fml2x2*complexconjugate(Ul2x1) + fml3x2*complexconjugate(Ul3x1)',
                  texname = '\\text{I5a12}')

I5a13 = Parameter(name = 'I5a13',
                  nature = 'internal',
                  type = 'complex',
                  value = 'fml1x3*complexconjugate(Ul1x1) + fml2x3*complexconjugate(Ul2x1) + fml3x3*complexconjugate(Ul3x1)',
                  texname = '\\text{I5a13}')

I5a21 = Parameter(name = 'I5a21',
                  nature = 'internal',
                  type = 'complex',
                  value = 'fml1x1*complexconjugate(Ul1x2) + fml2x1*complexconjugate(Ul2x2) + fml3x1*complexconjugate(Ul3x2)',
                  texname = '\\text{I5a21}')

I5a22 = Parameter(name = 'I5a22',
                  nature = 'internal',
                  type = 'complex',
                  value = 'fml1x2*complexconjugate(Ul1x2) + fml2x2*complexconjugate(Ul2x2) + fml3x2*complexconjugate(Ul3x2)',
                  texname = '\\text{I5a22}')

I5a23 = Parameter(name = 'I5a23',
                  nature = 'internal',
                  type = 'complex',
                  value = 'fml1x3*complexconjugate(Ul1x2) + fml2x3*complexconjugate(Ul2x2) + fml3x3*complexconjugate(Ul3x2)',
                  texname = '\\text{I5a23}')

I5a31 = Parameter(name = 'I5a31',
                  nature = 'internal',
                  type = 'complex',
                  value = 'fml1x1*complexconjugate(Ul1x3) + fml2x1*complexconjugate(Ul2x3) + fml3x1*complexconjugate(Ul3x3)',
                  texname = '\\text{I5a31}')

I5a32 = Parameter(name = 'I5a32',
                  nature = 'internal',
                  type = 'complex',
                  value = 'fml1x2*complexconjugate(Ul1x3) + fml2x2*complexconjugate(Ul2x3) + fml3x2*complexconjugate(Ul3x3)',
                  texname = '\\text{I5a32}')

I5a33 = Parameter(name = 'I5a33',
                  nature = 'internal',
                  type = 'complex',
                  value = 'fml1x3*complexconjugate(Ul1x3) + fml2x3*complexconjugate(Ul2x3) + fml3x3*complexconjugate(Ul3x3)',
                  texname = '\\text{I5a33}')

I6a11 = Parameter(name = 'I6a11',
                  nature = 'internal',
                  type = 'complex',
                  value = 'fml1x1*Ul1x1 + fml1x2*Ul2x1 + fml1x3*Ul3x1',
                  texname = '\\text{I6a11}')

I6a12 = Parameter(name = 'I6a12',
                  nature = 'internal',
                  type = 'complex',
                  value = 'fml1x1*Ul1x2 + fml1x2*Ul2x2 + fml1x3*Ul3x2',
                  texname = '\\text{I6a12}')

I6a13 = Parameter(name = 'I6a13',
                  nature = 'internal',
                  type = 'complex',
                  value = 'fml1x1*Ul1x3 + fml1x2*Ul2x3 + fml1x3*Ul3x3',
                  texname = '\\text{I6a13}')

I6a21 = Parameter(name = 'I6a21',
                  nature = 'internal',
                  type = 'complex',
                  value = 'fml2x1*Ul1x1 + fml2x2*Ul2x1 + fml2x3*Ul3x1',
                  texname = '\\text{I6a21}')

I6a22 = Parameter(name = 'I6a22',
                  nature = 'internal',
                  type = 'complex',
                  value = 'fml2x1*Ul1x2 + fml2x2*Ul2x2 + fml2x3*Ul3x2',
                  texname = '\\text{I6a22}')

I6a23 = Parameter(name = 'I6a23',
                  nature = 'internal',
                  type = 'complex',
                  value = 'fml2x1*Ul1x3 + fml2x2*Ul2x3 + fml2x3*Ul3x3',
                  texname = '\\text{I6a23}')

I6a31 = Parameter(name = 'I6a31',
                  nature = 'internal',
                  type = 'complex',
                  value = 'fml3x1*Ul1x1 + fml3x2*Ul2x1 + fml3x3*Ul3x1',
                  texname = '\\text{I6a31}')

I6a32 = Parameter(name = 'I6a32',
                  nature = 'internal',
                  type = 'complex',
                  value = 'fml3x1*Ul1x2 + fml3x2*Ul2x2 + fml3x3*Ul3x2',
                  texname = '\\text{I6a32}')

I6a33 = Parameter(name = 'I6a33',
                  nature = 'internal',
                  type = 'complex',
                  value = 'fml3x1*Ul1x3 + fml3x2*Ul2x3 + fml3x3*Ul3x3',
                  texname = '\\text{I6a33}')

