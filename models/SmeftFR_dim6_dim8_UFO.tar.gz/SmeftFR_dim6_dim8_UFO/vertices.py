# This file was automatically created by FeynRules 2.3.49
# Mathematica version: 13.1.0 for Mac OS X ARM (64-bit) (June 16, 2022)
# Date: Tue 7 Nov 2023 22:05:13


from object_library import all_vertices, Vertex
import particles as P
import couplings as C
import lorentz as L


V_1 = Vertex(name = 'V_1',
             particles = [ P.G0, P.G0, P.G0, P.G0 ],
             color = [ '1' ],
             lorentz = [ L.SSSS1, L.SSSS10, L.SSSS12, L.SSSS19, L.SSSS9 ],
             couplings = {(0,0):C.GC_59,(0,2):C.GC_121,(0,4):C.GC_124,(0,3):C.GC_358,(0,1):C.GC_470})

V_2 = Vertex(name = 'V_2',
             particles = [ P.G0, P.G0, P.G0, P.G0 ],
             color = [ '1' ],
             lorentz = [ L.SSSS1, L.SSSS9 ],
             couplings = {(0,0):C.GC_351,(0,1):C.GC_473})

V_3 = Vertex(name = 'V_3',
             particles = [ P.G0, P.G0, P.G0, P.G0 ],
             color = [ '1' ],
             lorentz = [ L.SSSS1 ],
             couplings = {(0,0):C.GC_510})

V_4 = Vertex(name = 'V_4',
             particles = [ P.G0, P.G0, P.G__minus__, P.G__plus__ ],
             color = [ '1' ],
             lorentz = [ L.SSSS1, L.SSSS10, L.SSSS13, L.SSSS15, L.SSSS16, L.SSSS2, L.SSSS3, L.SSSS7 ],
             couplings = {(0,0):C.GC_57,(0,2):C.GC_119,(0,6):C.GC_123,(0,4):C.GC_355,(0,3):C.GC_174,(0,1):C.GC_256,(0,5):C.GC_261,(0,7):C.GC_258})

V_5 = Vertex(name = 'V_5',
             particles = [ P.G0, P.G0, P.G__minus__, P.G__plus__ ],
             color = [ '1' ],
             lorentz = [ L.SSSS1, L.SSSS13, L.SSSS3 ],
             couplings = {(0,0):C.GC_170,(0,1):C.GC_266,(0,2):C.GC_267})

V_6 = Vertex(name = 'V_6',
             particles = [ P.G0, P.G0, P.G__minus__, P.G__plus__ ],
             color = [ '1' ],
             lorentz = [ L.SSSS1 ],
             couplings = {(0,0):C.GC_508})

V_7 = Vertex(name = 'V_7',
             particles = [ P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__ ],
             color = [ '1' ],
             lorentz = [ L.SSSS1, L.SSSS11, L.SSSS15, L.SSSS16, L.SSSS3 ],
             couplings = {(0,0):C.GC_58,(0,1):C.GC_120,(0,4):C.GC_124,(0,3):C.GC_357,(0,2):C.GC_173})

V_8 = Vertex(name = 'V_8',
             particles = [ P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__ ],
             color = [ '1' ],
             lorentz = [ L.SSSS1, L.SSSS11, L.SSSS3 ],
             couplings = {(0,0):C.GC_349,(0,1):C.GC_258,(0,2):C.GC_261})

V_9 = Vertex(name = 'V_9',
             particles = [ P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__ ],
             color = [ '1' ],
             lorentz = [ L.SSSS1 ],
             couplings = {(0,0):C.GC_507})

V_10 = Vertex(name = 'V_10',
              particles = [ P.G0, P.G0, P.H ],
              color = [ '1' ],
              lorentz = [ L.SSS1, L.SSS2, L.SSS6, L.SSS7 ],
              couplings = {(0,0):C.GC_55,(0,2):C.GC_135,(0,3):C.GC_254,(0,1):C.GC_321})

V_11 = Vertex(name = 'V_11',
              particles = [ P.G0, P.G0, P.H ],
              color = [ '1' ],
              lorentz = [ L.SSS1, L.SSS2, L.SSS6 ],
              couplings = {(0,0):C.GC_353,(0,2):C.GC_389,(0,1):C.GC_399})

V_12 = Vertex(name = 'V_12',
              particles = [ P.G0, P.G0, P.H ],
              color = [ '1' ],
              lorentz = [ L.SSS1 ],
              couplings = {(0,0):C.GC_505})

V_13 = Vertex(name = 'V_13',
              particles = [ P.G__minus__, P.G__plus__, P.H ],
              color = [ '1' ],
              lorentz = [ L.SSS1, L.SSS2, L.SSS4, L.SSS6, L.SSS8 ],
              couplings = {(0,0):C.GC_55,(0,3):C.GC_135,(0,4):C.GC_253,(0,2):C.GC_139,(0,1):C.GC_137})

V_14 = Vertex(name = 'V_14',
              particles = [ P.G__minus__, P.G__plus__, P.H ],
              color = [ '1' ],
              lorentz = [ L.SSS1, L.SSS2, L.SSS4, L.SSS6 ],
              couplings = {(0,0):C.GC_352,(0,3):C.GC_389,(0,2):C.GC_398,(0,1):C.GC_391})

V_15 = Vertex(name = 'V_15',
              particles = [ P.G__minus__, P.G__plus__, P.H ],
              color = [ '1' ],
              lorentz = [ L.SSS1 ],
              couplings = {(0,0):C.GC_504})

V_16 = Vertex(name = 'V_16',
              particles = [ P.G0, P.G0, P.H, P.H ],
              color = [ '1' ],
              lorentz = [ L.SSSS1, L.SSSS10, L.SSSS13, L.SSSS15, L.SSSS18, L.SSSS4, L.SSSS7 ],
              couplings = {(0,0):C.GC_57,(0,2):C.GC_119,(0,6):C.GC_124,(0,4):C.GC_172,(0,3):C.GC_357,(0,1):C.GC_469,(0,5):C.GC_459})

V_17 = Vertex(name = 'V_17',
              particles = [ P.G0, P.G0, P.H, P.H ],
              color = [ '1' ],
              lorentz = [ L.SSSS1, L.SSSS13, L.SSSS7 ],
              couplings = {(0,0):C.GC_129,(0,1):C.GC_264,(0,2):C.GC_268})

V_18 = Vertex(name = 'V_18',
              particles = [ P.G0, P.G0, P.H, P.H ],
              color = [ '1' ],
              lorentz = [ L.SSSS1 ],
              couplings = {(0,0):C.GC_171})

V_19 = Vertex(name = 'V_19',
              particles = [ P.G0, P.G0, P.H, P.H ],
              color = [ '1' ],
              lorentz = [ L.SSSS1 ],
              couplings = {(0,0):C.GC_387})

V_20 = Vertex(name = 'V_20',
              particles = [ P.G0, P.G0, P.H, P.H ],
              color = [ '1' ],
              lorentz = [ L.SSSS1 ],
              couplings = {(0,0):C.GC_509})

V_21 = Vertex(name = 'V_21',
              particles = [ P.G__minus__, P.G__plus__, P.H, P.H ],
              color = [ '1' ],
              lorentz = [ L.SSSS1, L.SSSS10, L.SSSS13, L.SSSS14, L.SSSS15, L.SSSS16, L.SSSS3, L.SSSS4, L.SSSS6 ],
              couplings = {(0,0):C.GC_57,(0,2):C.GC_119,(0,6):C.GC_123,(0,5):C.GC_355,(0,4):C.GC_174,(0,1):C.GC_257,(0,3):C.GC_266,(0,8):C.GC_262,(0,7):C.GC_259})

V_22 = Vertex(name = 'V_22',
              particles = [ P.G__minus__, P.G__plus__, P.H, P.H ],
              color = [ '1' ],
              lorentz = [ L.SSSS1, L.SSSS13, L.SSSS3 ],
              couplings = {(0,0):C.GC_129,(0,1):C.GC_264,(0,2):C.GC_267})

V_23 = Vertex(name = 'V_23',
              particles = [ P.G__minus__, P.G__plus__, P.H, P.H ],
              color = [ '1' ],
              lorentz = [ L.SSSS1 ],
              couplings = {(0,0):C.GC_386})

V_24 = Vertex(name = 'V_24',
              particles = [ P.G__minus__, P.G__plus__, P.H, P.H ],
              color = [ '1' ],
              lorentz = [ L.SSSS1 ],
              couplings = {(0,0):C.GC_320})

V_25 = Vertex(name = 'V_25',
              particles = [ P.H, P.H, P.H ],
              color = [ '1' ],
              lorentz = [ L.SSS1, L.SSS5, L.SSS6, L.SSS9 ],
              couplings = {(0,0):C.GC_56,(0,2):C.GC_136,(0,3):C.GC_255,(0,1):C.GC_321})

V_26 = Vertex(name = 'V_26',
              particles = [ P.H, P.H, P.H ],
              color = [ '1' ],
              lorentz = [ L.SSS1, L.SSS5, L.SSS6 ],
              couplings = {(0,0):C.GC_128,(0,2):C.GC_390,(0,1):C.GC_400})

V_27 = Vertex(name = 'V_27',
              particles = [ P.H, P.H, P.H ],
              color = [ '1' ],
              lorentz = [ L.SSS1 ],
              couplings = {(0,0):C.GC_354})

V_28 = Vertex(name = 'V_28',
              particles = [ P.H, P.H, P.H ],
              color = [ '1' ],
              lorentz = [ L.SSS1 ],
              couplings = {(0,0):C.GC_385})

V_29 = Vertex(name = 'V_29',
              particles = [ P.H, P.H, P.H ],
              color = [ '1' ],
              lorentz = [ L.SSS1 ],
              couplings = {(0,0):C.GC_506})

V_30 = Vertex(name = 'V_30',
              particles = [ P.H, P.H, P.H, P.H ],
              color = [ '1' ],
              lorentz = [ L.SSSS1, L.SSSS10, L.SSSS12, L.SSSS19, L.SSSS9 ],
              couplings = {(0,0):C.GC_59,(0,2):C.GC_121,(0,4):C.GC_124,(0,3):C.GC_358,(0,1):C.GC_471})

V_31 = Vertex(name = 'V_31',
              particles = [ P.H, P.H, P.H, P.H ],
              color = [ '1' ],
              lorentz = [ L.SSSS1, L.SSSS12, L.SSSS9 ],
              couplings = {(0,0):C.GC_130,(0,1):C.GC_265,(0,2):C.GC_472})

V_32 = Vertex(name = 'V_32',
              particles = [ P.H, P.H, P.H, P.H ],
              color = [ '1' ],
              lorentz = [ L.SSSS1 ],
              couplings = {(0,0):C.GC_350})

V_33 = Vertex(name = 'V_33',
              particles = [ P.H, P.H, P.H, P.H ],
              color = [ '1' ],
              lorentz = [ L.SSSS1 ],
              couplings = {(0,0):C.GC_388})

V_34 = Vertex(name = 'V_34',
              particles = [ P.H, P.H, P.H, P.H ],
              color = [ '1' ],
              lorentz = [ L.SSSS1 ],
              couplings = {(0,0):C.GC_511})

V_35 = Vertex(name = 'V_35',
              particles = [ P.G0, P.G0, P.G0, P.G0, P.G0, P.G0 ],
              color = [ '1' ],
              lorentz = [ L.SSSSSS1, L.SSSSSS10, L.SSSSSS15 ],
              couplings = {(0,0):C.GC_118,(0,2):C.GC_179,(0,1):C.GC_187})

V_36 = Vertex(name = 'V_36',
              particles = [ P.G0, P.G0, P.G0, P.G0, P.G0, P.G0 ],
              color = [ '1' ],
              lorentz = [ L.SSSSSS1 ],
              couplings = {(0,0):C.GC_462})

V_37 = Vertex(name = 'V_37',
              particles = [ P.G0, P.G0, P.G0, P.G0, P.G__minus__, P.G__plus__ ],
              color = [ '1' ],
              lorentz = [ L.SSSSSS1, L.SSSSSS18, L.SSSSSS5 ],
              couplings = {(0,0):C.GC_116,(0,1):C.GC_177,(0,2):C.GC_183})

V_38 = Vertex(name = 'V_38',
              particles = [ P.G0, P.G0, P.G0, P.G0, P.G__minus__, P.G__plus__ ],
              color = [ '1' ],
              lorentz = [ L.SSSSSS1 ],
              couplings = {(0,0):C.GC_467})

V_39 = Vertex(name = 'V_39',
              particles = [ P.G0, P.G0, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__ ],
              color = [ '1' ],
              lorentz = [ L.SSSSSS1, L.SSSSSS14, L.SSSSSS4 ],
              couplings = {(0,0):C.GC_115,(0,1):C.GC_176,(0,2):C.GC_183})

V_40 = Vertex(name = 'V_40',
              particles = [ P.G0, P.G0, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__ ],
              color = [ '1' ],
              lorentz = [ L.SSSSSS1 ],
              couplings = {(0,0):C.GC_464})

V_41 = Vertex(name = 'V_41',
              particles = [ P.G__minus__, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__, P.G__plus__ ],
              color = [ '1' ],
              lorentz = [ L.SSSSSS1, L.SSSSSS13, L.SSSSSS3 ],
              couplings = {(0,0):C.GC_117,(0,1):C.GC_178,(0,2):C.GC_186})

V_42 = Vertex(name = 'V_42',
              particles = [ P.G__minus__, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__, P.G__plus__ ],
              color = [ '1' ],
              lorentz = [ L.SSSSSS1 ],
              couplings = {(0,0):C.GC_263})

V_43 = Vertex(name = 'V_43',
              particles = [ P.G0, P.G0, P.G0, P.G0, P.H ],
              color = [ '1' ],
              lorentz = [ L.SSSSS1, L.SSSSS12, L.SSSSS2 ],
              couplings = {(0,0):C.GC_133,(0,1):C.GC_275,(0,2):C.GC_282})

V_44 = Vertex(name = 'V_44',
              particles = [ P.G0, P.G0, P.G0, P.G0, P.H ],
              color = [ '1' ],
              lorentz = [ L.SSSSS1 ],
              couplings = {(0,0):C.GC_395})

V_45 = Vertex(name = 'V_45',
              particles = [ P.G0, P.G0, P.G__minus__, P.G__plus__, P.H ],
              color = [ '1' ],
              lorentz = [ L.SSSSS1, L.SSSSS13, L.SSSSS7 ],
              couplings = {(0,0):C.GC_131,(0,2):C.GC_280,(0,1):C.GC_273})

V_46 = Vertex(name = 'V_46',
              particles = [ P.G0, P.G0, P.G__minus__, P.G__plus__, P.H ],
              color = [ '1' ],
              lorentz = [ L.SSSSS1 ],
              couplings = {(0,0):C.GC_393})

V_47 = Vertex(name = 'V_47',
              particles = [ P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__, P.H ],
              color = [ '1' ],
              lorentz = [ L.SSSSS1, L.SSSSS11, L.SSSSS9 ],
              couplings = {(0,0):C.GC_132,(0,2):C.GC_280,(0,1):C.GC_274})

V_48 = Vertex(name = 'V_48',
              particles = [ P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__, P.H ],
              color = [ '1' ],
              lorentz = [ L.SSSSS1 ],
              couplings = {(0,0):C.GC_392})

V_49 = Vertex(name = 'V_49',
              particles = [ P.G0, P.G0, P.G0, P.G0, P.H, P.H ],
              color = [ '1' ],
              lorentz = [ L.SSSSSS1, L.SSSSSS11, L.SSSSSS18 ],
              couplings = {(0,0):C.GC_116,(0,2):C.GC_177,(0,1):C.GC_185})

V_50 = Vertex(name = 'V_50',
              particles = [ P.G0, P.G0, P.G0, P.G0, P.H, P.H ],
              color = [ '1' ],
              lorentz = [ L.SSSSSS1 ],
              couplings = {(0,0):C.GC_460})

V_51 = Vertex(name = 'V_51',
              particles = [ P.G0, P.G0, P.G__minus__, P.G__plus__, P.H, P.H ],
              color = [ '1' ],
              lorentz = [ L.SSSSSS1, L.SSSSSS19, L.SSSSSS8 ],
              couplings = {(0,0):C.GC_114,(0,1):C.GC_175,(0,2):C.GC_183})

V_52 = Vertex(name = 'V_52',
              particles = [ P.G0, P.G0, P.G__minus__, P.G__plus__, P.H, P.H ],
              color = [ '1' ],
              lorentz = [ L.SSSSSS1 ],
              couplings = {(0,0):C.GC_465})

V_53 = Vertex(name = 'V_53',
              particles = [ P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__, P.H, P.H ],
              color = [ '1' ],
              lorentz = [ L.SSSSSS1, L.SSSSSS17, L.SSSSSS4 ],
              couplings = {(0,0):C.GC_115,(0,1):C.GC_176,(0,2):C.GC_183})

V_54 = Vertex(name = 'V_54',
              particles = [ P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__, P.H, P.H ],
              color = [ '1' ],
              lorentz = [ L.SSSSSS1 ],
              couplings = {(0,0):C.GC_466})

V_55 = Vertex(name = 'V_55',
              particles = [ P.G0, P.G0, P.H, P.H, P.H ],
              color = [ '1' ],
              lorentz = [ L.SSSSS1, L.SSSSS15, L.SSSSS6 ],
              couplings = {(0,0):C.GC_133,(0,1):C.GC_275,(0,2):C.GC_283})

V_56 = Vertex(name = 'V_56',
              particles = [ P.G0, P.G0, P.H, P.H, P.H ],
              color = [ '1' ],
              lorentz = [ L.SSSSS1 ],
              couplings = {(0,0):C.GC_396})

V_57 = Vertex(name = 'V_57',
              particles = [ P.G__minus__, P.G__plus__, P.H, P.H, P.H ],
              color = [ '1' ],
              lorentz = [ L.SSSSS1, L.SSSSS15, L.SSSSS8 ],
              couplings = {(0,0):C.GC_133,(0,2):C.GC_281,(0,1):C.GC_275})

V_58 = Vertex(name = 'V_58',
              particles = [ P.G__minus__, P.G__plus__, P.H, P.H, P.H ],
              color = [ '1' ],
              lorentz = [ L.SSSSS1 ],
              couplings = {(0,0):C.GC_394})

V_59 = Vertex(name = 'V_59',
              particles = [ P.G0, P.G0, P.H, P.H, P.H, P.H ],
              color = [ '1' ],
              lorentz = [ L.SSSSSS1, L.SSSSSS16, L.SSSSSS6 ],
              couplings = {(0,0):C.GC_116,(0,1):C.GC_177,(0,2):C.GC_187})

V_60 = Vertex(name = 'V_60',
              particles = [ P.G0, P.G0, P.H, P.H, P.H, P.H ],
              color = [ '1' ],
              lorentz = [ L.SSSSSS1 ],
              couplings = {(0,0):C.GC_461})

V_61 = Vertex(name = 'V_61',
              particles = [ P.G__minus__, P.G__plus__, P.H, P.H, P.H, P.H ],
              color = [ '1' ],
              lorentz = [ L.SSSSSS1, L.SSSSSS16, L.SSSSSS7 ],
              couplings = {(0,0):C.GC_116,(0,1):C.GC_177,(0,2):C.GC_184})

V_62 = Vertex(name = 'V_62',
              particles = [ P.G__minus__, P.G__plus__, P.H, P.H, P.H, P.H ],
              color = [ '1' ],
              lorentz = [ L.SSSSSS1 ],
              couplings = {(0,0):C.GC_468})

V_63 = Vertex(name = 'V_63',
              particles = [ P.H, P.H, P.H, P.H, P.H ],
              color = [ '1' ],
              lorentz = [ L.SSSSS1, L.SSSSS10, L.SSSSS14 ],
              couplings = {(0,0):C.GC_134,(0,2):C.GC_276,(0,1):C.GC_283})

V_64 = Vertex(name = 'V_64',
              particles = [ P.H, P.H, P.H, P.H, P.H ],
              color = [ '1' ],
              lorentz = [ L.SSSSS1 ],
              couplings = {(0,0):C.GC_397})

V_65 = Vertex(name = 'V_65',
              particles = [ P.H, P.H, P.H, P.H, P.H, P.H ],
              color = [ '1' ],
              lorentz = [ L.SSSSSS1, L.SSSSSS10, L.SSSSSS15 ],
              couplings = {(0,0):C.GC_118,(0,2):C.GC_179,(0,1):C.GC_187})

V_66 = Vertex(name = 'V_66',
              particles = [ P.H, P.H, P.H, P.H, P.H, P.H ],
              color = [ '1' ],
              lorentz = [ L.SSSSSS1 ],
              couplings = {(0,0):C.GC_463})

V_67 = Vertex(name = 'V_67',
              particles = [ P.G0, P.G0, P.G0, P.G0, P.G0, P.G0, P.G0, P.G0 ],
              color = [ '1' ],
              lorentz = [ L.SSSSSSSS1 ],
              couplings = {(0,0):C.GC_194})

V_68 = Vertex(name = 'V_68',
              particles = [ P.G0, P.G0, P.G0, P.G0, P.G0, P.G0, P.G__minus__, P.G__plus__ ],
              color = [ '1' ],
              lorentz = [ L.SSSSSSSS1 ],
              couplings = {(0,0):C.GC_192})

V_69 = Vertex(name = 'V_69',
              particles = [ P.G0, P.G0, P.G0, P.G0, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__ ],
              color = [ '1' ],
              lorentz = [ L.SSSSSSSS1 ],
              couplings = {(0,0):C.GC_190})

V_70 = Vertex(name = 'V_70',
              particles = [ P.G0, P.G0, P.G__minus__, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__, P.G__plus__ ],
              color = [ '1' ],
              lorentz = [ L.SSSSSSSS1 ],
              couplings = {(0,0):C.GC_190})

V_71 = Vertex(name = 'V_71',
              particles = [ P.G__minus__, P.G__minus__, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__, P.G__plus__, P.G__plus__ ],
              color = [ '1' ],
              lorentz = [ L.SSSSSSSS1 ],
              couplings = {(0,0):C.GC_193})

V_72 = Vertex(name = 'V_72',
              particles = [ P.G0, P.G0, P.G0, P.G0, P.G0, P.G0, P.H ],
              color = [ '1' ],
              lorentz = [ L.SSSSSSS1 ],
              couplings = {(0,0):C.GC_288})

V_73 = Vertex(name = 'V_73',
              particles = [ P.G0, P.G0, P.G0, P.G0, P.G__minus__, P.G__plus__, P.H ],
              color = [ '1' ],
              lorentz = [ L.SSSSSSS1 ],
              couplings = {(0,0):C.GC_285})

V_74 = Vertex(name = 'V_74',
              particles = [ P.G0, P.G0, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__, P.H ],
              color = [ '1' ],
              lorentz = [ L.SSSSSSS1 ],
              couplings = {(0,0):C.GC_284})

V_75 = Vertex(name = 'V_75',
              particles = [ P.G__minus__, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__, P.G__plus__, P.H ],
              color = [ '1' ],
              lorentz = [ L.SSSSSSS1 ],
              couplings = {(0,0):C.GC_286})

V_76 = Vertex(name = 'V_76',
              particles = [ P.G0, P.G0, P.G0, P.G0, P.G0, P.G0, P.H, P.H ],
              color = [ '1' ],
              lorentz = [ L.SSSSSSSS1 ],
              couplings = {(0,0):C.GC_192})

V_77 = Vertex(name = 'V_77',
              particles = [ P.G0, P.G0, P.G0, P.G0, P.G__minus__, P.G__plus__, P.H, P.H ],
              color = [ '1' ],
              lorentz = [ L.SSSSSSSS1 ],
              couplings = {(0,0):C.GC_189})

V_78 = Vertex(name = 'V_78',
              particles = [ P.G0, P.G0, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__, P.H, P.H ],
              color = [ '1' ],
              lorentz = [ L.SSSSSSSS1 ],
              couplings = {(0,0):C.GC_188})

V_79 = Vertex(name = 'V_79',
              particles = [ P.G__minus__, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__, P.G__plus__, P.H, P.H ],
              color = [ '1' ],
              lorentz = [ L.SSSSSSSS1 ],
              couplings = {(0,0):C.GC_190})

V_80 = Vertex(name = 'V_80',
              particles = [ P.G0, P.G0, P.G0, P.G0, P.H, P.H, P.H ],
              color = [ '1' ],
              lorentz = [ L.SSSSSSS1 ],
              couplings = {(0,0):C.GC_287})

V_81 = Vertex(name = 'V_81',
              particles = [ P.G0, P.G0, P.G__minus__, P.G__plus__, P.H, P.H, P.H ],
              color = [ '1' ],
              lorentz = [ L.SSSSSSS1 ],
              couplings = {(0,0):C.GC_285})

V_82 = Vertex(name = 'V_82',
              particles = [ P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__, P.H, P.H, P.H ],
              color = [ '1' ],
              lorentz = [ L.SSSSSSS1 ],
              couplings = {(0,0):C.GC_286})

V_83 = Vertex(name = 'V_83',
              particles = [ P.G0, P.G0, P.G0, P.G0, P.H, P.H, P.H, P.H ],
              color = [ '1' ],
              lorentz = [ L.SSSSSSSS1 ],
              couplings = {(0,0):C.GC_191})

V_84 = Vertex(name = 'V_84',
              particles = [ P.G0, P.G0, P.G__minus__, P.G__plus__, P.H, P.H, P.H, P.H ],
              color = [ '1' ],
              lorentz = [ L.SSSSSSSS1 ],
              couplings = {(0,0):C.GC_189})

V_85 = Vertex(name = 'V_85',
              particles = [ P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__, P.H, P.H, P.H, P.H ],
              color = [ '1' ],
              lorentz = [ L.SSSSSSSS1 ],
              couplings = {(0,0):C.GC_190})

V_86 = Vertex(name = 'V_86',
              particles = [ P.G0, P.G0, P.H, P.H, P.H, P.H, P.H ],
              color = [ '1' ],
              lorentz = [ L.SSSSSSS1 ],
              couplings = {(0,0):C.GC_288})

V_87 = Vertex(name = 'V_87',
              particles = [ P.G__minus__, P.G__plus__, P.H, P.H, P.H, P.H, P.H ],
              color = [ '1' ],
              lorentz = [ L.SSSSSSS1 ],
              couplings = {(0,0):C.GC_288})

V_88 = Vertex(name = 'V_88',
              particles = [ P.G0, P.G0, P.H, P.H, P.H, P.H, P.H, P.H ],
              color = [ '1' ],
              lorentz = [ L.SSSSSSSS1 ],
              couplings = {(0,0):C.GC_192})

V_89 = Vertex(name = 'V_89',
              particles = [ P.G__minus__, P.G__plus__, P.H, P.H, P.H, P.H, P.H, P.H ],
              color = [ '1' ],
              lorentz = [ L.SSSSSSSS1 ],
              couplings = {(0,0):C.GC_192})

V_90 = Vertex(name = 'V_90',
              particles = [ P.H, P.H, P.H, P.H, P.H, P.H, P.H ],
              color = [ '1' ],
              lorentz = [ L.SSSSSSS1 ],
              couplings = {(0,0):C.GC_289})

V_91 = Vertex(name = 'V_91',
              particles = [ P.H, P.H, P.H, P.H, P.H, P.H, P.H, P.H ],
              color = [ '1' ],
              lorentz = [ L.SSSSSSSS1 ],
              couplings = {(0,0):C.GC_194})

V_92 = Vertex(name = 'V_92',
              particles = [ P.ghWp, P.ghZ__tilde__, P.G__minus__ ],
              color = [ '1' ],
              lorentz = [ L.UUS1 ],
              couplings = {(0,0):C.GC_3840})

V_93 = Vertex(name = 'V_93',
              particles = [ P.ghWp, P.ghZ__tilde__, P.G__minus__ ],
              color = [ '1' ],
              lorentz = [ L.UUS1 ],
              couplings = {(0,0):C.GC_5858})

V_94 = Vertex(name = 'V_94',
              particles = [ P.ghWp, P.ghZ__tilde__, P.G__minus__ ],
              color = [ '1' ],
              lorentz = [ L.UUS1 ],
              couplings = {(0,0):C.GC_5859})

V_95 = Vertex(name = 'V_95',
              particles = [ P.ghWm, P.ghZ__tilde__, P.G__plus__ ],
              color = [ '1' ],
              lorentz = [ L.UUS1 ],
              couplings = {(0,0):C.GC_3840})

V_96 = Vertex(name = 'V_96',
              particles = [ P.ghWm, P.ghZ__tilde__, P.G__plus__ ],
              color = [ '1' ],
              lorentz = [ L.UUS1 ],
              couplings = {(0,0):C.GC_5858})

V_97 = Vertex(name = 'V_97',
              particles = [ P.ghWm, P.ghZ__tilde__, P.G__plus__ ],
              color = [ '1' ],
              lorentz = [ L.UUS1 ],
              couplings = {(0,0):C.GC_5859})

V_98 = Vertex(name = 'V_98',
              particles = [ P.ghZ, P.ghWm__tilde__, P.G__minus__ ],
              color = [ '1' ],
              lorentz = [ L.UUS1 ],
              couplings = {(0,0):C.GC_3081})

V_99 = Vertex(name = 'V_99',
              particles = [ P.ghZ, P.ghWm__tilde__, P.G__minus__ ],
              color = [ '1' ],
              lorentz = [ L.UUS1 ],
              couplings = {(0,0):C.GC_3082})

V_100 = Vertex(name = 'V_100',
               particles = [ P.ghZ, P.ghWm__tilde__, P.G__minus__ ],
               color = [ '1' ],
               lorentz = [ L.UUS1 ],
               couplings = {(0,0):C.GC_3841})

V_101 = Vertex(name = 'V_101',
               particles = [ P.ghZ, P.ghWp__tilde__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.UUS1 ],
               couplings = {(0,0):C.GC_3081})

V_102 = Vertex(name = 'V_102',
               particles = [ P.ghZ, P.ghWp__tilde__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.UUS1 ],
               couplings = {(0,0):C.GC_3082})

V_103 = Vertex(name = 'V_103',
               particles = [ P.ghZ, P.ghWp__tilde__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.UUS1 ],
               couplings = {(0,0):C.GC_3841})

V_104 = Vertex(name = 'V_104',
               particles = [ P.ghWm, P.ghWm__tilde__, P.G0 ],
               color = [ '1' ],
               lorentz = [ L.UUS1 ],
               couplings = {(0,0):C.GC_1443})

V_105 = Vertex(name = 'V_105',
               particles = [ P.ghWm, P.ghWm__tilde__, P.G0 ],
               color = [ '1' ],
               lorentz = [ L.UUS1 ],
               couplings = {(0,0):C.GC_1444})

V_106 = Vertex(name = 'V_106',
               particles = [ P.ghWm, P.ghWm__tilde__, P.G0 ],
               color = [ '1' ],
               lorentz = [ L.UUS1 ],
               couplings = {(0,0):C.GC_1449})

V_107 = Vertex(name = 'V_107',
               particles = [ P.ghWp, P.ghWp__tilde__, P.G0 ],
               color = [ '1' ],
               lorentz = [ L.UUS1 ],
               couplings = {(0,0):C.GC_1441})

V_108 = Vertex(name = 'V_108',
               particles = [ P.ghWp, P.ghWp__tilde__, P.G0 ],
               color = [ '1' ],
               lorentz = [ L.UUS1 ],
               couplings = {(0,0):C.GC_1445})

V_109 = Vertex(name = 'V_109',
               particles = [ P.ghWp, P.ghWp__tilde__, P.G0 ],
               color = [ '1' ],
               lorentz = [ L.UUS1 ],
               couplings = {(0,0):C.GC_1447})

V_110 = Vertex(name = 'V_110',
               particles = [ P.ghWm, P.ghWm__tilde__, P.H ],
               color = [ '1' ],
               lorentz = [ L.UUS1 ],
               couplings = {(0,0):C.GC_1442})

V_111 = Vertex(name = 'V_111',
               particles = [ P.ghWm, P.ghWm__tilde__, P.H ],
               color = [ '1' ],
               lorentz = [ L.UUS1 ],
               couplings = {(0,0):C.GC_1446})

V_112 = Vertex(name = 'V_112',
               particles = [ P.ghWm, P.ghWm__tilde__, P.H ],
               color = [ '1' ],
               lorentz = [ L.UUS1 ],
               couplings = {(0,0):C.GC_1448})

V_113 = Vertex(name = 'V_113',
               particles = [ P.ghWp, P.ghWp__tilde__, P.H ],
               color = [ '1' ],
               lorentz = [ L.UUS1 ],
               couplings = {(0,0):C.GC_1442})

V_114 = Vertex(name = 'V_114',
               particles = [ P.ghWp, P.ghWp__tilde__, P.H ],
               color = [ '1' ],
               lorentz = [ L.UUS1 ],
               couplings = {(0,0):C.GC_1446})

V_115 = Vertex(name = 'V_115',
               particles = [ P.ghWp, P.ghWp__tilde__, P.H ],
               color = [ '1' ],
               lorentz = [ L.UUS1 ],
               couplings = {(0,0):C.GC_1448})

V_116 = Vertex(name = 'V_116',
               particles = [ P.ghZ, P.ghZ__tilde__, P.H ],
               color = [ '1' ],
               lorentz = [ L.UUS1 ],
               couplings = {(0,0):C.GC_3175})

V_117 = Vertex(name = 'V_117',
               particles = [ P.ghZ, P.ghZ__tilde__, P.H ],
               color = [ '1' ],
               lorentz = [ L.UUS1 ],
               couplings = {(0,0):C.GC_5081})

V_118 = Vertex(name = 'V_118',
               particles = [ P.ghZ, P.ghZ__tilde__, P.H ],
               color = [ '1' ],
               lorentz = [ L.UUS1 ],
               couplings = {(0,0):C.GC_5082})

V_119 = Vertex(name = 'V_119',
               particles = [ P.ghWp, P.ghA__tilde__, P.G__minus__ ],
               color = [ '1' ],
               lorentz = [ L.UUS1 ],
               couplings = {(0,0):C.GC_5184})

V_120 = Vertex(name = 'V_120',
               particles = [ P.ghWp, P.ghA__tilde__, P.G__minus__ ],
               color = [ '1' ],
               lorentz = [ L.UUS1 ],
               couplings = {(0,0):C.GC_5345})

V_121 = Vertex(name = 'V_121',
               particles = [ P.ghWp, P.ghA__tilde__, P.G__minus__ ],
               color = [ '1' ],
               lorentz = [ L.UUS1 ],
               couplings = {(0,0):C.GC_5344})

V_122 = Vertex(name = 'V_122',
               particles = [ P.ghWm, P.ghA__tilde__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.UUS1 ],
               couplings = {(0,0):C.GC_5184})

V_123 = Vertex(name = 'V_123',
               particles = [ P.ghWm, P.ghA__tilde__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.UUS1 ],
               couplings = {(0,0):C.GC_5345})

V_124 = Vertex(name = 'V_124',
               particles = [ P.ghWm, P.ghA__tilde__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.UUS1 ],
               couplings = {(0,0):C.GC_5344})

V_125 = Vertex(name = 'V_125',
               particles = [ P.A, P.A, P.G__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSS38, L.VVSS39, L.VVSS4, L.VVSS49, L.VVSS50, L.VVSS55, L.VVSS65, L.VVSS74, L.VVSS78, L.VVSS79 ],
               couplings = {(0,2):C.GC_5387,(0,6):C.GC_5378,(0,5):C.GC_1618,(0,8):C.GC_5415,(0,1):C.GC_5410,(0,9):C.GC_5408,(0,0):C.GC_5482,(0,7):C.GC_5481,(0,4):C.GC_5419,(0,3):C.GC_5420})

V_126 = Vertex(name = 'V_126',
               particles = [ P.A, P.A, P.G__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSS4, L.VVSS55, L.VVSS65 ],
               couplings = {(0,0):C.GC_5438,(0,2):C.GC_5435,(0,1):C.GC_5606})

V_127 = Vertex(name = 'V_127',
               particles = [ P.A, P.A, P.G__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSS55 ],
               couplings = {(0,0):C.GC_5571})

V_128 = Vertex(name = 'V_128',
               particles = [ P.A, P.A, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS107, L.VVSSSS127, L.VVSSSS142, L.VVSSSS146, L.VVSSSS4, L.VVSSSS67, L.VVSSSS91 ],
               couplings = {(0,4):C.GC_6228,(0,0):C.GC_6220,(0,6):C.GC_1621,(0,2):C.GC_1669,(0,3):C.GC_1668,(0,5):C.GC_6352,(0,1):C.GC_6338})

V_129 = Vertex(name = 'V_129',
               particles = [ P.A, P.A, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS91 ],
               couplings = {(0,0):C.GC_6553})

V_130 = Vertex(name = 'V_130',
               particles = [ P.A, P.A, P.G0, P.G0, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSSSSSS1 ],
               couplings = {(0,0):C.GC_1671})

V_131 = Vertex(name = 'V_131',
               particles = [ P.A, P.A, P.G__minus__, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSSSSSS1 ],
               couplings = {(0,0):C.GC_1672})

V_132 = Vertex(name = 'V_132',
               particles = [ P.A, P.A, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSSSS1 ],
               couplings = {(0,0):C.GC_1637})

V_133 = Vertex(name = 'V_133',
               particles = [ P.A, P.A, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSSSSS1 ],
               couplings = {(0,0):C.GC_1671})

V_134 = Vertex(name = 'V_134',
               particles = [ P.A, P.A, P.A, P.A, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVVSSSS13 ],
               couplings = {(0,0):C.GC_1903})

V_135 = Vertex(name = 'V_135',
               particles = [ P.A, P.G0, P.G__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VSSS1, L.VSSS24, L.VSSS32 ],
               couplings = {(0,0):C.GC_7653,(0,2):C.GC_7607,(0,1):C.GC_7606})

V_136 = Vertex(name = 'V_136',
               particles = [ P.A, P.G0, P.G__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VSSS1 ],
               couplings = {(0,0):C.GC_7608})

V_137 = Vertex(name = 'V_137',
               particles = [ P.A, P.G0, P.G__minus__, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VSSSS25, L.VSSSS30, L.VSSSS54, L.VSSSS65, L.VSSSS75, L.VSSSS84, L.VSSSS93 ],
               couplings = {(0,5):C.GC_7593,(0,2):C.GC_7591,(0,0):C.GC_7662,(0,6):C.GC_7596,(0,3):C.GC_7595,(0,1):C.GC_7660,(0,4):C.GC_7681})

V_138 = Vertex(name = 'V_138',
               particles = [ P.A, P.G0, P.G__minus__, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VSSSS25 ],
               couplings = {(0,0):C.GC_7616})

V_139 = Vertex(name = 'V_139',
               particles = [ P.A, P.G0, P.G0, P.G0, P.G__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VSSSSS5 ],
               couplings = {(0,0):C.GC_4393})

V_140 = Vertex(name = 'V_140',
               particles = [ P.A, P.G0, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VSSSSS1 ],
               couplings = {(0,0):C.GC_4391})

V_141 = Vertex(name = 'V_141',
               particles = [ P.A, P.G0, P.G0, P.G0, P.G__minus__, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VSSSSSS10 ],
               couplings = {(0,0):C.GC_4443})

V_142 = Vertex(name = 'V_142',
               particles = [ P.A, P.G0, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VSSSSSS16 ],
               couplings = {(0,0):C.GC_4441})

V_143 = Vertex(name = 'V_143',
               particles = [ P.A, P.G0, P.G__minus__, P.G__plus__, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VSSSSS17 ],
               couplings = {(0,0):C.GC_4392})

V_144 = Vertex(name = 'V_144',
               particles = [ P.A, P.G0, P.G__minus__, P.G__plus__, P.H, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VSSSSSS25 ],
               couplings = {(0,0):C.GC_4442})

V_145 = Vertex(name = 'V_145',
               particles = [ P.A, P.A, P.G0, P.G0, P.G__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS107, L.VVSSSS126, L.VVSSSS13, L.VVSSSS4, L.VVSSSS66, L.VVSSSS97 ],
               couplings = {(0,3):C.GC_1477,(0,0):C.GC_1475,(0,2):C.GC_1667,(0,5):C.GC_1670,(0,4):C.GC_6349,(0,1):C.GC_6340})

V_146 = Vertex(name = 'V_146',
               particles = [ P.ghWm, P.ghWm__tilde__, P.A ],
               color = [ '1' ],
               lorentz = [ L.UUV1 ],
               couplings = {(0,0):C.GC_5182})

V_147 = Vertex(name = 'V_147',
               particles = [ P.ghWm, P.ghWm__tilde__, P.A ],
               color = [ '1' ],
               lorentz = [ L.UUV1 ],
               couplings = {(0,0):C.GC_5295})

V_148 = Vertex(name = 'V_148',
               particles = [ P.ghWm, P.ghWm__tilde__, P.A ],
               color = [ '1' ],
               lorentz = [ L.UUV1 ],
               couplings = {(0,0):C.GC_5288})

V_149 = Vertex(name = 'V_149',
               particles = [ P.ghWp, P.ghWp__tilde__, P.A ],
               color = [ '1' ],
               lorentz = [ L.UUV1 ],
               couplings = {(0,0):C.GC_5180})

V_150 = Vertex(name = 'V_150',
               particles = [ P.ghWp, P.ghWp__tilde__, P.A ],
               color = [ '1' ],
               lorentz = [ L.UUV1 ],
               couplings = {(0,0):C.GC_5297})

V_151 = Vertex(name = 'V_151',
               particles = [ P.ghWp, P.ghWp__tilde__, P.A ],
               color = [ '1' ],
               lorentz = [ L.UUV1 ],
               couplings = {(0,0):C.GC_5289})

V_152 = Vertex(name = 'V_152',
               particles = [ P.A, P.G__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VSS10, L.VSS2, L.VSS9 ],
               couplings = {(0,0):C.GC_5281,(0,2):C.GC_5280,(0,1):C.GC_5180})

V_153 = Vertex(name = 'V_153',
               particles = [ P.A, P.G__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VSS2 ],
               couplings = {(0,0):C.GC_5297})

V_154 = Vertex(name = 'V_154',
               particles = [ P.A, P.G__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VSS2 ],
               couplings = {(0,0):C.GC_5289})

V_155 = Vertex(name = 'V_155',
               particles = [ P.A, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VSSSS26, L.VSSSS58, L.VSSSS70, L.VSSSS78, L.VSSSS90 ],
               couplings = {(0,4):C.GC_7594,(0,1):C.GC_7592,(0,0):C.GC_7661,(0,3):C.GC_7682,(0,2):C.GC_7683})

V_156 = Vertex(name = 'V_156',
               particles = [ P.A, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VSSSS26 ],
               couplings = {(0,0):C.GC_7615})

V_157 = Vertex(name = 'V_157',
               particles = [ P.A, P.G0, P.G0, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VSSSSSS18 ],
               couplings = {(0,0):C.GC_4444})

V_158 = Vertex(name = 'V_158',
               particles = [ P.A, P.G__minus__, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VSSSSSS17 ],
               couplings = {(0,0):C.GC_4445})

V_159 = Vertex(name = 'V_159',
               particles = [ P.A, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VSSSSS6 ],
               couplings = {(0,0):C.GC_4394})

V_160 = Vertex(name = 'V_160',
               particles = [ P.A, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VSSSSSS4 ],
               couplings = {(0,0):C.GC_4444})

V_161 = Vertex(name = 'V_161',
               particles = [ P.A, P.A, P.A, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVSSSS229 ],
               couplings = {(0,0):C.GC_7260})

V_162 = Vertex(name = 'V_162',
               particles = [ P.G0, P.G__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.SSS3 ],
               couplings = {(0,0):C.GC_138})

V_163 = Vertex(name = 'V_163',
               particles = [ P.G0, P.G__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.SSS3 ],
               couplings = {(0,0):C.GC_401})

V_164 = Vertex(name = 'V_164',
               particles = [ P.G0, P.G__minus__, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.SSSS17, L.SSSS5, L.SSSS8 ],
               couplings = {(0,2):C.GC_122,(0,0):C.GC_356,(0,1):C.GC_260})

V_165 = Vertex(name = 'V_165',
               particles = [ P.G0, P.G__minus__, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.SSSS8 ],
               couplings = {(0,0):C.GC_474})

V_166 = Vertex(name = 'V_166',
               particles = [ P.G0, P.G0, P.G0, P.G__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.SSSSS4 ],
               couplings = {(0,0):C.GC_279})

V_167 = Vertex(name = 'V_167',
               particles = [ P.G0, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.SSSSS3 ],
               couplings = {(0,0):C.GC_278})

V_168 = Vertex(name = 'V_168',
               particles = [ P.G0, P.G0, P.G0, P.G__minus__, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.SSSSSS12 ],
               couplings = {(0,0):C.GC_182})

V_169 = Vertex(name = 'V_169',
               particles = [ P.G0, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.SSSSSS9 ],
               couplings = {(0,0):C.GC_181})

V_170 = Vertex(name = 'V_170',
               particles = [ P.G0, P.G__minus__, P.G__plus__, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.SSSSS5 ],
               couplings = {(0,0):C.GC_277})

V_171 = Vertex(name = 'V_171',
               particles = [ P.G0, P.G__minus__, P.G__plus__, P.H, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.SSSSSS2 ],
               couplings = {(0,0):C.GC_180})

V_172 = Vertex(name = 'V_172',
               particles = [ P.A, P.G0, P.G0, P.G__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VSSSS103, L.VSSSS39, L.VSSSS58, L.VSSSS60, L.VSSSS61, L.VSSSS90, L.VSSSS91 ],
               couplings = {(0,6):C.GC_2354,(0,4):C.GC_6915,(0,0):C.GC_4384,(0,5):C.GC_4388,(0,2):C.GC_4386,(0,1):C.GC_4440,(0,3):C.GC_7065})

V_173 = Vertex(name = 'V_173',
               particles = [ P.A, P.A, P.G0, P.G__minus__, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS135, L.VVSSSS70 ],
               couplings = {(0,1):C.GC_1615,(0,0):C.GC_1614})

V_174 = Vertex(name = 'V_174',
               particles = [ P.A, P.A, P.G__minus__, P.G__plus__, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS106, L.VVSSSS107, L.VVSSSS110, L.VVSSSS18, L.VVSSSS4, L.VVSSSS48 ],
               couplings = {(0,4):C.GC_1477,(0,1):C.GC_1475,(0,5):C.GC_1667,(0,0):C.GC_1670,(0,3):C.GC_6349,(0,2):C.GC_6340})

V_175 = Vertex(name = 'V_175',
               particles = [ P.A, P.G__minus__, P.G__plus__, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VSSSS58, L.VSSSS7, L.VSSSS71, L.VSSSS79, L.VSSSS90, L.VSSSS94, L.VSSSS96 ],
               couplings = {(0,5):C.GC_2353,(0,1):C.GC_6915,(0,6):C.GC_4383,(0,4):C.GC_4387,(0,0):C.GC_4385,(0,2):C.GC_7065,(0,3):C.GC_4440})

V_176 = Vertex(name = 'V_176',
               particles = [ P.A, P.A, P.A, P.G__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVSS102, L.VVVSS291, L.VVVSS305, L.VVVSS312, L.VVVSS324 ],
               couplings = {(0,3):C.GC_1984,(0,4):C.GC_1991,(0,2):C.GC_7070,(0,0):C.GC_7076,(0,1):C.GC_7074})

V_177 = Vertex(name = 'V_177',
               particles = [ P.A, P.A, P.G0, P.G__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSSS70, L.VVSSS9 ],
               couplings = {(0,1):C.GC_1564,(0,0):C.GC_1563})

V_178 = Vertex(name = 'V_178',
               particles = [ P.A, P.G0, P.G0, P.G0, P.G0 ],
               color = [ '1' ],
               lorentz = [ L.VSSSS102 ],
               couplings = {(0,0):C.GC_6917})

V_179 = Vertex(name = 'V_179',
               particles = [ P.A, P.G0, P.G0 ],
               color = [ '1' ],
               lorentz = [ L.VSS11 ],
               couplings = {(0,0):C.GC_6921})

V_180 = Vertex(name = 'V_180',
               particles = [ P.A, P.G0, P.G0, P.H ],
               color = [ '1' ],
               lorentz = [ L.VSSS9 ],
               couplings = {(0,0):C.GC_6956})

V_181 = Vertex(name = 'V_181',
               particles = [ P.A, P.G0, P.G0, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VSSSS98 ],
               couplings = {(0,0):C.GC_6917})

V_182 = Vertex(name = 'V_182',
               particles = [ P.A, P.A, P.G__minus__, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSS20, L.VVSSS4, L.VVSSS69, L.VVSSS74 ],
               couplings = {(0,0):C.GC_6258,(0,3):C.GC_6251,(0,1):C.GC_1536,(0,2):C.GC_1534})

V_183 = Vertex(name = 'V_183',
               particles = [ P.A, P.G__minus__, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VSSS25, L.VSSS35, L.VSSS7, L.VSSS8 ],
               couplings = {(0,3):C.GC_6955,(0,2):C.GC_6953,(0,1):C.GC_4390,(0,0):C.GC_4389})

V_184 = Vertex(name = 'V_184',
               particles = [ P.A, P.G0, P.G0, P.G0, P.H ],
               color = [ '1' ],
               lorentz = [ L.VSSSS101, L.VSSSS64 ],
               couplings = {(0,0):C.GC_6918,(0,1):C.GC_6916})

V_185 = Vertex(name = 'V_185',
               particles = [ P.A, P.G0, P.H ],
               color = [ '1' ],
               lorentz = [ L.VSS10, L.VSS9 ],
               couplings = {(0,0):C.GC_6922,(0,1):C.GC_6920})

V_186 = Vertex(name = 'V_186',
               particles = [ P.A, P.G0, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VSSS23, L.VSSS33 ],
               couplings = {(0,1):C.GC_6957,(0,0):C.GC_6954})

V_187 = Vertex(name = 'V_187',
               particles = [ P.A, P.G0, P.H, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VSSSS56, L.VSSSS88 ],
               couplings = {(0,1):C.GC_6918,(0,0):C.GC_6916})

V_188 = Vertex(name = 'V_188',
               particles = [ P.A, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VSS11 ],
               couplings = {(0,0):C.GC_6921})

V_189 = Vertex(name = 'V_189',
               particles = [ P.A, P.H, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VSSS36 ],
               couplings = {(0,0):C.GC_6956})

V_190 = Vertex(name = 'V_190',
               particles = [ P.A, P.H, P.H, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VSSSS102 ],
               couplings = {(0,0):C.GC_6917})

V_191 = Vertex(name = 'V_191',
               particles = [ P.A, P.A, P.G0, P.G0 ],
               color = [ '1' ],
               lorentz = [ L.VVSS39, L.VVSS4, L.VVSS49, L.VVSS65, L.VVSS78, L.VVSS79 ],
               couplings = {(0,1):C.GC_7373,(0,3):C.GC_7372,(0,4):C.GC_7388,(0,0):C.GC_7387,(0,5):C.GC_7386,(0,2):C.GC_7389})

V_192 = Vertex(name = 'V_192',
               particles = [ P.A, P.A, P.G0, P.G0 ],
               color = [ '1' ],
               lorentz = [ L.VVSS4, L.VVSS65 ],
               couplings = {(0,0):C.GC_7394,(0,1):C.GC_7392})

V_193 = Vertex(name = 'V_193',
               particles = [ P.A, P.A, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVS15, L.VVS4 ],
               couplings = {(0,1):C.GC_7375,(0,0):C.GC_7374})

V_194 = Vertex(name = 'V_194',
               particles = [ P.A, P.A, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVS15, L.VVS4 ],
               couplings = {(0,1):C.GC_7391,(0,0):C.GC_7390})

V_195 = Vertex(name = 'V_195',
               particles = [ P.A, P.A, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSS39, L.VVSS4, L.VVSS49, L.VVSS65, L.VVSS78, L.VVSS79 ],
               couplings = {(0,1):C.GC_7373,(0,3):C.GC_7372,(0,4):C.GC_7388,(0,0):C.GC_7387,(0,5):C.GC_7386,(0,2):C.GC_7389})

V_196 = Vertex(name = 'V_196',
               particles = [ P.A, P.A, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSS4, L.VVSS65 ],
               couplings = {(0,0):C.GC_7395,(0,1):C.GC_7393})

V_197 = Vertex(name = 'V_197',
               particles = [ P.A, P.A, P.G0, P.G0, P.G0, P.G0 ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS107, L.VVSSSS4 ],
               couplings = {(0,1):C.GC_6232,(0,0):C.GC_6222})

V_198 = Vertex(name = 'V_198',
               particles = [ P.A, P.A, P.G0, P.G0, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSS4, L.VVSSS69 ],
               couplings = {(0,0):C.GC_6247,(0,1):C.GC_6240})

V_199 = Vertex(name = 'V_199',
               particles = [ P.A, P.A, P.G0, P.G0, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS107, L.VVSSSS4 ],
               couplings = {(0,1):C.GC_6226,(0,0):C.GC_6216})

V_200 = Vertex(name = 'V_200',
               particles = [ P.A, P.A, P.H, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSS4, L.VVSSS69 ],
               couplings = {(0,0):C.GC_6250,(0,1):C.GC_6243})

V_201 = Vertex(name = 'V_201',
               particles = [ P.A, P.A, P.H, P.H, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS107, L.VVSSSS4 ],
               couplings = {(0,1):C.GC_6232,(0,0):C.GC_6222})

V_202 = Vertex(name = 'V_202',
               particles = [ P.A, P.A, P.A, P.A, P.G__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVVSS425, L.VVVVSS465, L.VVVVSS659, L.VVVVSS676 ],
               couplings = {(0,2):C.GC_6733,(0,0):C.GC_6700,(0,3):C.GC_6691,(0,1):C.GC_6756})

V_203 = Vertex(name = 'V_203',
               particles = [ P.A, P.A, P.A, P.A ],
               color = [ '1' ],
               lorentz = [ L.VVVV211, L.VVVV214, L.VVVV71 ],
               couplings = {(0,0):C.GC_1519,(0,2):C.GC_1499,(0,1):C.GC_1495})

V_204 = Vertex(name = 'V_204',
               particles = [ P.A, P.A, P.W__minus__, P.G__minus__, P.G__plus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVSSS151, L.VVVSSS174, L.VVVSSS177, L.VVVSSS3, L.VVVSSS57 ],
               couplings = {(0,3):C.GC_6305,(0,4):C.GC_6294,(0,0):C.GC_1777,(0,1):C.GC_1782,(0,2):C.GC_1662})

V_205 = Vertex(name = 'V_205',
               particles = [ P.A, P.A, P.W__minus__, P.G__minus__, P.G__plus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVSSS3, L.VVVSSS57 ],
               couplings = {(0,0):C.GC_6615,(0,1):C.GC_6612})

V_206 = Vertex(name = 'V_206',
               particles = [ P.A, P.A, P.W__minus__, P.G0, P.G__minus__, P.G__plus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVSSSS103, L.VVVSSSS256, L.VVVSSSS277, L.VVVSSSS290, L.VVVSSSS295, L.VVVSSSS3, L.VVVSSSS82 ],
               couplings = {(0,5):C.GC_6547,(0,0):C.GC_1760,(0,4):C.GC_1764,(0,6):C.GC_6516,(0,2):C.GC_1821,(0,1):C.GC_1815,(0,3):C.GC_1810})

V_207 = Vertex(name = 'V_207',
               particles = [ P.A, P.A, P.W__minus__, P.G0, P.G__minus__, P.G__plus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVSSSS3, L.VVVSSSS82 ],
               couplings = {(0,0):C.GC_6654,(0,1):C.GC_4198})

V_208 = Vertex(name = 'V_208',
               particles = [ P.A, P.A, P.W__minus__, P.G__minus__, P.G__plus__, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVSSSS159, L.VVVSSSS238, L.VVVSSSS239, L.VVVSSSS284, L.VVVSSSS3, L.VVVSSSS329, L.VVVSSSS82 ],
               couplings = {(0,4):C.GC_6539,(0,5):C.GC_1757,(0,2):C.GC_1768,(0,6):C.GC_6526,(0,3):C.GC_1813,(0,1):C.GC_1811,(0,0):C.GC_1818})

V_209 = Vertex(name = 'V_209',
               particles = [ P.A, P.A, P.W__minus__, P.G__minus__, P.G__plus__, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVSSSS3, L.VVVSSSS82 ],
               couplings = {(0,0):C.GC_6645,(0,1):C.GC_4201})

V_210 = Vertex(name = 'V_210',
               particles = [ P.A, P.W__minus__, P.G0, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSS3, L.VVSS30, L.VVSS34, L.VVSS37, L.VVSS43, L.VVSS47, L.VVSS48, L.VVSS51, L.VVSS52, L.VVSS53, L.VVSS54, L.VVSS55, L.VVSS65, L.VVSS66, L.VVSS67, L.VVSS68, L.VVSS71, L.VVSS72, L.VVSS77, L.VVSS78, L.VVSS79 ],
               couplings = {(0,0):C.GC_2343,(0,12):C.GC_2339,(0,7):C.GC_2364,(0,8):C.GC_2367,(0,11):C.GC_5336,(0,18):C.GC_5246,(0,19):C.GC_2362,(0,1):C.GC_2361,(0,20):C.GC_2358,(0,3):C.GC_2442,(0,15):C.GC_2441,(0,10):C.GC_5257,(0,9):C.GC_5258,(0,6):C.GC_5309,(0,4):C.GC_5328,(0,2):C.GC_3847,(0,17):C.GC_5306,(0,14):C.GC_5313,(0,16):C.GC_3842,(0,5):C.GC_3848,(0,13):C.GC_3844})

V_211 = Vertex(name = 'V_211',
               particles = [ P.A, P.W__minus__, P.G0, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSS3, L.VVSS55, L.VVSS65 ],
               couplings = {(0,0):C.GC_5277,(0,2):C.GC_5274,(0,1):C.GC_5338})

V_212 = Vertex(name = 'V_212',
               particles = [ P.A, P.W__minus__, P.G0, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSS55 ],
               couplings = {(0,0):C.GC_5331})

V_213 = Vertex(name = 'V_213',
               particles = [ P.A, P.W__minus__, P.G0, P.G0, P.G0, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS107, L.VVSSSS111, L.VVSSSS113, L.VVSSSS114, L.VVSSSS121, L.VVSSSS27, L.VVSSSS3, L.VVSSSS65, L.VVSSSS86, L.VVSSSS89 ],
               couplings = {(0,6):C.GC_6893,(0,0):C.GC_6887,(0,7):C.GC_2451,(0,3):C.GC_2450,(0,5):C.GC_7202,(0,2):C.GC_4597,(0,9):C.GC_4483,(0,8):C.GC_4490,(0,4):C.GC_4482,(0,1):C.GC_4489})

V_214 = Vertex(name = 'V_214',
               particles = [ P.A, P.W__minus__, P.G0, P.G__minus__, P.G__plus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS107, L.VVSSSS117, L.VVSSSS119, L.VVSSSS133, L.VVSSSS143, L.VVSSSS144, L.VVSSSS147, L.VVSSSS3, L.VVSSSS62, L.VVSSSS78, L.VVSSSS80, L.VVSSSS91 ],
               couplings = {(0,7):C.GC_7578,(0,0):C.GC_7575,(0,11):C.GC_7796,(0,8):C.GC_5132,(0,1):C.GC_5129,(0,4):C.GC_7854,(0,5):C.GC_7839,(0,6):C.GC_7840,(0,9):C.GC_7760,(0,10):C.GC_7778,(0,2):C.GC_7750,(0,3):C.GC_7762})

V_215 = Vertex(name = 'V_215',
               particles = [ P.A, P.W__minus__, P.G0, P.G__minus__, P.G__plus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS91 ],
               couplings = {(0,0):C.GC_7793})

V_216 = Vertex(name = 'V_216',
               particles = [ P.A, P.W__minus__, P.G0, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSS19, L.VVSSS23, L.VVSSS3, L.VVSSS33, L.VVSSS56, L.VVSSS69, L.VVSSS72, L.VVSSS73, L.VVSSS79 ],
               couplings = {(0,0):C.GC_2398,(0,6):C.GC_2397,(0,2):C.GC_6939,(0,5):C.GC_6935,(0,1):C.GC_4425,(0,4):C.GC_4435,(0,7):C.GC_4424,(0,8):C.GC_4427,(0,3):C.GC_7179})

V_217 = Vertex(name = 'V_217',
               particles = [ P.A, P.W__minus__, P.G0, P.G__plus__, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS106, L.VVSSSS107, L.VVSSSS108, L.VVSSSS109, L.VVSSSS120, L.VVSSSS17, L.VVSSSS20, L.VVSSSS3, L.VVSSSS46, L.VVSSSS50, L.VVSSSS83 ],
               couplings = {(0,7):C.GC_6892,(0,1):C.GC_6886,(0,5):C.GC_2451,(0,2):C.GC_2450,(0,8):C.GC_4591,(0,9):C.GC_4594,(0,0):C.GC_4597,(0,6):C.GC_4483,(0,10):C.GC_4495,(0,3):C.GC_4482,(0,4):C.GC_4486})

V_218 = Vertex(name = 'V_218',
               particles = [ P.W__minus__, P.G0, P.G0, P.G0, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VSSSS101, L.VSSSS104, L.VSSSS15, L.VSSSS41, L.VSSSS64, L.VSSSS83 ],
               couplings = {(0,1):C.GC_247,(0,0):C.GC_240,(0,4):C.GC_373,(0,2):C.GC_634,(0,5):C.GC_1297,(0,3):C.GC_672})

V_219 = Vertex(name = 'V_219',
               particles = [ P.W__minus__, P.G0, P.G0, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VSSS15, L.VSSS28, L.VSSS4, L.VSSS9 ],
               couplings = {(0,2):C.GC_529,(0,0):C.GC_549,(0,1):C.GC_1198,(0,3):C.GC_317})

V_220 = Vertex(name = 'V_220',
               particles = [ P.W__minus__, P.G0, P.G0, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VSSS4 ],
               couplings = {(0,0):C.GC_1238})

V_221 = Vertex(name = 'V_221',
               particles = [ P.W__minus__, P.G0, P.G0, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VSSSS24, L.VSSSS27, L.VSSSS31, L.VSSSS39, L.VSSSS4, L.VSSSS61, L.VSSSS66, L.VSSSS81, L.VSSSS82, L.VSSSS86, L.VSSSS92 ],
               couplings = {(0,10):C.GC_249,(0,9):C.GC_241,(0,6):C.GC_244,(0,5):C.GC_239,(0,1):C.GC_635,(0,4):C.GC_639,(0,0):C.GC_537,(0,2):C.GC_640,(0,3):C.GC_671,(0,7):C.GC_660,(0,8):C.GC_665})

V_222 = Vertex(name = 'V_222',
               particles = [ P.W__minus__, P.G0, P.G0, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VSSSS24 ],
               couplings = {(0,0):C.GC_641})

V_223 = Vertex(name = 'V_223',
               particles = [ P.A, P.W__minus__, P.G__minus__, P.G__plus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSSS3, L.VVSSS44, L.VVSSS53, L.VVSSS58, L.VVSSS69, L.VVSSS77, L.VVSSS84, L.VVSSS92, L.VVSSS94 ],
               couplings = {(0,1):C.GC_7644,(0,5):C.GC_7643,(0,0):C.GC_7599,(0,4):C.GC_7597,(0,3):C.GC_7823,(0,2):C.GC_7651,(0,6):C.GC_7648,(0,8):C.GC_7832,(0,7):C.GC_7834})

V_224 = Vertex(name = 'V_224',
               particles = [ P.A, P.W__minus__, P.G__minus__, P.G__plus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSSS58 ],
               couplings = {(0,0):C.GC_7790})

V_225 = Vertex(name = 'V_225',
               particles = [ P.A, P.W__minus__, P.G__minus__, P.G__plus__, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS107, L.VVSSSS112, L.VVSSSS115, L.VVSSSS122, L.VVSSSS125, L.VVSSSS140, L.VVSSSS150, L.VVSSSS3, L.VVSSSS64, L.VVSSSS84, L.VVSSSS88, L.VVSSSS91 ],
               couplings = {(0,7):C.GC_7577,(0,0):C.GC_7573,(0,11):C.GC_7797,(0,8):C.GC_5131,(0,2):C.GC_5130,(0,5):C.GC_7843,(0,6):C.GC_7836,(0,1):C.GC_7849,(0,9):C.GC_7785,(0,4):C.GC_7772,(0,10):C.GC_7756,(0,3):C.GC_7753})

V_226 = Vertex(name = 'V_226',
               particles = [ P.A, P.W__minus__, P.G__minus__, P.G__plus__, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS91 ],
               couplings = {(0,0):C.GC_7792})

V_227 = Vertex(name = 'V_227',
               particles = [ P.W__minus__, P.G0, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VSS10, L.VSS2, L.VSS3, L.VSS4, L.VSS9 ],
               couplings = {(0,0):C.GC_490,(0,4):C.GC_484,(0,2):C.GC_534,(0,3):C.GC_622,(0,1):C.GC_515})

V_228 = Vertex(name = 'V_228',
               particles = [ P.W__minus__, P.G0, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VSS3 ],
               couplings = {(0,0):C.GC_621})

V_229 = Vertex(name = 'V_229',
               particles = [ P.W__minus__, P.G0, P.G__minus__, P.G__plus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VSSSS1, L.VSSSS29, L.VSSSS55, L.VSSSS59, L.VSSSS68, L.VSSSS69, L.VSSSS76, L.VSSSS87, L.VSSSS89 ],
               couplings = {(0,7):C.GC_240,(0,8):C.GC_252,(0,2):C.GC_238,(0,3):C.GC_245,(0,1):C.GC_536,(0,0):C.GC_638,(0,6):C.GC_668,(0,4):C.GC_662,(0,5):C.GC_672})

V_230 = Vertex(name = 'V_230',
               particles = [ P.W__minus__, P.G0, P.G__minus__, P.G__plus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VSSSS29 ],
               couplings = {(0,0):C.GC_1253})

V_231 = Vertex(name = 'V_231',
               particles = [ P.W__minus__, P.G0, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VSSS1, L.VSSS10, L.VSSS12, L.VSSS24, L.VSSS27, L.VSSS32, L.VSSS7, L.VSSS8 ],
               couplings = {(0,1):C.GC_528,(0,4):C.GC_1199,(0,2):C.GC_1234,(0,0):C.GC_1235,(0,7):C.GC_309,(0,5):C.GC_315,(0,6):C.GC_308,(0,3):C.GC_311})

V_232 = Vertex(name = 'V_232',
               particles = [ P.W__minus__, P.G0, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VSSS10 ],
               couplings = {(0,0):C.GC_626})

V_233 = Vertex(name = 'V_233',
               particles = [ P.W__minus__, P.G0, P.G__plus__, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VSSSS1, L.VSSSS28, L.VSSSS38, L.VSSSS57, L.VSSSS7, L.VSSSS72, L.VSSSS73, L.VSSSS79, L.VSSSS8, L.VSSSS97 ],
               couplings = {(0,8):C.GC_240,(0,9):C.GC_246,(0,4):C.GC_238,(0,3):C.GC_242,(0,1):C.GC_536,(0,2):C.GC_636,(0,0):C.GC_637,(0,6):C.GC_659,(0,5):C.GC_667,(0,7):C.GC_672})

V_234 = Vertex(name = 'V_234',
               particles = [ P.W__minus__, P.G0, P.G__plus__, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VSSSS28 ],
               couplings = {(0,0):C.GC_1254})

V_235 = Vertex(name = 'V_235',
               particles = [ P.W__minus__, P.G__minus__, P.G__plus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VSSS11, L.VSSS21, L.VSSS23, L.VSSS26, L.VSSS33 ],
               couplings = {(0,0):C.GC_532,(0,3):C.GC_1201,(0,1):C.GC_547,(0,4):C.GC_319,(0,2):C.GC_313})

V_236 = Vertex(name = 'V_236',
               particles = [ P.W__minus__, P.G__minus__, P.G__plus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VSSS11 ],
               couplings = {(0,0):C.GC_625})

V_237 = Vertex(name = 'V_237',
               particles = [ P.W__minus__, P.G__minus__, P.G__plus__, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VSSSS1, L.VSSSS100, L.VSSSS14, L.VSSSS40, L.VSSSS62, L.VSSSS63, L.VSSSS67, L.VSSSS74, L.VSSSS9, L.VSSSS99 ],
               couplings = {(0,1):C.GC_251,(0,9):C.GC_241,(0,5):C.GC_244,(0,4):C.GC_239,(0,8):C.GC_540,(0,2):C.GC_639,(0,0):C.GC_640,(0,7):C.GC_661,(0,3):C.GC_671,(0,6):C.GC_664})

V_238 = Vertex(name = 'V_238',
               particles = [ P.W__minus__, P.G__minus__, P.G__plus__, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VSSSS9 ],
               couplings = {(0,0):C.GC_1249})

V_239 = Vertex(name = 'V_239',
               particles = [ P.A, P.W__minus__, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSS3, L.VVSS30, L.VVSS35, L.VVSS36, L.VVSS44, L.VVSS45, L.VVSS46, L.VVSS51, L.VVSS52, L.VVSS53, L.VVSS54, L.VVSS55, L.VVSS65, L.VVSS69, L.VVSS70, L.VVSS73, L.VVSS75, L.VVSS76, L.VVSS77, L.VVSS78, L.VVSS79 ],
               couplings = {(0,0):C.GC_2344,(0,12):C.GC_2341,(0,7):C.GC_2365,(0,8):C.GC_2366,(0,11):C.GC_5335,(0,18):C.GC_5249,(0,19):C.GC_2363,(0,1):C.GC_2360,(0,20):C.GC_2356,(0,3):C.GC_2443,(0,13):C.GC_2440,(0,10):C.GC_5256,(0,9):C.GC_5261,(0,6):C.GC_5311,(0,2):C.GC_3846,(0,16):C.GC_5303,(0,14):C.GC_3843,(0,5):C.GC_5326,(0,17):C.GC_5316,(0,4):C.GC_3849,(0,15):C.GC_3845})

V_240 = Vertex(name = 'V_240',
               particles = [ P.A, P.W__minus__, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSS3, L.VVSS55, L.VVSS65 ],
               couplings = {(0,0):C.GC_5276,(0,2):C.GC_5272,(0,1):C.GC_5339})

V_241 = Vertex(name = 'V_241',
               particles = [ P.A, P.W__minus__, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSS55 ],
               couplings = {(0,0):C.GC_5332})

V_242 = Vertex(name = 'V_242',
               particles = [ P.A, P.W__minus__, P.G0, P.G0, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS107, L.VVSSSS116, L.VVSSSS124, L.VVSSSS136, L.VVSSSS3, L.VVSSSS43, L.VVSSSS45, L.VVSSSS63, L.VVSSSS82, L.VVSSSS87, L.VVSSSS97 ],
               couplings = {(0,4):C.GC_6890,(0,0):C.GC_6882,(0,7):C.GC_2452,(0,1):C.GC_2449,(0,5):C.GC_4592,(0,6):C.GC_4593,(0,10):C.GC_4596,(0,8):C.GC_4493,(0,3):C.GC_4487,(0,9):C.GC_4484,(0,2):C.GC_4481})

V_243 = Vertex(name = 'V_243',
               particles = [ P.A, P.W__minus__, P.G__plus__, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSS3, L.VVSSS38, L.VVSSS43, L.VVSSS54, L.VVSSS57, L.VVSSS68, L.VVSSS69, L.VVSSS78, L.VVSSS81, L.VVSSS85 ],
               couplings = {(0,2):C.GC_2399,(0,7):C.GC_2396,(0,0):C.GC_6938,(0,6):C.GC_6933,(0,3):C.GC_4426,(0,8):C.GC_4423,(0,4):C.GC_4434,(0,9):C.GC_4428,(0,1):C.GC_7178,(0,5):C.GC_4519})

V_244 = Vertex(name = 'V_244',
               particles = [ P.A, P.W__minus__, P.G__plus__, P.H, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS107, L.VVSSSS118, L.VVSSSS130, L.VVSSSS134, L.VVSSSS151, L.VVSSSS3, L.VVSSSS54, L.VVSSSS61, L.VVSSSS76, L.VVSSSS85 ],
               couplings = {(0,5):C.GC_6891,(0,0):C.GC_6884,(0,7):C.GC_2453,(0,1):C.GC_2448,(0,6):C.GC_7198,(0,4):C.GC_4596,(0,8):C.GC_4485,(0,2):C.GC_4480,(0,9):C.GC_4493,(0,3):C.GC_4487})

V_245 = Vertex(name = 'V_245',
               particles = [ P.W__minus__, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VSS10, L.VSS2, L.VSS9 ],
               couplings = {(0,0):C.GC_492,(0,2):C.GC_487,(0,1):C.GC_516})

V_246 = Vertex(name = 'V_246',
               particles = [ P.W__minus__, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VSS2 ],
               couplings = {(0,0):C.GC_1195})

V_247 = Vertex(name = 'V_247',
               particles = [ P.W__minus__, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VSS2 ],
               couplings = {(0,0):C.GC_1230})

V_248 = Vertex(name = 'V_248',
               particles = [ P.W__minus__, P.G__plus__, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VSSS21, L.VSSS23, L.VSSS26, L.VSSS33, L.VSSS34 ],
               couplings = {(0,2):C.GC_1198,(0,0):C.GC_549,(0,3):C.GC_310,(0,4):C.GC_318,(0,1):C.GC_499})

V_249 = Vertex(name = 'V_249',
               particles = [ P.W__minus__, P.G__plus__, P.H, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VSSSS56, L.VSSSS77, L.VSSSS80, L.VSSSS88, L.VSSSS95 ],
               couplings = {(0,3):C.GC_241,(0,4):C.GC_250,(0,0):C.GC_376,(0,1):C.GC_1295,(0,2):C.GC_671})

V_250 = Vertex(name = 'V_250',
               particles = [ P.A, P.W__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVS11, L.VVS15, L.VVS16, L.VVS3, L.VVS7 ],
               couplings = {(0,4):C.GC_5302,(0,2):C.GC_5300,(0,3):C.GC_2352,(0,1):C.GC_2351,(0,0):C.GC_5183})

V_251 = Vertex(name = 'V_251',
               particles = [ P.A, P.W__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVS11, L.VVS15, L.VVS3 ],
               couplings = {(0,2):C.GC_5270,(0,1):C.GC_5268,(0,0):C.GC_5337})

V_252 = Vertex(name = 'V_252',
               particles = [ P.A, P.W__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVS11 ],
               couplings = {(0,0):C.GC_5330})

V_253 = Vertex(name = 'V_253',
               particles = [ P.A, P.W__minus__, P.G0, P.G0, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSSS15, L.VVSSS22, L.VVSSS3, L.VVSSS39, L.VVSSS64, L.VVSSS69, L.VVSSS72, L.VVSSS76 ],
               couplings = {(0,3):C.GC_7004,(0,7):C.GC_6998,(0,2):C.GC_6937,(0,5):C.GC_6931,(0,1):C.GC_4434,(0,6):C.GC_4428,(0,0):C.GC_7178,(0,4):C.GC_4519})

V_254 = Vertex(name = 'V_254',
               particles = [ P.W__minus__, P.W__minus__, P.G0, P.G0, P.G__plus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS107, L.VVSSSS137, L.VVSSSS141, L.VVSSSS145, L.VVSSSS4, L.VVSSSS53, L.VVSSSS71, L.VVSSSS91 ],
               couplings = {(0,4):C.GC_228,(0,0):C.GC_223,(0,7):C.GC_792,(0,2):C.GC_937,(0,5):C.GC_949,(0,3):C.GC_940,(0,6):C.GC_764,(0,1):C.GC_761})

V_255 = Vertex(name = 'V_255',
               particles = [ P.W__minus__, P.W__minus__, P.G0, P.G0, P.G__plus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS91 ],
               couplings = {(0,0):C.GC_801})

V_256 = Vertex(name = 'V_256',
               particles = [ P.W__minus__, P.W__minus__, P.G__plus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSS20, L.VVSS38, L.VVSS4, L.VVSS55, L.VVSS61, L.VVSS65, L.VVSS74 ],
               couplings = {(0,0):C.GC_1347,(0,3):C.GC_784,(0,4):C.GC_797,(0,2):C.GC_271,(0,5):C.GC_270,(0,1):C.GC_657,(0,6):C.GC_656})

V_257 = Vertex(name = 'V_257',
               particles = [ P.W__minus__, P.W__minus__, P.G__plus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSS55 ],
               couplings = {(0,0):C.GC_821})

V_258 = Vertex(name = 'V_258',
               particles = [ P.W__minus__, P.W__minus__, P.G0, P.G__plus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSSS36, L.VVSSS4, L.VVSSS48, L.VVSSS58, L.VVSSS69, L.VVSSS88, L.VVSSS90, L.VVSSS93 ],
               couplings = {(0,2):C.GC_615,(0,5):C.GC_614,(0,1):C.GC_307,(0,4):C.GC_300,(0,3):C.GC_785,(0,7):C.GC_855,(0,0):C.GC_861,(0,6):C.GC_845})

V_259 = Vertex(name = 'V_259',
               particles = [ P.W__minus__, P.W__minus__, P.G0, P.G__plus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSSS58 ],
               couplings = {(0,0):C.GC_1376})

V_260 = Vertex(name = 'V_260',
               particles = [ P.W__minus__, P.W__minus__, P.G0, P.G__plus__, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS107, L.VVSSSS128, L.VVSSSS139, L.VVSSSS148, L.VVSSSS4, L.VVSSSS55, L.VVSSSS68, L.VVSSSS91 ],
               couplings = {(0,4):C.GC_229,(0,0):C.GC_222,(0,7):C.GC_790,(0,2):C.GC_944,(0,5):C.GC_951,(0,3):C.GC_934,(0,6):C.GC_763,(0,1):C.GC_762})

V_261 = Vertex(name = 'V_261',
               particles = [ P.W__minus__, P.W__minus__, P.G0, P.G__plus__, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS91 ],
               couplings = {(0,0):C.GC_1352})

V_262 = Vertex(name = 'V_262',
               particles = [ P.W__minus__, P.W__minus__, P.G__plus__, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSS37, L.VVSSS4, L.VVSSS47, L.VVSSS58, L.VVSSS69, L.VVSSS75, L.VVSSS87, L.VVSSS95 ],
               couplings = {(0,2):C.GC_616,(0,6):C.GC_613,(0,1):C.GC_305,(0,4):C.GC_302,(0,3):C.GC_787,(0,7):C.GC_849,(0,0):C.GC_860,(0,5):C.GC_851})

V_263 = Vertex(name = 'V_263',
               particles = [ P.W__minus__, P.W__minus__, P.G__plus__, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSS58 ],
               couplings = {(0,0):C.GC_1375})

V_264 = Vertex(name = 'V_264',
               particles = [ P.W__minus__, P.W__minus__, P.G__plus__, P.G__plus__, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS107, L.VVSSSS137, L.VVSSSS141, L.VVSSSS145, L.VVSSSS4, L.VVSSSS53, L.VVSSSS71, L.VVSSSS91 ],
               couplings = {(0,4):C.GC_227,(0,0):C.GC_224,(0,7):C.GC_793,(0,2):C.GC_938,(0,5):C.GC_950,(0,3):C.GC_939,(0,6):C.GC_764,(0,1):C.GC_761})

V_265 = Vertex(name = 'V_265',
               particles = [ P.W__minus__, P.W__minus__, P.G__plus__, P.G__plus__, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS91 ],
               couplings = {(0,0):C.GC_1351})

V_266 = Vertex(name = 'V_266',
               particles = [ P.A, P.A, P.W__minus__, P.G0, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVSS101, L.VVVSS133, L.VVVSS176, L.VVVSS250, L.VVVSS253, L.VVVSS259, L.VVVSS261, L.VVVSS262, L.VVVSS263, L.VVVSS292, L.VVVSS294, L.VVVSS298, L.VVVSS3, L.VVVSS331, L.VVVSS332, L.VVVSS342 ],
               couplings = {(0,12):C.GC_7441,(0,6):C.GC_5168,(0,5):C.GC_5174,(0,3):C.GC_7434,(0,7):C.GC_5156,(0,8):C.GC_5164,(0,9):C.GC_5150,(0,13):C.GC_7470,(0,0):C.GC_5153,(0,2):C.GC_5152,(0,4):C.GC_7376,(0,11):C.GC_7491,(0,10):C.GC_7505,(0,14):C.GC_7485,(0,1):C.GC_7457,(0,15):C.GC_7445})

V_267 = Vertex(name = 'V_267',
               particles = [ P.A, P.A, P.W__minus__, P.G0, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVSS250, L.VVVSS3 ],
               couplings = {(0,1):C.GC_7525,(0,0):C.GC_7405})

V_268 = Vertex(name = 'V_268',
               particles = [ P.A, P.A, P.W__minus__, P.G0, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVSS250, L.VVVSS3 ],
               couplings = {(0,1):C.GC_7412,(0,0):C.GC_7520})

V_269 = Vertex(name = 'V_269',
               particles = [ P.A, P.A, P.W__minus__, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVSS101, L.VVVSS132, L.VVVSS176, L.VVVSS250, L.VVVSS253, L.VVVSS270, L.VVVSS280, L.VVVSS292, L.VVVSS295, L.VVVSS299, L.VVVSS3, L.VVVSS316, L.VVVSS317, L.VVVSS333, L.VVVSS334, L.VVVSS341 ],
               couplings = {(0,10):C.GC_7439,(0,6):C.GC_5167,(0,5):C.GC_5171,(0,3):C.GC_7436,(0,7):C.GC_5149,(0,0):C.GC_5154,(0,2):C.GC_5151,(0,11):C.GC_5155,(0,12):C.GC_5159,(0,14):C.GC_7471,(0,4):C.GC_7378,(0,9):C.GC_7490,(0,8):C.GC_7496,(0,13):C.GC_7476,(0,1):C.GC_7462,(0,15):C.GC_7448})

V_270 = Vertex(name = 'V_270',
               particles = [ P.A, P.A, P.W__minus__, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVSS250, L.VVVSS3 ],
               couplings = {(0,1):C.GC_7524,(0,0):C.GC_7407})

V_271 = Vertex(name = 'V_271',
               particles = [ P.A, P.A, P.W__minus__, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVSS250, L.VVVSS3 ],
               couplings = {(0,1):C.GC_7410,(0,0):C.GC_7522})

V_272 = Vertex(name = 'V_272',
               particles = [ P.A, P.A, P.W__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVS115, L.VVVS117, L.VVVS123, L.VVVS124, L.VVVS125, L.VVVS3, L.VVVS42, L.VVVS76 ],
               couplings = {(0,2):C.GC_7419,(0,6):C.GC_7418,(0,7):C.GC_7415,(0,5):C.GC_7432,(0,0):C.GC_7431,(0,4):C.GC_7421,(0,3):C.GC_7422,(0,1):C.GC_7397})

V_273 = Vertex(name = 'V_273',
               particles = [ P.A, P.A, P.W__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVS115, L.VVVS3 ],
               couplings = {(0,1):C.GC_7533,(0,0):C.GC_7532})

V_274 = Vertex(name = 'V_274',
               particles = [ P.A, P.A, P.W__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVS115, L.VVVS3 ],
               couplings = {(0,1):C.GC_7403,(0,0):C.GC_7402})

V_275 = Vertex(name = 'V_275',
               particles = [ P.A, P.A, P.W__plus__, P.G__minus__, P.G__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVSSS139, L.VVVSSS187, L.VVVSSS3, L.VVVSSS57, L.VVVSSS96 ],
               couplings = {(0,2):C.GC_6307,(0,3):C.GC_6292,(0,0):C.GC_1780,(0,4):C.GC_1778,(0,1):C.GC_1662})

V_276 = Vertex(name = 'V_276',
               particles = [ P.A, P.A, P.W__plus__, P.G__minus__, P.G__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVSSS3, L.VVVSSS57 ],
               couplings = {(0,0):C.GC_6624,(0,1):C.GC_6606})

V_277 = Vertex(name = 'V_277',
               particles = [ P.A, P.A, P.W__plus__, P.G0, P.G__minus__, P.G__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVSSSS103, L.VVVSSSS155, L.VVVSSSS238, L.VVVSSSS286, L.VVVSSSS3, L.VVVSSSS317, L.VVVSSSS82 ],
               couplings = {(0,4):C.GC_6547,(0,0):C.GC_1760,(0,5):C.GC_1771,(0,6):C.GC_6516,(0,3):C.GC_1821,(0,2):C.GC_1810,(0,1):C.GC_1815})

V_278 = Vertex(name = 'V_278',
               particles = [ P.A, P.A, P.W__plus__, P.G0, P.G__minus__, P.G__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVSSSS3, L.VVVSSSS82 ],
               couplings = {(0,0):C.GC_6653,(0,1):C.GC_4198})

V_279 = Vertex(name = 'V_279',
               particles = [ P.A, P.A, P.W__plus__, P.G__minus__, P.G__minus__, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVSSSS1, L.VVVSSSS2, L.VVVSSSS41, L.VVVSSSS42, L.VVVSSSS43, L.VVVSSSS44, L.VVVSSSS45, L.VVVSSSS46, L.VVVSSSS53, L.VVVSSSS54, L.VVVSSSS55, L.VVVSSSS56, L.VVVSSSS57, L.VVVSSSS77, L.VVVSSSS78, L.VVVSSSS79, L.VVVSSSS80, L.VVVSSSS81 ],
               couplings = {(0,0):C.GC_6541,(0,1):C.GC_6539,(0,2):C.GC_6524,(0,3):C.GC_6524,(0,4):C.GC_1766,(0,5):C.GC_1766,(0,6):C.GC_1769,(0,7):C.GC_1770,(0,8):C.GC_6526,(0,9):C.GC_1765,(0,10):C.GC_1765,(0,11):C.GC_1768,(0,12):C.GC_1767,(0,13):C.GC_6526,(0,14):C.GC_1765,(0,15):C.GC_1765,(0,16):C.GC_1768,(0,17):C.GC_1767})

V_280 = Vertex(name = 'V_280',
               particles = [ P.A, P.A, P.W__plus__, P.G__minus__, P.G__minus__, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVSSSS1, L.VVVSSSS2, L.VVVSSSS41, L.VVVSSSS42, L.VVVSSSS43, L.VVVSSSS44, L.VVVSSSS45, L.VVVSSSS46, L.VVVSSSS53, L.VVVSSSS54, L.VVVSSSS55, L.VVVSSSS56, L.VVVSSSS57, L.VVVSSSS77, L.VVVSSSS78, L.VVVSSSS79, L.VVVSSSS80, L.VVVSSSS81 ],
               couplings = {(0,0):C.GC_6662,(0,1):C.GC_6647,(0,2):C.GC_6641,(0,3):C.GC_6641,(0,4):C.GC_1817,(0,5):C.GC_1817,(0,6):C.GC_1814,(0,7):C.GC_1820,(0,8):C.GC_6642,(0,9):C.GC_1816,(0,10):C.GC_1816,(0,11):C.GC_1819,(0,12):C.GC_1812,(0,13):C.GC_6642,(0,14):C.GC_1816,(0,15):C.GC_1816,(0,16):C.GC_1819,(0,17):C.GC_1812})

V_281 = Vertex(name = 'V_281',
               particles = [ P.A, P.W__plus__, P.G0, P.G__minus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSS1, L.VVSS10, L.VVSS11, L.VVSS12, L.VVSS14, L.VVSS16, L.VVSS17, L.VVSS18, L.VVSS19, L.VVSS21, L.VVSS23, L.VVSS25, L.VVSS26, L.VVSS27, L.VVSS28, L.VVSS3, L.VVSS30, L.VVSS32, L.VVSS33, L.VVSS40, L.VVSS41, L.VVSS42, L.VVSS5, L.VVSS55, L.VVSS56, L.VVSS57, L.VVSS58, L.VVSS59, L.VVSS6, L.VVSS62, L.VVSS63, L.VVSS64, L.VVSS7, L.VVSS8, L.VVSS9 ],
               couplings = {(0,15):C.GC_2345,(0,0):C.GC_2342,(0,11):C.GC_5267,(0,4):C.GC_5260,(0,23):C.GC_5334,(0,2):C.GC_5255,(0,6):C.GC_5248,(0,24):C.GC_2339,(0,21):C.GC_5267,(0,7):C.GC_5254,(0,18):C.GC_5260,(0,12):C.GC_5247,(0,3):C.GC_5247,(0,29):C.GC_5255,(0,10):C.GC_5254,(0,30):C.GC_5248,(0,16):C.GC_2359,(0,14):C.GC_2355,(0,31):C.GC_2358,(0,32):C.GC_5329,(0,22):C.GC_5314,(0,9):C.GC_5310,(0,34):C.GC_5307,(0,25):C.GC_5321,(0,27):C.GC_5305,(0,13):C.GC_5266,(0,8):C.GC_5259,(0,20):C.GC_5266,(0,17):C.GC_5259,(0,33):C.GC_5323,(0,28):C.GC_5315,(0,19):C.GC_5323,(0,1):C.GC_5322,(0,5):C.GC_5315,(0,26):C.GC_5322})

V_282 = Vertex(name = 'V_282',
               particles = [ P.A, P.W__plus__, P.G0, P.G__minus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSS1, L.VVSS3, L.VVSS55, L.VVSS56 ],
               couplings = {(0,1):C.GC_5275,(0,0):C.GC_5271,(0,2):C.GC_5340,(0,3):C.GC_5274})

V_283 = Vertex(name = 'V_283',
               particles = [ P.A, P.W__plus__, P.G0, P.G__minus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSS55 ],
               couplings = {(0,0):C.GC_5333})

V_284 = Vertex(name = 'V_284',
               particles = [ P.A, P.W__plus__, P.G0, P.G0, P.G0, P.G__minus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS1, L.VVSSSS10, L.VVSSSS100, L.VVSSSS101, L.VVSSSS102, L.VVSSSS11, L.VVSSSS12, L.VVSSSS14, L.VVSSSS15, L.VVSSSS16, L.VVSSSS19, L.VVSSSS21, L.VVSSSS22, L.VVSSSS23, L.VVSSSS24, L.VVSSSS25, L.VVSSSS26, L.VVSSSS28, L.VVSSSS29, L.VVSSSS3, L.VVSSSS30, L.VVSSSS31, L.VVSSSS32, L.VVSSSS33, L.VVSSSS34, L.VVSSSS35, L.VVSSSS36, L.VVSSSS37, L.VVSSSS39, L.VVSSSS40, L.VVSSSS41, L.VVSSSS5, L.VVSSSS56, L.VVSSSS6, L.VVSSSS7, L.VVSSSS73, L.VVSSSS74, L.VVSSSS75, L.VVSSSS8, L.VVSSSS9, L.VVSSSS92, L.VVSSSS93, L.VVSSSS94, L.VVSSSS95, L.VVSSSS96, L.VVSSSS97, L.VVSSSS98, L.VVSSSS99 ],
               couplings = {(0,19):C.GC_6888,(0,0):C.GC_6880,(0,40):C.GC_6887,(0,34):C.GC_7155,(0,31):C.GC_7152,(0,7):C.GC_7155,(0,39):C.GC_7152,(0,17):C.GC_7155,(0,11):C.GC_7152,(0,32):C.GC_7140,(0,24):C.GC_7136,(0,41):C.GC_7144,(0,43):C.GC_7144,(0,46):C.GC_7144,(0,4):C.GC_7135,(0,1):C.GC_7196,(0,6):C.GC_7196,(0,12):C.GC_7196,(0,13):C.GC_7196,(0,15):C.GC_7196,(0,16):C.GC_7196,(0,45):C.GC_4595,(0,2):C.GC_4595,(0,3):C.GC_4595,(0,38):C.GC_7156,(0,33):C.GC_7145,(0,8):C.GC_7156,(0,9):C.GC_4494,(0,10):C.GC_4494,(0,5):C.GC_7145,(0,18):C.GC_7156,(0,20):C.GC_4494,(0,21):C.GC_4494,(0,22):C.GC_4494,(0,23):C.GC_4494,(0,14):C.GC_7145,(0,35):C.GC_7156,(0,36):C.GC_7156,(0,37):C.GC_7156,(0,25):C.GC_7154,(0,26):C.GC_7154,(0,27):C.GC_7154,(0,28):C.GC_7145,(0,29):C.GC_7145,(0,30):C.GC_7145,(0,42):C.GC_7154,(0,44):C.GC_7154,(0,47):C.GC_7154})

V_285 = Vertex(name = 'V_285',
               particles = [ P.A, P.W__plus__, P.G0, P.G__minus__, P.G__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS1, L.VVSSSS10, L.VVSSSS100, L.VVSSSS101, L.VVSSSS102, L.VVSSSS103, L.VVSSSS104, L.VVSSSS105, L.VVSSSS106, L.VVSSSS11, L.VVSSSS12, L.VVSSSS14, L.VVSSSS15, L.VVSSSS19, L.VVSSSS21, L.VVSSSS22, L.VVSSSS23, L.VVSSSS24, L.VVSSSS25, L.VVSSSS26, L.VVSSSS28, L.VVSSSS29, L.VVSSSS3, L.VVSSSS32, L.VVSSSS34, L.VVSSSS35, L.VVSSSS36, L.VVSSSS37, L.VVSSSS38, L.VVSSSS39, L.VVSSSS40, L.VVSSSS41, L.VVSSSS5, L.VVSSSS56, L.VVSSSS57, L.VVSSSS6, L.VVSSSS7, L.VVSSSS74, L.VVSSSS75, L.VVSSSS8, L.VVSSSS9, L.VVSSSS91, L.VVSSSS92, L.VVSSSS93, L.VVSSSS94, L.VVSSSS95, L.VVSSSS96, L.VVSSSS97, L.VVSSSS98, L.VVSSSS99 ],
               couplings = {(0,22):C.GC_7576,(0,0):C.GC_7572,(0,41):C.GC_7798,(0,42):C.GC_7575,(0,36):C.GC_7759,(0,32):C.GC_7752,(0,11):C.GC_7758,(0,40):C.GC_7748,(0,20):C.GC_7758,(0,14):C.GC_7748,(0,43):C.GC_7751,(0,45):C.GC_7749,(0,48):C.GC_7749,(0,1):C.GC_7775,(0,10):C.GC_7765,(0,15):C.GC_7775,(0,16):C.GC_7847,(0,18):C.GC_7765,(0,19):C.GC_7847,(0,25):C.GC_7846,(0,26):C.GC_7774,(0,27):C.GC_7774,(0,29):C.GC_7835,(0,30):C.GC_7764,(0,31):C.GC_7764,(0,47):C.GC_7838,(0,2):C.GC_7838,(0,6):C.GC_7840,(0,3):C.GC_7840,(0,7):C.GC_7853,(0,8):C.GC_7853,(0,39):C.GC_7779,(0,35):C.GC_7763,(0,12):C.GC_7788,(0,13):C.GC_7781,(0,9):C.GC_7774,(0,21):C.GC_7788,(0,23):C.GC_7781,(0,17):C.GC_7774,(0,33):C.GC_7789,(0,34):C.GC_7789,(0,37):C.GC_7780,(0,38):C.GC_7780,(0,24):C.GC_7762,(0,28):C.GC_7776,(0,4):C.GC_7776,(0,44):C.GC_7777,(0,46):C.GC_7764,(0,49):C.GC_7764,(0,5):C.GC_7762})

V_286 = Vertex(name = 'V_286',
               particles = [ P.A, P.W__plus__, P.G0, P.G__minus__, P.G__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS10, L.VVSSSS12, L.VVSSSS22, L.VVSSSS25, L.VVSSSS36, L.VVSSSS37, L.VVSSSS40, L.VVSSSS41, L.VVSSSS91 ],
               couplings = {(0,8):C.GC_7791,(0,0):C.GC_7852,(0,1):C.GC_7844,(0,2):C.GC_7852,(0,3):C.GC_7844,(0,4):C.GC_7853,(0,5):C.GC_7853,(0,6):C.GC_7845,(0,7):C.GC_7845})

V_287 = Vertex(name = 'V_287',
               particles = [ P.A, P.W__plus__, P.G0, P.G__minus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSS1, L.VVSSS11, L.VVSSS12, L.VVSSS14, L.VVSSS16, L.VVSSS21, L.VVSSS24, L.VVSSS25, L.VVSSS29, L.VVSSS3, L.VVSSS39, L.VVSSS5, L.VVSSS50, L.VVSSS59, L.VVSSS6, L.VVSSS60, L.VVSSS61, L.VVSSS62, L.VVSSS65, L.VVSSS7, L.VVSSS8 ],
               couplings = {(0,19):C.GC_7018,(0,11):C.GC_7006,(0,4):C.GC_7003,(0,1):C.GC_7000,(0,15):C.GC_7012,(0,17):C.GC_6999,(0,9):C.GC_6936,(0,0):C.GC_6930,(0,13):C.GC_6935,(0,20):C.GC_7014,(0,14):C.GC_7007,(0,5):C.GC_7014,(0,2):C.GC_7013,(0,3):C.GC_7007,(0,10):C.GC_4431,(0,12):C.GC_4435,(0,6):C.GC_4430,(0,7):C.GC_4427,(0,8):C.GC_4430,(0,18):C.GC_4427,(0,16):C.GC_7013})

V_288 = Vertex(name = 'V_288',
               particles = [ P.A, P.W__plus__, P.G0, P.G__minus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSS25, L.VVSSS29 ],
               couplings = {(0,0):C.GC_7177,(0,1):C.GC_7179})

V_289 = Vertex(name = 'V_289',
               particles = [ P.A, P.W__plus__, P.G0, P.G__minus__, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS1, L.VVSSSS10, L.VVSSSS102, L.VVSSSS106, L.VVSSSS12, L.VVSSSS14, L.VVSSSS19, L.VVSSSS21, L.VVSSSS22, L.VVSSSS25, L.VVSSSS28, L.VVSSSS3, L.VVSSSS32, L.VVSSSS34, L.VVSSSS35, L.VVSSSS37, L.VVSSSS39, L.VVSSSS41, L.VVSSSS5, L.VVSSSS56, L.VVSSSS6, L.VVSSSS60, L.VVSSSS7, L.VVSSSS73, L.VVSSSS75, L.VVSSSS8, L.VVSSSS9, L.VVSSSS92, L.VVSSSS93, L.VVSSSS94, L.VVSSSS95, L.VVSSSS98 ],
               couplings = {(0,11):C.GC_6889,(0,0):C.GC_6881,(0,27):C.GC_6886,(0,22):C.GC_7161,(0,18):C.GC_7143,(0,5):C.GC_7139,(0,26):C.GC_7134,(0,28):C.GC_7153,(0,30):C.GC_7133,(0,8):C.GC_4486,(0,9):C.GC_4489,(0,14):C.GC_4486,(0,15):C.GC_7196,(0,16):C.GC_4489,(0,17):C.GC_7196,(0,3):C.GC_4595,(0,25):C.GC_7156,(0,20):C.GC_7145,(0,6):C.GC_7156,(0,1):C.GC_7154,(0,4):C.GC_7145,(0,10):C.GC_4490,(0,12):C.GC_4495,(0,7):C.GC_4489,(0,19):C.GC_4490,(0,21):C.GC_4494,(0,23):C.GC_4495,(0,24):C.GC_4494,(0,13):C.GC_4489,(0,31):C.GC_4486,(0,2):C.GC_4486,(0,29):C.GC_7154})

V_290 = Vertex(name = 'V_290',
               particles = [ P.A, P.W__plus__, P.G0, P.G__minus__, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS22, L.VVSSSS25, L.VVSSSS35, L.VVSSSS39 ],
               couplings = {(0,0):C.GC_7197,(0,1):C.GC_7201,(0,2):C.GC_7197,(0,3):C.GC_7201})

V_291 = Vertex(name = 'V_291',
               particles = [ P.W__plus__, P.G0, P.G0, P.G0, P.G__minus__ ],
               color = [ '1' ],
               lorentz = [ L.VSSSS1, L.VSSSS10, L.VSSSS13, L.VSSSS17, L.VSSSS19, L.VSSSS2, L.VSSSS20, L.VSSSS21, L.VSSSS22, L.VSSSS23, L.VSSSS32, L.VSSSS33, L.VSSSS34, L.VSSSS35, L.VSSSS36, L.VSSSS37, L.VSSSS42, L.VSSSS44, L.VSSSS45, L.VSSSS46, L.VSSSS48, L.VSSSS49, L.VSSSS50, L.VSSSS51, L.VSSSS52, L.VSSSS6, L.VSSSS8, L.VSSSS84, L.VSSSS85, L.VSSSS86 ],
               couplings = {(0,25):C.GC_247,(0,26):C.GC_247,(0,3):C.GC_247,(0,7):C.GC_247,(0,8):C.GC_247,(0,9):C.GC_247,(0,27):C.GC_384,(0,28):C.GC_384,(0,29):C.GC_384,(0,10):C.GC_379,(0,11):C.GC_379,(0,13):C.GC_379,(0,16):C.GC_374,(0,17):C.GC_374,(0,20):C.GC_374,(0,0):C.GC_634,(0,5):C.GC_634,(0,1):C.GC_634,(0,2):C.GC_1303,(0,12):C.GC_669,(0,4):C.GC_1303,(0,14):C.GC_669,(0,18):C.GC_1290,(0,21):C.GC_1290,(0,6):C.GC_1303,(0,15):C.GC_669,(0,19):C.GC_1290,(0,22):C.GC_1290,(0,23):C.GC_1290,(0,24):C.GC_1290})

V_292 = Vertex(name = 'V_292',
               particles = [ P.W__plus__, P.G0, P.G0, P.G__minus__ ],
               color = [ '1' ],
               lorentz = [ L.VSSS1, L.VSSS15, L.VSSS2, L.VSSS20, L.VSSS21, L.VSSS6, L.VSSS8 ],
               couplings = {(0,0):C.GC_530,(0,2):C.GC_530,(0,1):C.GC_548,(0,3):C.GC_1197,(0,4):C.GC_1197,(0,5):C.GC_316,(0,6):C.GC_316})

V_293 = Vertex(name = 'V_293',
               particles = [ P.W__plus__, P.G0, P.G0, P.G__minus__ ],
               color = [ '1' ],
               lorentz = [ L.VSSS1, L.VSSS2 ],
               couplings = {(0,0):C.GC_1237,(0,1):C.GC_1237})

V_294 = Vertex(name = 'V_294',
               particles = [ P.W__plus__, P.G0, P.G0, P.G__minus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VSSSS1, L.VSSSS13, L.VSSSS19, L.VSSSS2, L.VSSSS20, L.VSSSS31, L.VSSSS32, L.VSSSS33, L.VSSSS34, L.VSSSS35, L.VSSSS36, L.VSSSS37, L.VSSSS42, L.VSSSS44, L.VSSSS45, L.VSSSS46, L.VSSSS48, L.VSSSS51, L.VSSSS52, L.VSSSS6, L.VSSSS8, L.VSSSS84, L.VSSSS85, L.VSSSS86 ],
               couplings = {(0,19):C.GC_248,(0,20):C.GC_248,(0,21):C.GC_251,(0,22):C.GC_251,(0,23):C.GC_382,(0,6):C.GC_244,(0,7):C.GC_244,(0,9):C.GC_375,(0,12):C.GC_243,(0,13):C.GC_243,(0,16):C.GC_378,(0,0):C.GC_538,(0,3):C.GC_538,(0,5):C.GC_539,(0,1):C.GC_670,(0,8):C.GC_1300,(0,2):C.GC_1292,(0,10):C.GC_1293,(0,14):C.GC_665,(0,4):C.GC_1292,(0,11):C.GC_1293,(0,15):C.GC_665,(0,17):C.GC_1294,(0,18):C.GC_1294})

V_295 = Vertex(name = 'V_295',
               particles = [ P.W__plus__, P.G0, P.G0, P.G__minus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VSSSS1, L.VSSSS2, L.VSSSS31 ],
               couplings = {(0,0):C.GC_1251,(0,1):C.GC_1251,(0,2):C.GC_1252})

V_296 = Vertex(name = 'V_296',
               particles = [ P.A, P.W__plus__, P.G__minus__, P.G__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSSS1, L.VVSSS11, L.VVSSS12, L.VVSSS13, L.VVSSS14, L.VVSSS16, L.VVSSS17, L.VVSSS24, L.VVSSS25, L.VVSSS26, L.VVSSS28, L.VVSSS29, L.VVSSS3, L.VVSSS30, L.VVSSS39, L.VVSSS40, L.VVSSS5, L.VVSSS50, L.VVSSS51, L.VVSSS58, L.VVSSS59, L.VVSSS6, L.VVSSS60, L.VVSSS61, L.VVSSS62, L.VVSSS63, L.VVSSS64, L.VVSSS65, L.VVSSS66, L.VVSSS67, L.VVSSS68, L.VVSSS7, L.VVSSS8 ],
               couplings = {(0,31):C.GC_7644,(0,16):C.GC_7643,(0,5):C.GC_7644,(0,1):C.GC_7643,(0,22):C.GC_7642,(0,24):C.GC_7642,(0,12):C.GC_7599,(0,0):C.GC_7597,(0,19):C.GC_7823,(0,20):C.GC_7598,(0,32):C.GC_7650,(0,21):C.GC_7646,(0,6):C.GC_7650,(0,3):C.GC_7646,(0,14):C.GC_7652,(0,15):C.GC_7652,(0,17):C.GC_7649,(0,18):C.GC_7649,(0,7):C.GC_7647,(0,8):C.GC_7646,(0,9):C.GC_7646,(0,10):C.GC_7648,(0,11):C.GC_7645,(0,13):C.GC_7645,(0,27):C.GC_7648,(0,23):C.GC_7645,(0,25):C.GC_7645,(0,28):C.GC_7647,(0,2):C.GC_7833,(0,4):C.GC_7833,(0,26):C.GC_7831,(0,29):C.GC_7834,(0,30):C.GC_7834})

V_297 = Vertex(name = 'V_297',
               particles = [ P.A, P.W__plus__, P.G__minus__, P.G__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSSS25, L.VVSSS26, L.VVSSS29, L.VVSSS30, L.VVSSS58 ],
               couplings = {(0,4):C.GC_7790,(0,0):C.GC_7834,(0,1):C.GC_7834,(0,2):C.GC_7832,(0,3):C.GC_7832})

V_298 = Vertex(name = 'V_298',
               particles = [ P.A, P.W__plus__, P.G__minus__, P.G__minus__, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS1, L.VVSSSS10, L.VVSSSS100, L.VVSSSS101, L.VVSSSS102, L.VVSSSS103, L.VVSSSS104, L.VVSSSS105, L.VVSSSS106, L.VVSSSS11, L.VVSSSS12, L.VVSSSS14, L.VVSSSS15, L.VVSSSS21, L.VVSSSS22, L.VVSSSS23, L.VVSSSS24, L.VVSSSS25, L.VVSSSS26, L.VVSSSS28, L.VVSSSS29, L.VVSSSS3, L.VVSSSS32, L.VVSSSS33, L.VVSSSS34, L.VVSSSS35, L.VVSSSS36, L.VVSSSS37, L.VVSSSS38, L.VVSSSS39, L.VVSSSS40, L.VVSSSS41, L.VVSSSS5, L.VVSSSS56, L.VVSSSS57, L.VVSSSS6, L.VVSSSS7, L.VVSSSS73, L.VVSSSS74, L.VVSSSS8, L.VVSSSS9, L.VVSSSS91, L.VVSSSS92, L.VVSSSS93, L.VVSSSS94, L.VVSSSS95, L.VVSSSS96, L.VVSSSS97, L.VVSSSS98, L.VVSSSS99 ],
               couplings = {(0,21):C.GC_7577,(0,0):C.GC_7573,(0,41):C.GC_7797,(0,42):C.GC_7574,(0,36):C.GC_7757,(0,32):C.GC_7754,(0,11):C.GC_7757,(0,40):C.GC_7754,(0,33):C.GC_7761,(0,24):C.GC_7746,(0,43):C.GC_7747,(0,45):C.GC_7747,(0,4):C.GC_7755,(0,1):C.GC_7848,(0,10):C.GC_7848,(0,14):C.GC_7768,(0,15):C.GC_7768,(0,17):C.GC_7766,(0,18):C.GC_7766,(0,25):C.GC_7767,(0,26):C.GC_7767,(0,27):C.GC_7837,(0,29):C.GC_7769,(0,30):C.GC_7769,(0,31):C.GC_7851,(0,47):C.GC_7842,(0,2):C.GC_7850,(0,6):C.GC_7836,(0,3):C.GC_7850,(0,7):C.GC_7836,(0,8):C.GC_7842,(0,39):C.GC_7783,(0,35):C.GC_7768,(0,12):C.GC_7783,(0,9):C.GC_7768,(0,19):C.GC_7787,(0,20):C.GC_7787,(0,22):C.GC_7782,(0,23):C.GC_7782,(0,13):C.GC_7770,(0,16):C.GC_7772,(0,34):C.GC_7786,(0,37):C.GC_7784,(0,38):C.GC_7784,(0,28):C.GC_7771,(0,48):C.GC_7772,(0,44):C.GC_7766,(0,46):C.GC_7766,(0,49):C.GC_7770,(0,5):C.GC_7773})

V_299 = Vertex(name = 'V_299',
               particles = [ P.A, P.W__plus__, P.G__minus__, P.G__minus__, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS22, L.VVSSSS23, L.VVSSSS25, L.VVSSSS26, L.VVSSSS35, L.VVSSSS36, L.VVSSSS39, L.VVSSSS40, L.VVSSSS91 ],
               couplings = {(0,8):C.GC_7792,(0,0):C.GC_7850,(0,1):C.GC_7850,(0,2):C.GC_7843,(0,3):C.GC_7843,(0,4):C.GC_7841,(0,5):C.GC_7841,(0,6):C.GC_7849,(0,7):C.GC_7849})

V_300 = Vertex(name = 'V_300',
               particles = [ P.W__plus__, P.G0, P.G__minus__ ],
               color = [ '1' ],
               lorentz = [ L.VSS1, L.VSS10, L.VSS5, L.VSS6, L.VSS7 ],
               couplings = {(0,1):C.GC_493,(0,3):C.GC_489,(0,4):C.GC_485,(0,0):C.GC_515,(0,2):C.GC_518})

V_301 = Vertex(name = 'V_301',
               particles = [ P.W__plus__, P.G0, P.G__minus__ ],
               color = [ '1' ],
               lorentz = [ L.VSS1, L.VSS5 ],
               couplings = {(0,0):C.GC_534,(0,1):C.GC_535})

V_302 = Vertex(name = 'V_302',
               particles = [ P.W__plus__, P.G0, P.G__minus__ ],
               color = [ '1' ],
               lorentz = [ L.VSS1, L.VSS5 ],
               couplings = {(0,0):C.GC_1233,(0,1):C.GC_1232})

V_303 = Vertex(name = 'V_303',
               particles = [ P.W__plus__, P.G0, P.G__minus__, P.G__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VSSSS1, L.VSSSS10, L.VSSSS11, L.VSSSS16, L.VSSSS2, L.VSSSS22, L.VSSSS3, L.VSSSS31, L.VSSSS33, L.VSSSS34, L.VSSSS35, L.VSSSS36, L.VSSSS37, L.VSSSS44, L.VSSSS45, L.VSSSS46, L.VSSSS48, L.VSSSS49, L.VSSSS5, L.VSSSS50, L.VSSSS51, L.VSSSS52, L.VSSSS8, L.VSSSS85, L.VSSSS86 ],
               couplings = {(0,22):C.GC_381,(0,5):C.GC_381,(0,23):C.GC_246,(0,24):C.GC_246,(0,6):C.GC_373,(0,2):C.GC_373,(0,18):C.GC_380,(0,8):C.GC_242,(0,3):C.GC_380,(0,10):C.GC_242,(0,13):C.GC_245,(0,16):C.GC_245,(0,4):C.GC_541,(0,1):C.GC_541,(0,7):C.GC_536,(0,0):C.GC_638,(0,9):C.GC_662,(0,11):C.GC_662,(0,14):C.GC_668,(0,17):C.GC_668,(0,12):C.GC_663,(0,15):C.GC_672,(0,19):C.GC_1298,(0,20):C.GC_672,(0,21):C.GC_1298})

V_304 = Vertex(name = 'V_304',
               particles = [ P.W__plus__, P.G0, P.G__minus__, P.G__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VSSSS10, L.VSSSS2, L.VSSSS31 ],
               couplings = {(0,1):C.GC_1247,(0,0):C.GC_1247,(0,2):C.GC_1253})

V_305 = Vertex(name = 'V_305',
               particles = [ P.W__plus__, P.G0, P.G__minus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VSSS1, L.VSSS12, L.VSSS13, L.VSSS15, L.VSSS17, L.VSSS21, L.VSSS3, L.VSSS30, L.VSSS5, L.VSSS8 ],
               couplings = {(0,0):C.GC_528,(0,1):C.GC_533,(0,3):C.GC_1199,(0,5):C.GC_1196,(0,9):C.GC_503,(0,7):C.GC_315,(0,6):C.GC_501,(0,2):C.GC_311,(0,8):C.GC_497,(0,4):C.GC_314})

V_306 = Vertex(name = 'V_306',
               particles = [ P.W__plus__, P.G0, P.G__minus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VSSS1, L.VSSS12 ],
               couplings = {(0,0):C.GC_1239,(0,1):C.GC_1236})

V_307 = Vertex(name = 'V_307',
               particles = [ P.W__plus__, P.G0, P.G__minus__, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VSSSS1, L.VSSSS10, L.VSSSS11, L.VSSSS13, L.VSSSS16, L.VSSSS20, L.VSSSS22, L.VSSSS3, L.VSSSS31, L.VSSSS32, L.VSSSS34, L.VSSSS36, L.VSSSS37, L.VSSSS42, L.VSSSS46, L.VSSSS49, L.VSSSS5, L.VSSSS50, L.VSSSS51, L.VSSSS52, L.VSSSS53, L.VSSSS8, L.VSSSS84, L.VSSSS86 ],
               couplings = {(0,21):C.GC_384,(0,6):C.GC_246,(0,20):C.GC_247,(0,22):C.GC_246,(0,23):C.GC_247,(0,7):C.GC_379,(0,2):C.GC_242,(0,9):C.GC_242,(0,16):C.GC_374,(0,4):C.GC_245,(0,13):C.GC_245,(0,0):C.GC_536,(0,1):C.GC_541,(0,8):C.GC_541,(0,3):C.GC_1296,(0,10):C.GC_1296,(0,11):C.GC_668,(0,15):C.GC_668,(0,5):C.GC_1291,(0,12):C.GC_1290,(0,14):C.GC_1291,(0,17):C.GC_1290,(0,18):C.GC_1302,(0,19):C.GC_669})

V_308 = Vertex(name = 'V_308',
               particles = [ P.W__plus__, P.G0, P.G__minus__, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VSSSS1, L.VSSSS10, L.VSSSS31 ],
               couplings = {(0,0):C.GC_1255,(0,1):C.GC_1246,(0,2):C.GC_1246})

V_309 = Vertex(name = 'V_309',
               particles = [ P.W__plus__, P.G__minus__, P.G__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VSSS1, L.VSSS12, L.VSSS13, L.VSSS14, L.VSSS15, L.VSSS17, L.VSSS19, L.VSSS2, L.VSSS20, L.VSSS21, L.VSSS30, L.VSSS31 ],
               couplings = {(0,0):C.GC_530,(0,7):C.GC_530,(0,1):C.GC_531,(0,4):C.GC_546,(0,8):C.GC_1200,(0,9):C.GC_1200,(0,10):C.GC_318,(0,11):C.GC_318,(0,2):C.GC_312,(0,3):C.GC_312,(0,5):C.GC_313,(0,6):C.GC_313})

V_310 = Vertex(name = 'V_310',
               particles = [ P.W__plus__, P.G__minus__, P.G__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VSSS1, L.VSSS12, L.VSSS2 ],
               couplings = {(0,0):C.GC_623,(0,2):C.GC_623,(0,1):C.GC_624})

V_311 = Vertex(name = 'V_311',
               particles = [ P.W__plus__, P.G__minus__, P.G__minus__, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VSSSS1, L.VSSSS10, L.VSSSS11, L.VSSSS12, L.VSSSS13, L.VSSSS16, L.VSSSS18, L.VSSSS19, L.VSSSS2, L.VSSSS20, L.VSSSS22, L.VSSSS23, L.VSSSS32, L.VSSSS33, L.VSSSS36, L.VSSSS37, L.VSSSS42, L.VSSSS44, L.VSSSS49, L.VSSSS50, L.VSSSS51, L.VSSSS52, L.VSSSS84, L.VSSSS85 ],
               couplings = {(0,10):C.GC_250,(0,11):C.GC_250,(0,22):C.GC_383,(0,23):C.GC_383,(0,2):C.GC_243,(0,12):C.GC_377,(0,3):C.GC_243,(0,13):C.GC_377,(0,5):C.GC_244,(0,6):C.GC_244,(0,16):C.GC_376,(0,17):C.GC_376,(0,0):C.GC_538,(0,8):C.GC_538,(0,1):C.GC_539,(0,4):C.GC_666,(0,7):C.GC_1299,(0,14):C.GC_671,(0,18):C.GC_661,(0,9):C.GC_1299,(0,15):C.GC_671,(0,19):C.GC_661,(0,20):C.GC_665,(0,21):C.GC_665})

V_312 = Vertex(name = 'V_312',
               particles = [ P.W__plus__, P.G__minus__, P.G__minus__, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VSSSS1, L.VSSSS10, L.VSSSS2 ],
               couplings = {(0,0):C.GC_1248,(0,2):C.GC_1248,(0,1):C.GC_1250})

V_313 = Vertex(name = 'V_313',
               particles = [ P.A, P.W__plus__, P.G__minus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSS1, L.VVSS10, L.VVSS11, L.VVSS12, L.VVSS14, L.VVSS15, L.VVSS16, L.VVSS17, L.VVSS18, L.VVSS19, L.VVSS21, L.VVSS22, L.VVSS23, L.VVSS25, L.VVSS26, L.VVSS27, L.VVSS28, L.VVSS3, L.VVSS30, L.VVSS32, L.VVSS33, L.VVSS40, L.VVSS41, L.VVSS42, L.VVSS5, L.VVSS55, L.VVSS56, L.VVSS57, L.VVSS59, L.VVSS60, L.VVSS62, L.VVSS63, L.VVSS64, L.VVSS7, L.VVSS9 ],
               couplings = {(0,17):C.GC_2344,(0,0):C.GC_2341,(0,13):C.GC_5263,(0,4):C.GC_5265,(0,25):C.GC_5335,(0,2):C.GC_5251,(0,7):C.GC_5253,(0,26):C.GC_2340,(0,23):C.GC_5263,(0,8):C.GC_5250,(0,20):C.GC_5265,(0,14):C.GC_5252,(0,3):C.GC_5252,(0,30):C.GC_5251,(0,12):C.GC_5250,(0,31):C.GC_5253,(0,18):C.GC_2360,(0,16):C.GC_2356,(0,32):C.GC_2357,(0,33):C.GC_5312,(0,24):C.GC_5304,(0,10):C.GC_5325,(0,34):C.GC_5319,(0,27):C.GC_5308,(0,28):C.GC_5318,(0,15):C.GC_5262,(0,9):C.GC_5264,(0,22):C.GC_5262,(0,19):C.GC_5264,(0,11):C.GC_5324,(0,21):C.GC_5327,(0,1):C.GC_5317,(0,5):C.GC_5317,(0,6):C.GC_5320,(0,29):C.GC_5320})

V_314 = Vertex(name = 'V_314',
               particles = [ P.A, P.W__plus__, P.G__minus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSS1, L.VVSS3, L.VVSS55, L.VVSS56 ],
               couplings = {(0,1):C.GC_5276,(0,0):C.GC_5272,(0,2):C.GC_5339,(0,3):C.GC_5273})

V_315 = Vertex(name = 'V_315',
               particles = [ P.A, P.W__plus__, P.G__minus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSS55 ],
               couplings = {(0,0):C.GC_5332})

V_316 = Vertex(name = 'V_316',
               particles = [ P.A, P.W__plus__, P.G0, P.G0, P.G__minus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS1, L.VVSSSS10, L.VVSSSS102, L.VVSSSS103, L.VVSSSS12, L.VVSSSS14, L.VVSSSS16, L.VVSSSS19, L.VVSSSS21, L.VVSSSS28, L.VVSSSS3, L.VVSSSS34, L.VVSSSS35, L.VVSSSS36, L.VVSSSS37, L.VVSSSS38, L.VVSSSS39, L.VVSSSS40, L.VVSSSS41, L.VVSSSS5, L.VVSSSS56, L.VVSSSS57, L.VVSSSS7, L.VVSSSS73, L.VVSSSS74, L.VVSSSS75, L.VVSSSS9, L.VVSSSS92, L.VVSSSS93, L.VVSSSS95, L.VVSSSS97, L.VVSSSS98 ],
               couplings = {(0,10):C.GC_6890,(0,0):C.GC_6882,(0,27):C.GC_6883,(0,9):C.GC_7141,(0,8):C.GC_7132,(0,20):C.GC_7159,(0,11):C.GC_7148,(0,31):C.GC_7137,(0,2):C.GC_7149,(0,1):C.GC_7198,(0,4):C.GC_7198,(0,12):C.GC_4488,(0,13):C.GC_4488,(0,16):C.GC_4487,(0,17):C.GC_4487,(0,30):C.GC_4596,(0,22):C.GC_4492,(0,19):C.GC_4488,(0,5):C.GC_4492,(0,6):C.GC_4491,(0,7):C.GC_4491,(0,26):C.GC_4488,(0,21):C.GC_7157,(0,23):C.GC_4492,(0,24):C.GC_4492,(0,25):C.GC_7160,(0,14):C.GC_7146,(0,15):C.GC_7146,(0,18):C.GC_7151,(0,28):C.GC_4487,(0,29):C.GC_4487,(0,3):C.GC_7151})

V_317 = Vertex(name = 'V_317',
               particles = [ P.A, P.W__plus__, P.G0, P.G0, P.G__minus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS35, L.VVSSSS36, L.VVSSSS39, L.VVSSSS40 ],
               couplings = {(0,0):C.GC_7200,(0,1):C.GC_7200,(0,2):C.GC_7199,(0,3):C.GC_7199})

V_318 = Vertex(name = 'V_318',
               particles = [ P.A, P.W__plus__, P.G__minus__, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSS1, L.VVSSS11, L.VVSSS12, L.VVSSS13, L.VVSSS14, L.VVSSS16, L.VVSSS17, L.VVSSS21, L.VVSSS24, L.VVSSS25, L.VVSSS26, L.VVSSS28, L.VVSSS29, L.VVSSS3, L.VVSSS30, L.VVSSS39, L.VVSSS40, L.VVSSS42, L.VVSSS5, L.VVSSS50, L.VVSSS51, L.VVSSS59, L.VVSSS60, L.VVSSS62, L.VVSSS63, L.VVSSS65, L.VVSSS66, L.VVSSS68, L.VVSSS7 ],
               couplings = {(0,28):C.GC_7005,(0,18):C.GC_6997,(0,5):C.GC_7016,(0,1):C.GC_7010,(0,15):C.GC_7016,(0,8):C.GC_7010,(0,22):C.GC_7002,(0,23):C.GC_7009,(0,25):C.GC_7009,(0,13):C.GC_6938,(0,0):C.GC_6933,(0,21):C.GC_6934,(0,6):C.GC_7015,(0,7):C.GC_7017,(0,2):C.GC_7008,(0,3):C.GC_7008,(0,4):C.GC_7011,(0,16):C.GC_7015,(0,17):C.GC_4432,(0,19):C.GC_7017,(0,20):C.GC_4432,(0,9):C.GC_7008,(0,11):C.GC_7008,(0,12):C.GC_7011,(0,24):C.GC_7011,(0,26):C.GC_7011,(0,10):C.GC_7178,(0,14):C.GC_7178,(0,27):C.GC_4519})

V_319 = Vertex(name = 'V_319',
               particles = [ P.A, P.W__plus__, P.G__minus__, P.H, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS1, L.VVSSSS10, L.VVSSSS101, L.VVSSSS102, L.VVSSSS103, L.VVSSSS105, L.VVSSSS106, L.VVSSSS11, L.VVSSSS12, L.VVSSSS14, L.VVSSSS15, L.VVSSSS19, L.VVSSSS21, L.VVSSSS22, L.VVSSSS23, L.VVSSSS24, L.VVSSSS25, L.VVSSSS26, L.VVSSSS28, L.VVSSSS29, L.VVSSSS3, L.VVSSSS31, L.VVSSSS32, L.VVSSSS33, L.VVSSSS34, L.VVSSSS35, L.VVSSSS36, L.VVSSSS37, L.VVSSSS38, L.VVSSSS39, L.VVSSSS40, L.VVSSSS41, L.VVSSSS5, L.VVSSSS56, L.VVSSSS57, L.VVSSSS59, L.VVSSSS60, L.VVSSSS7, L.VVSSSS73, L.VVSSSS74, L.VVSSSS75, L.VVSSSS9, L.VVSSSS92, L.VVSSSS93, L.VVSSSS95, L.VVSSSS96, L.VVSSSS98, L.VVSSSS99 ],
               couplings = {(0,20):C.GC_6891,(0,0):C.GC_6884,(0,42):C.GC_6885,(0,37):C.GC_7142,(0,32):C.GC_7131,(0,9):C.GC_7158,(0,41):C.GC_7150,(0,18):C.GC_7158,(0,12):C.GC_7150,(0,33):C.GC_7158,(0,24):C.GC_7150,(0,43):C.GC_7138,(0,44):C.GC_7147,(0,46):C.GC_7147,(0,3):C.GC_7147,(0,14):C.GC_7198,(0,17):C.GC_7198,(0,26):C.GC_7198,(0,27):C.GC_7198,(0,30):C.GC_7198,(0,31):C.GC_7198,(0,2):C.GC_4596,(0,5):C.GC_4596,(0,6):C.GC_4596,(0,10):C.GC_7157,(0,11):C.GC_7160,(0,1):C.GC_7146,(0,7):C.GC_7146,(0,8):C.GC_7151,(0,19):C.GC_7157,(0,21):C.GC_4491,(0,22):C.GC_7160,(0,23):C.GC_4491,(0,13):C.GC_7146,(0,15):C.GC_7146,(0,16):C.GC_7151,(0,34):C.GC_7157,(0,35):C.GC_4491,(0,36):C.GC_4491,(0,38):C.GC_7160,(0,39):C.GC_4491,(0,40):C.GC_4491,(0,25):C.GC_7146,(0,28):C.GC_7146,(0,29):C.GC_7151,(0,45):C.GC_7151,(0,47):C.GC_7151,(0,4):C.GC_7151})

V_320 = Vertex(name = 'V_320',
               particles = [ P.W__plus__, P.G__minus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VSS1, L.VSS10, L.VSS5, L.VSS6, L.VSS7 ],
               couplings = {(0,1):C.GC_491,(0,3):C.GC_486,(0,4):C.GC_488,(0,0):C.GC_517,(0,2):C.GC_516})

V_321 = Vertex(name = 'V_321',
               particles = [ P.W__plus__, P.G__minus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VSS1, L.VSS5 ],
               couplings = {(0,0):C.GC_1194,(0,1):C.GC_1195})

V_322 = Vertex(name = 'V_322',
               particles = [ P.W__plus__, P.G__minus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VSS1, L.VSS5 ],
               couplings = {(0,0):C.GC_1231,(0,1):C.GC_1230})

V_323 = Vertex(name = 'V_323',
               particles = [ P.W__plus__, P.G__minus__, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VSSS13, L.VSSS15, L.VSSS17, L.VSSS20, L.VSSS21, L.VSSS22, L.VSSS3, L.VSSS30, L.VSSS31, L.VSSS5, L.VSSS8 ],
               couplings = {(0,1):C.GC_1197,(0,3):C.GC_1197,(0,4):C.GC_548,(0,10):C.GC_502,(0,5):C.GC_316,(0,7):C.GC_502,(0,8):C.GC_316,(0,6):C.GC_498,(0,0):C.GC_498,(0,9):C.GC_500,(0,2):C.GC_500})

V_324 = Vertex(name = 'V_324',
               particles = [ P.W__plus__, P.G__minus__, P.H, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VSSSS11, L.VSSSS13, L.VSSSS16, L.VSSSS19, L.VSSSS20, L.VSSSS21, L.VSSSS22, L.VSSSS23, L.VSSSS3, L.VSSSS32, L.VSSSS34, L.VSSSS36, L.VSSSS37, L.VSSSS42, L.VSSSS45, L.VSSSS46, L.VSSSS47, L.VSSSS49, L.VSSSS5, L.VSSSS50, L.VSSSS51, L.VSSSS52, L.VSSSS53, L.VSSSS8, L.VSSSS84, L.VSSSS85, L.VSSSS86 ],
               couplings = {(0,23):C.GC_382,(0,5):C.GC_248,(0,6):C.GC_382,(0,7):C.GC_248,(0,16):C.GC_248,(0,22):C.GC_248,(0,24):C.GC_382,(0,25):C.GC_248,(0,26):C.GC_248,(0,8):C.GC_375,(0,0):C.GC_375,(0,9):C.GC_375,(0,18):C.GC_378,(0,2):C.GC_378,(0,13):C.GC_378,(0,1):C.GC_1292,(0,10):C.GC_1292,(0,3):C.GC_1292,(0,11):C.GC_1292,(0,14):C.GC_1292,(0,17):C.GC_1292,(0,4):C.GC_670,(0,12):C.GC_1301,(0,15):C.GC_670,(0,19):C.GC_1301,(0,20):C.GC_670,(0,21):C.GC_1301})

V_325 = Vertex(name = 'V_325',
               particles = [ P.A, P.W__plus__, P.G__minus__ ],
               color = [ '1' ],
               lorentz = [ L.VVS1, L.VVS11, L.VVS12, L.VVS13, L.VVS3, L.VVS5, L.VVS7 ],
               couplings = {(0,6):C.GC_5302,(0,5):C.GC_5300,(0,3):C.GC_5301,(0,4):C.GC_2352,(0,0):C.GC_2351,(0,1):C.GC_5183,(0,2):C.GC_2350})

V_326 = Vertex(name = 'V_326',
               particles = [ P.A, P.W__plus__, P.G__minus__ ],
               color = [ '1' ],
               lorentz = [ L.VVS1, L.VVS11, L.VVS12, L.VVS3 ],
               couplings = {(0,3):C.GC_5270,(0,0):C.GC_5268,(0,1):C.GC_5337,(0,2):C.GC_5269})

V_327 = Vertex(name = 'V_327',
               particles = [ P.A, P.W__plus__, P.G__minus__ ],
               color = [ '1' ],
               lorentz = [ L.VVS11 ],
               couplings = {(0,0):C.GC_5330})

V_328 = Vertex(name = 'V_328',
               particles = [ P.A, P.W__plus__, P.G0, P.G0, P.G__minus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSSS1, L.VVSSS11, L.VVSSS12, L.VVSSS14, L.VVSSS16, L.VVSSS18, L.VVSSS21, L.VVSSS24, L.VVSSS3, L.VVSSS39, L.VVSSS5, L.VVSSS59, L.VVSSS60, L.VVSSS62, L.VVSSS64, L.VVSSS65, L.VVSSS7 ],
               couplings = {(0,9):C.GC_7004,(0,7):C.GC_6998,(0,15):C.GC_7001,(0,8):C.GC_6937,(0,0):C.GC_6931,(0,11):C.GC_6932,(0,16):C.GC_4433,(0,10):C.GC_4429,(0,4):C.GC_4433,(0,5):C.GC_4432,(0,6):C.GC_4432,(0,1):C.GC_4429,(0,12):C.GC_4428,(0,13):C.GC_4428,(0,2):C.GC_7178,(0,3):C.GC_7178,(0,14):C.GC_4519})

V_329 = Vertex(name = 'V_329',
               particles = [ P.W__minus__, P.W__plus__, P.G0, P.G0 ],
               color = [ '1' ],
               lorentz = [ L.VVSS1, L.VVSS10, L.VVSS11, L.VVSS12, L.VVSS14, L.VVSS15, L.VVSS16, L.VVSS17, L.VVSS18, L.VVSS19, L.VVSS21, L.VVSS22, L.VVSS23, L.VVSS25, L.VVSS26, L.VVSS27, L.VVSS28, L.VVSS3, L.VVSS30, L.VVSS31, L.VVSS32, L.VVSS33, L.VVSS40, L.VVSS41, L.VVSS42, L.VVSS5, L.VVSS55, L.VVSS56, L.VVSS57, L.VVSS58, L.VVSS59, L.VVSS6, L.VVSS60, L.VVSS61, L.VVSS62, L.VVSS63, L.VVSS64, L.VVSS7, L.VVSS8, L.VVSS9 ],
               couplings = {(0,17):C.GC_127,(0,0):C.GC_126,(0,13):C.GC_210,(0,15):C.GC_210,(0,4):C.GC_210,(0,1):C.GC_1344,(0,9):C.GC_210,(0,6):C.GC_1344,(0,26):C.GC_779,(0,2):C.GC_204,(0,7):C.GC_204,(0,27):C.GC_125,(0,24):C.GC_210,(0,8):C.GC_203,(0,21):C.GC_210,(0,14):C.GC_203,(0,23):C.GC_210,(0,3):C.GC_203,(0,34):C.GC_204,(0,20):C.GC_210,(0,12):C.GC_203,(0,35):C.GC_204,(0,18):C.GC_207,(0,16):C.GC_205,(0,33):C.GC_798,(0,36):C.GC_206,(0,37):C.GC_1281,(0,38):C.GC_1280,(0,25):C.GC_1264,(0,31):C.GC_1262,(0,10):C.GC_1281,(0,11):C.GC_1280,(0,19):C.GC_653,(0,22):C.GC_653,(0,39):C.GC_1264,(0,5):C.GC_1262,(0,28):C.GC_1263,(0,30):C.GC_1263,(0,29):C.GC_1265,(0,32):C.GC_1265})

V_330 = Vertex(name = 'V_330',
               particles = [ P.W__minus__, P.W__plus__, P.G0, P.G0 ],
               color = [ '1' ],
               lorentz = [ L.VVSS1, L.VVSS3, L.VVSS55, L.VVSS56 ],
               couplings = {(0,1):C.GC_479,(0,0):C.GC_476,(0,2):C.GC_782,(0,3):C.GC_475})

V_331 = Vertex(name = 'V_331',
               particles = [ P.W__minus__, P.W__plus__, P.G0, P.G0 ],
               color = [ '1' ],
               lorentz = [ L.VVSS55 ],
               couplings = {(0,0):C.GC_1371})

V_332 = Vertex(name = 'V_332',
               particles = [ P.W__minus__, P.W__plus__, P.G__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSS1, L.VVSS10, L.VVSS11, L.VVSS12, L.VVSS14, L.VVSS15, L.VVSS16, L.VVSS17, L.VVSS18, L.VVSS19, L.VVSS21, L.VVSS22, L.VVSS23, L.VVSS25, L.VVSS26, L.VVSS27, L.VVSS28, L.VVSS3, L.VVSS30, L.VVSS32, L.VVSS33, L.VVSS40, L.VVSS41, L.VVSS42, L.VVSS5, L.VVSS55, L.VVSS56, L.VVSS57, L.VVSS58, L.VVSS59, L.VVSS6, L.VVSS60, L.VVSS61, L.VVSS62, L.VVSS63, L.VVSS64, L.VVSS7, L.VVSS8, L.VVSS9 ],
               couplings = {(0,17):C.GC_127,(0,0):C.GC_126,(0,13):C.GC_364,(0,15):C.GC_364,(0,4):C.GC_363,(0,1):C.GC_651,(0,9):C.GC_363,(0,6):C.GC_648,(0,25):C.GC_779,(0,2):C.GC_362,(0,7):C.GC_360,(0,26):C.GC_125,(0,23):C.GC_364,(0,8):C.GC_361,(0,20):C.GC_363,(0,14):C.GC_359,(0,22):C.GC_364,(0,3):C.GC_359,(0,33):C.GC_362,(0,19):C.GC_363,(0,12):C.GC_361,(0,34):C.GC_360,(0,18):C.GC_207,(0,16):C.GC_205,(0,32):C.GC_1346,(0,35):C.GC_206,(0,36):C.GC_657,(0,37):C.GC_1282,(0,24):C.GC_656,(0,30):C.GC_1266,(0,10):C.GC_1283,(0,11):C.GC_657,(0,21):C.GC_652,(0,38):C.GC_1268,(0,5):C.GC_655,(0,27):C.GC_655,(0,29):C.GC_1267,(0,28):C.GC_1269,(0,31):C.GC_656})

V_333 = Vertex(name = 'V_333',
               particles = [ P.W__minus__, P.W__plus__, P.G__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSS1, L.VVSS10, L.VVSS16, L.VVSS3, L.VVSS55, L.VVSS56 ],
               couplings = {(0,3):C.GC_483,(0,0):C.GC_482,(0,1):C.GC_1346,(0,2):C.GC_796,(0,4):C.GC_783,(0,5):C.GC_481})

V_334 = Vertex(name = 'V_334',
               particles = [ P.W__minus__, P.W__plus__, P.G__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSS55 ],
               couplings = {(0,0):C.GC_820})

V_335 = Vertex(name = 'V_335',
               particles = [ P.W__minus__, P.W__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVS1, L.VVS11, L.VVS12, L.VVS13, L.VVS14, L.VVS3, L.VVS5, L.VVS6, L.VVS7, L.VVS8 ],
               couplings = {(0,8):C.GC_1245,(0,9):C.GC_1244,(0,6):C.GC_1242,(0,7):C.GC_1240,(0,3):C.GC_1241,(0,4):C.GC_1243,(0,5):C.GC_142,(0,0):C.GC_141,(0,1):C.GC_778,(0,2):C.GC_140})

V_336 = Vertex(name = 'V_336',
               particles = [ P.W__minus__, P.W__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVS1, L.VVS11, L.VVS12, L.VVS3 ],
               couplings = {(0,3):C.GC_404,(0,0):C.GC_403,(0,1):C.GC_1342,(0,2):C.GC_402})

V_337 = Vertex(name = 'V_337',
               particles = [ P.W__minus__, P.W__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVS11 ],
               couplings = {(0,0):C.GC_1370})

V_338 = Vertex(name = 'V_338',
               particles = [ P.W__minus__, P.W__plus__, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSS1, L.VVSS10, L.VVSS11, L.VVSS12, L.VVSS14, L.VVSS15, L.VVSS16, L.VVSS17, L.VVSS18, L.VVSS19, L.VVSS21, L.VVSS22, L.VVSS23, L.VVSS25, L.VVSS26, L.VVSS27, L.VVSS28, L.VVSS3, L.VVSS30, L.VVSS31, L.VVSS32, L.VVSS33, L.VVSS40, L.VVSS41, L.VVSS42, L.VVSS5, L.VVSS55, L.VVSS56, L.VVSS57, L.VVSS58, L.VVSS59, L.VVSS6, L.VVSS60, L.VVSS61, L.VVSS62, L.VVSS63, L.VVSS64, L.VVSS7, L.VVSS8, L.VVSS9 ],
               couplings = {(0,17):C.GC_127,(0,0):C.GC_126,(0,13):C.GC_210,(0,15):C.GC_210,(0,4):C.GC_210,(0,1):C.GC_1344,(0,9):C.GC_210,(0,6):C.GC_1344,(0,26):C.GC_779,(0,2):C.GC_204,(0,7):C.GC_204,(0,27):C.GC_125,(0,24):C.GC_210,(0,8):C.GC_203,(0,21):C.GC_210,(0,14):C.GC_203,(0,23):C.GC_210,(0,3):C.GC_203,(0,34):C.GC_204,(0,20):C.GC_210,(0,12):C.GC_203,(0,35):C.GC_204,(0,18):C.GC_207,(0,16):C.GC_205,(0,33):C.GC_798,(0,36):C.GC_206,(0,37):C.GC_1285,(0,38):C.GC_1284,(0,25):C.GC_1272,(0,31):C.GC_1270,(0,10):C.GC_1285,(0,11):C.GC_1284,(0,19):C.GC_653,(0,22):C.GC_653,(0,39):C.GC_1272,(0,5):C.GC_1270,(0,28):C.GC_1271,(0,30):C.GC_1271,(0,29):C.GC_1273,(0,32):C.GC_1273})

V_339 = Vertex(name = 'V_339',
               particles = [ P.W__minus__, P.W__plus__, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSS1, L.VVSS3, L.VVSS55, L.VVSS56 ],
               couplings = {(0,1):C.GC_480,(0,0):C.GC_478,(0,2):C.GC_1341,(0,3):C.GC_477})

V_340 = Vertex(name = 'V_340',
               particles = [ P.W__minus__, P.W__plus__, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSS55 ],
               couplings = {(0,0):C.GC_1372})

V_341 = Vertex(name = 'V_341',
               particles = [ P.W__minus__, P.W__plus__, P.G0, P.G0, P.G0, P.G0 ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS1, L.VVSSSS10, L.VVSSSS100, L.VVSSSS101, L.VVSSSS102, L.VVSSSS103, L.VVSSSS104, L.VVSSSS105, L.VVSSSS106, L.VVSSSS11, L.VVSSSS12, L.VVSSSS14, L.VVSSSS15, L.VVSSSS16, L.VVSSSS19, L.VVSSSS21, L.VVSSSS22, L.VVSSSS23, L.VVSSSS24, L.VVSSSS25, L.VVSSSS26, L.VVSSSS28, L.VVSSSS29, L.VVSSSS3, L.VVSSSS30, L.VVSSSS31, L.VVSSSS32, L.VVSSSS33, L.VVSSSS34, L.VVSSSS35, L.VVSSSS36, L.VVSSSS37, L.VVSSSS38, L.VVSSSS39, L.VVSSSS40, L.VVSSSS41, L.VVSSSS5, L.VVSSSS56, L.VVSSSS57, L.VVSSSS58, L.VVSSSS59, L.VVSSSS6, L.VVSSSS60, L.VVSSSS7, L.VVSSSS73, L.VVSSSS74, L.VVSSSS75, L.VVSSSS8, L.VVSSSS9, L.VVSSSS92, L.VVSSSS93, L.VVSSSS94, L.VVSSSS95, L.VVSSSS96, L.VVSSSS97, L.VVSSSS98, L.VVSSSS99 ],
               couplings = {(0,23):C.GC_221,(0,0):C.GC_218,(0,49):C.GC_217,(0,1):C.GC_1393,(0,10):C.GC_1393,(0,16):C.GC_1393,(0,17):C.GC_1393,(0,19):C.GC_1393,(0,20):C.GC_1393,(0,29):C.GC_1393,(0,30):C.GC_1393,(0,31):C.GC_1393,(0,33):C.GC_1393,(0,34):C.GC_1393,(0,35):C.GC_1393,(0,54):C.GC_949,(0,2):C.GC_949,(0,6):C.GC_949,(0,3):C.GC_949,(0,7):C.GC_949,(0,8):C.GC_949,(0,43):C.GC_1338,(0,47):C.GC_1337,(0,36):C.GC_1325,(0,41):C.GC_1323,(0,11):C.GC_1338,(0,12):C.GC_1337,(0,13):C.GC_754,(0,14):C.GC_754,(0,48):C.GC_1325,(0,9):C.GC_1323,(0,21):C.GC_1338,(0,22):C.GC_1337,(0,24):C.GC_754,(0,25):C.GC_754,(0,26):C.GC_754,(0,27):C.GC_754,(0,15):C.GC_1325,(0,18):C.GC_1323,(0,37):C.GC_1338,(0,38):C.GC_1337,(0,39):C.GC_754,(0,40):C.GC_754,(0,42):C.GC_754,(0,44):C.GC_754,(0,45):C.GC_754,(0,46):C.GC_754,(0,28):C.GC_1325,(0,32):C.GC_1323,(0,50):C.GC_1324,(0,52):C.GC_1324,(0,55):C.GC_1324,(0,4):C.GC_1324,(0,51):C.GC_1326,(0,53):C.GC_1326,(0,56):C.GC_1326,(0,5):C.GC_1326})

V_342 = Vertex(name = 'V_342',
               particles = [ P.W__minus__, P.W__plus__, P.G0, P.G0, P.G__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS1, L.VVSSSS10, L.VVSSSS100, L.VVSSSS101, L.VVSSSS102, L.VVSSSS103, L.VVSSSS104, L.VVSSSS105, L.VVSSSS106, L.VVSSSS11, L.VVSSSS12, L.VVSSSS14, L.VVSSSS15, L.VVSSSS16, L.VVSSSS19, L.VVSSSS21, L.VVSSSS22, L.VVSSSS23, L.VVSSSS24, L.VVSSSS25, L.VVSSSS26, L.VVSSSS28, L.VVSSSS29, L.VVSSSS3, L.VVSSSS32, L.VVSSSS33, L.VVSSSS34, L.VVSSSS35, L.VVSSSS36, L.VVSSSS37, L.VVSSSS38, L.VVSSSS39, L.VVSSSS40, L.VVSSSS41, L.VVSSSS5, L.VVSSSS56, L.VVSSSS57, L.VVSSSS6, L.VVSSSS7, L.VVSSSS73, L.VVSSSS74, L.VVSSSS75, L.VVSSSS8, L.VVSSSS9, L.VVSSSS91, L.VVSSSS92, L.VVSSSS93, L.VVSSSS94, L.VVSSSS95, L.VVSSSS96, L.VVSSSS97, L.VVSSSS98, L.VVSSSS99 ],
               couplings = {(0,23):C.GC_367,(0,0):C.GC_366,(0,44):C.GC_791,(0,45):C.GC_365,(0,1):C.GC_1396,(0,10):C.GC_1396,(0,16):C.GC_760,(0,17):C.GC_760,(0,19):C.GC_761,(0,20):C.GC_761,(0,27):C.GC_760,(0,28):C.GC_760,(0,29):C.GC_752,(0,31):C.GC_761,(0,32):C.GC_761,(0,33):C.GC_749,(0,50):C.GC_1398,(0,2):C.GC_940,(0,6):C.GC_940,(0,3):C.GC_940,(0,7):C.GC_940,(0,8):C.GC_1398,(0,38):C.GC_1336,(0,42):C.GC_1335,(0,34):C.GC_1316,(0,37):C.GC_1320,(0,11):C.GC_1336,(0,12):C.GC_1335,(0,13):C.GC_754,(0,14):C.GC_754,(0,43):C.GC_1316,(0,9):C.GC_1320,(0,21):C.GC_764,(0,22):C.GC_1333,(0,24):C.GC_765,(0,25):C.GC_765,(0,15):C.GC_761,(0,18):C.GC_1315,(0,35):C.GC_1334,(0,36):C.GC_764,(0,39):C.GC_765,(0,40):C.GC_765,(0,41):C.GC_753,(0,26):C.GC_1319,(0,30):C.GC_760,(0,46):C.GC_1321,(0,48):C.GC_1321,(0,51):C.GC_760,(0,4):C.GC_1318,(0,47):C.GC_1317,(0,49):C.GC_1317,(0,52):C.GC_1322,(0,5):C.GC_761})

V_343 = Vertex(name = 'V_343',
               particles = [ P.W__minus__, P.W__plus__, P.G0, P.G0, P.G__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS22, L.VVSSSS23, L.VVSSSS25, L.VVSSSS26, L.VVSSSS35, L.VVSSSS36, L.VVSSSS37, L.VVSSSS39, L.VVSSSS40, L.VVSSSS41, L.VVSSSS91 ],
               couplings = {(0,10):C.GC_1349,(0,0):C.GC_936,(0,1):C.GC_936,(0,2):C.GC_948,(0,3):C.GC_948,(0,4):C.GC_948,(0,5):C.GC_948,(0,6):C.GC_1398,(0,7):C.GC_936,(0,8):C.GC_936,(0,9):C.GC_942})

V_344 = Vertex(name = 'V_344',
               particles = [ P.W__minus__, P.W__plus__, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS1, L.VVSSSS100, L.VVSSSS101, L.VVSSSS102, L.VVSSSS104, L.VVSSSS105, L.VVSSSS11, L.VVSSSS15, L.VVSSSS21, L.VVSSSS22, L.VVSSSS23, L.VVSSSS25, L.VVSSSS26, L.VVSSSS28, L.VVSSSS3, L.VVSSSS32, L.VVSSSS33, L.VVSSSS34, L.VVSSSS35, L.VVSSSS36, L.VVSSSS39, L.VVSSSS40, L.VVSSSS56, L.VVSSSS6, L.VVSSSS73, L.VVSSSS74, L.VVSSSS8, L.VVSSSS91, L.VVSSSS92, L.VVSSSS94, L.VVSSSS96, L.VVSSSS98 ],
               couplings = {(0,14):C.GC_220,(0,0):C.GC_216,(0,27):C.GC_799,(0,28):C.GC_215,(0,9):C.GC_752,(0,10):C.GC_752,(0,11):C.GC_749,(0,12):C.GC_749,(0,18):C.GC_752,(0,19):C.GC_752,(0,20):C.GC_749,(0,21):C.GC_749,(0,1):C.GC_949,(0,4):C.GC_949,(0,2):C.GC_949,(0,5):C.GC_949,(0,26):C.GC_1339,(0,23):C.GC_1329,(0,7):C.GC_1339,(0,6):C.GC_1329,(0,13):C.GC_1340,(0,15):C.GC_753,(0,16):C.GC_753,(0,8):C.GC_1327,(0,22):C.GC_1340,(0,24):C.GC_753,(0,25):C.GC_753,(0,17):C.GC_1327,(0,31):C.GC_1330,(0,3):C.GC_1330,(0,29):C.GC_1328,(0,30):C.GC_1328})

V_345 = Vertex(name = 'V_345',
               particles = [ P.W__minus__, P.W__plus__, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS22, L.VVSSSS23, L.VVSSSS25, L.VVSSSS26, L.VVSSSS35, L.VVSSSS36, L.VVSSSS39, L.VVSSSS40 ],
               couplings = {(0,0):C.GC_941,(0,1):C.GC_941,(0,2):C.GC_937,(0,3):C.GC_937,(0,4):C.GC_941,(0,5):C.GC_941,(0,6):C.GC_937,(0,7):C.GC_937})

V_346 = Vertex(name = 'V_346',
               particles = [ P.W__minus__, P.W__plus__, P.G0, P.G0, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSS1, L.VVSSS11, L.VVSSS12, L.VVSSS13, L.VVSSS14, L.VVSSS16, L.VVSSS17, L.VVSSS18, L.VVSSS21, L.VVSSS24, L.VVSSS28, L.VVSSS3, L.VVSSS39, L.VVSSS40, L.VVSSS5, L.VVSSS59, L.VVSSS6, L.VVSSS60, L.VVSSS61, L.VVSSS62, L.VVSSS63, L.VVSSS64, L.VVSSS65, L.VVSSS66, L.VVSSS7, L.VVSSS8 ],
               couplings = {(0,24):C.GC_1223,(0,25):C.GC_1222,(0,14):C.GC_1208,(0,16):C.GC_1206,(0,5):C.GC_1223,(0,6):C.GC_1222,(0,7):C.GC_606,(0,8):C.GC_606,(0,1):C.GC_1208,(0,3):C.GC_1206,(0,12):C.GC_1223,(0,13):C.GC_1222,(0,9):C.GC_1208,(0,10):C.GC_1206,(0,17):C.GC_1207,(0,19):C.GC_1207,(0,22):C.GC_1207,(0,18):C.GC_1209,(0,20):C.GC_1209,(0,23):C.GC_1209,(0,11):C.GC_298,(0,0):C.GC_295,(0,15):C.GC_294,(0,2):C.GC_1383,(0,4):C.GC_1383,(0,21):C.GC_859})

V_347 = Vertex(name = 'V_347',
               particles = [ P.W__minus__, P.W__plus__, P.G__minus__, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSS1, L.VVSSS11, L.VVSSS12, L.VVSSS13, L.VVSSS14, L.VVSSS16, L.VVSSS17, L.VVSSS21, L.VVSSS24, L.VVSSS25, L.VVSSS26, L.VVSSS28, L.VVSSS29, L.VVSSS3, L.VVSSS30, L.VVSSS39, L.VVSSS40, L.VVSSS5, L.VVSSS50, L.VVSSS51, L.VVSSS58, L.VVSSS59, L.VVSSS6, L.VVSSS60, L.VVSSS61, L.VVSSS62, L.VVSSS63, L.VVSSS64, L.VVSSS65, L.VVSSS66, L.VVSSS67, L.VVSSS68, L.VVSSS7, L.VVSSS8 ],
               couplings = {(0,32):C.GC_616,(0,33):C.GC_1224,(0,17):C.GC_613,(0,22):C.GC_1210,(0,5):C.GC_1225,(0,6):C.GC_616,(0,7):C.GC_605,(0,1):C.GC_1214,(0,2):C.GC_604,(0,3):C.GC_612,(0,4):C.GC_601,(0,15):C.GC_1227,(0,16):C.GC_1226,(0,18):C.GC_616,(0,19):C.GC_616,(0,8):C.GC_1211,(0,9):C.GC_613,(0,10):C.GC_613,(0,11):C.GC_1215,(0,12):C.GC_612,(0,14):C.GC_612,(0,23):C.GC_612,(0,25):C.GC_1213,(0,28):C.GC_1216,(0,24):C.GC_1217,(0,26):C.GC_613,(0,29):C.GC_1212,(0,20):C.GC_786,(0,13):C.GC_496,(0,0):C.GC_495,(0,21):C.GC_494,(0,27):C.GC_1386,(0,30):C.GC_852,(0,31):C.GC_852})

V_348 = Vertex(name = 'V_348',
               particles = [ P.W__minus__, P.W__plus__, P.G__minus__, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSS12, L.VVSSS14, L.VVSSS25, L.VVSSS26, L.VVSSS29, L.VVSSS30, L.VVSSS58 ],
               couplings = {(0,0):C.GC_1386,(0,1):C.GC_853,(0,2):C.GC_858,(0,3):C.GC_847,(0,4):C.GC_847,(0,5):C.GC_858,(0,6):C.GC_1373})

V_349 = Vertex(name = 'V_349',
               particles = [ P.W__minus__, P.W__plus__, P.G0, P.G0, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS1, L.VVSSSS10, L.VVSSSS102, L.VVSSSS103, L.VVSSSS106, L.VVSSSS11, L.VVSSSS12, L.VVSSSS14, L.VVSSSS15, L.VVSSSS16, L.VVSSSS19, L.VVSSSS21, L.VVSSSS24, L.VVSSSS28, L.VVSSSS29, L.VVSSSS3, L.VVSSSS34, L.VVSSSS37, L.VVSSSS38, L.VVSSSS41, L.VVSSSS5, L.VVSSSS56, L.VVSSSS57, L.VVSSSS6, L.VVSSSS60, L.VVSSSS7, L.VVSSSS75, L.VVSSSS8, L.VVSSSS9, L.VVSSSS92, L.VVSSSS93, L.VVSSSS94, L.VVSSSS95, L.VVSSSS96, L.VVSSSS97, L.VVSSSS98, L.VVSSSS99 ],
               couplings = {(0,15):C.GC_219,(0,0):C.GC_214,(0,29):C.GC_213,(0,1):C.GC_1393,(0,6):C.GC_1393,(0,17):C.GC_1393,(0,19):C.GC_1393,(0,34):C.GC_949,(0,4):C.GC_949,(0,25):C.GC_1332,(0,27):C.GC_1331,(0,20):C.GC_1313,(0,23):C.GC_1311,(0,7):C.GC_1332,(0,8):C.GC_1331,(0,9):C.GC_754,(0,10):C.GC_754,(0,28):C.GC_1313,(0,5):C.GC_1311,(0,13):C.GC_1332,(0,14):C.GC_1331,(0,11):C.GC_1313,(0,12):C.GC_1311,(0,21):C.GC_1332,(0,22):C.GC_1331,(0,24):C.GC_754,(0,26):C.GC_754,(0,16):C.GC_1313,(0,18):C.GC_1311,(0,30):C.GC_1312,(0,32):C.GC_1312,(0,35):C.GC_1312,(0,2):C.GC_1312,(0,31):C.GC_1314,(0,33):C.GC_1314,(0,36):C.GC_1314,(0,3):C.GC_1314})

V_350 = Vertex(name = 'V_350',
               particles = [ P.W__minus__, P.W__plus__, P.G__minus__, P.G__plus__, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS1, L.VVSSSS10, L.VVSSSS100, L.VVSSSS101, L.VVSSSS102, L.VVSSSS103, L.VVSSSS104, L.VVSSSS105, L.VVSSSS106, L.VVSSSS11, L.VVSSSS12, L.VVSSSS14, L.VVSSSS15, L.VVSSSS19, L.VVSSSS21, L.VVSSSS22, L.VVSSSS23, L.VVSSSS24, L.VVSSSS25, L.VVSSSS26, L.VVSSSS28, L.VVSSSS29, L.VVSSSS3, L.VVSSSS32, L.VVSSSS33, L.VVSSSS34, L.VVSSSS35, L.VVSSSS36, L.VVSSSS37, L.VVSSSS38, L.VVSSSS39, L.VVSSSS40, L.VVSSSS41, L.VVSSSS5, L.VVSSSS56, L.VVSSSS57, L.VVSSSS6, L.VVSSSS60, L.VVSSSS7, L.VVSSSS73, L.VVSSSS74, L.VVSSSS75, L.VVSSSS8, L.VVSSSS9, L.VVSSSS91, L.VVSSSS92, L.VVSSSS93, L.VVSSSS94, L.VVSSSS95, L.VVSSSS96, L.VVSSSS97, L.VVSSSS98, L.VVSSSS99 ],
               couplings = {(0,22):C.GC_367,(0,0):C.GC_366,(0,44):C.GC_791,(0,45):C.GC_365,(0,1):C.GC_752,(0,10):C.GC_749,(0,15):C.GC_761,(0,16):C.GC_761,(0,18):C.GC_760,(0,19):C.GC_760,(0,26):C.GC_761,(0,27):C.GC_761,(0,28):C.GC_1396,(0,30):C.GC_760,(0,31):C.GC_760,(0,32):C.GC_1396,(0,50):C.GC_1398,(0,2):C.GC_940,(0,6):C.GC_940,(0,3):C.GC_940,(0,7):C.GC_940,(0,8):C.GC_1398,(0,38):C.GC_764,(0,42):C.GC_1333,(0,33):C.GC_761,(0,36):C.GC_1315,(0,11):C.GC_1334,(0,12):C.GC_764,(0,13):C.GC_753,(0,43):C.GC_1319,(0,9):C.GC_760,(0,20):C.GC_1336,(0,21):C.GC_1335,(0,23):C.GC_764,(0,24):C.GC_764,(0,14):C.GC_1316,(0,17):C.GC_1320,(0,34):C.GC_1336,(0,35):C.GC_1335,(0,37):C.GC_754,(0,39):C.GC_764,(0,40):C.GC_764,(0,41):C.GC_754,(0,25):C.GC_1316,(0,29):C.GC_1320,(0,46):C.GC_760,(0,48):C.GC_1318,(0,51):C.GC_1321,(0,4):C.GC_1321,(0,47):C.GC_1322,(0,49):C.GC_761,(0,52):C.GC_1317,(0,5):C.GC_1317})

V_351 = Vertex(name = 'V_351',
               particles = [ P.W__minus__, P.W__plus__, P.G__minus__, P.G__plus__, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS10, L.VVSSSS12, L.VVSSSS22, L.VVSSSS23, L.VVSSSS25, L.VVSSSS26, L.VVSSSS35, L.VVSSSS36, L.VVSSSS39, L.VVSSSS40, L.VVSSSS91 ],
               couplings = {(0,10):C.GC_1350,(0,0):C.GC_1398,(0,1):C.GC_942,(0,2):C.GC_948,(0,3):C.GC_936,(0,4):C.GC_936,(0,5):C.GC_948,(0,6):C.GC_948,(0,7):C.GC_936,(0,8):C.GC_936,(0,9):C.GC_948})

V_352 = Vertex(name = 'V_352',
               particles = [ P.W__minus__, P.W__plus__, P.H, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSS1, L.VVSSS11, L.VVSSS12, L.VVSSS13, L.VVSSS14, L.VVSSS16, L.VVSSS17, L.VVSSS18, L.VVSSS21, L.VVSSS24, L.VVSSS25, L.VVSSS26, L.VVSSS28, L.VVSSS29, L.VVSSS3, L.VVSSS30, L.VVSSS39, L.VVSSS40, L.VVSSS41, L.VVSSS42, L.VVSSS5, L.VVSSS50, L.VVSSS51, L.VVSSS59, L.VVSSS6, L.VVSSS60, L.VVSSS61, L.VVSSS62, L.VVSSS63, L.VVSSS64, L.VVSSS65, L.VVSSS66, L.VVSSS67, L.VVSSS68, L.VVSSS7, L.VVSSS8 ],
               couplings = {(0,34):C.GC_1229,(0,35):C.GC_1228,(0,20):C.GC_1220,(0,24):C.GC_1218,(0,5):C.GC_1229,(0,6):C.GC_1228,(0,7):C.GC_606,(0,8):C.GC_606,(0,1):C.GC_1220,(0,3):C.GC_1218,(0,16):C.GC_1229,(0,17):C.GC_1228,(0,18):C.GC_606,(0,19):C.GC_606,(0,21):C.GC_606,(0,22):C.GC_606,(0,9):C.GC_1220,(0,12):C.GC_1218,(0,25):C.GC_1219,(0,27):C.GC_1219,(0,30):C.GC_1219,(0,26):C.GC_1221,(0,28):C.GC_1221,(0,31):C.GC_1221,(0,14):C.GC_299,(0,0):C.GC_297,(0,23):C.GC_296,(0,2):C.GC_1383,(0,4):C.GC_1383,(0,10):C.GC_1383,(0,11):C.GC_1383,(0,13):C.GC_1383,(0,15):C.GC_1383,(0,29):C.GC_859,(0,32):C.GC_859,(0,33):C.GC_859})

V_353 = Vertex(name = 'V_353',
               particles = [ P.W__minus__, P.W__plus__, P.H, P.H, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS1, L.VVSSSS10, L.VVSSSS100, L.VVSSSS101, L.VVSSSS102, L.VVSSSS103, L.VVSSSS104, L.VVSSSS105, L.VVSSSS106, L.VVSSSS11, L.VVSSSS12, L.VVSSSS14, L.VVSSSS15, L.VVSSSS16, L.VVSSSS19, L.VVSSSS21, L.VVSSSS22, L.VVSSSS23, L.VVSSSS24, L.VVSSSS25, L.VVSSSS26, L.VVSSSS28, L.VVSSSS29, L.VVSSSS3, L.VVSSSS30, L.VVSSSS31, L.VVSSSS32, L.VVSSSS33, L.VVSSSS34, L.VVSSSS35, L.VVSSSS36, L.VVSSSS37, L.VVSSSS38, L.VVSSSS39, L.VVSSSS40, L.VVSSSS41, L.VVSSSS5, L.VVSSSS56, L.VVSSSS57, L.VVSSSS58, L.VVSSSS59, L.VVSSSS6, L.VVSSSS60, L.VVSSSS7, L.VVSSSS73, L.VVSSSS74, L.VVSSSS75, L.VVSSSS8, L.VVSSSS9, L.VVSSSS92, L.VVSSSS93, L.VVSSSS94, L.VVSSSS95, L.VVSSSS96, L.VVSSSS97, L.VVSSSS98, L.VVSSSS99 ],
               couplings = {(0,23):C.GC_221,(0,0):C.GC_218,(0,49):C.GC_217,(0,1):C.GC_1393,(0,10):C.GC_1393,(0,16):C.GC_1393,(0,17):C.GC_1393,(0,19):C.GC_1393,(0,20):C.GC_1393,(0,29):C.GC_1393,(0,30):C.GC_1393,(0,31):C.GC_1393,(0,33):C.GC_1393,(0,34):C.GC_1393,(0,35):C.GC_1393,(0,54):C.GC_949,(0,2):C.GC_949,(0,6):C.GC_949,(0,3):C.GC_949,(0,7):C.GC_949,(0,8):C.GC_949,(0,43):C.GC_1338,(0,47):C.GC_1337,(0,36):C.GC_1325,(0,41):C.GC_1323,(0,11):C.GC_1338,(0,12):C.GC_1337,(0,13):C.GC_754,(0,14):C.GC_754,(0,48):C.GC_1325,(0,9):C.GC_1323,(0,21):C.GC_1338,(0,22):C.GC_1337,(0,24):C.GC_754,(0,25):C.GC_754,(0,26):C.GC_754,(0,27):C.GC_754,(0,15):C.GC_1325,(0,18):C.GC_1323,(0,37):C.GC_1338,(0,38):C.GC_1337,(0,39):C.GC_754,(0,40):C.GC_754,(0,42):C.GC_754,(0,44):C.GC_754,(0,45):C.GC_754,(0,46):C.GC_754,(0,28):C.GC_1325,(0,32):C.GC_1323,(0,50):C.GC_1324,(0,52):C.GC_1324,(0,55):C.GC_1324,(0,4):C.GC_1324,(0,51):C.GC_1326,(0,53):C.GC_1326,(0,56):C.GC_1326,(0,5):C.GC_1326})

V_354 = Vertex(name = 'V_354',
               particles = [ P.A, P.A, P.W__minus__, P.W__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVV10, L.VVVV100, L.VVVV101, L.VVVV104, L.VVVV108, L.VVVV11, L.VVVV112, L.VVVV113, L.VVVV114, L.VVVV116, L.VVVV12, L.VVVV120, L.VVVV122, L.VVVV123, L.VVVV124, L.VVVV126, L.VVVV128, L.VVVV129, L.VVVV13, L.VVVV130, L.VVVV132, L.VVVV133, L.VVVV134, L.VVVV135, L.VVVV136, L.VVVV137, L.VVVV138, L.VVVV14, L.VVVV140, L.VVVV142, L.VVVV147, L.VVVV15, L.VVVV150, L.VVVV151, L.VVVV152, L.VVVV153, L.VVVV156, L.VVVV158, L.VVVV159, L.VVVV16, L.VVVV160, L.VVVV162, L.VVVV166, L.VVVV167, L.VVVV168, L.VVVV169, L.VVVV17, L.VVVV171, L.VVVV173, L.VVVV174, L.VVVV175, L.VVVV177, L.VVVV178, L.VVVV18, L.VVVV180, L.VVVV181, L.VVVV184, L.VVVV186, L.VVVV187, L.VVVV188, L.VVVV189, L.VVVV19, L.VVVV190, L.VVVV191, L.VVVV192, L.VVVV193, L.VVVV195, L.VVVV197, L.VVVV198, L.VVVV199, L.VVVV20, L.VVVV200, L.VVVV201, L.VVVV203, L.VVVV204, L.VVVV205, L.VVVV206, L.VVVV207, L.VVVV208, L.VVVV21, L.VVVV210, L.VVVV22, L.VVVV23, L.VVVV24, L.VVVV25, L.VVVV28, L.VVVV29, L.VVVV3, L.VVVV30, L.VVVV31, L.VVVV34, L.VVVV35, L.VVVV36, L.VVVV37, L.VVVV38, L.VVVV39, L.VVVV4, L.VVVV41, L.VVVV42, L.VVVV43, L.VVVV44, L.VVVV45, L.VVVV46, L.VVVV47, L.VVVV48, L.VVVV58, L.VVVV59, L.VVVV6, L.VVVV60, L.VVVV62, L.VVVV68, L.VVVV69, L.VVVV7, L.VVVV70, L.VVVV72, L.VVVV73, L.VVVV75, L.VVVV76, L.VVVV79, L.VVVV80, L.VVVV81, L.VVVV82, L.VVVV84, L.VVVV88, L.VVVV89, L.VVVV9, L.VVVV92, L.VVVV93, L.VVVV94, L.VVVV96, L.VVVV97, L.VVVV98, L.VVVV99 ],
               couplings = {(0,108):C.GC_1507,(0,109):C.GC_1498,(0,105):C.GC_1511,(0,106):C.GC_1511,(0,110):C.GC_1498,(0,111):C.GC_1486,(0,113):C.GC_1484,(0,85):C.GC_1511,(0,84):C.GC_1488,(0,90):C.GC_1511,(0,89):C.GC_1488,(0,94):C.GC_1505,(0,95):C.GC_1503,(0,93):C.GC_1480,(0,114):C.GC_5597,(0,115):C.GC_5597,(0,127):C.GC_5595,(0,7):C.GC_5595,(0,20):C.GC_5595,(0,33):C.GC_1617,(0,38):C.GC_5595,(0,51):C.GC_1617,(0,58):C.GC_5593,(0,59):C.GC_5591,(0,57):C.GC_5587,(0,73):C.GC_1619,(0,126):C.GC_1509,(0,122):C.GC_1482,(0,34):C.GC_5597,(0,52):C.GC_5597,(0,74):C.GC_5589,(0,6):C.GC_1515,(0,3):C.GC_1490,(0,16):C.GC_1515,(0,15):C.GC_1490,(0,32):C.GC_1515,(0,29):C.GC_1490,(0,37):C.GC_1488,(0,48):C.GC_1515,(0,47):C.GC_1490,(0,56):C.GC_1488,(0,68):C.GC_1503,(0,69):C.GC_1505,(0,67):C.GC_1482,(0,80):C.GC_1480,(0,31):C.GC_1551,(0,39):C.GC_1551,(0,46):C.GC_1551,(0,61):C.GC_1551,(0,70):C.GC_1552,(0,79):C.GC_1552,(0,125):C.GC_1551,(0,0):C.GC_1551,(0,5):C.GC_1551,(0,10):C.GC_1551,(0,18):C.GC_1551,(0,27):C.GC_1552,(0,97):C.GC_1552,(0,98):C.GC_1551,(0,99):C.GC_1551,(0,101):C.GC_1552,(0,102):C.GC_1552,(0,103):C.GC_1552,(0,82):C.GC_1552,(0,83):C.GC_1552,(0,86):C.GC_1552,(0,88):C.GC_1552,(0,91):C.GC_1551,(0,92):C.GC_1552,(0,118):C.GC_1551,(0,119):C.GC_1551,(0,116):C.GC_1550,(0,117):C.GC_1550,(0,123):C.GC_1552,(0,124):C.GC_1552,(0,120):C.GC_1550,(0,121):C.GC_1550,(0,132):C.GC_1551,(0,1):C.GC_1551,(0,129):C.GC_1550,(0,130):C.GC_1549,(0,131):C.GC_1549,(0,4):C.GC_1551,(0,2):C.GC_1549,(0,11):C.GC_1551,(0,9):C.GC_1549,(0,17):C.GC_1551,(0,19):C.GC_1551,(0,12):C.GC_1550,(0,13):C.GC_1549,(0,14):C.GC_1549,(0,25):C.GC_1551,(0,26):C.GC_1551,(0,22):C.GC_1549,(0,23):C.GC_1550,(0,24):C.GC_1549,(0,30):C.GC_1551,(0,28):C.GC_1549,(0,42):C.GC_1551,(0,41):C.GC_1549,(0,49):C.GC_1551,(0,50):C.GC_1551,(0,43):C.GC_1549,(0,44):C.GC_1550,(0,45):C.GC_1549,(0,63):C.GC_1552,(0,64):C.GC_1551,(0,60):C.GC_1550,(0,62):C.GC_1550,(0,71):C.GC_1552,(0,72):C.GC_1551,(0,65):C.GC_1550,(0,66):C.GC_1550,(0,53):C.GC_1552,(0,35):C.GC_1550,(0,75):C.GC_1549,(0,100):C.GC_1551,(0,55):C.GC_1550,(0,77):C.GC_1549,(0,81):C.GC_1551,(0,54):C.GC_1550,(0,76):C.GC_1549,(0,104):C.GC_1552,(0,36):C.GC_1550,(0,78):C.GC_1549,(0,107):C.GC_5601,(0,112):C.GC_5600,(0,87):C.GC_5598,(0,96):C.GC_5599,(0,128):C.GC_5598,(0,8):C.GC_5599,(0,21):C.GC_5598,(0,40):C.GC_5599})

V_355 = Vertex(name = 'V_355',
               particles = [ P.A, P.A, P.W__minus__, P.W__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVV10, L.VVVV100, L.VVVV101, L.VVVV108, L.VVVV11, L.VVVV116, L.VVVV12, L.VVVV120, L.VVVV122, L.VVVV123, L.VVVV124, L.VVVV129, L.VVVV13, L.VVVV130, L.VVVV134, L.VVVV135, L.VVVV136, L.VVVV137, L.VVVV138, L.VVVV14, L.VVVV140, L.VVVV147, L.VVVV15, L.VVVV151, L.VVVV153, L.VVVV156, L.VVVV16, L.VVVV162, L.VVVV166, L.VVVV167, L.VVVV168, L.VVVV169, L.VVVV17, L.VVVV174, L.VVVV175, L.VVVV177, L.VVVV18, L.VVVV180, L.VVVV181, L.VVVV189, L.VVVV19, L.VVVV190, L.VVVV191, L.VVVV192, L.VVVV193, L.VVVV195, L.VVVV20, L.VVVV200, L.VVVV201, L.VVVV203, L.VVVV205, L.VVVV206, L.VVVV207, L.VVVV208, L.VVVV21, L.VVVV22, L.VVVV23, L.VVVV24, L.VVVV29, L.VVVV30, L.VVVV35, L.VVVV36, L.VVVV41, L.VVVV42, L.VVVV43, L.VVVV44, L.VVVV45, L.VVVV46, L.VVVV47, L.VVVV48, L.VVVV75, L.VVVV76, L.VVVV79, L.VVVV80, L.VVVV81, L.VVVV82, L.VVVV88, L.VVVV89, L.VVVV9, L.VVVV96, L.VVVV97, L.VVVV98, L.VVVV99 ],
               couplings = {(0,23):C.GC_5603,(0,35):C.GC_5603,(0,49):C.GC_5604,(0,22):C.GC_5500,(0,26):C.GC_5500,(0,32):C.GC_5500,(0,40):C.GC_5500,(0,46):C.GC_5496,(0,54):C.GC_5496,(0,78):C.GC_5500,(0,0):C.GC_5502,(0,4):C.GC_5502,(0,6):C.GC_5500,(0,12):C.GC_5502,(0,19):C.GC_5498,(0,62):C.GC_5496,(0,63):C.GC_5500,(0,64):C.GC_5500,(0,66):C.GC_5496,(0,67):C.GC_5496,(0,68):C.GC_5496,(0,56):C.GC_5496,(0,57):C.GC_5498,(0,58):C.GC_5498,(0,59):C.GC_5496,(0,60):C.GC_5502,(0,61):C.GC_5498,(0,72):C.GC_5500,(0,73):C.GC_5500,(0,70):C.GC_5484,(0,71):C.GC_5484,(0,76):C.GC_5496,(0,77):C.GC_5496,(0,74):C.GC_5484,(0,75):C.GC_5484,(0,82):C.GC_5500,(0,1):C.GC_5502,(0,79):C.GC_5484,(0,80):C.GC_5486,(0,81):C.GC_5486,(0,3):C.GC_5500,(0,2):C.GC_5486,(0,7):C.GC_5500,(0,5):C.GC_5486,(0,11):C.GC_5500,(0,13):C.GC_5502,(0,8):C.GC_5484,(0,9):C.GC_5486,(0,10):C.GC_5486,(0,17):C.GC_5502,(0,18):C.GC_5500,(0,14):C.GC_5486,(0,15):C.GC_5484,(0,16):C.GC_5486,(0,21):C.GC_5500,(0,20):C.GC_5486,(0,28):C.GC_5500,(0,27):C.GC_5486,(0,33):C.GC_5502,(0,34):C.GC_5500,(0,29):C.GC_5486,(0,30):C.GC_5484,(0,31):C.GC_5486,(0,42):C.GC_5498,(0,43):C.GC_5502,(0,39):C.GC_5484,(0,41):C.GC_5484,(0,47):C.GC_5498,(0,48):C.GC_5502,(0,44):C.GC_5484,(0,45):C.GC_5484,(0,36):C.GC_5496,(0,24):C.GC_5484,(0,50):C.GC_5486,(0,65):C.GC_5500,(0,38):C.GC_5484,(0,52):C.GC_5486,(0,55):C.GC_5500,(0,37):C.GC_5484,(0,51):C.GC_5486,(0,69):C.GC_5496,(0,25):C.GC_5484,(0,53):C.GC_5486})

V_356 = Vertex(name = 'V_356',
               particles = [ P.A, P.A, P.W__minus__, P.W__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVV151, L.VVVV177, L.VVVV203 ],
               couplings = {(0,0):C.GC_5569,(0,1):C.GC_5569,(0,2):C.GC_5570})

V_357 = Vertex(name = 'V_357',
               particles = [ P.W__plus__, P.W__plus__, P.G0, P.G0, P.G__minus__, P.G__minus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS1, L.VVSSSS10, L.VVSSSS100, L.VVSSSS101, L.VVSSSS102, L.VVSSSS103, L.VVSSSS104, L.VVSSSS105, L.VVSSSS106, L.VVSSSS11, L.VVSSSS12, L.VVSSSS14, L.VVSSSS15, L.VVSSSS2, L.VVSSSS21, L.VVSSSS22, L.VVSSSS23, L.VVSSSS24, L.VVSSSS25, L.VVSSSS26, L.VVSSSS28, L.VVSSSS29, L.VVSSSS3, L.VVSSSS34, L.VVSSSS35, L.VVSSSS36, L.VVSSSS37, L.VVSSSS38, L.VVSSSS39, L.VVSSSS40, L.VVSSSS41, L.VVSSSS5, L.VVSSSS56, L.VVSSSS57, L.VVSSSS6, L.VVSSSS7, L.VVSSSS8, L.VVSSSS9, L.VVSSSS91, L.VVSSSS92, L.VVSSSS93, L.VVSSSS94, L.VVSSSS95, L.VVSSSS96, L.VVSSSS97, L.VVSSSS98, L.VVSSSS99 ],
               couplings = {(0,13):C.GC_228,(0,22):C.GC_227,(0,0):C.GC_223,(0,38):C.GC_792,(0,39):C.GC_224,(0,1):C.GC_1398,(0,10):C.GC_1398,(0,15):C.GC_1397,(0,16):C.GC_1397,(0,18):C.GC_1397,(0,19):C.GC_1397,(0,24):C.GC_1397,(0,25):C.GC_1397,(0,26):C.GC_1398,(0,28):C.GC_1397,(0,29):C.GC_1397,(0,30):C.GC_1398,(0,44):C.GC_942,(0,2):C.GC_938,(0,6):C.GC_938,(0,3):C.GC_938,(0,7):C.GC_938,(0,8):C.GC_942,(0,35):C.GC_765,(0,36):C.GC_764,(0,31):C.GC_760,(0,34):C.GC_760,(0,11):C.GC_765,(0,12):C.GC_764,(0,37):C.GC_760,(0,9):C.GC_760,(0,20):C.GC_764,(0,21):C.GC_765,(0,14):C.GC_761,(0,17):C.GC_761,(0,32):C.GC_764,(0,33):C.GC_765,(0,23):C.GC_761,(0,27):C.GC_761,(0,40):C.GC_761,(0,42):C.GC_761,(0,45):C.GC_760,(0,4):C.GC_760,(0,41):C.GC_761,(0,43):C.GC_761,(0,46):C.GC_760,(0,5):C.GC_760})

V_358 = Vertex(name = 'V_358',
               particles = [ P.W__plus__, P.W__plus__, P.G0, P.G0, P.G__minus__, P.G__minus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS91 ],
               couplings = {(0,0):C.GC_801})

V_359 = Vertex(name = 'V_359',
               particles = [ P.W__plus__, P.W__plus__, P.G__minus__, P.G__minus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSS1, L.VVSS10, L.VVSS15, L.VVSS16, L.VVSS2, L.VVSS21, L.VVSS22, L.VVSS3, L.VVSS5, L.VVSS55, L.VVSS56, L.VVSS57, L.VVSS58, L.VVSS59, L.VVSS6, L.VVSS60, L.VVSS61, L.VVSS7, L.VVSS8, L.VVSS9 ],
               couplings = {(0,1):C.GC_1347,(0,3):C.GC_1347,(0,9):C.GC_784,(0,16):C.GC_797,(0,4):C.GC_271,(0,7):C.GC_272,(0,0):C.GC_270,(0,10):C.GC_269,(0,17):C.GC_658,(0,18):C.GC_657,(0,8):C.GC_655,(0,14):C.GC_655,(0,5):C.GC_658,(0,6):C.GC_657,(0,19):C.GC_655,(0,2):C.GC_655,(0,11):C.GC_656,(0,13):C.GC_656,(0,12):C.GC_656,(0,15):C.GC_656})

V_360 = Vertex(name = 'V_360',
               particles = [ P.W__plus__, P.W__plus__, P.G__minus__, P.G__minus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSS55 ],
               couplings = {(0,0):C.GC_821})

V_361 = Vertex(name = 'V_361',
               particles = [ P.W__plus__, P.W__plus__, P.G0, P.G__minus__, P.G__minus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSSS1, L.VVSSS11, L.VVSSS12, L.VVSSS13, L.VVSSS14, L.VVSSS16, L.VVSSS17, L.VVSSS2, L.VVSSS24, L.VVSSS25, L.VVSSS26, L.VVSSS28, L.VVSSS29, L.VVSSS3, L.VVSSS30, L.VVSSS39, L.VVSSS40, L.VVSSS5, L.VVSSS58, L.VVSSS59, L.VVSSS6, L.VVSSS60, L.VVSSS61, L.VVSSS62, L.VVSSS63, L.VVSSS64, L.VVSSS65, L.VVSSS66, L.VVSSS67, L.VVSSS68, L.VVSSS7, L.VVSSS8 ],
               couplings = {(0,30):C.GC_615,(0,31):C.GC_619,(0,17):C.GC_614,(0,20):C.GC_614,(0,5):C.GC_619,(0,6):C.GC_615,(0,1):C.GC_610,(0,3):C.GC_610,(0,15):C.GC_619,(0,16):C.GC_615,(0,8):C.GC_610,(0,11):C.GC_610,(0,21):C.GC_610,(0,23):C.GC_614,(0,26):C.GC_614,(0,22):C.GC_610,(0,24):C.GC_614,(0,27):C.GC_614,(0,7):C.GC_304,(0,13):C.GC_307,(0,0):C.GC_303,(0,18):C.GC_788,(0,19):C.GC_300,(0,2):C.GC_1384,(0,4):C.GC_1384,(0,9):C.GC_1384,(0,10):C.GC_1388,(0,12):C.GC_1384,(0,14):C.GC_1388,(0,25):C.GC_845,(0,28):C.GC_845,(0,29):C.GC_856})

V_362 = Vertex(name = 'V_362',
               particles = [ P.W__plus__, P.W__plus__, P.G0, P.G__minus__, P.G__minus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSSS58 ],
               couplings = {(0,0):C.GC_1374})

V_363 = Vertex(name = 'V_363',
               particles = [ P.W__plus__, P.W__plus__, P.G0, P.G__minus__, P.G__minus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS1, L.VVSSSS10, L.VVSSSS100, L.VVSSSS101, L.VVSSSS102, L.VVSSSS103, L.VVSSSS104, L.VVSSSS105, L.VVSSSS106, L.VVSSSS11, L.VVSSSS12, L.VVSSSS14, L.VVSSSS15, L.VVSSSS2, L.VVSSSS21, L.VVSSSS22, L.VVSSSS23, L.VVSSSS24, L.VVSSSS25, L.VVSSSS26, L.VVSSSS28, L.VVSSSS29, L.VVSSSS3, L.VVSSSS34, L.VVSSSS35, L.VVSSSS36, L.VVSSSS37, L.VVSSSS38, L.VVSSSS39, L.VVSSSS40, L.VVSSSS41, L.VVSSSS5, L.VVSSSS56, L.VVSSSS57, L.VVSSSS6, L.VVSSSS7, L.VVSSSS8, L.VVSSSS9, L.VVSSSS91, L.VVSSSS92, L.VVSSSS93, L.VVSSSS94, L.VVSSSS95, L.VVSSSS96, L.VVSSSS97, L.VVSSSS98, L.VVSSSS99 ],
               couplings = {(0,13):C.GC_226,(0,22):C.GC_229,(0,0):C.GC_225,(0,38):C.GC_794,(0,39):C.GC_222,(0,1):C.GC_1394,(0,10):C.GC_1394,(0,15):C.GC_1394,(0,16):C.GC_1400,(0,18):C.GC_1394,(0,19):C.GC_1400,(0,24):C.GC_1400,(0,25):C.GC_1394,(0,26):C.GC_1394,(0,28):C.GC_1400,(0,29):C.GC_1394,(0,30):C.GC_1394,(0,44):C.GC_934,(0,2):C.GC_934,(0,6):C.GC_946,(0,3):C.GC_946,(0,7):C.GC_934,(0,8):C.GC_934,(0,35):C.GC_763,(0,36):C.GC_767,(0,31):C.GC_762,(0,34):C.GC_762,(0,11):C.GC_767,(0,12):C.GC_763,(0,37):C.GC_758,(0,9):C.GC_758,(0,20):C.GC_767,(0,21):C.GC_763,(0,14):C.GC_758,(0,17):C.GC_758,(0,32):C.GC_763,(0,33):C.GC_767,(0,23):C.GC_762,(0,27):C.GC_762,(0,40):C.GC_758,(0,42):C.GC_762,(0,45):C.GC_762,(0,4):C.GC_758,(0,41):C.GC_758,(0,43):C.GC_762,(0,46):C.GC_762,(0,5):C.GC_758})

V_364 = Vertex(name = 'V_364',
               particles = [ P.W__plus__, P.W__plus__, P.G0, P.G__minus__, P.G__minus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS91 ],
               couplings = {(0,0):C.GC_1348})

V_365 = Vertex(name = 'V_365',
               particles = [ P.W__plus__, P.W__plus__, P.G__minus__, P.G__minus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSS1, L.VVSSS11, L.VVSSS12, L.VVSSS13, L.VVSSS14, L.VVSSS16, L.VVSSS17, L.VVSSS2, L.VVSSS24, L.VVSSS25, L.VVSSS26, L.VVSSS28, L.VVSSS29, L.VVSSS3, L.VVSSS30, L.VVSSS39, L.VVSSS40, L.VVSSS5, L.VVSSS58, L.VVSSS59, L.VVSSS6, L.VVSSS60, L.VVSSS61, L.VVSSS62, L.VVSSS63, L.VVSSS64, L.VVSSS65, L.VVSSS66, L.VVSSS67, L.VVSSS68, L.VVSSS7, L.VVSSS8 ],
               couplings = {(0,30):C.GC_617,(0,31):C.GC_616,(0,17):C.GC_612,(0,20):C.GC_612,(0,5):C.GC_617,(0,6):C.GC_616,(0,1):C.GC_612,(0,3):C.GC_612,(0,15):C.GC_616,(0,16):C.GC_617,(0,8):C.GC_613,(0,11):C.GC_613,(0,21):C.GC_613,(0,23):C.GC_613,(0,26):C.GC_612,(0,22):C.GC_613,(0,24):C.GC_613,(0,27):C.GC_612,(0,7):C.GC_305,(0,13):C.GC_306,(0,0):C.GC_302,(0,18):C.GC_787,(0,19):C.GC_301,(0,2):C.GC_1387,(0,4):C.GC_1387,(0,9):C.GC_1385,(0,10):C.GC_1385,(0,12):C.GC_1385,(0,14):C.GC_1385,(0,25):C.GC_854,(0,28):C.GC_848,(0,29):C.GC_848})

V_366 = Vertex(name = 'V_366',
               particles = [ P.W__plus__, P.W__plus__, P.G__minus__, P.G__minus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSS58 ],
               couplings = {(0,0):C.GC_1375})

V_367 = Vertex(name = 'V_367',
               particles = [ P.W__plus__, P.W__plus__, P.G__minus__, P.G__minus__, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS1, L.VVSSSS10, L.VVSSSS100, L.VVSSSS101, L.VVSSSS102, L.VVSSSS103, L.VVSSSS104, L.VVSSSS105, L.VVSSSS106, L.VVSSSS11, L.VVSSSS12, L.VVSSSS14, L.VVSSSS15, L.VVSSSS2, L.VVSSSS21, L.VVSSSS22, L.VVSSSS23, L.VVSSSS24, L.VVSSSS25, L.VVSSSS26, L.VVSSSS28, L.VVSSSS29, L.VVSSSS3, L.VVSSSS34, L.VVSSSS35, L.VVSSSS36, L.VVSSSS37, L.VVSSSS38, L.VVSSSS39, L.VVSSSS40, L.VVSSSS41, L.VVSSSS5, L.VVSSSS56, L.VVSSSS57, L.VVSSSS6, L.VVSSSS7, L.VVSSSS8, L.VVSSSS9, L.VVSSSS91, L.VVSSSS92, L.VVSSSS93, L.VVSSSS94, L.VVSSSS95, L.VVSSSS96, L.VVSSSS97, L.VVSSSS98, L.VVSSSS99 ],
               couplings = {(0,13):C.GC_227,(0,22):C.GC_228,(0,0):C.GC_224,(0,38):C.GC_793,(0,39):C.GC_223,(0,1):C.GC_1399,(0,10):C.GC_1399,(0,15):C.GC_1395,(0,16):C.GC_1395,(0,18):C.GC_1395,(0,19):C.GC_1395,(0,24):C.GC_1395,(0,25):C.GC_1395,(0,26):C.GC_1399,(0,28):C.GC_1395,(0,29):C.GC_1395,(0,30):C.GC_1399,(0,44):C.GC_943,(0,2):C.GC_937,(0,6):C.GC_937,(0,3):C.GC_937,(0,7):C.GC_937,(0,8):C.GC_943,(0,35):C.GC_765,(0,36):C.GC_764,(0,31):C.GC_760,(0,34):C.GC_760,(0,11):C.GC_765,(0,12):C.GC_764,(0,37):C.GC_760,(0,9):C.GC_760,(0,20):C.GC_764,(0,21):C.GC_765,(0,14):C.GC_761,(0,17):C.GC_761,(0,32):C.GC_764,(0,33):C.GC_765,(0,23):C.GC_761,(0,27):C.GC_761,(0,40):C.GC_761,(0,42):C.GC_761,(0,45):C.GC_760,(0,4):C.GC_760,(0,41):C.GC_761,(0,43):C.GC_761,(0,46):C.GC_760,(0,5):C.GC_760})

V_368 = Vertex(name = 'V_368',
               particles = [ P.W__plus__, P.W__plus__, P.G__minus__, P.G__minus__, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS91 ],
               couplings = {(0,0):C.GC_1351})

V_369 = Vertex(name = 'V_369',
               particles = [ P.A, P.A, P.W__plus__, P.G0, P.G__minus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVSS1, L.VVVSS10, L.VVVSS104, L.VVVSS105, L.VVVSS106, L.VVVSS107, L.VVVSS116, L.VVVSS117, L.VVVSS119, L.VVVSS12, L.VVVSS120, L.VVVSS122, L.VVVSS123, L.VVVSS125, L.VVVSS126, L.VVVSS128, L.VVVSS129, L.VVVSS136, L.VVVSS137, L.VVVSS139, L.VVVSS140, L.VVVSS144, L.VVVSS145, L.VVVSS146, L.VVVSS147, L.VVVSS148, L.VVVSS149, L.VVVSS15, L.VVVSS150, L.VVVSS151, L.VVVSS152, L.VVVSS153, L.VVVSS155, L.VVVSS156, L.VVVSS158, L.VVVSS161, L.VVVSS162, L.VVVSS163, L.VVVSS164, L.VVVSS17, L.VVVSS170, L.VVVSS171, L.VVVSS172, L.VVVSS173, L.VVVSS177, L.VVVSS181, L.VVVSS183, L.VVVSS184, L.VVVSS185, L.VVVSS186, L.VVVSS187, L.VVVSS188, L.VVVSS19, L.VVVSS190, L.VVVSS191, L.VVVSS192, L.VVVSS193, L.VVVSS195, L.VVVSS198, L.VVVSS2, L.VVVSS20, L.VVVSS200, L.VVVSS201, L.VVVSS207, L.VVVSS209, L.VVVSS218, L.VVVSS22, L.VVVSS223, L.VVVSS224, L.VVVSS225, L.VVVSS226, L.VVVSS227, L.VVVSS228, L.VVVSS229, L.VVVSS23, L.VVVSS230, L.VVVSS231, L.VVVSS232, L.VVVSS233, L.VVVSS235, L.VVVSS238, L.VVVSS240, L.VVVSS241, L.VVVSS246, L.VVVSS248, L.VVVSS25, L.VVVSS26, L.VVVSS27, L.VVVSS28, L.VVVSS29, L.VVVSS30, L.VVVSS32, L.VVVSS33, L.VVVSS34, L.VVVSS35, L.VVVSS36, L.VVVSS37, L.VVVSS38, L.VVVSS39, L.VVVSS40, L.VVVSS42, L.VVVSS43, L.VVVSS44, L.VVVSS45, L.VVVSS46, L.VVVSS47, L.VVVSS48, L.VVVSS49, L.VVVSS5, L.VVVSS50, L.VVVSS51, L.VVVSS52, L.VVVSS53, L.VVVSS54, L.VVVSS55, L.VVVSS62, L.VVVSS63, L.VVVSS64, L.VVVSS66, L.VVVSS67, L.VVVSS70, L.VVVSS71, L.VVVSS77, L.VVVSS78, L.VVVSS79, L.VVVSS8, L.VVVSS81, L.VVVSS82, L.VVVSS85, L.VVVSS86, L.VVVSS87, L.VVVSS92, L.VVVSS94, L.VVVSS96, L.VVVSS97 ],
               couplings = {(0,0):C.GC_7441,(0,59):C.GC_7438,(0,19):C.GC_7434,(0,20):C.GC_7434,(0,23):C.GC_5169,(0,44):C.GC_7437,(0,46):C.GC_5173,(0,65):C.GC_7437,(0,68):C.GC_5173,(0,109):C.GC_7493,(0,111):C.GC_7493,(0,104):C.GC_5166,(0,105):C.GC_5166,(0,52):C.GC_7487,(0,85):C.GC_7492,(0,66):C.GC_7474,(0,87):C.GC_7487,(0,92):C.GC_7492,(0,90):C.GC_7474,(0,94):C.GC_7458,(0,95):C.GC_7468,(0,93):C.GC_7456,(0,98):C.GC_5165,(0,99):C.GC_5158,(0,96):C.GC_7475,(0,97):C.GC_7475,(0,6):C.GC_7509,(0,7):C.GC_5165,(0,8):C.GC_5165,(0,10):C.GC_7509,(0,11):C.GC_5158,(0,12):C.GC_5165,(0,113):C.GC_7486,(0,118):C.GC_7508,(0,119):C.GC_5157,(0,115):C.GC_7488,(0,116):C.GC_7489,(0,117):C.GC_7475,(0,120):C.GC_7486,(0,126):C.GC_5157,(0,127):C.GC_7508,(0,122):C.GC_7489,(0,123):C.GC_7488,(0,124):C.GC_7475,(0,129):C.GC_7459,(0,130):C.GC_7467,(0,128):C.GC_7455,(0,133):C.GC_5166,(0,134):C.GC_5157,(0,131):C.GC_7474,(0,132):C.GC_7474,(0,32):C.GC_7493,(0,33):C.GC_7493,(0,56):C.GC_5166,(0,78):C.GC_5166,(0,24):C.GC_7446,(0,34):C.GC_7447,(0,47):C.GC_7472,(0,57):C.GC_7473,(0,69):C.GC_7472,(0,79):C.GC_7473,(0,25):C.GC_7488,(0,70):C.GC_7489,(0,110):C.GC_7492,(0,17):C.GC_7492,(0,28):C.GC_7472,(0,35):C.GC_7489,(0,53):C.GC_7489,(0,58):C.GC_7474,(0,72):C.GC_7487,(0,75):C.GC_7474,(0,15):C.GC_7493,(0,37):C.GC_7473,(0,40):C.GC_7488,(0,63):C.GC_7475,(0,81):C.GC_7486,(0,26):C.GC_7488,(0,49):C.GC_7489,(0,112):C.GC_7509,(0,18):C.GC_7509,(0,29):C.GC_7472,(0,36):C.GC_7489,(0,50):C.GC_7487,(0,54):C.GC_7474,(0,76):C.GC_7489,(0,80):C.GC_7474,(0,16):C.GC_7508,(0,38):C.GC_7473,(0,41):C.GC_7488,(0,61):C.GC_7486,(0,83):C.GC_7475,(0,106):C.GC_5158,(0,107):C.GC_5165,(0,30):C.GC_7475,(0,31):C.GC_7475,(0,55):C.GC_7488,(0,77):C.GC_7488,(0,39):C.GC_7376,(0,27):C.GC_7379,(0,108):C.GC_7376,(0,125):C.GC_7376,(0,21):C.GC_7376,(0,22):C.GC_7376,(0,45):C.GC_7376,(0,67):C.GC_7376,(0,9):C.GC_7379,(0,1):C.GC_7376,(0,102):C.GC_7506,(0,100):C.GC_7495,(0,60):C.GC_7507,(0,86):C.GC_7457,(0,74):C.GC_7445,(0,88):C.GC_7507,(0,91):C.GC_7457,(0,89):C.GC_7445,(0,4):C.GC_7507,(0,2):C.GC_7494,(0,114):C.GC_7506,(0,121):C.GC_7506,(0,51):C.GC_7495,(0,62):C.GC_7494,(0,73):C.GC_7495,(0,82):C.GC_7494,(0,48):C.GC_7454,(0,103):C.GC_7494,(0,5):C.GC_7495,(0,71):C.GC_7454,(0,101):C.GC_7507,(0,3):C.GC_7506,(0,13):C.GC_7457,(0,14):C.GC_7469,(0,42):C.GC_7454,(0,43):C.GC_7454,(0,64):C.GC_7445,(0,84):C.GC_7445})

V_370 = Vertex(name = 'V_370',
               particles = [ P.A, P.A, P.W__plus__, P.G0, P.G__minus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVSS1, L.VVVSS139, L.VVVSS140, L.VVVSS177, L.VVVSS2, L.VVVSS218 ],
               couplings = {(0,0):C.GC_7525,(0,4):C.GC_7526,(0,1):C.GC_7521,(0,2):C.GC_7521,(0,3):C.GC_7519,(0,5):C.GC_7519})

V_371 = Vertex(name = 'V_371',
               particles = [ P.A, P.A, P.W__plus__, P.G0, P.G__minus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVSS1, L.VVVSS139, L.VVVSS140, L.VVVSS177, L.VVVSS2, L.VVVSS218 ],
               couplings = {(0,0):C.GC_7412,(0,4):C.GC_7409,(0,1):C.GC_7405,(0,2):C.GC_7405,(0,3):C.GC_7408,(0,5):C.GC_7408})

V_372 = Vertex(name = 'V_372',
               particles = [ P.A, P.A, P.W__plus__, P.G__minus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVSS1, L.VVVSS10, L.VVVSS104, L.VVVSS105, L.VVVSS106, L.VVVSS107, L.VVVSS108, L.VVVSS109, L.VVVSS110, L.VVVSS111, L.VVVSS112, L.VVVSS113, L.VVVSS114, L.VVVSS115, L.VVVSS116, L.VVVSS117, L.VVVSS119, L.VVVSS12, L.VVVSS120, L.VVVSS122, L.VVVSS123, L.VVVSS125, L.VVVSS126, L.VVVSS128, L.VVVSS129, L.VVVSS136, L.VVVSS137, L.VVVSS139, L.VVVSS140, L.VVVSS144, L.VVVSS145, L.VVVSS147, L.VVVSS15, L.VVVSS150, L.VVVSS151, L.VVVSS157, L.VVVSS158, L.VVVSS159, L.VVVSS160, L.VVVSS161, L.VVVSS162, L.VVVSS163, L.VVVSS164, L.VVVSS165, L.VVVSS166, L.VVVSS168, L.VVVSS169, L.VVVSS17, L.VVVSS170, L.VVVSS171, L.VVVSS172, L.VVVSS173, L.VVVSS177, L.VVVSS181, L.VVVSS184, L.VVVSS187, L.VVVSS188, L.VVVSS19, L.VVVSS194, L.VVVSS195, L.VVVSS196, L.VVVSS197, L.VVVSS198, L.VVVSS2, L.VVVSS20, L.VVVSS200, L.VVVSS201, L.VVVSS203, L.VVVSS204, L.VVVSS205, L.VVVSS206, L.VVVSS207, L.VVVSS209, L.VVVSS218, L.VVVSS223, L.VVVSS225, L.VVVSS228, L.VVVSS229, L.VVVSS234, L.VVVSS235, L.VVVSS236, L.VVVSS237, L.VVVSS238, L.VVVSS240, L.VVVSS241, L.VVVSS242, L.VVVSS243, L.VVVSS244, L.VVVSS245, L.VVVSS246, L.VVVSS248, L.VVVSS27, L.VVVSS28, L.VVVSS34, L.VVVSS35, L.VVVSS36, L.VVVSS42, L.VVVSS43, L.VVVSS44, L.VVVSS45, L.VVVSS5, L.VVVSS54, L.VVVSS55, L.VVVSS57, L.VVVSS58, L.VVVSS60, L.VVVSS61, L.VVVSS62, L.VVVSS63, L.VVVSS64, L.VVVSS66, L.VVVSS67, L.VVVSS70, L.VVVSS71, L.VVVSS72, L.VVVSS73, L.VVVSS75, L.VVVSS76, L.VVVSS77, L.VVVSS78, L.VVVSS79, L.VVVSS8, L.VVVSS81, L.VVVSS82, L.VVVSS85, L.VVVSS86, L.VVVSS87, L.VVVSS88, L.VVVSS89, L.VVVSS90, L.VVVSS91, L.VVVSS92, L.VVVSS94, L.VVVSS96, L.VVVSS97 ],
               couplings = {(0,0):C.GC_7440,(0,63):C.GC_7439,(0,27):C.GC_7435,(0,28):C.GC_7435,(0,35):C.GC_5172,(0,52):C.GC_7436,(0,58):C.GC_5170,(0,73):C.GC_7436,(0,78):C.GC_5170,(0,57):C.GC_7481,(0,91):C.GC_7481,(0,94):C.GC_7461,(0,95):C.GC_7463,(0,93):C.GC_7452,(0,10):C.GC_7501,(0,12):C.GC_7501,(0,6):C.GC_5162,(0,7):C.GC_5162,(0,14):C.GC_7504,(0,15):C.GC_5161,(0,16):C.GC_5161,(0,18):C.GC_7504,(0,19):C.GC_5162,(0,20):C.GC_5161,(0,101):C.GC_7482,(0,105):C.GC_7502,(0,103):C.GC_7480,(0,110):C.GC_7503,(0,111):C.GC_5163,(0,107):C.GC_7483,(0,108):C.GC_7484,(0,109):C.GC_7480,(0,112):C.GC_7482,(0,117):C.GC_7502,(0,115):C.GC_7480,(0,122):C.GC_5163,(0,123):C.GC_7503,(0,118):C.GC_7484,(0,119):C.GC_7483,(0,120):C.GC_7480,(0,125):C.GC_7460,(0,126):C.GC_7464,(0,124):C.GC_7453,(0,129):C.GC_5163,(0,130):C.GC_5160,(0,127):C.GC_7479,(0,128):C.GC_7479,(0,133):C.GC_5160,(0,134):C.GC_5163,(0,131):C.GC_7479,(0,132):C.GC_7479,(0,45):C.GC_7501,(0,46):C.GC_7501,(0,70):C.GC_5162,(0,88):C.GC_5162,(0,31):C.GC_7450,(0,36):C.GC_7449,(0,54):C.GC_7478,(0,59):C.GC_7477,(0,75):C.GC_7478,(0,79):C.GC_7477,(0,37):C.GC_7484,(0,80):C.GC_7483,(0,25):C.GC_7501,(0,33):C.GC_7478,(0,39):C.GC_7484,(0,62):C.GC_7479,(0,76):C.GC_7481,(0,11):C.GC_7502,(0,23):C.GC_7502,(0,41):C.GC_7477,(0,48):C.GC_7483,(0,67):C.GC_7483,(0,71):C.GC_7480,(0,83):C.GC_7482,(0,85):C.GC_7480,(0,38):C.GC_7484,(0,61):C.GC_7483,(0,26):C.GC_7504,(0,34):C.GC_7478,(0,40):C.GC_7484,(0,55):C.GC_7481,(0,82):C.GC_7479,(0,13):C.GC_7503,(0,24):C.GC_7503,(0,42):C.GC_7477,(0,49):C.GC_7483,(0,65):C.GC_7482,(0,68):C.GC_7480,(0,86):C.GC_7483,(0,89):C.GC_7480,(0,8):C.GC_5160,(0,9):C.GC_5163,(0,43):C.GC_7479,(0,44):C.GC_7479,(0,69):C.GC_7484,(0,87):C.GC_7484,(0,47):C.GC_7377,(0,32):C.GC_7378,(0,100):C.GC_7377,(0,121):C.GC_7377,(0,29):C.GC_7377,(0,30):C.GC_7377,(0,53):C.GC_7377,(0,74):C.GC_7377,(0,17):C.GC_7378,(0,1):C.GC_7377,(0,98):C.GC_7499,(0,96):C.GC_7498,(0,64):C.GC_7500,(0,92):C.GC_7500,(0,4):C.GC_7500,(0,2):C.GC_7497,(0,102):C.GC_7499,(0,106):C.GC_7465,(0,104):C.GC_7448,(0,113):C.GC_7499,(0,116):C.GC_7465,(0,114):C.GC_7448,(0,56):C.GC_7498,(0,66):C.GC_7497,(0,77):C.GC_7498,(0,84):C.GC_7497,(0,60):C.GC_7451,(0,99):C.GC_7497,(0,5):C.GC_7498,(0,81):C.GC_7451,(0,97):C.GC_7500,(0,3):C.GC_7499,(0,21):C.GC_7465,(0,22):C.GC_7466,(0,50):C.GC_7451,(0,51):C.GC_7451,(0,72):C.GC_7448,(0,90):C.GC_7448})

V_373 = Vertex(name = 'V_373',
               particles = [ P.A, P.A, P.W__plus__, P.G__minus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVSS1, L.VVVSS139, L.VVVSS140, L.VVVSS177, L.VVVSS2, L.VVVSS218 ],
               couplings = {(0,0):C.GC_7527,(0,4):C.GC_7524,(0,1):C.GC_7518,(0,2):C.GC_7518,(0,3):C.GC_7523,(0,5):C.GC_7523})

V_374 = Vertex(name = 'V_374',
               particles = [ P.A, P.A, P.W__plus__, P.G__minus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVSS1, L.VVVSS139, L.VVVSS140, L.VVVSS177, L.VVVSS2, L.VVVSS218 ],
               couplings = {(0,0):C.GC_7411,(0,4):C.GC_7410,(0,1):C.GC_7406,(0,2):C.GC_7406,(0,3):C.GC_7407,(0,5):C.GC_7407})

V_375 = Vertex(name = 'V_375',
               particles = [ P.A, P.A, P.W__plus__, P.G__minus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVS1, L.VVVS10, L.VVVS104, L.VVVS106, L.VVVS109, L.VVVS110, L.VVVS12, L.VVVS15, L.VVVS17, L.VVVS19, L.VVVS2, L.VVVS20, L.VVVS27, L.VVVS28, L.VVVS35, L.VVVS36, L.VVVS37, L.VVVS46, L.VVVS47, L.VVVS48, L.VVVS49, L.VVVS5, L.VVVS58, L.VVVS59, L.VVVS63, L.VVVS64, L.VVVS66, L.VVVS69, L.VVVS70, L.VVVS77, L.VVVS8, L.VVVS81, L.VVVS84, L.VVVS87, L.VVVS88, L.VVVS99 ],
               couplings = {(0,9):C.GC_7420,(0,12):C.GC_7420,(0,15):C.GC_7417,(0,16):C.GC_7418,(0,14):C.GC_7416,(0,26):C.GC_7415,(0,32):C.GC_7419,(0,3):C.GC_7419,(0,27):C.GC_7419,(0,4):C.GC_7420,(0,28):C.GC_7419,(0,33):C.GC_7420,(0,0):C.GC_7433,(0,10):C.GC_7432,(0,22):C.GC_7430,(0,23):C.GC_7430,(0,29):C.GC_7431,(0,35):C.GC_7431,(0,19):C.GC_7425,(0,17):C.GC_7424,(0,11):C.GC_7426,(0,13):C.GC_7426,(0,34):C.GC_7424,(0,5):C.GC_7424,(0,20):C.GC_7423,(0,18):C.GC_7426,(0,8):C.GC_7396,(0,7):C.GC_7397,(0,21):C.GC_7396,(0,30):C.GC_7396,(0,24):C.GC_7396,(0,25):C.GC_7396,(0,31):C.GC_7396,(0,2):C.GC_7396,(0,6):C.GC_7397,(0,1):C.GC_7396})

V_376 = Vertex(name = 'V_376',
               particles = [ P.A, P.A, P.W__plus__, P.G__minus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVS1, L.VVVS2, L.VVVS58, L.VVVS59, L.VVVS77, L.VVVS99 ],
               couplings = {(0,0):C.GC_7534,(0,1):C.GC_7533,(0,2):C.GC_7531,(0,3):C.GC_7531,(0,4):C.GC_7532,(0,5):C.GC_7532})

V_377 = Vertex(name = 'V_377',
               particles = [ P.A, P.A, P.W__plus__, P.G__minus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVS1, L.VVVS2, L.VVVS58, L.VVVS59, L.VVVS77, L.VVVS99 ],
               couplings = {(0,0):C.GC_7404,(0,1):C.GC_7403,(0,2):C.GC_7401,(0,3):C.GC_7401,(0,4):C.GC_7402,(0,5):C.GC_7402})

V_378 = Vertex(name = 'V_378',
               particles = [ P.A, P.A, P.W__minus__, P.W__plus__, P.G__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVVSS10, L.VVVVSS100, L.VVVVSS101, L.VVVVSS102, L.VVVVSS103, L.VVVVSS105, L.VVVVSS106, L.VVVVSS107, L.VVVVSS108, L.VVVVSS109, L.VVVVSS11, L.VVVVSS110, L.VVVVSS111, L.VVVVSS112, L.VVVVSS113, L.VVVVSS114, L.VVVVSS115, L.VVVVSS116, L.VVVVSS117, L.VVVVSS118, L.VVVVSS119, L.VVVVSS12, L.VVVVSS120, L.VVVVSS121, L.VVVVSS122, L.VVVVSS123, L.VVVVSS124, L.VVVVSS125, L.VVVVSS126, L.VVVVSS127, L.VVVVSS128, L.VVVVSS129, L.VVVVSS13, L.VVVVSS133, L.VVVVSS134, L.VVVVSS135, L.VVVVSS136, L.VVVVSS137, L.VVVVSS138, L.VVVVSS139, L.VVVVSS14, L.VVVVSS140, L.VVVVSS141, L.VVVVSS142, L.VVVVSS144, L.VVVVSS145, L.VVVVSS146, L.VVVVSS147, L.VVVVSS148, L.VVVVSS149, L.VVVVSS15, L.VVVVSS150, L.VVVVSS151, L.VVVVSS152, L.VVVVSS153, L.VVVVSS154, L.VVVVSS155, L.VVVVSS156, L.VVVVSS157, L.VVVVSS158, L.VVVVSS159, L.VVVVSS16, L.VVVVSS160, L.VVVVSS161, L.VVVVSS162, L.VVVVSS163, L.VVVVSS164, L.VVVVSS169, L.VVVVSS17, L.VVVVSS170, L.VVVVSS171, L.VVVVSS172, L.VVVVSS175, L.VVVVSS176, L.VVVVSS177, L.VVVVSS178, L.VVVVSS179, L.VVVVSS18, L.VVVVSS180, L.VVVVSS181, L.VVVVSS182, L.VVVVSS183, L.VVVVSS184, L.VVVVSS185, L.VVVVSS186, L.VVVVSS187, L.VVVVSS188, L.VVVVSS189, L.VVVVSS19, L.VVVVSS190, L.VVVVSS191, L.VVVVSS192, L.VVVVSS193, L.VVVVSS194, L.VVVVSS195, L.VVVVSS196, L.VVVVSS197, L.VVVVSS198, L.VVVVSS199, L.VVVVSS2, L.VVVVSS20, L.VVVVSS200, L.VVVVSS201, L.VVVVSS21, L.VVVVSS210, L.VVVVSS211, L.VVVVSS212, L.VVVVSS213, L.VVVVSS214, L.VVVVSS215, L.VVVVSS216, L.VVVVSS217, L.VVVVSS218, L.VVVVSS219, L.VVVVSS22, L.VVVVSS221, L.VVVVSS222, L.VVVVSS223, L.VVVVSS224, L.VVVVSS225, L.VVVVSS226, L.VVVVSS227, L.VVVVSS228, L.VVVVSS229, L.VVVVSS23, L.VVVVSS230, L.VVVVSS231, L.VVVVSS232, L.VVVVSS233, L.VVVVSS234, L.VVVVSS235, L.VVVVSS236, L.VVVVSS237, L.VVVVSS238, L.VVVVSS239, L.VVVVSS24, L.VVVVSS240, L.VVVVSS241, L.VVVVSS242, L.VVVVSS243, L.VVVVSS244, L.VVVVSS245, L.VVVVSS246, L.VVVVSS247, L.VVVVSS248, L.VVVVSS249, L.VVVVSS25, L.VVVVSS250, L.VVVVSS251, L.VVVVSS252, L.VVVVSS253, L.VVVVSS254, L.VVVVSS255, L.VVVVSS256, L.VVVVSS257, L.VVVVSS26, L.VVVVSS267, L.VVVVSS268, L.VVVVSS269, L.VVVVSS27, L.VVVVSS270, L.VVVVSS273, L.VVVVSS274, L.VVVVSS275, L.VVVVSS276, L.VVVVSS277, L.VVVVSS278, L.VVVVSS279, L.VVVVSS28, L.VVVVSS280, L.VVVVSS281, L.VVVVSS282, L.VVVVSS283, L.VVVVSS284, L.VVVVSS285, L.VVVVSS286, L.VVVVSS287, L.VVVVSS288, L.VVVVSS289, L.VVVVSS29, L.VVVVSS290, L.VVVVSS291, L.VVVVSS292, L.VVVVSS293, L.VVVVSS294, L.VVVVSS295, L.VVVVSS296, L.VVVVSS297, L.VVVVSS298, L.VVVVSS299, L.VVVVSS3, L.VVVVSS30, L.VVVVSS300, L.VVVVSS301, L.VVVVSS302, L.VVVVSS303, L.VVVVSS304, L.VVVVSS305, L.VVVVSS306, L.VVVVSS307, L.VVVVSS308, L.VVVVSS309, L.VVVVSS31, L.VVVVSS310, L.VVVVSS311, L.VVVVSS312, L.VVVVSS313, L.VVVVSS314, L.VVVVSS315, L.VVVVSS32, L.VVVVSS33, L.VVVVSS34, L.VVVVSS35, L.VVVVSS36, L.VVVVSS360, L.VVVVSS361, L.VVVVSS362, L.VVVVSS363, L.VVVVSS364, L.VVVVSS365, L.VVVVSS366, L.VVVVSS367, L.VVVVSS368, L.VVVVSS369, L.VVVVSS37, L.VVVVSS370, L.VVVVSS371, L.VVVVSS372, L.VVVVSS373, L.VVVVSS374, L.VVVVSS375, L.VVVVSS376, L.VVVVSS377, L.VVVVSS378, L.VVVVSS379, L.VVVVSS38, L.VVVVSS380, L.VVVVSS381, L.VVVVSS382, L.VVVVSS383, L.VVVVSS384, L.VVVVSS385, L.VVVVSS386, L.VVVVSS387, L.VVVVSS388, L.VVVVSS389, L.VVVVSS39, L.VVVVSS390, L.VVVVSS391, L.VVVVSS392, L.VVVVSS393, L.VVVVSS394, L.VVVVSS395, L.VVVVSS396, L.VVVVSS397, L.VVVVSS398, L.VVVVSS399, L.VVVVSS4, L.VVVVSS40, L.VVVVSS400, L.VVVVSS401, L.VVVVSS402, L.VVVVSS403, L.VVVVSS404, L.VVVVSS405, L.VVVVSS406, L.VVVVSS41, L.VVVVSS42, L.VVVVSS43, L.VVVVSS44, L.VVVVSS45, L.VVVVSS46, L.VVVVSS47, L.VVVVSS48, L.VVVVSS49, L.VVVVSS5, L.VVVVSS50, L.VVVVSS51, L.VVVVSS52, L.VVVVSS53, L.VVVVSS54, L.VVVVSS55, L.VVVVSS56, L.VVVVSS57, L.VVVVSS58, L.VVVVSS59, L.VVVVSS6, L.VVVVSS60, L.VVVVSS61, L.VVVVSS62, L.VVVVSS63, L.VVVVSS64, L.VVVVSS65, L.VVVVSS66, L.VVVVSS67, L.VVVVSS68, L.VVVVSS69, L.VVVVSS7, L.VVVVSS71, L.VVVVSS72, L.VVVVSS74, L.VVVVSS75, L.VVVVSS8, L.VVVVSS81, L.VVVVSS82, L.VVVVSS83, L.VVVVSS84, L.VVVVSS85, L.VVVVSS86, L.VVVVSS87, L.VVVVSS88, L.VVVVSS89, L.VVVVSS9, L.VVVVSS90, L.VVVVSS91, L.VVVVSS92, L.VVVVSS93, L.VVVVSS94, L.VVVVSS95, L.VVVVSS96, L.VVVVSS99 ],
               couplings = {(0,138):C.GC_1622,(0,192):C.GC_1622,(0,248):C.GC_1623,(0,21):C.GC_6359,(0,40):C.GC_6359,(0,61):C.GC_6359,(0,77):C.GC_6360,(0,297):C.GC_6361,(0,302):C.GC_6361,(0,0):C.GC_6361,(0,10):C.GC_6362,(0,168):C.GC_6360,(0,179):C.GC_6359,(0,209):C.GC_6360,(0,210):C.GC_6360,(0,213):C.GC_1710,(0,224):C.GC_1710,(0,103):C.GC_6362,(0,114):C.GC_1710,(0,124):C.GC_6362,(0,146):C.GC_1710,(0,155):C.GC_6361,(0,159):C.GC_6362,(0,277):C.GC_6752,(0,280):C.GC_6748,(0,282):C.GC_1718,(0,283):C.GC_1718,(0,284):C.GC_1712,(0,285):C.GC_1712,(0,235):C.GC_6758,(0,246):C.GC_6697,(0,258):C.GC_1717,(0,266):C.GC_1715,(0,267):C.GC_6697,(0,268):C.GC_6758,(0,269):C.GC_1717,(0,270):C.GC_1715,(0,273):C.GC_1716,(0,274):C.GC_1714,(0,304):C.GC_6755,(0,307):C.GC_6746,(0,309):C.GC_1716,(0,310):C.GC_1716,(0,311):C.GC_1714,(0,313):C.GC_1714,(0,314):C.GC_1722,(0,315):C.GC_1722,(0,287):C.GC_6762,(0,288):C.GC_6698,(0,289):C.GC_1719,(0,290):C.GC_1713,(0,291):C.GC_1720,(0,292):C.GC_6698,(0,293):C.GC_6762,(0,294):C.GC_1719,(0,295):C.GC_1713,(0,296):C.GC_1720,(0,298):C.GC_1718,(0,299):C.GC_1712,(0,316):C.GC_6717,(0,317):C.GC_6717,(0,320):C.GC_6359,(0,1):C.GC_6359,(0,318):C.GC_6355,(0,319):C.GC_6355,(0,5):C.GC_6360,(0,6):C.GC_6360,(0,7):C.GC_1692,(0,2):C.GC_6355,(0,3):C.GC_6355,(0,4):C.GC_1688,(0,17):C.GC_1723,(0,18):C.GC_1720,(0,8):C.GC_6721,(0,9):C.GC_6721,(0,11):C.GC_1703,(0,12):C.GC_6729,(0,13):C.GC_6729,(0,14):C.GC_1702,(0,30):C.GC_1722,(0,31):C.GC_1721,(0,19):C.GC_6728,(0,20):C.GC_6728,(0,22):C.GC_1702,(0,23):C.GC_1705,(0,24):C.GC_6726,(0,25):C.GC_6726,(0,26):C.GC_1703,(0,27):C.GC_1703,(0,33):C.GC_6706,(0,39):C.GC_6361,(0,35):C.GC_6355,(0,36):C.GC_6357,(0,37):C.GC_6357,(0,44):C.GC_6359,(0,46):C.GC_1707,(0,41):C.GC_6357,(0,43):C.GC_1684,(0,53):C.GC_6748,(0,54):C.GC_1712,(0,55):C.GC_1718,(0,56):C.GC_1718,(0,47):C.GC_6716,(0,48):C.GC_1698,(0,49):C.GC_1701,(0,51):C.GC_6730,(0,52):C.GC_1699,(0,65):C.GC_1716,(0,66):C.GC_1716,(0,57):C.GC_6727,(0,58):C.GC_6712,(0,59):C.GC_1700,(0,60):C.GC_1694,(0,62):C.GC_6710,(0,63):C.GC_1698,(0,64):C.GC_1698,(0,67):C.GC_6706,(0,72):C.GC_6359,(0,70):C.GC_6357,(0,80):C.GC_6361,(0,81):C.GC_1707,(0,74):C.GC_6355,(0,75):C.GC_6357,(0,76):C.GC_6357,(0,78):C.GC_1684,(0,87):C.GC_1718,(0,89):C.GC_1718,(0,82):C.GC_6722,(0,83):C.GC_6707,(0,84):C.GC_1700,(0,85):C.GC_6715,(0,86):C.GC_1698,(0,97):C.GC_6746,(0,98):C.GC_1714,(0,101):C.GC_1716,(0,102):C.GC_1716,(0,90):C.GC_6711,(0,91):C.GC_1698,(0,92):C.GC_1701,(0,93):C.GC_1698,(0,94):C.GC_6731,(0,95):C.GC_1699,(0,96):C.GC_1694,(0,104):C.GC_6706,(0,109):C.GC_6361,(0,106):C.GC_6357,(0,107):C.GC_6355,(0,108):C.GC_6357,(0,116):C.GC_6359,(0,117):C.GC_1707,(0,112):C.GC_6357,(0,113):C.GC_1684,(0,123):C.GC_1712,(0,125):C.GC_6748,(0,126):C.GC_1718,(0,127):C.GC_1718,(0,118):C.GC_1698,(0,119):C.GC_6716,(0,120):C.GC_1701,(0,121):C.GC_6730,(0,122):C.GC_1699,(0,136):C.GC_1716,(0,137):C.GC_1716,(0,128):C.GC_6712,(0,129):C.GC_6727,(0,130):C.GC_1700,(0,131):C.GC_1694,(0,132):C.GC_6710,(0,133):C.GC_1698,(0,134):C.GC_1698,(0,156):C.GC_6706,(0,162):C.GC_6359,(0,160):C.GC_6357,(0,167):C.GC_6361,(0,170):C.GC_1707,(0,163):C.GC_6357,(0,164):C.GC_6355,(0,165):C.GC_6357,(0,166):C.GC_1684,(0,176):C.GC_1718,(0,177):C.GC_1718,(0,171):C.GC_6707,(0,172):C.GC_6722,(0,173):C.GC_1700,(0,174):C.GC_6715,(0,175):C.GC_1698,(0,186):C.GC_1714,(0,187):C.GC_6746,(0,188):C.GC_1716,(0,189):C.GC_1716,(0,178):C.GC_1698,(0,180):C.GC_6711,(0,181):C.GC_1701,(0,182):C.GC_1698,(0,183):C.GC_6731,(0,184):C.GC_1699,(0,185):C.GC_1694,(0,215):C.GC_6696,(0,216):C.GC_6695,(0,214):C.GC_6685,(0,219):C.GC_6362,(0,220):C.GC_6361,(0,217):C.GC_6355,(0,218):C.GC_6355,(0,226):C.GC_6362,(0,227):C.GC_6361,(0,221):C.GC_6355,(0,222):C.GC_1685,(0,223):C.GC_6355,(0,225):C.GC_1685,(0,234):C.GC_1718,(0,236):C.GC_1712,(0,228):C.GC_6724,(0,229):C.GC_1696,(0,230):C.GC_1697,(0,231):C.GC_6724,(0,232):C.GC_1696,(0,233):C.GC_1697,(0,245):C.GC_1716,(0,247):C.GC_1714,(0,237):C.GC_6719,(0,238):C.GC_1697,(0,239):C.GC_1696,(0,240):C.GC_1685,(0,241):C.GC_6719,(0,242):C.GC_1697,(0,243):C.GC_1696,(0,244):C.GC_1685,(0,139):C.GC_6717,(0,193):C.GC_6717,(0,249):C.GC_6686,(0,140):C.GC_6355,(0,250):C.GC_6357,(0,196):C.GC_6355,(0,252):C.GC_6357,(0,278):C.GC_6763,(0,145):C.GC_1695,(0,199):C.GC_6723,(0,255):C.GC_6709,(0,305):C.GC_6759,(0,150):C.GC_6718,(0,204):C.GC_1695,(0,261):C.GC_6714,(0,195):C.GC_6355,(0,251):C.GC_6357,(0,143):C.GC_6355,(0,253):C.GC_6357,(0,281):C.GC_6758,(0,147):C.GC_6723,(0,200):C.GC_1695,(0,256):C.GC_6709,(0,308):C.GC_6762,(0,151):C.GC_1695,(0,205):C.GC_6718,(0,262):C.GC_6714,(0,144):C.GC_1685,(0,198):C.GC_1685,(0,254):C.GC_1689,(0,148):C.GC_1695,(0,201):C.GC_1695,(0,259):C.GC_1704,(0,152):C.GC_1694,(0,206):C.GC_1694,(0,263):C.GC_1705,(0,149):C.GC_1694,(0,203):C.GC_1694,(0,260):C.GC_1705,(0,153):C.GC_1695,(0,207):C.GC_1695,(0,264):C.GC_1704,(0,154):C.GC_1687,(0,208):C.GC_1687,(0,265):C.GC_1689,(0,32):C.GC_6359,(0,68):C.GC_6360,(0,286):C.GC_6359,(0,312):C.GC_6359,(0,191):C.GC_6359,(0,211):C.GC_6360,(0,100):C.GC_6360,(0,135):C.GC_6360,(0,38):C.GC_6359,(0,79):C.GC_6359,(0,110):C.GC_6359,(0,169):C.GC_6359,(0,50):C.GC_6360,(0,202):C.GC_6359,(0,88):C.GC_6359,(0,212):C.GC_6360,(0,257):C.GC_6742,(0,275):C.GC_6743,(0,99):C.GC_6741,(0,190):C.GC_6740,(0,276):C.GC_6747,(0,279):C.GC_6747,(0,271):C.GC_4243,(0,272):C.GC_4242,(0,303):C.GC_6753,(0,306):C.GC_6753,(0,300):C.GC_4243,(0,301):C.GC_4242,(0,15):C.GC_6751,(0,16):C.GC_6751,(0,28):C.GC_6745,(0,29):C.GC_6745,(0,34):C.GC_6741,(0,45):C.GC_4243,(0,42):C.GC_4237,(0,69):C.GC_6740,(0,73):C.GC_4243,(0,71):C.GC_4237,(0,105):C.GC_6741,(0,115):C.GC_4243,(0,111):C.GC_4237,(0,157):C.GC_6740,(0,161):C.GC_4243,(0,158):C.GC_4237,(0,194):C.GC_4236,(0,142):C.GC_4236,(0,141):C.GC_4236,(0,197):C.GC_4236})

V_379 = Vertex(name = 'V_379',
               particles = [ P.A, P.A, P.W__minus__, P.W__plus__, P.G__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVVSS10, L.VVVVSS100, L.VVVVSS101, L.VVVVSS102, L.VVVVSS105, L.VVVVSS106, L.VVVVSS11, L.VVVVSS12, L.VVVVSS135, L.VVVVSS136, L.VVVVSS137, L.VVVVSS139, L.VVVVSS14, L.VVVVSS140, L.VVVVSS144, L.VVVVSS16, L.VVVVSS171, L.VVVVSS175, L.VVVVSS177, L.VVVVSS178, L.VVVVSS179, L.VVVVSS18, L.VVVVSS182, L.VVVVSS21, L.VVVVSS212, L.VVVVSS213, L.VVVVSS214, L.VVVVSS215, L.VVVVSS218, L.VVVVSS222, L.VVVVSS23, L.VVVVSS242, L.VVVVSS244, L.VVVVSS247, L.VVVVSS26, L.VVVVSS27, L.VVVVSS270, L.VVVVSS274, L.VVVVSS275, L.VVVVSS276, L.VVVVSS277, L.VVVVSS279, L.VVVVSS28, L.VVVVSS29, L.VVVVSS300, L.VVVVSS303, L.VVVVSS304, L.VVVVSS32, L.VVVVSS33, L.VVVVSS363, L.VVVVSS364, L.VVVVSS365, L.VVVVSS366, L.VVVVSS367, L.VVVVSS369, L.VVVVSS371, L.VVVVSS372, L.VVVVSS391, L.VVVVSS393, L.VVVVSS394, L.VVVVSS395, L.VVVVSS396, L.VVVVSS7, L.VVVVSS8, L.VVVVSS95, L.VVVVSS96, L.VVVVSS99 ],
               couplings = {(0,31):C.GC_6560,(0,44):C.GC_6560,(0,57):C.GC_6561,(0,7):C.GC_6749,(0,12):C.GC_6755,(0,15):C.GC_6749,(0,21):C.GC_6746,(0,62):C.GC_1718,(0,63):C.GC_1718,(0,0):C.GC_1716,(0,6):C.GC_1714,(0,42):C.GC_6754,(0,43):C.GC_6752,(0,47):C.GC_6754,(0,48):C.GC_6748,(0,23):C.GC_1714,(0,30):C.GC_1714,(0,34):C.GC_1718,(0,35):C.GC_1712,(0,66):C.GC_6749,(0,1):C.GC_6749,(0,64):C.GC_6719,(0,65):C.GC_6719,(0,4):C.GC_6754,(0,5):C.GC_6754,(0,2):C.GC_6724,(0,3):C.GC_6724,(0,11):C.GC_1718,(0,8):C.GC_6708,(0,9):C.GC_6725,(0,10):C.GC_6714,(0,14):C.GC_6752,(0,13):C.GC_6720,(0,17):C.GC_6755,(0,16):C.GC_6725,(0,22):C.GC_1716,(0,18):C.GC_6713,(0,19):C.GC_6720,(0,20):C.GC_6709,(0,27):C.GC_1718,(0,24):C.GC_6725,(0,25):C.GC_6708,(0,26):C.GC_6714,(0,29):C.GC_6752,(0,28):C.GC_6720,(0,37):C.GC_6755,(0,36):C.GC_6725,(0,41):C.GC_1716,(0,38):C.GC_6720,(0,39):C.GC_6713,(0,40):C.GC_6709,(0,51):C.GC_1714,(0,52):C.GC_1716,(0,49):C.GC_6719,(0,50):C.GC_6719,(0,55):C.GC_1712,(0,56):C.GC_1718,(0,53):C.GC_6724,(0,54):C.GC_6724,(0,32):C.GC_6708,(0,58):C.GC_6714,(0,46):C.GC_6713,(0,60):C.GC_6709,(0,45):C.GC_6708,(0,59):C.GC_6714,(0,33):C.GC_6713,(0,61):C.GC_6709})

V_380 = Vertex(name = 'V_380',
               particles = [ P.A, P.A, P.W__minus__, P.W__plus__, P.G__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVVSS242, L.VVVVSS300, L.VVVVSS391 ],
               couplings = {(0,0):C.GC_1773,(0,1):C.GC_1773,(0,2):C.GC_1774})

V_381 = Vertex(name = 'V_381',
               particles = [ P.A, P.A, P.W__minus__, P.W__plus__, P.G__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVVSS242, L.VVVVSS300, L.VVVVSS391 ],
               couplings = {(0,0):C.GC_1871,(0,1):C.GC_1871,(0,2):C.GC_1873})

V_382 = Vertex(name = 'V_382',
               particles = [ P.A, P.W__minus__, P.W__plus__, P.G__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVSS1, L.VVVSS10, L.VVVSS103, L.VVVSS104, L.VVVSS105, L.VVVSS106, L.VVVSS107, L.VVVSS108, L.VVVSS111, L.VVVSS114, L.VVVSS115, L.VVVSS116, L.VVVSS117, L.VVVSS118, L.VVVSS12, L.VVVSS120, L.VVVSS121, L.VVVSS123, L.VVVSS124, L.VVVSS125, L.VVVSS126, L.VVVSS127, L.VVVSS128, L.VVVSS129, L.VVVSS130, L.VVVSS136, L.VVVSS137, L.VVVSS138, L.VVVSS139, L.VVVSS14, L.VVVSS140, L.VVVSS141, L.VVVSS142, L.VVVSS145, L.VVVSS146, L.VVVSS148, L.VVVSS149, L.VVVSS15, L.VVVSS152, L.VVVSS153, L.VVVSS155, L.VVVSS156, L.VVVSS157, L.VVVSS158, L.VVVSS16, L.VVVSS160, L.VVVSS161, L.VVVSS162, L.VVVSS163, L.VVVSS164, L.VVVSS166, L.VVVSS169, L.VVVSS17, L.VVVSS170, L.VVVSS171, L.VVVSS172, L.VVVSS173, L.VVVSS177, L.VVVSS178, L.VVVSS179, L.VVVSS18, L.VVVSS180, L.VVVSS182, L.VVVSS183, L.VVVSS185, L.VVVSS186, L.VVVSS190, L.VVVSS191, L.VVVSS192, L.VVVSS193, L.VVVSS194, L.VVVSS195, L.VVVSS197, L.VVVSS198, L.VVVSS199, L.VVVSS2, L.VVVSS200, L.VVVSS202, L.VVVSS204, L.VVVSS206, L.VVVSS207, L.VVVSS208, L.VVVSS209, L.VVVSS210, L.VVVSS218, L.VVVSS219, L.VVVSS22, L.VVVSS220, L.VVVSS221, L.VVVSS223, L.VVVSS224, L.VVVSS226, L.VVVSS227, L.VVVSS23, L.VVVSS230, L.VVVSS231, L.VVVSS232, L.VVVSS233, L.VVVSS234, L.VVVSS235, L.VVVSS237, L.VVVSS238, L.VVVSS239, L.VVVSS240, L.VVVSS241, L.VVVSS243, L.VVVSS244, L.VVVSS246, L.VVVSS247, L.VVVSS248, L.VVVSS249, L.VVVSS25, L.VVVSS26, L.VVVSS29, L.VVVSS30, L.VVVSS32, L.VVVSS33, L.VVVSS37, L.VVVSS38, L.VVVSS39, L.VVVSS4, L.VVVSS40, L.VVVSS41, L.VVVSS46, L.VVVSS47, L.VVVSS48, L.VVVSS49, L.VVVSS50, L.VVVSS51, L.VVVSS52, L.VVVSS53, L.VVVSS54, L.VVVSS56, L.VVVSS58, L.VVVSS6, L.VVVSS61, L.VVVSS62, L.VVVSS63, L.VVVSS64, L.VVVSS65, L.VVVSS66, L.VVVSS67, L.VVVSS68, L.VVVSS7, L.VVVSS70, L.VVVSS71, L.VVVSS73, L.VVVSS76, L.VVVSS77, L.VVVSS78, L.VVVSS79, L.VVVSS8, L.VVVSS80, L.VVVSS82, L.VVVSS83, L.VVVSS85, L.VVVSS87, L.VVVSS89, L.VVVSS9, L.VVVSS91, L.VVVSS92, L.VVVSS93, L.VVVSS94, L.VVVSS95, L.VVVSS97, L.VVVSS98 ],
               couplings = {(0,44):C.GC_7584,(0,52):C.GC_7584,(0,29):C.GC_7587,(0,37):C.GC_7586,(0,134):C.GC_7587,(0,120):C.GC_7579,(0,151):C.GC_7589,(0,143):C.GC_7582,(0,33):C.GC_7587,(0,62):C.GC_7587,(0,89):C.GC_7589,(0,60):C.GC_7587,(0,59):C.GC_7579,(0,87):C.GC_7582,(0,14):C.GC_7587,(0,31):C.GC_7582,(0,88):C.GC_7579,(0,1):C.GC_7589,(0,32):C.GC_7579,(0,61):C.GC_7582,(0,0):C.GC_7625,(0,28):C.GC_7618,(0,57):C.GC_7622,(0,75):C.GC_7678,(0,158):C.GC_7678,(0,30):C.GC_7673,(0,58):C.GC_7669,(0,84):C.GC_7669,(0,85):C.GC_7673,(0,127):C.GC_7739,(0,111):C.GC_7735,(0,86):C.GC_7710,(0,115):C.GC_5139,(0,113):C.GC_5135,(0,117):C.GC_7717,(0,5):C.GC_7736,(0,11):C.GC_5146,(0,132):C.GC_7733,(0,131):C.GC_7718,(0,140):C.GC_5145,(0,136):C.GC_7690,(0,138):C.GC_7686,(0,144):C.GC_7713,(0,148):C.GC_7691,(0,156):C.GC_5140,(0,155):C.GC_5136,(0,160):C.GC_7685,(0,40):C.GC_7739,(0,77):C.GC_7736,(0,43):C.GC_5135,(0,71):C.GC_7716,(0,99):C.GC_7711,(0,35):C.GC_7712,(0,64):C.GC_5136,(0,91):C.GC_7719,(0,128):C.GC_7735,(0,25):C.GC_5142,(0,46):C.GC_7691,(0,66):C.GC_7719,(0,73):C.GC_7685,(0,94):C.GC_7710,(0,6):C.GC_7733,(0,22):C.GC_5143,(0,48):C.GC_7711,(0,53):C.GC_7690,(0,80):C.GC_7686,(0,103):C.GC_7718,(0,49):C.GC_7716,(0,76):C.GC_7713,(0,38):C.GC_7717,(0,68):C.GC_7712,(0,19):C.GC_7699,(0,55):C.GC_7697,(0,82):C.GC_7693,(0,122):C.GC_7808,(0,2):C.GC_7808,(0,34):C.GC_7813,(0,42):C.GC_7815,(0,63):C.GC_7814,(0,70):C.GC_7813,(0,90):C.GC_7820,(0,98):C.GC_7819,(0,129):C.GC_7732,(0,123):C.GC_7732,(0,124):C.GC_7738,(0,112):C.GC_7698,(0,93):C.GC_7692,(0,116):C.GC_7737,(0,114):C.GC_7720,(0,119):C.GC_7737,(0,121):C.GC_7737,(0,118):C.GC_7714,(0,3):C.GC_7734,(0,9):C.GC_7734,(0,7):C.GC_7734,(0,12):C.GC_7737,(0,13):C.GC_7734,(0,15):C.GC_7737,(0,16):C.GC_7737,(0,17):C.GC_7737,(0,18):C.GC_7737,(0,135):C.GC_7701,(0,133):C.GC_7695,(0,141):C.GC_7732,(0,142):C.GC_7738,(0,137):C.GC_7720,(0,139):C.GC_7721,(0,145):C.GC_7732,(0,147):C.GC_7738,(0,146):C.GC_7721,(0,153):C.GC_7732,(0,154):C.GC_7732,(0,149):C.GC_7714,(0,150):C.GC_7721,(0,152):C.GC_7714,(0,159):C.GC_7738,(0,157):C.GC_7715,(0,164):C.GC_7732,(0,165):C.GC_7732,(0,161):C.GC_7715,(0,162):C.GC_7715,(0,163):C.GC_7720,(0,41):C.GC_7732,(0,51):C.GC_7734,(0,69):C.GC_7732,(0,79):C.GC_7734,(0,97):C.GC_7738,(0,104):C.GC_7734,(0,36):C.GC_7721,(0,45):C.GC_7720,(0,65):C.GC_7715,(0,72):C.GC_7714,(0,92):C.GC_7695,(0,100):C.GC_7692,(0,130):C.GC_7734,(0,26):C.GC_7737,(0,47):C.GC_7720,(0,67):C.GC_7720,(0,95):C.GC_7715,(0,101):C.GC_7715,(0,4):C.GC_7732,(0,10):C.GC_7732,(0,23):C.GC_7732,(0,54):C.GC_7714,(0,78):C.GC_7721,(0,105):C.GC_7714,(0,107):C.GC_7721,(0,125):C.GC_7734,(0,126):C.GC_7734,(0,27):C.GC_7734,(0,39):C.GC_7714,(0,74):C.GC_7721,(0,96):C.GC_7721,(0,102):C.GC_7714,(0,8):C.GC_7732,(0,24):C.GC_7738,(0,50):C.GC_7715,(0,81):C.GC_7715,(0,106):C.GC_7720,(0,108):C.GC_7720,(0,20):C.GC_7698,(0,21):C.GC_7698,(0,56):C.GC_7692,(0,83):C.GC_7695,(0,109):C.GC_7695,(0,110):C.GC_7692})

V_383 = Vertex(name = 'V_383',
               particles = [ P.A, P.W__minus__, P.W__plus__, P.G__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVSS1, L.VVVSS139, L.VVVSS140, L.VVVSS146, L.VVVSS157, L.VVVSS177, L.VVVSS178, L.VVVSS183, L.VVVSS194, L.VVVSS2, L.VVVSS218, L.VVVSS219, L.VVVSS224, L.VVVSS234, L.VVVSS9 ],
               couplings = {(0,0):C.GC_7677,(0,1):C.GC_7672,(0,5):C.GC_7671,(0,9):C.GC_7623,(0,14):C.GC_7623,(0,2):C.GC_7620,(0,6):C.GC_7617,(0,10):C.GC_7617,(0,11):C.GC_7620,(0,3):C.GC_7857,(0,4):C.GC_7856,(0,7):C.GC_7855,(0,8):C.GC_7858,(0,12):C.GC_7857,(0,13):C.GC_7858})

V_384 = Vertex(name = 'V_384',
               particles = [ P.A, P.W__minus__, P.W__plus__, P.G__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVSS1, L.VVVSS139, L.VVVSS140, L.VVVSS177, L.VVVSS178, L.VVVSS2, L.VVVSS218, L.VVVSS219, L.VVVSS9 ],
               couplings = {(0,0):C.GC_7809,(0,1):C.GC_7803,(0,3):C.GC_7801,(0,5):C.GC_7809,(0,8):C.GC_7809,(0,2):C.GC_7801,(0,4):C.GC_7803,(0,6):C.GC_7803,(0,7):C.GC_7801})

V_385 = Vertex(name = 'V_385',
               particles = [ P.W__minus__, P.W__plus__, P.G0, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSS10, L.VVSS11, L.VVSS12, L.VVSS14, L.VVSS15, L.VVSS16, L.VVSS17, L.VVSS18, L.VVSS19, L.VVSS21, L.VVSS22, L.VVSS23, L.VVSS25, L.VVSS26, L.VVSS27, L.VVSS32, L.VVSS33, L.VVSS40, L.VVSS41, L.VVSS42, L.VVSS5, L.VVSS57, L.VVSS58, L.VVSS59, L.VVSS6, L.VVSS60, L.VVSS62, L.VVSS63, L.VVSS7, L.VVSS8, L.VVSS9 ],
               couplings = {(0,12):C.GC_212,(0,14):C.GC_212,(0,3):C.GC_211,(0,0):C.GC_649,(0,8):C.GC_211,(0,5):C.GC_650,(0,1):C.GC_209,(0,6):C.GC_208,(0,19):C.GC_212,(0,7):C.GC_209,(0,16):C.GC_211,(0,13):C.GC_208,(0,18):C.GC_212,(0,2):C.GC_208,(0,26):C.GC_209,(0,15):C.GC_211,(0,11):C.GC_209,(0,27):C.GC_208,(0,28):C.GC_1287,(0,29):C.GC_1278,(0,20):C.GC_1258,(0,24):C.GC_1259,(0,9):C.GC_1279,(0,10):C.GC_1286,(0,17):C.GC_654,(0,30):C.GC_1275,(0,4):C.GC_1274,(0,21):C.GC_1277,(0,23):C.GC_1260,(0,22):C.GC_1276,(0,25):C.GC_1261})

V_386 = Vertex(name = 'V_386',
               particles = [ P.W__minus__, P.W__plus__, P.G0, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSS10, L.VVSS16 ],
               couplings = {(0,0):C.GC_1343,(0,1):C.GC_1345})

V_387 = Vertex(name = 'V_387',
               particles = [ P.A, P.W__minus__, P.W__plus__, P.G0, P.G0 ],
               color = [ '1' ],
               lorentz = [ L.VVVSS1, L.VVVSS10, L.VVVSS103, L.VVVSS104, L.VVVSS105, L.VVVSS106, L.VVVSS107, L.VVVSS109, L.VVVSS110, L.VVVSS112, L.VVVSS113, L.VVVSS116, L.VVVSS117, L.VVVSS118, L.VVVSS12, L.VVVSS120, L.VVVSS121, L.VVVSS123, L.VVVSS124, L.VVVSS125, L.VVVSS126, L.VVVSS127, L.VVVSS128, L.VVVSS129, L.VVVSS130, L.VVVSS136, L.VVVSS137, L.VVVSS138, L.VVVSS139, L.VVVSS14, L.VVVSS140, L.VVVSS141, L.VVVSS142, L.VVVSS145, L.VVVSS146, L.VVVSS147, L.VVVSS148, L.VVVSS15, L.VVVSS150, L.VVVSS151, L.VVVSS152, L.VVVSS155, L.VVVSS157, L.VVVSS158, L.VVVSS159, L.VVVSS16, L.VVVSS161, L.VVVSS162, L.VVVSS163, L.VVVSS164, L.VVVSS165, L.VVVSS168, L.VVVSS17, L.VVVSS170, L.VVVSS171, L.VVVSS172, L.VVVSS173, L.VVVSS177, L.VVVSS178, L.VVVSS179, L.VVVSS18, L.VVVSS180, L.VVVSS182, L.VVVSS183, L.VVVSS184, L.VVVSS185, L.VVVSS187, L.VVVSS189, L.VVVSS19, L.VVVSS190, L.VVVSS192, L.VVVSS194, L.VVVSS195, L.VVVSS196, L.VVVSS198, L.VVVSS199, L.VVVSS2, L.VVVSS200, L.VVVSS202, L.VVVSS203, L.VVVSS205, L.VVVSS207, L.VVVSS208, L.VVVSS209, L.VVVSS21, L.VVVSS210, L.VVVSS218, L.VVVSS219, L.VVVSS22, L.VVVSS220, L.VVVSS221, L.VVVSS223, L.VVVSS224, L.VVVSS225, L.VVVSS226, L.VVVSS228, L.VVVSS229, L.VVVSS230, L.VVVSS233, L.VVVSS234, L.VVVSS235, L.VVVSS236, L.VVVSS238, L.VVVSS239, L.VVVSS240, L.VVVSS241, L.VVVSS242, L.VVVSS245, L.VVVSS246, L.VVVSS247, L.VVVSS248, L.VVVSS249, L.VVVSS25, L.VVVSS27, L.VVVSS28, L.VVVSS29, L.VVVSS32, L.VVVSS34, L.VVVSS36, L.VVVSS37, L.VVVSS39, L.VVVSS4, L.VVVSS41, L.VVVSS42, L.VVVSS43, L.VVVSS44, L.VVVSS45, L.VVVSS47, L.VVVSS48, L.VVVSS50, L.VVVSS51, L.VVVSS54, L.VVVSS56, L.VVVSS57, L.VVVSS6, L.VVVSS60, L.VVVSS62, L.VVVSS63, L.VVVSS64, L.VVVSS65, L.VVVSS66, L.VVVSS67, L.VVVSS68, L.VVVSS7, L.VVVSS70, L.VVVSS71, L.VVVSS72, L.VVVSS75, L.VVVSS77, L.VVVSS78, L.VVVSS79, L.VVVSS8, L.VVVSS80, L.VVVSS82, L.VVVSS83, L.VVVSS85, L.VVVSS87, L.VVVSS88, L.VVVSS9, L.VVVSS90, L.VVVSS92, L.VVVSS93, L.VVVSS94, L.VVVSS95, L.VVVSS97, L.VVVSS98 ],
               couplings = {(0,0):C.GC_7624,(0,45):C.GC_7583,(0,52):C.GC_7583,(0,29):C.GC_7588,(0,37):C.GC_7585,(0,134):C.GC_7588,(0,121):C.GC_7580,(0,151):C.GC_7590,(0,143):C.GC_7581,(0,28):C.GC_7619,(0,33):C.GC_7588,(0,57):C.GC_7621,(0,62):C.GC_7588,(0,91):C.GC_7590,(0,60):C.GC_7588,(0,59):C.GC_7580,(0,89):C.GC_7581,(0,14):C.GC_7588,(0,31):C.GC_7581,(0,90):C.GC_7580,(0,1):C.GC_7590,(0,32):C.GC_7580,(0,61):C.GC_7581,(0,76):C.GC_7667,(0,158):C.GC_7667,(0,30):C.GC_7664,(0,58):C.GC_7663,(0,86):C.GC_7663,(0,87):C.GC_7664,(0,125):C.GC_7725,(0,129):C.GC_7730,(0,84):C.GC_7728,(0,68):C.GC_7706,(0,112):C.GC_7726,(0,88):C.GC_7704,(0,113):C.GC_7703,(0,116):C.GC_5138,(0,115):C.GC_5134,(0,118):C.GC_5137,(0,117):C.GC_5133,(0,119):C.GC_7709,(0,5):C.GC_7725,(0,9):C.GC_7730,(0,11):C.GC_5141,(0,132):C.GC_7728,(0,131):C.GC_7706,(0,135):C.GC_7726,(0,133):C.GC_7704,(0,140):C.GC_5141,(0,136):C.GC_7689,(0,138):C.GC_7687,(0,144):C.GC_7703,(0,147):C.GC_5138,(0,146):C.GC_5134,(0,148):C.GC_7689,(0,156):C.GC_5137,(0,155):C.GC_5133,(0,157):C.GC_7709,(0,160):C.GC_7687,(0,41):C.GC_7730,(0,51):C.GC_7730,(0,67):C.GC_7725,(0,78):C.GC_7725,(0,35):C.GC_5134,(0,43):C.GC_5134,(0,64):C.GC_7708,(0,72):C.GC_7708,(0,93):C.GC_7705,(0,100):C.GC_7705,(0,36):C.GC_7702,(0,44):C.GC_7702,(0,65):C.GC_5133,(0,73):C.GC_5133,(0,94):C.GC_7707,(0,101):C.GC_7707,(0,126):C.GC_7728,(0,130):C.GC_7726,(0,25):C.GC_5144,(0,38):C.GC_7705,(0,46):C.GC_7689,(0,69):C.GC_7707,(0,74):C.GC_7687,(0,95):C.GC_7706,(0,97):C.GC_7704,(0,6):C.GC_7728,(0,10):C.GC_7726,(0,22):C.GC_5144,(0,48):C.GC_7705,(0,53):C.GC_7689,(0,79):C.GC_7707,(0,81):C.GC_7687,(0,104):C.GC_7706,(0,106):C.GC_7704,(0,39):C.GC_7708,(0,66):C.GC_7703,(0,49):C.GC_7708,(0,77):C.GC_7703,(0,40):C.GC_7709,(0,70):C.GC_7702,(0,50):C.GC_7709,(0,80):C.GC_7702,(0,19):C.GC_7700,(0,55):C.GC_7696,(0,83):C.GC_7694,(0,122):C.GC_7809,(0,2):C.GC_7809,(0,34):C.GC_7811,(0,42):C.GC_7811,(0,63):C.GC_7812,(0,71):C.GC_7812,(0,92):C.GC_7816,(0,99):C.GC_7816,(0,123):C.GC_7724,(0,127):C.GC_7729,(0,114):C.GC_7727,(0,120):C.GC_7731,(0,3):C.GC_7724,(0,7):C.GC_7729,(0,12):C.GC_7723,(0,13):C.GC_7722,(0,15):C.GC_7723,(0,16):C.GC_7723,(0,17):C.GC_7723,(0,18):C.GC_7723,(0,141):C.GC_7723,(0,142):C.GC_7722,(0,137):C.GC_7684,(0,139):C.GC_7688,(0,145):C.GC_7727,(0,153):C.GC_7723,(0,154):C.GC_7723,(0,149):C.GC_7684,(0,150):C.GC_7688,(0,152):C.GC_7684,(0,159):C.GC_7731,(0,164):C.GC_7723,(0,165):C.GC_7723,(0,161):C.GC_7688,(0,162):C.GC_7688,(0,163):C.GC_7684,(0,96):C.GC_7724,(0,98):C.GC_7729,(0,105):C.GC_7724,(0,107):C.GC_7729,(0,124):C.GC_7727,(0,26):C.GC_7723,(0,47):C.GC_7684,(0,102):C.GC_7688,(0,4):C.GC_7727,(0,23):C.GC_7723,(0,54):C.GC_7684,(0,108):C.GC_7688,(0,128):C.GC_7724,(0,27):C.GC_7722,(0,75):C.GC_7688,(0,103):C.GC_7684,(0,8):C.GC_7724,(0,24):C.GC_7722,(0,82):C.GC_7688,(0,109):C.GC_7684,(0,20):C.GC_7698,(0,21):C.GC_7698,(0,56):C.GC_7692,(0,85):C.GC_7695,(0,110):C.GC_7695,(0,111):C.GC_7692})

V_388 = Vertex(name = 'V_388',
               particles = [ P.A, P.W__minus__, P.W__plus__, P.G0, P.G0 ],
               color = [ '1' ],
               lorentz = [ L.VVVSS1, L.VVVSS139, L.VVVSS140, L.VVVSS177, L.VVVSS178, L.VVVSS2, L.VVVSS218, L.VVVSS219, L.VVVSS9 ],
               couplings = {(0,0):C.GC_7679,(0,1):C.GC_7670,(0,3):C.GC_7674,(0,5):C.GC_7623,(0,8):C.GC_7623,(0,2):C.GC_7620,(0,4):C.GC_7617,(0,6):C.GC_7617,(0,7):C.GC_7620})

V_389 = Vertex(name = 'V_389',
               particles = [ P.A, P.W__minus__, P.W__plus__, P.G0, P.G0 ],
               color = [ '1' ],
               lorentz = [ L.VVVSS1, L.VVVSS139, L.VVVSS177 ],
               couplings = {(0,0):C.GC_7810,(0,1):C.GC_7804,(0,2):C.GC_7802})

V_390 = Vertex(name = 'V_390',
               particles = [ P.A, P.W__minus__, P.W__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVV1, L.VVV10, L.VVV11, L.VVV12, L.VVV13, L.VVV14, L.VVV15, L.VVV16, L.VVV17, L.VVV18, L.VVV19, L.VVV2, L.VVV20, L.VVV21, L.VVV22, L.VVV23, L.VVV24, L.VVV25, L.VVV26, L.VVV27, L.VVV28, L.VVV29, L.VVV3, L.VVV4, L.VVV5, L.VVV6, L.VVV7, L.VVV8, L.VVV9 ],
               couplings = {(0,0):C.GC_5291,(0,3):C.GC_5284,(0,4):C.GC_5284,(0,1):C.GC_5282,(0,2):C.GC_5285,(0,23):C.GC_5282,(0,22):C.GC_5279,(0,25):C.GC_5283,(0,24):C.GC_5278,(0,6):C.GC_5341,(0,10):C.GC_5282,(0,12):C.GC_5342,(0,16):C.GC_5282,(0,21):C.GC_5283,(0,5):C.GC_5282,(0,14):C.GC_5279,(0,19):C.GC_5278,(0,28):C.GC_5282,(0,8):C.GC_5278,(0,20):C.GC_5279,(0,27):C.GC_5283,(0,9):C.GC_5279,(0,15):C.GC_5278,(0,7):C.GC_5180,(0,13):C.GC_5182,(0,17):C.GC_5182,(0,18):C.GC_5180,(0,11):C.GC_5292,(0,26):C.GC_5292})

V_391 = Vertex(name = 'V_391',
               particles = [ P.A, P.W__minus__, P.W__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVV1, L.VVV10, L.VVV11, L.VVV12, L.VVV13, L.VVV14, L.VVV15, L.VVV16, L.VVV17, L.VVV18, L.VVV19, L.VVV2, L.VVV20, L.VVV21, L.VVV22, L.VVV23, L.VVV24, L.VVV25, L.VVV26, L.VVV27, L.VVV28, L.VVV29, L.VVV3, L.VVV4, L.VVV5, L.VVV6, L.VVV7, L.VVV8, L.VVV9 ],
               couplings = {(0,0):C.GC_5299,(0,3):C.GC_5245,(0,4):C.GC_5245,(0,1):C.GC_5244,(0,2):C.GC_5245,(0,23):C.GC_5244,(0,22):C.GC_5243,(0,25):C.GC_5244,(0,24):C.GC_5242,(0,6):C.GC_5288,(0,10):C.GC_5244,(0,12):C.GC_5289,(0,16):C.GC_5244,(0,21):C.GC_5244,(0,5):C.GC_5244,(0,14):C.GC_5243,(0,19):C.GC_5242,(0,28):C.GC_5244,(0,8):C.GC_5242,(0,20):C.GC_5243,(0,27):C.GC_5244,(0,9):C.GC_5243,(0,15):C.GC_5242,(0,7):C.GC_5297,(0,13):C.GC_5295,(0,17):C.GC_5295,(0,18):C.GC_5297,(0,11):C.GC_5290,(0,26):C.GC_5290})

V_392 = Vertex(name = 'V_392',
               particles = [ P.A, P.W__minus__, P.W__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVV1, L.VVV15, L.VVV16, L.VVV20, L.VVV21, L.VVV25, L.VVV26 ],
               couplings = {(0,0):C.GC_5343,(0,1):C.GC_5181,(0,3):C.GC_5179,(0,2):C.GC_5289,(0,4):C.GC_5288,(0,5):C.GC_5288,(0,6):C.GC_5289})

V_393 = Vertex(name = 'V_393',
               particles = [ P.A, P.W__minus__, P.W__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVV15, L.VVV20 ],
               couplings = {(0,0):C.GC_5296,(0,1):C.GC_5294})

V_394 = Vertex(name = 'V_394',
               particles = [ P.A, P.W__minus__, P.W__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVS1, L.VVVS10, L.VVVS100, L.VVVS101, L.VVVS102, L.VVVS104, L.VVVS105, L.VVVS106, L.VVVS107, L.VVVS109, L.VVVS110, L.VVVS111, L.VVVS114, L.VVVS12, L.VVVS14, L.VVVS15, L.VVVS16, L.VVVS17, L.VVVS18, L.VVVS19, L.VVVS2, L.VVVS21, L.VVVS22, L.VVVS25, L.VVVS27, L.VVVS28, L.VVVS29, L.VVVS32, L.VVVS35, L.VVVS37, L.VVVS38, L.VVVS4, L.VVVS40, L.VVVS45, L.VVVS46, L.VVVS47, L.VVVS48, L.VVVS49, L.VVVS51, L.VVVS52, L.VVVS54, L.VVVS55, L.VVVS58, L.VVVS59, L.VVVS6, L.VVVS60, L.VVVS61, L.VVVS64, L.VVVS65, L.VVVS66, L.VVVS67, L.VVVS69, L.VVVS7, L.VVVS70, L.VVVS71, L.VVVS74, L.VVVS77, L.VVVS78, L.VVVS79, L.VVVS8, L.VVVS80, L.VVVS82, L.VVVS83, L.VVVS84, L.VVVS85, L.VVVS87, L.VVVS89, L.VVVS9, L.VVVS90, L.VVVS92, L.VVVS99 ],
               couplings = {(0,0):C.GC_7614,(0,36):C.GC_7635,(0,40):C.GC_7640,(0,21):C.GC_7638,(0,19):C.GC_7630,(0,23):C.GC_7636,(0,22):C.GC_7628,(0,24):C.GC_7627,(0,27):C.GC_5128,(0,26):C.GC_5126,(0,29):C.GC_5127,(0,28):C.GC_5125,(0,30):C.GC_7633,(0,42):C.GC_7610,(0,55):C.GC_7640,(0,56):C.GC_7612,(0,66):C.GC_7635,(0,49):C.GC_5126,(0,63):C.GC_7632,(0,7):C.GC_7629,(0,50):C.GC_7626,(0,64):C.GC_5125,(0,8):C.GC_7631,(0,37):C.GC_7638,(0,41):C.GC_7636,(0,51):C.GC_7629,(0,68):C.GC_7631,(0,9):C.GC_7630,(0,11):C.GC_7628,(0,53):C.GC_7632,(0,65):C.GC_7627,(0,54):C.GC_7633,(0,69):C.GC_7626,(0,20):C.GC_7656,(0,67):C.GC_7656,(0,43):C.GC_7655,(0,57):C.GC_7654,(0,70):C.GC_7654,(0,2):C.GC_7655,(0,16):C.GC_7602,(0,17):C.GC_7602,(0,14):C.GC_7604,(0,44):C.GC_7604,(0,47):C.GC_7604,(0,61):C.GC_7604,(0,18):C.GC_7604,(0,13):C.GC_7604,(0,15):C.GC_7603,(0,31):C.GC_7600,(0,59):C.GC_7605,(0,52):C.GC_7601,(0,5):C.GC_7605,(0,58):C.GC_7600,(0,3):C.GC_7601,(0,45):C.GC_7601,(0,4):C.GC_7600,(0,1):C.GC_7605,(0,46):C.GC_7600,(0,60):C.GC_7601,(0,34):C.GC_7634,(0,38):C.GC_7639,(0,25):C.GC_7637,(0,32):C.GC_7641,(0,10):C.GC_7634,(0,12):C.GC_7639,(0,35):C.GC_7637,(0,39):C.GC_7634,(0,48):C.GC_7828,(0,62):C.GC_7829,(0,33):C.GC_7826,(0,6):C.GC_7830})

V_395 = Vertex(name = 'V_395',
               particles = [ P.A, P.W__minus__, P.W__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVS1, L.VVVS100, L.VVVS2, L.VVVS58, L.VVVS59, L.VVVS77, L.VVVS78, L.VVVS9, L.VVVS99 ],
               couplings = {(0,0):C.GC_7659,(0,3):C.GC_7657,(0,5):C.GC_7658,(0,2):C.GC_7613,(0,7):C.GC_7613,(0,4):C.GC_7611,(0,6):C.GC_7609,(0,8):C.GC_7609,(0,1):C.GC_7611})

V_396 = Vertex(name = 'V_396',
               particles = [ P.A, P.W__minus__, P.W__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVS1, L.VVVS58, L.VVVS77 ],
               couplings = {(0,0):C.GC_7827,(0,1):C.GC_7825,(0,2):C.GC_7824})

V_397 = Vertex(name = 'V_397',
               particles = [ P.A, P.W__minus__, P.W__plus__, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVSS1, L.VVVSS10, L.VVVSS103, L.VVVSS104, L.VVVSS105, L.VVVSS106, L.VVVSS107, L.VVVSS109, L.VVVSS110, L.VVVSS112, L.VVVSS113, L.VVVSS116, L.VVVSS117, L.VVVSS118, L.VVVSS12, L.VVVSS120, L.VVVSS121, L.VVVSS123, L.VVVSS124, L.VVVSS125, L.VVVSS126, L.VVVSS127, L.VVVSS128, L.VVVSS129, L.VVVSS130, L.VVVSS136, L.VVVSS137, L.VVVSS138, L.VVVSS139, L.VVVSS14, L.VVVSS140, L.VVVSS141, L.VVVSS142, L.VVVSS145, L.VVVSS146, L.VVVSS147, L.VVVSS148, L.VVVSS15, L.VVVSS150, L.VVVSS151, L.VVVSS152, L.VVVSS155, L.VVVSS157, L.VVVSS158, L.VVVSS159, L.VVVSS16, L.VVVSS161, L.VVVSS162, L.VVVSS163, L.VVVSS164, L.VVVSS165, L.VVVSS168, L.VVVSS17, L.VVVSS170, L.VVVSS171, L.VVVSS172, L.VVVSS173, L.VVVSS177, L.VVVSS178, L.VVVSS179, L.VVVSS18, L.VVVSS180, L.VVVSS182, L.VVVSS183, L.VVVSS184, L.VVVSS185, L.VVVSS187, L.VVVSS189, L.VVVSS19, L.VVVSS190, L.VVVSS192, L.VVVSS194, L.VVVSS195, L.VVVSS196, L.VVVSS198, L.VVVSS199, L.VVVSS2, L.VVVSS200, L.VVVSS202, L.VVVSS203, L.VVVSS205, L.VVVSS207, L.VVVSS208, L.VVVSS209, L.VVVSS21, L.VVVSS210, L.VVVSS218, L.VVVSS219, L.VVVSS22, L.VVVSS220, L.VVVSS221, L.VVVSS223, L.VVVSS224, L.VVVSS225, L.VVVSS226, L.VVVSS228, L.VVVSS229, L.VVVSS230, L.VVVSS233, L.VVVSS234, L.VVVSS235, L.VVVSS236, L.VVVSS238, L.VVVSS239, L.VVVSS240, L.VVVSS241, L.VVVSS242, L.VVVSS245, L.VVVSS246, L.VVVSS247, L.VVVSS248, L.VVVSS249, L.VVVSS25, L.VVVSS27, L.VVVSS28, L.VVVSS29, L.VVVSS32, L.VVVSS34, L.VVVSS36, L.VVVSS37, L.VVVSS39, L.VVVSS4, L.VVVSS41, L.VVVSS42, L.VVVSS43, L.VVVSS44, L.VVVSS45, L.VVVSS47, L.VVVSS48, L.VVVSS50, L.VVVSS51, L.VVVSS54, L.VVVSS56, L.VVVSS57, L.VVVSS6, L.VVVSS60, L.VVVSS62, L.VVVSS63, L.VVVSS64, L.VVVSS65, L.VVVSS66, L.VVVSS67, L.VVVSS68, L.VVVSS7, L.VVVSS70, L.VVVSS71, L.VVVSS72, L.VVVSS75, L.VVVSS77, L.VVVSS78, L.VVVSS79, L.VVVSS8, L.VVVSS80, L.VVVSS82, L.VVVSS83, L.VVVSS85, L.VVVSS87, L.VVVSS88, L.VVVSS9, L.VVVSS90, L.VVVSS92, L.VVVSS93, L.VVVSS94, L.VVVSS95, L.VVVSS97, L.VVVSS98 ],
               couplings = {(0,0):C.GC_7624,(0,45):C.GC_7583,(0,52):C.GC_7583,(0,29):C.GC_7588,(0,37):C.GC_7585,(0,134):C.GC_7588,(0,121):C.GC_7580,(0,151):C.GC_7590,(0,143):C.GC_7581,(0,28):C.GC_7619,(0,33):C.GC_7588,(0,57):C.GC_7621,(0,62):C.GC_7588,(0,91):C.GC_7590,(0,60):C.GC_7588,(0,59):C.GC_7580,(0,89):C.GC_7581,(0,14):C.GC_7588,(0,31):C.GC_7581,(0,90):C.GC_7580,(0,1):C.GC_7590,(0,32):C.GC_7580,(0,61):C.GC_7581,(0,76):C.GC_7668,(0,158):C.GC_7668,(0,30):C.GC_7666,(0,58):C.GC_7665,(0,86):C.GC_7665,(0,87):C.GC_7666,(0,125):C.GC_7725,(0,129):C.GC_7730,(0,84):C.GC_7728,(0,68):C.GC_7706,(0,112):C.GC_7726,(0,88):C.GC_7704,(0,113):C.GC_7703,(0,116):C.GC_5138,(0,115):C.GC_5134,(0,118):C.GC_5137,(0,117):C.GC_5133,(0,119):C.GC_7709,(0,5):C.GC_7725,(0,9):C.GC_7730,(0,11):C.GC_5141,(0,132):C.GC_7728,(0,131):C.GC_7706,(0,135):C.GC_7726,(0,133):C.GC_7704,(0,140):C.GC_5141,(0,136):C.GC_7689,(0,138):C.GC_7687,(0,144):C.GC_7703,(0,147):C.GC_5138,(0,146):C.GC_5134,(0,148):C.GC_7689,(0,156):C.GC_5137,(0,155):C.GC_5133,(0,157):C.GC_7709,(0,160):C.GC_7687,(0,41):C.GC_7730,(0,51):C.GC_7730,(0,67):C.GC_7725,(0,78):C.GC_7725,(0,35):C.GC_5134,(0,43):C.GC_5134,(0,64):C.GC_7708,(0,72):C.GC_7708,(0,93):C.GC_7705,(0,100):C.GC_7705,(0,36):C.GC_7702,(0,44):C.GC_7702,(0,65):C.GC_5133,(0,73):C.GC_5133,(0,94):C.GC_7707,(0,101):C.GC_7707,(0,126):C.GC_7728,(0,130):C.GC_7726,(0,25):C.GC_5144,(0,38):C.GC_7705,(0,46):C.GC_7689,(0,69):C.GC_7707,(0,74):C.GC_7687,(0,95):C.GC_7706,(0,97):C.GC_7704,(0,6):C.GC_7728,(0,10):C.GC_7726,(0,22):C.GC_5144,(0,48):C.GC_7705,(0,53):C.GC_7689,(0,79):C.GC_7707,(0,81):C.GC_7687,(0,104):C.GC_7706,(0,106):C.GC_7704,(0,39):C.GC_7708,(0,66):C.GC_7703,(0,49):C.GC_7708,(0,77):C.GC_7703,(0,40):C.GC_7709,(0,70):C.GC_7702,(0,50):C.GC_7709,(0,80):C.GC_7702,(0,19):C.GC_7700,(0,55):C.GC_7696,(0,83):C.GC_7694,(0,122):C.GC_7806,(0,2):C.GC_7806,(0,34):C.GC_7817,(0,42):C.GC_7817,(0,63):C.GC_7818,(0,71):C.GC_7818,(0,92):C.GC_7821,(0,99):C.GC_7821,(0,123):C.GC_7724,(0,127):C.GC_7729,(0,114):C.GC_7727,(0,120):C.GC_7731,(0,3):C.GC_7724,(0,7):C.GC_7729,(0,12):C.GC_7723,(0,13):C.GC_7722,(0,15):C.GC_7723,(0,16):C.GC_7723,(0,17):C.GC_7723,(0,18):C.GC_7723,(0,141):C.GC_7723,(0,142):C.GC_7722,(0,137):C.GC_7684,(0,139):C.GC_7688,(0,145):C.GC_7727,(0,153):C.GC_7723,(0,154):C.GC_7723,(0,149):C.GC_7684,(0,150):C.GC_7688,(0,152):C.GC_7684,(0,159):C.GC_7731,(0,164):C.GC_7723,(0,165):C.GC_7723,(0,161):C.GC_7688,(0,162):C.GC_7688,(0,163):C.GC_7684,(0,96):C.GC_7724,(0,98):C.GC_7729,(0,105):C.GC_7724,(0,107):C.GC_7729,(0,124):C.GC_7727,(0,26):C.GC_7723,(0,47):C.GC_7684,(0,102):C.GC_7688,(0,4):C.GC_7727,(0,23):C.GC_7723,(0,54):C.GC_7684,(0,108):C.GC_7688,(0,128):C.GC_7724,(0,27):C.GC_7722,(0,75):C.GC_7688,(0,103):C.GC_7684,(0,8):C.GC_7724,(0,24):C.GC_7722,(0,82):C.GC_7688,(0,109):C.GC_7684,(0,20):C.GC_7698,(0,21):C.GC_7698,(0,56):C.GC_7692,(0,85):C.GC_7695,(0,110):C.GC_7695,(0,111):C.GC_7692})

V_398 = Vertex(name = 'V_398',
               particles = [ P.A, P.W__minus__, P.W__plus__, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVSS1, L.VVVSS139, L.VVVSS140, L.VVVSS177, L.VVVSS178, L.VVVSS2, L.VVVSS218, L.VVVSS219, L.VVVSS9 ],
               couplings = {(0,0):C.GC_7680,(0,1):C.GC_7675,(0,3):C.GC_7676,(0,5):C.GC_7623,(0,8):C.GC_7623,(0,2):C.GC_7620,(0,4):C.GC_7617,(0,6):C.GC_7617,(0,7):C.GC_7620})

V_399 = Vertex(name = 'V_399',
               particles = [ P.A, P.W__minus__, P.W__plus__, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVSS1, L.VVVSS139, L.VVVSS177 ],
               couplings = {(0,0):C.GC_7807,(0,1):C.GC_7805,(0,2):C.GC_7800})

V_400 = Vertex(name = 'V_400',
               particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVV10, L.VVVV100, L.VVVV101, L.VVVV102, L.VVVV104, L.VVVV108, L.VVVV109, L.VVVV11, L.VVVV112, L.VVVV116, L.VVVV117, L.VVVV12, L.VVVV120, L.VVVV121, L.VVVV122, L.VVVV123, L.VVVV124, L.VVVV126, L.VVVV128, L.VVVV129, L.VVVV13, L.VVVV130, L.VVVV134, L.VVVV135, L.VVVV136, L.VVVV137, L.VVVV138, L.VVVV139, L.VVVV14, L.VVVV140, L.VVVV142, L.VVVV146, L.VVVV147, L.VVVV15, L.VVVV150, L.VVVV151, L.VVVV153, L.VVVV154, L.VVVV155, L.VVVV156, L.VVVV158, L.VVVV16, L.VVVV161, L.VVVV162, L.VVVV165, L.VVVV166, L.VVVV167, L.VVVV168, L.VVVV169, L.VVVV17, L.VVVV171, L.VVVV173, L.VVVV174, L.VVVV175, L.VVVV177, L.VVVV179, L.VVVV18, L.VVVV180, L.VVVV181, L.VVVV182, L.VVVV184, L.VVVV189, L.VVVV19, L.VVVV190, L.VVVV191, L.VVVV192, L.VVVV193, L.VVVV195, L.VVVV197, L.VVVV198, L.VVVV199, L.VVVV20, L.VVVV200, L.VVVV201, L.VVVV203, L.VVVV205, L.VVVV206, L.VVVV207, L.VVVV208, L.VVVV21, L.VVVV210, L.VVVV22, L.VVVV23, L.VVVV24, L.VVVV25, L.VVVV28, L.VVVV29, L.VVVV30, L.VVVV31, L.VVVV34, L.VVVV35, L.VVVV36, L.VVVV37, L.VVVV38, L.VVVV39, L.VVVV41, L.VVVV42, L.VVVV43, L.VVVV44, L.VVVV45, L.VVVV46, L.VVVV47, L.VVVV48, L.VVVV55, L.VVVV58, L.VVVV59, L.VVVV60, L.VVVV62, L.VVVV65, L.VVVV66, L.VVVV68, L.VVVV69, L.VVVV70, L.VVVV75, L.VVVV76, L.VVVV79, L.VVVV80, L.VVVV81, L.VVVV82, L.VVVV84, L.VVVV88, L.VVVV89, L.VVVV9, L.VVVV91, L.VVVV92, L.VVVV96, L.VVVV97, L.VVVV98, L.VVVV99 ],
               couplings = {(0,33):C.GC_544,(0,49):C.GC_544,(0,62):C.GC_544,(0,79):C.GC_545,(0,0):C.GC_544,(0,7):C.GC_544,(0,20):C.GC_544,(0,28):C.GC_545,(0,95):C.GC_545,(0,96):C.GC_544,(0,99):C.GC_545,(0,100):C.GC_545,(0,103):C.GC_234,(0,106):C.GC_235,(0,107):C.GC_370,(0,104):C.GC_372,(0,105):C.GC_372,(0,108):C.GC_233,(0,109):C.GC_232,(0,110):C.GC_370,(0,111):C.GC_232,(0,112):C.GC_233,(0,83):C.GC_545,(0,85):C.GC_372,(0,84):C.GC_369,(0,86):C.GC_545,(0,89):C.GC_372,(0,88):C.GC_369,(0,90):C.GC_544,(0,91):C.GC_545,(0,93):C.GC_234,(0,94):C.GC_235,(0,92):C.GC_231,(0,115):C.GC_544,(0,116):C.GC_544,(0,113):C.GC_543,(0,114):C.GC_543,(0,120):C.GC_545,(0,121):C.GC_545,(0,117):C.GC_543,(0,118):C.GC_543,(0,1):C.GC_544,(0,125):C.GC_543,(0,126):C.GC_542,(0,127):C.GC_542,(0,5):C.GC_544,(0,6):C.GC_804,(0,2):C.GC_542,(0,3):C.GC_803,(0,12):C.GC_544,(0,13):C.GC_804,(0,9):C.GC_542,(0,10):C.GC_803,(0,21):C.GC_544,(0,14):C.GC_543,(0,15):C.GC_542,(0,16):C.GC_542,(0,25):C.GC_544,(0,22):C.GC_542,(0,23):C.GC_543,(0,24):C.GC_542,(0,31):C.GC_804,(0,32):C.GC_544,(0,27):C.GC_803,(0,29):C.GC_542,(0,35):C.GC_780,(0,44):C.GC_804,(0,45):C.GC_544,(0,42):C.GC_803,(0,43):C.GC_542,(0,52):C.GC_544,(0,46):C.GC_542,(0,47):C.GC_543,(0,48):C.GC_542,(0,54):C.GC_780,(0,64):C.GC_545,(0,65):C.GC_544,(0,61):C.GC_543,(0,63):C.GC_543,(0,72):C.GC_545,(0,73):C.GC_544,(0,66):C.GC_543,(0,67):C.GC_543,(0,74):C.GC_781,(0,123):C.GC_235,(0,124):C.GC_234,(0,119):C.GC_230,(0,8):C.GC_371,(0,4):C.GC_368,(0,36):C.GC_543,(0,55):C.GC_802,(0,75):C.GC_542,(0,18):C.GC_371,(0,17):C.GC_368,(0,38):C.GC_802,(0,58):C.GC_543,(0,77):C.GC_542,(0,34):C.GC_371,(0,30):C.GC_368,(0,37):C.GC_802,(0,57):C.GC_543,(0,76):C.GC_542,(0,40):C.GC_369,(0,39):C.GC_543,(0,51):C.GC_371,(0,50):C.GC_368,(0,59):C.GC_802,(0,78):C.GC_542,(0,60):C.GC_369,(0,69):C.GC_235,(0,70):C.GC_234,(0,68):C.GC_230,(0,80):C.GC_231,(0,41):C.GC_544,(0,71):C.GC_545,(0,122):C.GC_544,(0,11):C.GC_544,(0,97):C.GC_544,(0,101):C.GC_545,(0,82):C.GC_545,(0,87):C.GC_545,(0,128):C.GC_544,(0,19):C.GC_544,(0,26):C.GC_544,(0,53):C.GC_544,(0,56):C.GC_545,(0,98):C.GC_544,(0,81):C.GC_544,(0,102):C.GC_545})

V_401 = Vertex(name = 'V_401',
               particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVV10, L.VVVV100, L.VVVV101, L.VVVV108, L.VVVV11, L.VVVV116, L.VVVV12, L.VVVV120, L.VVVV122, L.VVVV123, L.VVVV124, L.VVVV129, L.VVVV13, L.VVVV130, L.VVVV134, L.VVVV135, L.VVVV136, L.VVVV137, L.VVVV138, L.VVVV14, L.VVVV140, L.VVVV147, L.VVVV15, L.VVVV151, L.VVVV153, L.VVVV156, L.VVVV16, L.VVVV162, L.VVVV166, L.VVVV167, L.VVVV168, L.VVVV169, L.VVVV17, L.VVVV174, L.VVVV175, L.VVVV177, L.VVVV18, L.VVVV180, L.VVVV181, L.VVVV189, L.VVVV19, L.VVVV190, L.VVVV191, L.VVVV192, L.VVVV193, L.VVVV195, L.VVVV20, L.VVVV200, L.VVVV201, L.VVVV203, L.VVVV205, L.VVVV206, L.VVVV207, L.VVVV208, L.VVVV21, L.VVVV22, L.VVVV23, L.VVVV24, L.VVVV29, L.VVVV30, L.VVVV35, L.VVVV36, L.VVVV41, L.VVVV42, L.VVVV43, L.VVVV44, L.VVVV45, L.VVVV46, L.VVVV47, L.VVVV48, L.VVVV75, L.VVVV76, L.VVVV79, L.VVVV80, L.VVVV81, L.VVVV82, L.VVVV88, L.VVVV89, L.VVVV9, L.VVVV96, L.VVVV97, L.VVVV98, L.VVVV99 ],
               couplings = {(0,22):C.GC_1288,(0,32):C.GC_1288,(0,40):C.GC_1288,(0,54):C.GC_1289,(0,0):C.GC_1288,(0,4):C.GC_1288,(0,12):C.GC_1288,(0,19):C.GC_1289,(0,62):C.GC_1289,(0,63):C.GC_1288,(0,66):C.GC_1289,(0,67):C.GC_1289,(0,57):C.GC_1289,(0,58):C.GC_1289,(0,60):C.GC_1288,(0,61):C.GC_1289,(0,72):C.GC_1288,(0,73):C.GC_1288,(0,70):C.GC_1257,(0,71):C.GC_1257,(0,76):C.GC_1289,(0,77):C.GC_1289,(0,74):C.GC_1257,(0,75):C.GC_1257,(0,1):C.GC_1288,(0,79):C.GC_1257,(0,80):C.GC_1256,(0,81):C.GC_1256,(0,3):C.GC_1288,(0,2):C.GC_1256,(0,7):C.GC_1288,(0,5):C.GC_1256,(0,13):C.GC_1288,(0,8):C.GC_1257,(0,9):C.GC_1256,(0,10):C.GC_1256,(0,17):C.GC_1288,(0,14):C.GC_1256,(0,15):C.GC_1257,(0,16):C.GC_1256,(0,21):C.GC_1288,(0,20):C.GC_1256,(0,23):C.GC_822,(0,28):C.GC_1288,(0,27):C.GC_1256,(0,33):C.GC_1288,(0,29):C.GC_1256,(0,30):C.GC_1257,(0,31):C.GC_1256,(0,35):C.GC_822,(0,42):C.GC_1289,(0,43):C.GC_1288,(0,39):C.GC_1257,(0,41):C.GC_1257,(0,47):C.GC_1289,(0,48):C.GC_1288,(0,44):C.GC_1257,(0,45):C.GC_1257,(0,49):C.GC_823,(0,24):C.GC_1257,(0,50):C.GC_1256,(0,38):C.GC_1257,(0,52):C.GC_1256,(0,37):C.GC_1257,(0,51):C.GC_1256,(0,25):C.GC_1257,(0,53):C.GC_1256,(0,26):C.GC_1288,(0,46):C.GC_1289,(0,78):C.GC_1288,(0,6):C.GC_1288,(0,64):C.GC_1288,(0,68):C.GC_1289,(0,56):C.GC_1289,(0,59):C.GC_1289,(0,82):C.GC_1288,(0,11):C.GC_1288,(0,18):C.GC_1288,(0,34):C.GC_1288,(0,36):C.GC_1289,(0,65):C.GC_1288,(0,55):C.GC_1288,(0,69):C.GC_1289})

V_402 = Vertex(name = 'V_402',
               particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVV10, L.VVVV100, L.VVVV101, L.VVVV108, L.VVVV11, L.VVVV116, L.VVVV120, L.VVVV122, L.VVVV123, L.VVVV124, L.VVVV13, L.VVVV130, L.VVVV134, L.VVVV135, L.VVVV136, L.VVVV137, L.VVVV14, L.VVVV140, L.VVVV147, L.VVVV15, L.VVVV151, L.VVVV153, L.VVVV156, L.VVVV162, L.VVVV166, L.VVVV167, L.VVVV168, L.VVVV169, L.VVVV17, L.VVVV174, L.VVVV177, L.VVVV180, L.VVVV181, L.VVVV189, L.VVVV19, L.VVVV190, L.VVVV191, L.VVVV192, L.VVVV193, L.VVVV195, L.VVVV200, L.VVVV201, L.VVVV203, L.VVVV205, L.VVVV206, L.VVVV207, L.VVVV208, L.VVVV21, L.VVVV24, L.VVVV29, L.VVVV35, L.VVVV36, L.VVVV41, L.VVVV42, L.VVVV45, L.VVVV46, L.VVVV75, L.VVVV76, L.VVVV79, L.VVVV80, L.VVVV81, L.VVVV82, L.VVVV88, L.VVVV89, L.VVVV96, L.VVVV97, L.VVVV98 ],
               couplings = {(0,19):C.GC_1359,(0,28):C.GC_1360,(0,34):C.GC_1359,(0,47):C.GC_1357,(0,0):C.GC_1359,(0,4):C.GC_1359,(0,10):C.GC_1360,(0,16):C.GC_1357,(0,52):C.GC_1358,(0,53):C.GC_1360,(0,54):C.GC_1358,(0,55):C.GC_1357,(0,48):C.GC_1358,(0,49):C.GC_1358,(0,50):C.GC_1360,(0,51):C.GC_1357,(0,58):C.GC_1359,(0,59):C.GC_1359,(0,56):C.GC_1354,(0,57):C.GC_1354,(0,62):C.GC_1358,(0,63):C.GC_1358,(0,60):C.GC_1354,(0,61):C.GC_1354,(0,1):C.GC_1359,(0,64):C.GC_1353,(0,65):C.GC_1356,(0,66):C.GC_1355,(0,3):C.GC_1360,(0,2):C.GC_1356,(0,6):C.GC_1360,(0,5):C.GC_1356,(0,11):C.GC_1359,(0,7):C.GC_1353,(0,8):C.GC_1356,(0,9):C.GC_1355,(0,15):C.GC_1359,(0,12):C.GC_1356,(0,13):C.GC_1353,(0,14):C.GC_1355,(0,18):C.GC_1360,(0,17):C.GC_1356,(0,20):C.GC_1046,(0,24):C.GC_1360,(0,23):C.GC_1356,(0,29):C.GC_1359,(0,25):C.GC_1356,(0,26):C.GC_1353,(0,27):C.GC_1355,(0,30):C.GC_1046,(0,36):C.GC_1357,(0,37):C.GC_1360,(0,33):C.GC_1354,(0,35):C.GC_1354,(0,40):C.GC_1357,(0,41):C.GC_1360,(0,38):C.GC_1354,(0,39):C.GC_1354,(0,42):C.GC_1048,(0,21):C.GC_1353,(0,43):C.GC_1355,(0,32):C.GC_1353,(0,45):C.GC_1355,(0,31):C.GC_1353,(0,44):C.GC_1355,(0,22):C.GC_1353,(0,46):C.GC_1355})

V_403 = Vertex(name = 'V_403',
               particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVV151, L.VVVV177, L.VVVV203 ],
               couplings = {(0,0):C.GC_1422,(0,1):C.GC_1422,(0,2):C.GC_1180})

V_404 = Vertex(name = 'V_404',
               particles = [ P.A, P.A, P.Z, P.G__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVSS1, L.VVVSS104, L.VVVSS105, L.VVVSS106, L.VVVSS107, L.VVVSS108, L.VVVSS109, L.VVVSS110, L.VVVSS111, L.VVVSS112, L.VVVSS113, L.VVVSS114, L.VVVSS115, L.VVVSS139, L.VVVSS140, L.VVVSS147, L.VVVSS148, L.VVVSS149, L.VVVSS150, L.VVVSS151, L.VVVSS152, L.VVVSS153, L.VVVSS155, L.VVVSS156, L.VVVSS158, L.VVVSS159, L.VVVSS160, L.VVVSS163, L.VVVSS164, L.VVVSS165, L.VVVSS166, L.VVVSS168, L.VVVSS169, L.VVVSS177, L.VVVSS184, L.VVVSS185, L.VVVSS186, L.VVVSS187, L.VVVSS188, L.VVVSS19, L.VVVSS190, L.VVVSS191, L.VVVSS192, L.VVVSS193, L.VVVSS195, L.VVVSS196, L.VVVSS197, L.VVVSS2, L.VVVSS20, L.VVVSS200, L.VVVSS201, L.VVVSS203, L.VVVSS204, L.VVVSS205, L.VVVSS206, L.VVVSS218, L.VVVSS22, L.VVVSS225, L.VVVSS226, L.VVVSS227, L.VVVSS228, L.VVVSS229, L.VVVSS23, L.VVVSS230, L.VVVSS231, L.VVVSS232, L.VVVSS233, L.VVVSS235, L.VVVSS236, L.VVVSS237, L.VVVSS240, L.VVVSS241, L.VVVSS242, L.VVVSS243, L.VVVSS244, L.VVVSS245, L.VVVSS25, L.VVVSS26, L.VVVSS27, L.VVVSS28, L.VVVSS29, L.VVVSS30, L.VVVSS32, L.VVVSS33, L.VVVSS34, L.VVVSS35, L.VVVSS36, L.VVVSS37, L.VVVSS38, L.VVVSS39, L.VVVSS40, L.VVVSS42, L.VVVSS43, L.VVVSS44, L.VVVSS45, L.VVVSS46, L.VVVSS47, L.VVVSS48, L.VVVSS49, L.VVVSS50, L.VVVSS51, L.VVVSS52, L.VVVSS53, L.VVVSS54, L.VVVSS55, L.VVVSS57, L.VVVSS58, L.VVVSS60, L.VVVSS61, L.VVVSS70, L.VVVSS71, L.VVVSS72, L.VVVSS73, L.VVVSS75, L.VVVSS76, L.VVVSS85, L.VVVSS86, L.VVVSS87, L.VVVSS88, L.VVVSS89, L.VVVSS90, L.VVVSS91 ],
               couplings = {(0,0):C.GC_3523,(0,47):C.GC_3524,(0,13):C.GC_3514,(0,14):C.GC_3514,(0,33):C.GC_3513,(0,55):C.GC_3513,(0,39):C.GC_7107,(0,77):C.GC_7103,(0,56):C.GC_7109,(0,62):C.GC_7093,(0,78):C.GC_7107,(0,82):C.GC_7103,(0,80):C.GC_7093,(0,81):C.GC_7109,(0,85):C.GC_7102,(0,86):C.GC_7101,(0,84):C.GC_7094,(0,87):C.GC_7108,(0,88):C.GC_7108,(0,103):C.GC_7111,(0,108):C.GC_7104,(0,105):C.GC_7113,(0,106):C.GC_7095,(0,109):C.GC_7111,(0,113):C.GC_7104,(0,111):C.GC_7095,(0,112):C.GC_7113,(0,116):C.GC_7101,(0,117):C.GC_7102,(0,115):C.GC_7097,(0,118):C.GC_7112,(0,119):C.GC_7112,(0,15):C.GC_7097,(0,24):C.GC_7094,(0,34):C.GC_7111,(0,44):C.GC_7107,(0,57):C.GC_7111,(0,67):C.GC_7107,(0,16):C.GC_7113,(0,25):C.GC_7109,(0,35):C.GC_7095,(0,45):C.GC_7093,(0,58):C.GC_7112,(0,68):C.GC_7108,(0,18):C.GC_7111,(0,40):C.GC_7112,(0,60):C.GC_7107,(0,63):C.GC_7109,(0,27):C.GC_7107,(0,51):C.GC_7108,(0,70):C.GC_7111,(0,72):C.GC_7113,(0,17):C.GC_7113,(0,26):C.GC_7109,(0,36):C.GC_7112,(0,46):C.GC_7108,(0,59):C.GC_7095,(0,69):C.GC_7093,(0,19):C.GC_7111,(0,37):C.GC_7107,(0,41):C.GC_7109,(0,64):C.GC_7112,(0,28):C.GC_7107,(0,49):C.GC_7111,(0,52):C.GC_7113,(0,73):C.GC_7108,(0,20):C.GC_7108,(0,21):C.GC_7108,(0,42):C.GC_7113,(0,65):C.GC_7113,(0,29):C.GC_7112,(0,30):C.GC_7112,(0,53):C.GC_7109,(0,74):C.GC_7109,(0,93):C.GC_7117,(0,91):C.GC_7119,(0,99):C.GC_6155,(0,101):C.GC_6155,(0,95):C.GC_7123,(0,96):C.GC_7123,(0,48):C.GC_7116,(0,76):C.GC_6156,(0,79):C.GC_7116,(0,83):C.GC_6156,(0,89):C.GC_7121,(0,90):C.GC_7124,(0,3):C.GC_7120,(0,1):C.GC_7116,(0,9):C.GC_6153,(0,11):C.GC_6153,(0,5):C.GC_7121,(0,6):C.GC_7121,(0,104):C.GC_7119,(0,107):C.GC_6154,(0,110):C.GC_7119,(0,114):C.GC_6154,(0,120):C.GC_7123,(0,121):C.GC_7122,(0,22):C.GC_6155,(0,23):C.GC_6155,(0,31):C.GC_6153,(0,32):C.GC_6153,(0,38):C.GC_7119,(0,43):C.GC_7123,(0,50):C.GC_7116,(0,54):C.GC_7121,(0,61):C.GC_7119,(0,66):C.GC_7123,(0,71):C.GC_7116,(0,75):C.GC_7121,(0,94):C.GC_7120,(0,100):C.GC_6156,(0,4):C.GC_7117,(0,10):C.GC_6154,(0,92):C.GC_7116,(0,102):C.GC_6153,(0,2):C.GC_7119,(0,12):C.GC_6155,(0,97):C.GC_7124,(0,98):C.GC_7121,(0,7):C.GC_7122,(0,8):C.GC_7123})

V_405 = Vertex(name = 'V_405',
               particles = [ P.A, P.A, P.Z, P.G0, P.G0, P.G__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVSSSS1, L.VVVSSSS2, L.VVVSSSS41, L.VVVSSSS42, L.VVVSSSS53, L.VVVSSSS77 ],
               couplings = {(0,0):C.GC_3658,(0,1):C.GC_3659,(0,2):C.GC_3654,(0,3):C.GC_3654,(0,4):C.GC_3653,(0,5):C.GC_3653})

V_406 = Vertex(name = 'V_406',
               particles = [ P.A, P.A, P.Z, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVSSSS43, L.VVVSSSS44, L.VVVSSSS45, L.VVVSSSS46, L.VVVSSSS54, L.VVVSSSS55, L.VVVSSSS56, L.VVVSSSS57, L.VVVSSSS78, L.VVVSSSS79, L.VVVSSSS80, L.VVVSSSS81 ],
               couplings = {(0,0):C.GC_3744,(0,1):C.GC_3744,(0,2):C.GC_3745,(0,3):C.GC_3745,(0,4):C.GC_3744,(0,5):C.GC_3744,(0,6):C.GC_3745,(0,7):C.GC_3745,(0,8):C.GC_3744,(0,9):C.GC_3744,(0,10):C.GC_3745,(0,11):C.GC_3745})

V_407 = Vertex(name = 'V_407',
               particles = [ P.A, P.A, P.Z, P.G__minus__, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVSSS1, L.VVVSSS2, L.VVVSSS29, L.VVVSSS30, L.VVVSSS38, L.VVVSSS54 ],
               couplings = {(0,0):C.GC_3577,(0,1):C.GC_3578,(0,2):C.GC_3573,(0,3):C.GC_3573,(0,4):C.GC_3572,(0,5):C.GC_3572})

V_408 = Vertex(name = 'V_408',
               particles = [ P.A, P.A, P.Z, P.G__minus__, P.G__plus__, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVSSSS1, L.VVVSSSS2, L.VVVSSSS41, L.VVVSSSS42, L.VVVSSSS53, L.VVVSSSS77 ],
               couplings = {(0,0):C.GC_3658,(0,1):C.GC_3659,(0,2):C.GC_3654,(0,3):C.GC_3654,(0,4):C.GC_3653,(0,5):C.GC_3653})

V_409 = Vertex(name = 'V_409',
               particles = [ P.A, P.Z, P.G0, P.G__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSSS12, L.VVSSS14, L.VVSSS25, L.VVSSS29, L.VVSSS5, L.VVSSS6, L.VVSSS60, L.VVSSS61, L.VVSSS64, L.VVSSS67, L.VVSSS7, L.VVSSS8 ],
               couplings = {(0,10):C.GC_6315,(0,11):C.GC_4136,(0,4):C.GC_6313,(0,5):C.GC_4134,(0,6):C.GC_6314,(0,7):C.GC_4135,(0,0):C.GC_3869,(0,1):C.GC_6098,(0,2):C.GC_3868,(0,3):C.GC_6097,(0,8):C.GC_6098,(0,9):C.GC_6097})

V_410 = Vertex(name = 'V_410',
               particles = [ P.A, P.Z, P.G0, P.G__minus__, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS10, L.VVSSSS100, L.VVSSSS102, L.VVSSSS103, L.VVSSSS105, L.VVSSSS106, L.VVSSSS12, L.VVSSSS22, L.VVSSSS25, L.VVSSSS34, L.VVSSSS36, L.VVSSSS37, L.VVSSSS38, L.VVSSSS40, L.VVSSSS41, L.VVSSSS5, L.VVSSSS56, L.VVSSSS57, L.VVSSSS6, L.VVSSSS7, L.VVSSSS8, L.VVSSSS93, L.VVSSSS94, L.VVSSSS97 ],
               couplings = {(0,0):C.GC_3915,(0,6):C.GC_6109,(0,7):C.GC_3914,(0,8):C.GC_6108,(0,10):C.GC_6108,(0,11):C.GC_6109,(0,13):C.GC_3914,(0,14):C.GC_3915,(0,23):C.GC_6109,(0,1):C.GC_6108,(0,4):C.GC_6108,(0,5):C.GC_6109,(0,19):C.GC_6552,(0,20):C.GC_4142,(0,15):C.GC_6549,(0,18):C.GC_4140,(0,16):C.GC_6551,(0,17):C.GC_4143,(0,9):C.GC_6550,(0,12):C.GC_4141,(0,21):C.GC_6550,(0,2):C.GC_6549,(0,22):C.GC_4141,(0,3):C.GC_4140})

V_411 = Vertex(name = 'V_411',
               particles = [ P.Z, P.G0, P.G0, P.G0, P.G0 ],
               color = [ '1' ],
               lorentz = [ L.VSSSS17, L.VSSSS21, L.VSSSS22, L.VSSSS23, L.VSSSS43, L.VSSSS47, L.VSSSS53, L.VSSSS6, L.VSSSS8, L.VSSSS84, L.VSSSS85, L.VSSSS86 ],
               couplings = {(0,7):C.GC_6877,(0,8):C.GC_6877,(0,0):C.GC_6877,(0,1):C.GC_6877,(0,2):C.GC_6877,(0,3):C.GC_6877,(0,4):C.GC_6877,(0,5):C.GC_6877,(0,6):C.GC_6877,(0,9):C.GC_6877,(0,10):C.GC_6877,(0,11):C.GC_6877})

V_412 = Vertex(name = 'V_412',
               particles = [ P.Z, P.G0, P.G0 ],
               color = [ '1' ],
               lorentz = [ L.VSS10, L.VSS8 ],
               couplings = {(0,1):C.GC_6919,(0,0):C.GC_6919})

V_413 = Vertex(name = 'V_413',
               particles = [ P.Z, P.G0, P.G0, P.G__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VSSSS10, L.VSSSS11, L.VSSSS12, L.VSSSS13, L.VSSSS16, L.VSSSS18, L.VSSSS19, L.VSSSS20, L.VSSSS22, L.VSSSS23, L.VSSSS31, L.VSSSS32, L.VSSSS33, L.VSSSS34, L.VSSSS35, L.VSSSS36, L.VSSSS37, L.VSSSS42, L.VSSSS44, L.VSSSS45, L.VSSSS46, L.VSSSS48, L.VSSSS49, L.VSSSS50, L.VSSSS6, L.VSSSS8, L.VSSSS84, L.VSSSS85, L.VSSSS86 ],
               couplings = {(0,24):C.GC_6877,(0,25):C.GC_6877,(0,8):C.GC_2374,(0,9):C.GC_2374,(0,26):C.GC_2374,(0,27):C.GC_2374,(0,28):C.GC_6879,(0,1):C.GC_2370,(0,11):C.GC_2370,(0,2):C.GC_2370,(0,12):C.GC_2370,(0,4):C.GC_2369,(0,5):C.GC_2369,(0,14):C.GC_6876,(0,17):C.GC_2369,(0,18):C.GC_2369,(0,21):C.GC_6873,(0,0):C.GC_2823,(0,10):C.GC_2824,(0,3):C.GC_3379,(0,13):C.GC_3377,(0,6):C.GC_3370,(0,15):C.GC_3369,(0,19):C.GC_3367,(0,22):C.GC_3368,(0,7):C.GC_3370,(0,16):C.GC_3369,(0,20):C.GC_3367,(0,23):C.GC_3368})

V_414 = Vertex(name = 'V_414',
               particles = [ P.Z, P.G0, P.G0, P.G__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VSSSS10, L.VSSSS31 ],
               couplings = {(0,0):C.GC_3337,(0,1):C.GC_3335})

V_415 = Vertex(name = 'V_415',
               particles = [ P.Z, P.G0, P.G0, P.H ],
               color = [ '1' ],
               lorentz = [ L.VSSS6, L.VSSS8 ],
               couplings = {(0,0):C.GC_6927,(0,1):C.GC_6927})

V_416 = Vertex(name = 'V_416',
               particles = [ P.Z, P.G0, P.G0, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VSSSS53, L.VSSSS6, L.VSSSS8, L.VSSSS86 ],
               couplings = {(0,1):C.GC_6877,(0,2):C.GC_6877,(0,0):C.GC_6877,(0,3):C.GC_6877})

V_417 = Vertex(name = 'V_417',
               particles = [ P.A, P.Z, P.G__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSS1, L.VVSS11, L.VVSS12, L.VVSS14, L.VVSS15, L.VVSS17, L.VVSS18, L.VVSS19, L.VVSS21, L.VVSS22, L.VVSS23, L.VVSS25, L.VVSS26, L.VVSS27, L.VVSS28, L.VVSS3, L.VVSS30, L.VVSS32, L.VVSS33, L.VVSS41, L.VVSS42, L.VVSS5, L.VVSS55, L.VVSS56, L.VVSS57, L.VVSS58, L.VVSS59, L.VVSS6, L.VVSS60, L.VVSS62, L.VVSS63, L.VVSS64, L.VVSS7, L.VVSS8, L.VVSS9 ],
               couplings = {(0,15):C.GC_5187,(0,0):C.GC_5186,(0,11):C.GC_1524,(0,13):C.GC_1527,(0,3):C.GC_1525,(0,7):C.GC_1526,(0,22):C.GC_5353,(0,1):C.GC_5190,(0,5):C.GC_5191,(0,23):C.GC_5185,(0,20):C.GC_1524,(0,6):C.GC_5188,(0,18):C.GC_1525,(0,12):C.GC_5189,(0,19):C.GC_1527,(0,2):C.GC_5189,(0,29):C.GC_5190,(0,17):C.GC_1526,(0,10):C.GC_5188,(0,30):C.GC_5191,(0,16):C.GC_5194,(0,14):C.GC_5192,(0,31):C.GC_5193,(0,32):C.GC_5350,(0,33):C.GC_5220,(0,21):C.GC_5349,(0,27):C.GC_5218,(0,8):C.GC_5351,(0,9):C.GC_5220,(0,34):C.GC_5347,(0,4):C.GC_5218,(0,24):C.GC_5346,(0,26):C.GC_5348,(0,25):C.GC_5219,(0,28):C.GC_5219})

V_418 = Vertex(name = 'V_418',
               particles = [ P.A, P.Z, P.G__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSS1, L.VVSS3, L.VVSS55, L.VVSS56 ],
               couplings = {(0,1):C.GC_5209,(0,0):C.GC_5207,(0,2):C.GC_5370,(0,3):C.GC_5208})

V_419 = Vertex(name = 'V_419',
               particles = [ P.A, P.Z, P.G__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSS55 ],
               couplings = {(0,0):C.GC_5352})

V_420 = Vertex(name = 'V_420',
               particles = [ P.A, P.Z, P.G0, P.G0, P.G__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS1, L.VVSSSS10, L.VVSSSS100, L.VVSSSS101, L.VVSSSS102, L.VVSSSS103, L.VVSSSS104, L.VVSSSS105, L.VVSSSS12, L.VVSSSS14, L.VVSSSS21, L.VVSSSS24, L.VVSSSS25, L.VVSSSS26, L.VVSSSS28, L.VVSSSS29, L.VVSSSS3, L.VVSSSS34, L.VVSSSS38, L.VVSSSS39, L.VVSSSS40, L.VVSSSS5, L.VVSSSS56, L.VVSSSS57, L.VVSSSS7, L.VVSSSS9, L.VVSSSS91, L.VVSSSS92, L.VVSSSS93, L.VVSSSS95, L.VVSSSS97, L.VVSSSS98, L.VVSSSS99 ],
               couplings = {(0,26):C.GC_7891,(0,24):C.GC_7880,(0,21):C.GC_7878,(0,9):C.GC_7880,(0,25):C.GC_7878,(0,14):C.GC_7887,(0,15):C.GC_7515,(0,10):C.GC_7882,(0,11):C.GC_7511,(0,22):C.GC_7886,(0,23):C.GC_7515,(0,17):C.GC_7884,(0,18):C.GC_7511,(0,28):C.GC_7877,(0,29):C.GC_7877,(0,31):C.GC_7885,(0,4):C.GC_7883,(0,32):C.GC_7512,(0,5):C.GC_7512,(0,16):C.GC_7384,(0,0):C.GC_7380,(0,27):C.GC_7381,(0,1):C.GC_7899,(0,8):C.GC_7899,(0,12):C.GC_7897,(0,13):C.GC_7897,(0,19):C.GC_7897,(0,20):C.GC_7897,(0,30):C.GC_7902,(0,2):C.GC_7898,(0,6):C.GC_7898,(0,3):C.GC_7898,(0,7):C.GC_7898})

V_421 = Vertex(name = 'V_421',
               particles = [ P.A, P.Z, P.G0, P.G0, P.G__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS91 ],
               couplings = {(0,0):C.GC_7889})

V_422 = Vertex(name = 'V_422',
               particles = [ P.A, P.Z, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS1, L.VVSSSS10, L.VVSSSS100, L.VVSSSS101, L.VVSSSS102, L.VVSSSS103, L.VVSSSS104, L.VVSSSS105, L.VVSSSS106, L.VVSSSS11, L.VVSSSS12, L.VVSSSS14, L.VVSSSS15, L.VVSSSS21, L.VVSSSS22, L.VVSSSS23, L.VVSSSS24, L.VVSSSS25, L.VVSSSS26, L.VVSSSS28, L.VVSSSS29, L.VVSSSS3, L.VVSSSS34, L.VVSSSS35, L.VVSSSS36, L.VVSSSS37, L.VVSSSS38, L.VVSSSS39, L.VVSSSS40, L.VVSSSS41, L.VVSSSS5, L.VVSSSS56, L.VVSSSS57, L.VVSSSS6, L.VVSSSS7, L.VVSSSS8, L.VVSSSS9, L.VVSSSS91, L.VVSSSS92, L.VVSSSS93, L.VVSSSS94, L.VVSSSS95, L.VVSSSS96, L.VVSSSS97, L.VVSSSS98, L.VVSSSS99 ],
               couplings = {(0,21):C.GC_7385,(0,0):C.GC_7383,(0,37):C.GC_7893,(0,38):C.GC_7382,(0,34):C.GC_7881,(0,35):C.GC_7514,(0,30):C.GC_7876,(0,33):C.GC_7510,(0,11):C.GC_7881,(0,12):C.GC_7514,(0,36):C.GC_7876,(0,9):C.GC_7510,(0,19):C.GC_7881,(0,20):C.GC_7514,(0,13):C.GC_7876,(0,16):C.GC_7510,(0,31):C.GC_7881,(0,32):C.GC_7514,(0,22):C.GC_7876,(0,26):C.GC_7510,(0,39):C.GC_7879,(0,41):C.GC_7879,(0,44):C.GC_7879,(0,4):C.GC_7879,(0,40):C.GC_7513,(0,42):C.GC_7513,(0,45):C.GC_7513,(0,5):C.GC_7513,(0,1):C.GC_7904,(0,10):C.GC_7904,(0,14):C.GC_7901,(0,15):C.GC_7901,(0,17):C.GC_7901,(0,18):C.GC_7901,(0,23):C.GC_7901,(0,24):C.GC_7901,(0,25):C.GC_7904,(0,27):C.GC_7901,(0,28):C.GC_7901,(0,29):C.GC_7904,(0,43):C.GC_7900,(0,2):C.GC_7903,(0,6):C.GC_7903,(0,3):C.GC_7903,(0,7):C.GC_7903,(0,8):C.GC_7900})

V_423 = Vertex(name = 'V_423',
               particles = [ P.A, P.Z, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS91 ],
               couplings = {(0,0):C.GC_7890})

V_424 = Vertex(name = 'V_424',
               particles = [ P.A, P.Z, P.G__minus__, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSS1, L.VVSSS11, L.VVSSS13, L.VVSSS16, L.VVSSS17, L.VVSSS24, L.VVSSS25, L.VVSSS26, L.VVSSS3, L.VVSSS39, L.VVSSS5, L.VVSSS58, L.VVSSS59, L.VVSSS6, L.VVSSS60, L.VVSSS61, L.VVSSS62, L.VVSSS63, L.VVSSS65, L.VVSSS67, L.VVSSS68, L.VVSSS7, L.VVSSS8 ],
               couplings = {(0,21):C.GC_7875,(0,22):C.GC_7429,(0,10):C.GC_7870,(0,13):C.GC_7427,(0,3):C.GC_7874,(0,4):C.GC_7429,(0,1):C.GC_7872,(0,2):C.GC_7427,(0,9):C.GC_7869,(0,5):C.GC_7868,(0,14):C.GC_7873,(0,16):C.GC_7871,(0,18):C.GC_7867,(0,15):C.GC_7428,(0,17):C.GC_7428,(0,11):C.GC_7894,(0,8):C.GC_7400,(0,0):C.GC_7398,(0,12):C.GC_7399,(0,6):C.GC_7895,(0,7):C.GC_7895,(0,19):C.GC_7896,(0,20):C.GC_7896})

V_425 = Vertex(name = 'V_425',
               particles = [ P.A, P.Z, P.G__minus__, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSS58 ],
               couplings = {(0,0):C.GC_7888})

V_426 = Vertex(name = 'V_426',
               particles = [ P.A, P.Z, P.G__minus__, P.G__plus__, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS1, L.VVSSSS100, L.VVSSSS101, L.VVSSSS102, L.VVSSSS104, L.VVSSSS105, L.VVSSSS106, L.VVSSSS11, L.VVSSSS14, L.VVSSSS15, L.VVSSSS21, L.VVSSSS22, L.VVSSSS23, L.VVSSSS28, L.VVSSSS3, L.VVSSSS34, L.VVSSSS35, L.VVSSSS36, L.VVSSSS37, L.VVSSSS41, L.VVSSSS5, L.VVSSSS56, L.VVSSSS6, L.VVSSSS7, L.VVSSSS8, L.VVSSSS9, L.VVSSSS91, L.VVSSSS92, L.VVSSSS93, L.VVSSSS94, L.VVSSSS95, L.VVSSSS96, L.VVSSSS98 ],
               couplings = {(0,26):C.GC_7892,(0,23):C.GC_7887,(0,24):C.GC_7515,(0,20):C.GC_7882,(0,22):C.GC_7511,(0,8):C.GC_7886,(0,9):C.GC_7515,(0,25):C.GC_7884,(0,7):C.GC_7511,(0,13):C.GC_7880,(0,10):C.GC_7878,(0,21):C.GC_7880,(0,15):C.GC_7878,(0,28):C.GC_7885,(0,30):C.GC_7883,(0,32):C.GC_7877,(0,3):C.GC_7877,(0,29):C.GC_7512,(0,31):C.GC_7512,(0,14):C.GC_7384,(0,0):C.GC_7380,(0,27):C.GC_7381,(0,11):C.GC_7897,(0,12):C.GC_7897,(0,16):C.GC_7897,(0,17):C.GC_7897,(0,18):C.GC_7899,(0,19):C.GC_7899,(0,1):C.GC_7898,(0,4):C.GC_7898,(0,2):C.GC_7898,(0,5):C.GC_7898,(0,6):C.GC_7902})

V_427 = Vertex(name = 'V_427',
               particles = [ P.A, P.Z, P.G__minus__, P.G__plus__, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS91 ],
               couplings = {(0,0):C.GC_7889})

V_428 = Vertex(name = 'V_428',
               particles = [ P.Z, P.G0, P.G__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VSSS1, L.VSSS13, L.VSSS15, L.VSSS17, L.VSSS20, L.VSSS21, L.VSSS3, L.VSSS30, L.VSSS5, L.VSSS8 ],
               couplings = {(0,0):C.GC_3262,(0,2):C.GC_3269,(0,4):C.GC_3269,(0,5):C.GC_2828,(0,9):C.GC_2382,(0,7):C.GC_2380,(0,6):C.GC_2379,(0,1):C.GC_2376,(0,8):C.GC_2376,(0,3):C.GC_2379})

V_429 = Vertex(name = 'V_429',
               particles = [ P.Z, P.G0, P.G__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VSSS1 ],
               couplings = {(0,0):C.GC_7019})

V_430 = Vertex(name = 'V_430',
               particles = [ P.Z, P.G0, P.G__minus__, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VSSSS1, L.VSSSS11, L.VSSSS13, L.VSSSS16, L.VSSSS19, L.VSSSS20, L.VSSSS22, L.VSSSS3, L.VSSSS31, L.VSSSS32, L.VSSSS33, L.VSSSS34, L.VSSSS35, L.VSSSS36, L.VSSSS37, L.VSSSS42, L.VSSSS44, L.VSSSS46, L.VSSSS48, L.VSSSS5, L.VSSSS50, L.VSSSS51, L.VSSSS52, L.VSSSS8, L.VSSSS84, L.VSSSS85, L.VSSSS86 ],
               couplings = {(0,23):C.GC_2375,(0,6):C.GC_2372,(0,24):C.GC_6878,(0,25):C.GC_2375,(0,26):C.GC_2372,(0,7):C.GC_2371,(0,1):C.GC_2368,(0,9):C.GC_6875,(0,19):C.GC_2368,(0,10):C.GC_2371,(0,3):C.GC_2371,(0,12):C.GC_2368,(0,15):C.GC_6874,(0,16):C.GC_2368,(0,18):C.GC_2371,(0,0):C.GC_3268,(0,8):C.GC_3265,(0,2):C.GC_3365,(0,11):C.GC_3366,(0,4):C.GC_3365,(0,13):C.GC_3366,(0,5):C.GC_2852,(0,14):C.GC_2853,(0,17):C.GC_3373,(0,20):C.GC_3374,(0,21):C.GC_3373,(0,22):C.GC_3374})

V_431 = Vertex(name = 'V_431',
               particles = [ P.Z, P.G0, P.G__minus__, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VSSSS1, L.VSSSS31 ],
               couplings = {(0,0):C.GC_7020,(0,1):C.GC_7023})

V_432 = Vertex(name = 'V_432',
               particles = [ P.Z, P.G__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VSS1, L.VSS10, L.VSS5, L.VSS6, L.VSS7 ],
               couplings = {(0,1):C.GC_5676,(0,3):C.GC_5674,(0,4):C.GC_5671,(0,0):C.GC_3260,(0,2):C.GC_3261})

V_433 = Vertex(name = 'V_433',
               particles = [ P.Z, P.G__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VSS1, L.VSS5 ],
               couplings = {(0,0):C.GC_5704,(0,1):C.GC_5702})

V_434 = Vertex(name = 'V_434',
               particles = [ P.Z, P.G__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VSS1, L.VSS5 ],
               couplings = {(0,0):C.GC_5735,(0,1):C.GC_5733})

V_435 = Vertex(name = 'V_435',
               particles = [ P.Z, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VSSSS1, L.VSSSS10, L.VSSSS11, L.VSSSS12, L.VSSSS13, L.VSSSS16, L.VSSSS18, L.VSSSS19, L.VSSSS2, L.VSSSS20, L.VSSSS22, L.VSSSS23, L.VSSSS31, L.VSSSS32, L.VSSSS33, L.VSSSS34, L.VSSSS36, L.VSSSS37, L.VSSSS42, L.VSSSS44, L.VSSSS45, L.VSSSS46, L.VSSSS49, L.VSSSS50, L.VSSSS51, L.VSSSS52, L.VSSSS84, L.VSSSS85 ],
               couplings = {(0,10):C.GC_6879,(0,11):C.GC_6879,(0,26):C.GC_6879,(0,27):C.GC_6879,(0,2):C.GC_6876,(0,13):C.GC_6876,(0,3):C.GC_6876,(0,14):C.GC_6876,(0,5):C.GC_6873,(0,6):C.GC_6873,(0,18):C.GC_6873,(0,19):C.GC_6873,(0,0):C.GC_3266,(0,8):C.GC_3266,(0,1):C.GC_3267,(0,12):C.GC_3267,(0,4):C.GC_3372,(0,15):C.GC_3372,(0,7):C.GC_3380,(0,16):C.GC_3378,(0,20):C.GC_3380,(0,22):C.GC_3378,(0,9):C.GC_3380,(0,17):C.GC_3378,(0,21):C.GC_3380,(0,23):C.GC_3378,(0,24):C.GC_3371,(0,25):C.GC_3371})

V_436 = Vertex(name = 'V_436',
               particles = [ P.Z, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VSSSS1, L.VSSSS10, L.VSSSS2, L.VSSSS31 ],
               couplings = {(0,0):C.GC_7022,(0,2):C.GC_7022,(0,1):C.GC_7021,(0,3):C.GC_7021})

V_437 = Vertex(name = 'V_437',
               particles = [ P.Z, P.G__minus__, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VSSS1, L.VSSS13, L.VSSS14, L.VSSS17, L.VSSS19, L.VSSS2, L.VSSS20, L.VSSS21, L.VSSS3, L.VSSS30, L.VSSS31, L.VSSS5, L.VSSS8 ],
               couplings = {(0,0):C.GC_2815,(0,5):C.GC_2816,(0,6):C.GC_3271,(0,7):C.GC_3270,(0,12):C.GC_6929,(0,9):C.GC_2381,(0,10):C.GC_2381,(0,8):C.GC_6926,(0,1):C.GC_2377,(0,11):C.GC_6923,(0,2):C.GC_2377,(0,3):C.GC_2378,(0,4):C.GC_2378})

V_438 = Vertex(name = 'V_438',
               particles = [ P.Z, P.G__minus__, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VSSS1, L.VSSS2 ],
               couplings = {(0,0):C.GC_3325,(0,1):C.GC_3324})

V_439 = Vertex(name = 'V_439',
               particles = [ P.Z, P.G__minus__, P.G__plus__, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VSSSS1, L.VSSSS11, L.VSSSS12, L.VSSSS16, L.VSSSS18, L.VSSSS19, L.VSSSS2, L.VSSSS20, L.VSSSS22, L.VSSSS23, L.VSSSS3, L.VSSSS32, L.VSSSS33, L.VSSSS36, L.VSSSS37, L.VSSSS42, L.VSSSS44, L.VSSSS45, L.VSSSS46, L.VSSSS49, L.VSSSS5, L.VSSSS50, L.VSSSS51, L.VSSSS52, L.VSSSS53, L.VSSSS8, L.VSSSS84, L.VSSSS85, L.VSSSS86 ],
               couplings = {(0,25):C.GC_6879,(0,8):C.GC_2373,(0,9):C.GC_2373,(0,24):C.GC_6877,(0,26):C.GC_2373,(0,27):C.GC_2373,(0,28):C.GC_6877,(0,10):C.GC_6876,(0,1):C.GC_2369,(0,11):C.GC_2369,(0,20):C.GC_6873,(0,2):C.GC_2369,(0,12):C.GC_2369,(0,3):C.GC_2370,(0,4):C.GC_2370,(0,15):C.GC_2370,(0,16):C.GC_2370,(0,0):C.GC_2823,(0,6):C.GC_2824,(0,5):C.GC_3369,(0,13):C.GC_3370,(0,17):C.GC_3369,(0,19):C.GC_3370,(0,7):C.GC_3368,(0,14):C.GC_3367,(0,18):C.GC_3368,(0,21):C.GC_3367,(0,22):C.GC_3379,(0,23):C.GC_3377})

V_440 = Vertex(name = 'V_440',
               particles = [ P.Z, P.G__minus__, P.G__plus__, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VSSSS1, L.VSSSS2 ],
               couplings = {(0,0):C.GC_3338,(0,1):C.GC_3336})

V_441 = Vertex(name = 'V_441',
               particles = [ P.Z, P.G0, P.G0, P.G0, P.H ],
               color = [ '1' ],
               lorentz = [ L.VSSSS1, L.VSSSS10, L.VSSSS13, L.VSSSS19, L.VSSSS2, L.VSSSS20, L.VSSSS31, L.VSSSS32, L.VSSSS33, L.VSSSS34, L.VSSSS35, L.VSSSS36, L.VSSSS37, L.VSSSS42, L.VSSSS44, L.VSSSS45, L.VSSSS46, L.VSSSS48, L.VSSSS49, L.VSSSS50, L.VSSSS51, L.VSSSS52, L.VSSSS84, L.VSSSS85, L.VSSSS86 ],
               couplings = {(0,22):C.GC_6878,(0,23):C.GC_6878,(0,24):C.GC_6878,(0,7):C.GC_6875,(0,8):C.GC_6875,(0,10):C.GC_6875,(0,13):C.GC_6874,(0,14):C.GC_6874,(0,17):C.GC_6874,(0,0):C.GC_2825,(0,4):C.GC_2825,(0,1):C.GC_2825,(0,6):C.GC_2821,(0,2):C.GC_3375,(0,9):C.GC_3381,(0,3):C.GC_3375,(0,11):C.GC_3381,(0,15):C.GC_2851,(0,18):C.GC_2851,(0,5):C.GC_3375,(0,12):C.GC_3381,(0,16):C.GC_2851,(0,19):C.GC_2851,(0,20):C.GC_2851,(0,21):C.GC_2851})

V_442 = Vertex(name = 'V_442',
               particles = [ P.Z, P.G0, P.G0, P.G0, P.H ],
               color = [ '1' ],
               lorentz = [ L.VSSSS1, L.VSSSS10, L.VSSSS2, L.VSSSS31 ],
               couplings = {(0,0):C.GC_3334,(0,2):C.GC_3334,(0,1):C.GC_3334,(0,3):C.GC_3340})

V_443 = Vertex(name = 'V_443',
               particles = [ P.Z, P.G0, P.H ],
               color = [ '1' ],
               lorentz = [ L.VSS1, L.VSS10, L.VSS5, L.VSS6, L.VSS7 ],
               couplings = {(0,1):C.GC_5675,(0,3):C.GC_5673,(0,4):C.GC_5672,(0,0):C.GC_2813,(0,2):C.GC_2810})

V_444 = Vertex(name = 'V_444',
               particles = [ P.Z, P.G0, P.H ],
               color = [ '1' ],
               lorentz = [ L.VSS1, L.VSS5 ],
               couplings = {(0,0):C.GC_3264,(0,1):C.GC_3263})

V_445 = Vertex(name = 'V_445',
               particles = [ P.Z, P.G0, P.H ],
               color = [ '1' ],
               lorentz = [ L.VSS1, L.VSS5 ],
               couplings = {(0,0):C.GC_3318,(0,1):C.GC_3319})

V_446 = Vertex(name = 'V_446',
               particles = [ P.Z, P.G0, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VSSS1, L.VSSS12, L.VSSS13, L.VSSS15, L.VSSS17, L.VSSS2, L.VSSS20, L.VSSS21, L.VSSS3, L.VSSS30, L.VSSS5, L.VSSS8 ],
               couplings = {(0,0):C.GC_2818,(0,5):C.GC_2814,(0,1):C.GC_2814,(0,3):C.GC_2827,(0,6):C.GC_2827,(0,7):C.GC_3273,(0,11):C.GC_6928,(0,9):C.GC_6928,(0,8):C.GC_6925,(0,2):C.GC_6925,(0,10):C.GC_6924,(0,4):C.GC_6924})

V_447 = Vertex(name = 'V_447',
               particles = [ P.Z, P.G0, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VSSS1, L.VSSS12, L.VSSS2 ],
               couplings = {(0,0):C.GC_3322,(0,2):C.GC_3326,(0,1):C.GC_3326})

V_448 = Vertex(name = 'V_448',
               particles = [ P.Z, P.G0, P.H, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VSSSS1, L.VSSSS10, L.VSSSS11, L.VSSSS13, L.VSSSS16, L.VSSSS19, L.VSSSS2, L.VSSSS20, L.VSSSS22, L.VSSSS3, L.VSSSS31, L.VSSSS32, L.VSSSS34, L.VSSSS36, L.VSSSS37, L.VSSSS42, L.VSSSS45, L.VSSSS46, L.VSSSS49, L.VSSSS5, L.VSSSS50, L.VSSSS51, L.VSSSS52, L.VSSSS8, L.VSSSS84 ],
               couplings = {(0,23):C.GC_6878,(0,8):C.GC_6878,(0,24):C.GC_6878,(0,9):C.GC_6875,(0,2):C.GC_6875,(0,11):C.GC_6875,(0,19):C.GC_6874,(0,4):C.GC_6874,(0,15):C.GC_6874,(0,0):C.GC_2826,(0,6):C.GC_2822,(0,1):C.GC_2822,(0,10):C.GC_2822,(0,3):C.GC_2850,(0,12):C.GC_2850,(0,5):C.GC_2850,(0,13):C.GC_2850,(0,16):C.GC_2850,(0,18):C.GC_2850,(0,7):C.GC_3376,(0,14):C.GC_3382,(0,17):C.GC_3376,(0,20):C.GC_3382,(0,21):C.GC_3376,(0,22):C.GC_3382})

V_449 = Vertex(name = 'V_449',
               particles = [ P.Z, P.G0, P.H, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VSSSS1, L.VSSSS10, L.VSSSS2, L.VSSSS31 ],
               couplings = {(0,0):C.GC_3333,(0,2):C.GC_3339,(0,1):C.GC_3339,(0,3):C.GC_3339})

V_450 = Vertex(name = 'V_450',
               particles = [ P.Z, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VSS10, L.VSS8 ],
               couplings = {(0,1):C.GC_6919,(0,0):C.GC_6919})

V_451 = Vertex(name = 'V_451',
               particles = [ P.Z, P.H, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VSSS18, L.VSSS22, L.VSSS30, L.VSSS31, L.VSSS6, L.VSSS8 ],
               couplings = {(0,4):C.GC_6927,(0,5):C.GC_6927,(0,0):C.GC_6927,(0,1):C.GC_6927,(0,2):C.GC_6927,(0,3):C.GC_6927})

V_452 = Vertex(name = 'V_452',
               particles = [ P.Z, P.H, P.H, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VSSSS17, L.VSSSS21, L.VSSSS22, L.VSSSS23, L.VSSSS43, L.VSSSS47, L.VSSSS53, L.VSSSS6, L.VSSSS8, L.VSSSS84, L.VSSSS85, L.VSSSS86 ],
               couplings = {(0,7):C.GC_6877,(0,8):C.GC_6877,(0,0):C.GC_6877,(0,1):C.GC_6877,(0,2):C.GC_6877,(0,3):C.GC_6877,(0,4):C.GC_6877,(0,5):C.GC_6877,(0,6):C.GC_6877,(0,9):C.GC_6877,(0,10):C.GC_6877,(0,11):C.GC_6877})

V_453 = Vertex(name = 'V_453',
               particles = [ P.A, P.Z, P.G0, P.G0 ],
               color = [ '1' ],
               lorentz = [ L.VVSS1, L.VVSS11, L.VVSS12, L.VVSS14, L.VVSS17, L.VVSS18, L.VVSS19, L.VVSS21, L.VVSS23, L.VVSS25, L.VVSS26, L.VVSS27, L.VVSS28, L.VVSS3, L.VVSS30, L.VVSS32, L.VVSS33, L.VVSS41, L.VVSS42, L.VVSS5, L.VVSS56, L.VVSS57, L.VVSS59, L.VVSS62, L.VVSS63, L.VVSS64, L.VVSS7, L.VVSS9 ],
               couplings = {(0,13):C.GC_5382,(0,0):C.GC_5375,(0,9):C.GC_2124,(0,11):C.GC_1523,(0,3):C.GC_2124,(0,6):C.GC_1523,(0,1):C.GC_5399,(0,4):C.GC_5399,(0,20):C.GC_5376,(0,18):C.GC_2124,(0,5):C.GC_5400,(0,16):C.GC_2124,(0,10):C.GC_5400,(0,17):C.GC_1523,(0,2):C.GC_5400,(0,23):C.GC_5399,(0,15):C.GC_1523,(0,8):C.GC_5400,(0,24):C.GC_5399,(0,14):C.GC_5403,(0,12):C.GC_5402,(0,25):C.GC_5401,(0,26):C.GC_5905,(0,19):C.GC_5902,(0,7):C.GC_5905,(0,27):C.GC_5902,(0,21):C.GC_5903,(0,22):C.GC_5903})

V_454 = Vertex(name = 'V_454',
               particles = [ P.A, P.Z, P.G0, P.G0 ],
               color = [ '1' ],
               lorentz = [ L.VVSS1, L.VVSS3, L.VVSS56 ],
               couplings = {(0,1):C.GC_5443,(0,0):C.GC_5439,(0,2):C.GC_5440})

V_455 = Vertex(name = 'V_455',
               particles = [ P.A, P.Z, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVS1, L.VVS12, L.VVS13, L.VVS3, L.VVS5, L.VVS7 ],
               couplings = {(0,5):C.GC_5884,(0,4):C.GC_5882,(0,2):C.GC_5883,(0,3):C.GC_5392,(0,0):C.GC_5388,(0,1):C.GC_5389})

V_456 = Vertex(name = 'V_456',
               particles = [ P.A, P.Z, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVS1, L.VVS12, L.VVS3 ],
               couplings = {(0,2):C.GC_5428,(0,0):C.GC_5426,(0,1):C.GC_5427})

V_457 = Vertex(name = 'V_457',
               particles = [ P.A, P.Z, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSS1, L.VVSS11, L.VVSS12, L.VVSS14, L.VVSS17, L.VVSS18, L.VVSS19, L.VVSS21, L.VVSS23, L.VVSS25, L.VVSS26, L.VVSS27, L.VVSS28, L.VVSS3, L.VVSS30, L.VVSS32, L.VVSS33, L.VVSS41, L.VVSS42, L.VVSS5, L.VVSS56, L.VVSS57, L.VVSS59, L.VVSS62, L.VVSS63, L.VVSS64, L.VVSS7, L.VVSS9 ],
               couplings = {(0,13):C.GC_5382,(0,0):C.GC_5375,(0,9):C.GC_2124,(0,11):C.GC_1523,(0,3):C.GC_2124,(0,6):C.GC_1523,(0,1):C.GC_5399,(0,4):C.GC_5399,(0,20):C.GC_5376,(0,18):C.GC_2124,(0,5):C.GC_5400,(0,16):C.GC_2124,(0,10):C.GC_5400,(0,17):C.GC_1523,(0,2):C.GC_5400,(0,23):C.GC_5399,(0,15):C.GC_1523,(0,8):C.GC_5400,(0,24):C.GC_5399,(0,14):C.GC_5403,(0,12):C.GC_5402,(0,25):C.GC_5401,(0,26):C.GC_5906,(0,19):C.GC_5901,(0,7):C.GC_5906,(0,27):C.GC_5901,(0,21):C.GC_5904,(0,22):C.GC_5904})

V_458 = Vertex(name = 'V_458',
               particles = [ P.A, P.Z, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSS1, L.VVSS3, L.VVSS56 ],
               couplings = {(0,1):C.GC_5444,(0,0):C.GC_5441,(0,2):C.GC_5442})

V_459 = Vertex(name = 'V_459',
               particles = [ P.A, P.Z, P.G0, P.G0, P.G0, P.G0 ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS1, L.VVSSSS102, L.VVSSSS14, L.VVSSSS21, L.VVSSSS28, L.VVSSSS3, L.VVSSSS34, L.VVSSSS5, L.VVSSSS56, L.VVSSSS7, L.VVSSSS9, L.VVSSSS92, L.VVSSSS93, L.VVSSSS95, L.VVSSSS98 ],
               couplings = {(0,5):C.GC_6206,(0,0):C.GC_6204,(0,11):C.GC_6203,(0,9):C.GC_6056,(0,7):C.GC_6051,(0,2):C.GC_6056,(0,10):C.GC_6051,(0,4):C.GC_6056,(0,3):C.GC_6051,(0,8):C.GC_6056,(0,6):C.GC_6051,(0,12):C.GC_6054,(0,13):C.GC_6054,(0,14):C.GC_6054,(0,1):C.GC_6054})

V_460 = Vertex(name = 'V_460',
               particles = [ P.A, P.Z, P.G0, P.G0, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSS1, L.VVSSS11, L.VVSSS16, L.VVSSS24, L.VVSSS3, L.VVSSS39, L.VVSSS5, L.VVSSS59, L.VVSSS60, L.VVSSS62, L.VVSSS65, L.VVSSS7 ],
               couplings = {(0,11):C.GC_6011,(0,6):C.GC_6008,(0,2):C.GC_6011,(0,1):C.GC_6008,(0,5):C.GC_6011,(0,3):C.GC_6008,(0,8):C.GC_6009,(0,9):C.GC_6009,(0,10):C.GC_6009,(0,4):C.GC_6237,(0,0):C.GC_6234,(0,7):C.GC_6233})

V_461 = Vertex(name = 'V_461',
               particles = [ P.A, P.Z, P.G0, P.G0, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS1, L.VVSSSS102, L.VVSSSS14, L.VVSSSS21, L.VVSSSS28, L.VVSSSS3, L.VVSSSS34, L.VVSSSS5, L.VVSSSS56, L.VVSSSS7, L.VVSSSS9, L.VVSSSS92, L.VVSSSS93, L.VVSSSS95, L.VVSSSS98 ],
               couplings = {(0,5):C.GC_6205,(0,0):C.GC_6202,(0,11):C.GC_6201,(0,9):C.GC_6055,(0,7):C.GC_6052,(0,2):C.GC_6055,(0,10):C.GC_6052,(0,4):C.GC_6055,(0,3):C.GC_6052,(0,8):C.GC_6055,(0,6):C.GC_6052,(0,12):C.GC_6053,(0,13):C.GC_6053,(0,14):C.GC_6053,(0,1):C.GC_6053})

V_462 = Vertex(name = 'V_462',
               particles = [ P.A, P.Z, P.H, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSS1, L.VVSSS11, L.VVSSS16, L.VVSSS24, L.VVSSS3, L.VVSSS39, L.VVSSS5, L.VVSSS59, L.VVSSS60, L.VVSSS62, L.VVSSS65, L.VVSSS7 ],
               couplings = {(0,11):C.GC_6012,(0,6):C.GC_6007,(0,2):C.GC_6012,(0,1):C.GC_6007,(0,5):C.GC_6012,(0,3):C.GC_6007,(0,8):C.GC_6010,(0,9):C.GC_6010,(0,10):C.GC_6010,(0,4):C.GC_6238,(0,0):C.GC_6236,(0,7):C.GC_6235})

V_463 = Vertex(name = 'V_463',
               particles = [ P.A, P.Z, P.H, P.H, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS1, L.VVSSSS102, L.VVSSSS14, L.VVSSSS21, L.VVSSSS28, L.VVSSSS3, L.VVSSSS34, L.VVSSSS5, L.VVSSSS56, L.VVSSSS7, L.VVSSSS9, L.VVSSSS92, L.VVSSSS93, L.VVSSSS95, L.VVSSSS98 ],
               couplings = {(0,5):C.GC_6206,(0,0):C.GC_6204,(0,11):C.GC_6203,(0,9):C.GC_6056,(0,7):C.GC_6051,(0,2):C.GC_6056,(0,10):C.GC_6051,(0,4):C.GC_6056,(0,3):C.GC_6051,(0,8):C.GC_6056,(0,6):C.GC_6051,(0,12):C.GC_6054,(0,13):C.GC_6054,(0,14):C.GC_6054,(0,1):C.GC_6054})

V_464 = Vertex(name = 'V_464',
               particles = [ P.A, P.A, P.A, P.Z ],
               color = [ '1' ],
               lorentz = [ L.VVVV104, L.VVVV112, L.VVVV126, L.VVVV127, L.VVVV128, L.VVVV142, L.VVVV150, L.VVVV158, L.VVVV171, L.VVVV172, L.VVVV173, L.VVVV184, L.VVVV197, L.VVVV198, L.VVVV199, L.VVVV210, L.VVVV25, L.VVVV27, L.VVVV28, L.VVVV31, L.VVVV33, L.VVVV34, L.VVVV37, L.VVVV38, L.VVVV39, L.VVVV58, L.VVVV59, L.VVVV60, L.VVVV61, L.VVVV62, L.VVVV67, L.VVVV68, L.VVVV69, L.VVVV70, L.VVVV84, L.VVVV92 ],
               couplings = {(0,27):C.GC_6214,(0,28):C.GC_6209,(0,29):C.GC_6210,(0,25):C.GC_6214,(0,26):C.GC_6214,(0,30):C.GC_6209,(0,31):C.GC_6210,(0,32):C.GC_6209,(0,33):C.GC_6210,(0,17):C.GC_6211,(0,18):C.GC_6212,(0,16):C.GC_6208,(0,20):C.GC_6211,(0,21):C.GC_6212,(0,19):C.GC_6208,(0,23):C.GC_6211,(0,24):C.GC_6212,(0,22):C.GC_6208,(0,35):C.GC_6213,(0,34):C.GC_6207,(0,1):C.GC_6213,(0,0):C.GC_6207,(0,3):C.GC_6212,(0,4):C.GC_6211,(0,2):C.GC_6207,(0,6):C.GC_6213,(0,5):C.GC_6207,(0,7):C.GC_6208,(0,9):C.GC_6212,(0,10):C.GC_6211,(0,8):C.GC_6207,(0,11):C.GC_6208,(0,13):C.GC_6212,(0,14):C.GC_6211,(0,12):C.GC_6207,(0,15):C.GC_6208})

V_465 = Vertex(name = 'V_465',
               particles = [ P.W__minus__, P.Z, P.G0, P.G0, P.G0, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS1, L.VVSSSS10, L.VVSSSS100, L.VVSSSS101, L.VVSSSS102, L.VVSSSS103, L.VVSSSS104, L.VVSSSS105, L.VVSSSS106, L.VVSSSS11, L.VVSSSS12, L.VVSSSS14, L.VVSSSS15, L.VVSSSS16, L.VVSSSS19, L.VVSSSS21, L.VVSSSS22, L.VVSSSS23, L.VVSSSS24, L.VVSSSS25, L.VVSSSS26, L.VVSSSS28, L.VVSSSS29, L.VVSSSS3, L.VVSSSS30, L.VVSSSS31, L.VVSSSS32, L.VVSSSS33, L.VVSSSS34, L.VVSSSS35, L.VVSSSS36, L.VVSSSS37, L.VVSSSS38, L.VVSSSS39, L.VVSSSS40, L.VVSSSS41, L.VVSSSS5, L.VVSSSS56, L.VVSSSS57, L.VVSSSS6, L.VVSSSS7, L.VVSSSS73, L.VVSSSS74, L.VVSSSS75, L.VVSSSS8, L.VVSSSS9, L.VVSSSS91, L.VVSSSS92, L.VVSSSS93, L.VVSSSS94, L.VVSSSS95, L.VVSSSS96, L.VVSSSS97, L.VVSSSS98, L.VVSSSS99 ],
               couplings = {(0,23):C.GC_6914,(0,0):C.GC_6905,(0,46):C.GC_2884,(0,47):C.GC_6894,(0,1):C.GC_3597,(0,10):C.GC_3597,(0,16):C.GC_3597,(0,17):C.GC_3597,(0,19):C.GC_3597,(0,20):C.GC_3597,(0,33):C.GC_2001,(0,34):C.GC_2001,(0,35):C.GC_2001,(0,52):C.GC_3620,(0,2):C.GC_3620,(0,6):C.GC_3612,(0,3):C.GC_3620,(0,7):C.GC_3612,(0,8):C.GC_3612,(0,40):C.GC_3477,(0,44):C.GC_7055,(0,36):C.GC_3423,(0,39):C.GC_7040,(0,11):C.GC_3477,(0,12):C.GC_7055,(0,13):C.GC_2523,(0,14):C.GC_2523,(0,45):C.GC_3423,(0,9):C.GC_7040,(0,21):C.GC_3477,(0,22):C.GC_7055,(0,24):C.GC_2523,(0,25):C.GC_2523,(0,26):C.GC_2523,(0,27):C.GC_2523,(0,15):C.GC_3423,(0,18):C.GC_7040,(0,37):C.GC_3458,(0,38):C.GC_7059,(0,41):C.GC_2007,(0,42):C.GC_2007,(0,43):C.GC_2007,(0,28):C.GC_3457,(0,29):C.GC_1994,(0,30):C.GC_1994,(0,31):C.GC_1994,(0,32):C.GC_7044,(0,48):C.GC_3449,(0,50):C.GC_3449,(0,53):C.GC_3449,(0,4):C.GC_3414,(0,49):C.GC_7036,(0,51):C.GC_7036,(0,54):C.GC_7036,(0,5):C.GC_7043})

V_466 = Vertex(name = 'V_466',
               particles = [ P.W__minus__, P.Z, P.G0, P.G0, P.G0, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS39, L.VVSSSS40, L.VVSSSS41, L.VVSSSS91 ],
               couplings = {(0,3):C.GC_3493,(0,0):C.GC_3600,(0,1):C.GC_3600,(0,2):C.GC_3600})

V_467 = Vertex(name = 'V_467',
               particles = [ P.W__minus__, P.Z, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVS1, L.VVS11, L.VVS12, L.VVS13, L.VVS14, L.VVS3, L.VVS5, L.VVS6, L.VVS7, L.VVS8 ],
               couplings = {(0,8):C.GC_3332,(0,9):C.GC_5740,(0,6):C.GC_3328,(0,7):C.GC_5739,(0,3):C.GC_3329,(0,4):C.GC_5738,(0,1):C.GC_3481,(0,5):C.GC_5670,(0,0):C.GC_5668,(0,2):C.GC_5669})

V_468 = Vertex(name = 'V_468',
               particles = [ P.W__minus__, P.Z, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVS1, L.VVS11, L.VVS12, L.VVS3 ],
               couplings = {(0,1):C.GC_5841,(0,3):C.GC_5624,(0,0):C.GC_5622,(0,2):C.GC_5623})

V_469 = Vertex(name = 'V_469',
               particles = [ P.W__minus__, P.Z, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVS11 ],
               couplings = {(0,0):C.GC_5848})

V_470 = Vertex(name = 'V_470',
               particles = [ P.W__minus__, P.Z, P.G0, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSS1, L.VVSS10, L.VVSS11, L.VVSS12, L.VVSS14, L.VVSS15, L.VVSS16, L.VVSS17, L.VVSS18, L.VVSS19, L.VVSS21, L.VVSS22, L.VVSS23, L.VVSS25, L.VVSS26, L.VVSS27, L.VVSS28, L.VVSS3, L.VVSS30, L.VVSS32, L.VVSS33, L.VVSS40, L.VVSS41, L.VVSS42, L.VVSS5, L.VVSS55, L.VVSS56, L.VVSS57, L.VVSS58, L.VVSS59, L.VVSS6, L.VVSS60, L.VVSS61, L.VVSS62, L.VVSS63, L.VVSS64, L.VVSS7, L.VVSS8, L.VVSS9 ],
               couplings = {(0,13):C.GC_1926,(0,15):C.GC_5666,(0,4):C.GC_1921,(0,1):C.GC_1945,(0,9):C.GC_5667,(0,6):C.GC_1952,(0,2):C.GC_5657,(0,7):C.GC_5658,(0,23):C.GC_1926,(0,8):C.GC_5645,(0,20):C.GC_1921,(0,14):C.GC_5646,(0,22):C.GC_5666,(0,3):C.GC_5646,(0,33):C.GC_5657,(0,19):C.GC_5667,(0,12):C.GC_5645,(0,34):C.GC_5658,(0,32):C.GC_3489,(0,17):C.GC_5685,(0,0):C.GC_5682,(0,25):C.GC_3484,(0,26):C.GC_5679,(0,36):C.GC_3358,(0,37):C.GC_5762,(0,24):C.GC_3356,(0,30):C.GC_5754,(0,10):C.GC_3357,(0,11):C.GC_5761,(0,21):C.GC_1956,(0,38):C.GC_3355,(0,5):C.GC_5753,(0,27):C.GC_3342,(0,29):C.GC_3341,(0,28):C.GC_5752,(0,31):C.GC_5750,(0,18):C.GC_5641,(0,16):C.GC_5637,(0,35):C.GC_5640})

V_471 = Vertex(name = 'V_471',
               particles = [ P.W__minus__, P.Z, P.G0, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSS1, L.VVSS10, L.VVSS16, L.VVSS3, L.VVSS55, L.VVSS56 ],
               couplings = {(0,1):C.GC_2885,(0,2):C.GC_3489,(0,3):C.GC_5621,(0,0):C.GC_5618,(0,4):C.GC_5852,(0,5):C.GC_5615})

V_472 = Vertex(name = 'V_472',
               particles = [ P.W__minus__, P.Z, P.G0, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSS55 ],
               couplings = {(0,0):C.GC_5838})

V_473 = Vertex(name = 'V_473',
               particles = [ P.W__minus__, P.Z, P.G0, P.G0, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSSS1, L.VVSSS11, L.VVSSS12, L.VVSSS13, L.VVSSS14, L.VVSSS16, L.VVSSS17, L.VVSSS18, L.VVSSS21, L.VVSSS24, L.VVSSS25, L.VVSSS26, L.VVSSS28, L.VVSSS29, L.VVSSS3, L.VVSSS30, L.VVSSS39, L.VVSSS40, L.VVSSS5, L.VVSSS58, L.VVSSS59, L.VVSSS6, L.VVSSS60, L.VVSSS61, L.VVSSS62, L.VVSSS63, L.VVSSS64, L.VVSSS65, L.VVSSS66, L.VVSSS67, L.VVSSS68, L.VVSSS7, L.VVSSS8 ],
               couplings = {(0,31):C.GC_2847,(0,32):C.GC_2435,(0,18):C.GC_2845,(0,21):C.GC_2428,(0,5):C.GC_2847,(0,6):C.GC_2435,(0,7):C.GC_2434,(0,8):C.GC_2434,(0,1):C.GC_2845,(0,3):C.GC_2428,(0,16):C.GC_3312,(0,17):C.GC_6976,(0,9):C.GC_3290,(0,12):C.GC_6968,(0,22):C.GC_2844,(0,24):C.GC_2844,(0,27):C.GC_3292,(0,23):C.GC_2429,(0,25):C.GC_2429,(0,28):C.GC_6959,(0,19):C.GC_2876,(0,14):C.GC_6949,(0,0):C.GC_6941,(0,20):C.GC_6942,(0,2):C.GC_3558,(0,4):C.GC_3558,(0,10):C.GC_2896,(0,11):C.GC_2896,(0,13):C.GC_2889,(0,15):C.GC_2889,(0,26):C.GC_3561,(0,29):C.GC_2892,(0,30):C.GC_2892})

V_474 = Vertex(name = 'V_474',
               particles = [ P.W__minus__, P.Z, P.G0, P.G0, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSSS58 ],
               couplings = {(0,0):C.GC_3534})

V_475 = Vertex(name = 'V_475',
               particles = [ P.W__minus__, P.Z, P.G0, P.G__minus__, P.G__plus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS1, L.VVSSSS10, L.VVSSSS100, L.VVSSSS101, L.VVSSSS102, L.VVSSSS103, L.VVSSSS104, L.VVSSSS105, L.VVSSSS106, L.VVSSSS11, L.VVSSSS12, L.VVSSSS14, L.VVSSSS15, L.VVSSSS21, L.VVSSSS22, L.VVSSSS23, L.VVSSSS24, L.VVSSSS25, L.VVSSSS26, L.VVSSSS28, L.VVSSSS29, L.VVSSSS3, L.VVSSSS32, L.VVSSSS33, L.VVSSSS34, L.VVSSSS35, L.VVSSSS36, L.VVSSSS37, L.VVSSSS38, L.VVSSSS39, L.VVSSSS40, L.VVSSSS41, L.VVSSSS5, L.VVSSSS56, L.VVSSSS57, L.VVSSSS6, L.VVSSSS7, L.VVSSSS73, L.VVSSSS74, L.VVSSSS8, L.VVSSSS9, L.VVSSSS91, L.VVSSSS92, L.VVSSSS93, L.VVSSSS94, L.VVSSSS95, L.VVSSSS96, L.VVSSSS97, L.VVSSSS98, L.VVSSSS99 ],
               couplings = {(0,21):C.GC_6913,(0,0):C.GC_6904,(0,41):C.GC_3488,(0,42):C.GC_6895,(0,1):C.GC_3594,(0,10):C.GC_3640,(0,14):C.GC_2000,(0,15):C.GC_2509,(0,17):C.GC_1995,(0,18):C.GC_2514,(0,25):C.GC_2000,(0,26):C.GC_2509,(0,27):C.GC_3636,(0,29):C.GC_1995,(0,30):C.GC_2514,(0,31):C.GC_3636,(0,47):C.GC_3615,(0,2):C.GC_3590,(0,6):C.GC_3590,(0,3):C.GC_3618,(0,7):C.GC_3618,(0,8):C.GC_3615,(0,36):C.GC_3479,(0,39):C.GC_7057,(0,32):C.GC_3418,(0,35):C.GC_7042,(0,11):C.GC_3460,(0,12):C.GC_2525,(0,40):C.GC_3453,(0,9):C.GC_2515,(0,19):C.GC_3412,(0,20):C.GC_7053,(0,22):C.GC_2003,(0,23):C.GC_2524,(0,13):C.GC_3406,(0,16):C.GC_7038,(0,33):C.GC_3412,(0,34):C.GC_7053,(0,37):C.GC_2003,(0,38):C.GC_2524,(0,24):C.GC_3406,(0,28):C.GC_7038,(0,43):C.GC_3454,(0,45):C.GC_3416,(0,48):C.GC_3405,(0,4):C.GC_3405,(0,44):C.GC_7041,(0,46):C.GC_2508,(0,49):C.GC_7035,(0,5):C.GC_7035})

V_476 = Vertex(name = 'V_476',
               particles = [ P.W__minus__, P.Z, P.G0, P.G__minus__, P.G__plus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS22, L.VVSSSS23, L.VVSSSS25, L.VVSSSS26, L.VVSSSS35, L.VVSSSS36, L.VVSSSS39, L.VVSSSS40, L.VVSSSS91 ],
               couplings = {(0,8):C.GC_7164,(0,0):C.GC_3598,(0,1):C.GC_3624,(0,2):C.GC_3621,(0,3):C.GC_3596,(0,4):C.GC_3598,(0,5):C.GC_3624,(0,6):C.GC_3621,(0,7):C.GC_3596})

V_477 = Vertex(name = 'V_477',
               particles = [ P.W__minus__, P.Z, P.G__minus__, P.G__plus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSSS1, L.VVSSS11, L.VVSSS12, L.VVSSS13, L.VVSSS14, L.VVSSS16, L.VVSSS17, L.VVSSS21, L.VVSSS24, L.VVSSS25, L.VVSSS26, L.VVSSS28, L.VVSSS29, L.VVSSS3, L.VVSSS30, L.VVSSS39, L.VVSSS40, L.VVSSS5, L.VVSSS50, L.VVSSS58, L.VVSSS59, L.VVSSS6, L.VVSSS60, L.VVSSS61, L.VVSSS62, L.VVSSS63, L.VVSSS64, L.VVSSS65, L.VVSSS66, L.VVSSS67, L.VVSSS68, L.VVSSS7, L.VVSSS8 ],
               couplings = {(0,31):C.GC_3315,(0,32):C.GC_2437,(0,17):C.GC_3296,(0,21):C.GC_2430,(0,5):C.GC_3282,(0,6):C.GC_6976,(0,7):C.GC_2435,(0,1):C.GC_3281,(0,2):C.GC_2429,(0,3):C.GC_6968,(0,4):C.GC_2428,(0,15):C.GC_3282,(0,16):C.GC_6976,(0,18):C.GC_2435,(0,8):C.GC_3281,(0,9):C.GC_2429,(0,11):C.GC_6968,(0,12):C.GC_2428,(0,22):C.GC_3297,(0,24):C.GC_3278,(0,27):C.GC_3278,(0,23):C.GC_2431,(0,25):C.GC_6959,(0,28):C.GC_6959,(0,19):C.GC_3485,(0,13):C.GC_6950,(0,0):C.GC_6943,(0,20):C.GC_6944,(0,10):C.GC_3556,(0,14):C.GC_3556,(0,26):C.GC_3559,(0,29):C.GC_3559,(0,30):C.GC_3551})

V_478 = Vertex(name = 'V_478',
               particles = [ P.W__minus__, P.Z, P.G__minus__, P.G__plus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSSS12, L.VVSSS14, L.VVSSS25, L.VVSSS29, L.VVSSS58 ],
               couplings = {(0,0):C.GC_3557,(0,1):C.GC_3552,(0,2):C.GC_3557,(0,3):C.GC_3552,(0,4):C.GC_7173})

V_479 = Vertex(name = 'V_479',
               particles = [ P.W__minus__, P.Z, P.G0, P.G0, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS1, L.VVSSSS10, L.VVSSSS100, L.VVSSSS101, L.VVSSSS102, L.VVSSSS103, L.VVSSSS104, L.VVSSSS105, L.VVSSSS106, L.VVSSSS11, L.VVSSSS12, L.VVSSSS14, L.VVSSSS15, L.VVSSSS16, L.VVSSSS19, L.VVSSSS21, L.VVSSSS22, L.VVSSSS23, L.VVSSSS24, L.VVSSSS25, L.VVSSSS26, L.VVSSSS28, L.VVSSSS29, L.VVSSSS3, L.VVSSSS34, L.VVSSSS35, L.VVSSSS36, L.VVSSSS37, L.VVSSSS38, L.VVSSSS39, L.VVSSSS40, L.VVSSSS41, L.VVSSSS5, L.VVSSSS56, L.VVSSSS57, L.VVSSSS6, L.VVSSSS7, L.VVSSSS73, L.VVSSSS74, L.VVSSSS75, L.VVSSSS8, L.VVSSSS9, L.VVSSSS91, L.VVSSSS92, L.VVSSSS93, L.VVSSSS94, L.VVSSSS95, L.VVSSSS96, L.VVSSSS97, L.VVSSSS98, L.VVSSSS99 ],
               couplings = {(0,23):C.GC_6909,(0,0):C.GC_6897,(0,42):C.GC_2881,(0,43):C.GC_6898,(0,1):C.GC_3630,(0,10):C.GC_3630,(0,16):C.GC_2943,(0,17):C.GC_2943,(0,19):C.GC_2936,(0,20):C.GC_2936,(0,25):C.GC_2511,(0,26):C.GC_2511,(0,27):C.GC_1997,(0,29):C.GC_2510,(0,30):C.GC_2510,(0,31):C.GC_1998,(0,48):C.GC_3634,(0,2):C.GC_2939,(0,6):C.GC_2939,(0,3):C.GC_2939,(0,7):C.GC_2939,(0,8):C.GC_3606,(0,36):C.GC_2872,(0,40):C.GC_2519,(0,32):C.GC_2870,(0,35):C.GC_2510,(0,11):C.GC_2872,(0,12):C.GC_2519,(0,13):C.GC_2518,(0,14):C.GC_2518,(0,41):C.GC_2870,(0,9):C.GC_2510,(0,21):C.GC_3468,(0,22):C.GC_7060,(0,15):C.GC_3428,(0,18):C.GC_7045,(0,33):C.GC_3469,(0,34):C.GC_7062,(0,37):C.GC_2519,(0,38):C.GC_2519,(0,39):C.GC_2005,(0,24):C.GC_3430,(0,28):C.GC_7047,(0,44):C.GC_2869,(0,46):C.GC_2869,(0,49):C.GC_3431,(0,4):C.GC_3432,(0,45):C.GC_2511,(0,47):C.GC_2511,(0,50):C.GC_7032,(0,5):C.GC_7033})

V_480 = Vertex(name = 'V_480',
               particles = [ P.W__minus__, P.Z, P.G0, P.G0, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS35, L.VVSSSS36, L.VVSSSS37, L.VVSSSS39, L.VVSSSS40, L.VVSSSS41, L.VVSSSS91 ],
               couplings = {(0,6):C.GC_3495,(0,0):C.GC_3602,(0,1):C.GC_3602,(0,2):C.GC_3606,(0,3):C.GC_3627,(0,4):C.GC_3627,(0,5):C.GC_2944})

V_481 = Vertex(name = 'V_481',
               particles = [ P.W__minus__, P.Z, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSS1, L.VVSS10, L.VVSS11, L.VVSS12, L.VVSS14, L.VVSS15, L.VVSS16, L.VVSS17, L.VVSS18, L.VVSS19, L.VVSS21, L.VVSS22, L.VVSS23, L.VVSS25, L.VVSS26, L.VVSS27, L.VVSS28, L.VVSS3, L.VVSS30, L.VVSS32, L.VVSS33, L.VVSS40, L.VVSS41, L.VVSS42, L.VVSS5, L.VVSS55, L.VVSS56, L.VVSS57, L.VVSS58, L.VVSS59, L.VVSS6, L.VVSS60, L.VVSS61, L.VVSS62, L.VVSS63, L.VVSS64, L.VVSS7, L.VVSS8, L.VVSS9 ],
               couplings = {(0,13):C.GC_1925,(0,15):C.GC_5665,(0,4):C.GC_1923,(0,1):C.GC_1948,(0,9):C.GC_5662,(0,25):C.GC_3483,(0,2):C.GC_5651,(0,7):C.GC_5648,(0,23):C.GC_1925,(0,8):C.GC_5655,(0,20):C.GC_1923,(0,14):C.GC_5652,(0,22):C.GC_5665,(0,3):C.GC_5652,(0,33):C.GC_5651,(0,19):C.GC_5662,(0,12):C.GC_5655,(0,34):C.GC_5648,(0,32):C.GC_3490,(0,17):C.GC_5684,(0,0):C.GC_5680,(0,26):C.GC_5681,(0,36):C.GC_3364,(0,37):C.GC_5765,(0,24):C.GC_3350,(0,30):C.GC_5758,(0,10):C.GC_3361,(0,11):C.GC_5763,(0,21):C.GC_1954,(0,38):C.GC_3348,(0,5):C.GC_5756,(0,6):C.GC_1949,(0,27):C.GC_3351,(0,29):C.GC_3345,(0,28):C.GC_5747,(0,31):C.GC_5749,(0,18):C.GC_5642,(0,16):C.GC_5639,(0,35):C.GC_5638})

V_482 = Vertex(name = 'V_482',
               particles = [ P.W__minus__, P.Z, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSS1, L.VVSS10, L.VVSS3, L.VVSS55, L.VVSS56 ],
               couplings = {(0,1):C.GC_3491,(0,3):C.GC_5839,(0,2):C.GC_5620,(0,0):C.GC_5616,(0,4):C.GC_5617})

V_483 = Vertex(name = 'V_483',
               particles = [ P.W__minus__, P.Z, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSS55 ],
               couplings = {(0,0):C.GC_5853})

V_484 = Vertex(name = 'V_484',
               particles = [ P.W__minus__, P.Z, P.G0, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSS1, L.VVSSS11, L.VVSSS12, L.VVSSS13, L.VVSSS14, L.VVSSS16, L.VVSSS17, L.VVSSS21, L.VVSSS24, L.VVSSS25, L.VVSSS26, L.VVSSS28, L.VVSSS29, L.VVSSS3, L.VVSSS30, L.VVSSS39, L.VVSSS40, L.VVSSS5, L.VVSSS50, L.VVSSS58, L.VVSSS59, L.VVSSS6, L.VVSSS60, L.VVSSS61, L.VVSSS62, L.VVSSS63, L.VVSSS64, L.VVSSS65, L.VVSSS66, L.VVSSS67, L.VVSSS68, L.VVSSS7, L.VVSSS8 ],
               couplings = {(0,31):C.GC_3307,(0,32):C.GC_6975,(0,17):C.GC_3305,(0,21):C.GC_6966,(0,5):C.GC_3306,(0,6):C.GC_6974,(0,7):C.GC_1942,(0,1):C.GC_3304,(0,2):C.GC_1931,(0,3):C.GC_6965,(0,4):C.GC_1938,(0,15):C.GC_2849,(0,16):C.GC_2439,(0,18):C.GC_2433,(0,8):C.GC_2843,(0,9):C.GC_2432,(0,11):C.GC_2432,(0,12):C.GC_2427,(0,22):C.GC_3285,(0,24):C.GC_3284,(0,27):C.GC_2846,(0,23):C.GC_6964,(0,25):C.GC_6962,(0,28):C.GC_2427,(0,19):C.GC_2878,(0,13):C.GC_6952,(0,0):C.GC_6947,(0,20):C.GC_6940,(0,10):C.GC_2890,(0,14):C.GC_2897,(0,26):C.GC_3546,(0,29):C.GC_2893,(0,30):C.GC_2893})

V_485 = Vertex(name = 'V_485',
               particles = [ P.W__minus__, P.Z, P.G0, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSS12, L.VVSSS14, L.VVSSS25, L.VVSSS29, L.VVSSS58 ],
               couplings = {(0,0):C.GC_2894,(0,1):C.GC_3546,(0,2):C.GC_3562,(0,3):C.GC_3553,(0,4):C.GC_3533})

V_486 = Vertex(name = 'V_486',
               particles = [ P.W__minus__, P.Z, P.G__minus__, P.G__plus__, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS1, L.VVSSSS10, L.VVSSSS100, L.VVSSSS101, L.VVSSSS102, L.VVSSSS103, L.VVSSSS104, L.VVSSSS105, L.VVSSSS106, L.VVSSSS11, L.VVSSSS12, L.VVSSSS14, L.VVSSSS15, L.VVSSSS19, L.VVSSSS21, L.VVSSSS22, L.VVSSSS23, L.VVSSSS24, L.VVSSSS25, L.VVSSSS26, L.VVSSSS28, L.VVSSSS29, L.VVSSSS3, L.VVSSSS32, L.VVSSSS34, L.VVSSSS35, L.VVSSSS36, L.VVSSSS37, L.VVSSSS38, L.VVSSSS39, L.VVSSSS40, L.VVSSSS41, L.VVSSSS5, L.VVSSSS56, L.VVSSSS57, L.VVSSSS6, L.VVSSSS7, L.VVSSSS74, L.VVSSSS75, L.VVSSSS8, L.VVSSSS9, L.VVSSSS91, L.VVSSSS92, L.VVSSSS93, L.VVSSSS94, L.VVSSSS95, L.VVSSSS96, L.VVSSSS97, L.VVSSSS98, L.VVSSSS99 ],
               couplings = {(0,22):C.GC_6910,(0,0):C.GC_6899,(0,41):C.GC_3487,(0,42):C.GC_6900,(0,1):C.GC_2511,(0,10):C.GC_2510,(0,15):C.GC_2511,(0,16):C.GC_3626,(0,18):C.GC_2510,(0,19):C.GC_3626,(0,25):C.GC_3631,(0,26):C.GC_1999,(0,27):C.GC_1999,(0,29):C.GC_3592,(0,30):C.GC_1996,(0,31):C.GC_1996,(0,47):C.GC_3632,(0,2):C.GC_3632,(0,6):C.GC_3608,(0,3):C.GC_3608,(0,7):C.GC_3591,(0,8):C.GC_3591,(0,36):C.GC_3473,(0,39):C.GC_2521,(0,32):C.GC_3437,(0,35):C.GC_2512,(0,11):C.GC_3410,(0,12):C.GC_7060,(0,13):C.GC_2519,(0,40):C.GC_3409,(0,9):C.GC_7045,(0,20):C.GC_3410,(0,21):C.GC_7060,(0,23):C.GC_2519,(0,14):C.GC_3409,(0,17):C.GC_7045,(0,33):C.GC_3472,(0,34):C.GC_7063,(0,37):C.GC_2004,(0,38):C.GC_2004,(0,24):C.GC_3442,(0,28):C.GC_7048,(0,43):C.GC_3440,(0,45):C.GC_3402,(0,48):C.GC_3402,(0,4):C.GC_3438,(0,44):C.GC_2513,(0,46):C.GC_7032,(0,49):C.GC_7032,(0,5):C.GC_7031})

V_487 = Vertex(name = 'V_487',
               particles = [ P.W__minus__, P.Z, P.G__minus__, P.G__plus__, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS10, L.VVSSSS12, L.VVSSSS22, L.VVSSSS25, L.VVSSSS36, L.VVSSSS37, L.VVSSSS40, L.VVSSSS41, L.VVSSSS91 ],
               couplings = {(0,8):C.GC_7165,(0,0):C.GC_3629,(0,1):C.GC_3609,(0,2):C.GC_3629,(0,3):C.GC_3609,(0,4):C.GC_3628,(0,5):C.GC_3628,(0,6):C.GC_3604,(0,7):C.GC_3604})

V_488 = Vertex(name = 'V_488',
               particles = [ P.W__minus__, P.Z, P.G0, P.G__plus__, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS1, L.VVSSSS10, L.VVSSSS100, L.VVSSSS101, L.VVSSSS102, L.VVSSSS103, L.VVSSSS104, L.VVSSSS105, L.VVSSSS106, L.VVSSSS11, L.VVSSSS12, L.VVSSSS14, L.VVSSSS15, L.VVSSSS19, L.VVSSSS21, L.VVSSSS22, L.VVSSSS23, L.VVSSSS24, L.VVSSSS25, L.VVSSSS26, L.VVSSSS28, L.VVSSSS29, L.VVSSSS3, L.VVSSSS32, L.VVSSSS34, L.VVSSSS35, L.VVSSSS36, L.VVSSSS37, L.VVSSSS38, L.VVSSSS39, L.VVSSSS40, L.VVSSSS41, L.VVSSSS5, L.VVSSSS56, L.VVSSSS57, L.VVSSSS6, L.VVSSSS60, L.VVSSSS7, L.VVSSSS73, L.VVSSSS75, L.VVSSSS8, L.VVSSSS9, L.VVSSSS91, L.VVSSSS92, L.VVSSSS93, L.VVSSSS94, L.VVSSSS95, L.VVSSSS96, L.VVSSSS97, L.VVSSSS98, L.VVSSSS99 ],
               couplings = {(0,22):C.GC_6912,(0,0):C.GC_6903,(0,42):C.GC_2883,(0,43):C.GC_6896,(0,1):C.GC_1994,(0,10):C.GC_2001,(0,15):C.GC_2514,(0,16):C.GC_2937,(0,18):C.GC_2509,(0,19):C.GC_2945,(0,25):C.GC_2514,(0,26):C.GC_2937,(0,27):C.GC_3623,(0,29):C.GC_2509,(0,30):C.GC_2945,(0,31):C.GC_3623,(0,48):C.GC_3599,(0,2):C.GC_2940,(0,6):C.GC_2940,(0,3):C.GC_2940,(0,7):C.GC_2940,(0,8):C.GC_3619,(0,37):C.GC_3462,(0,40):C.GC_7054,(0,32):C.GC_3451,(0,35):C.GC_7039,(0,11):C.GC_3461,(0,12):C.GC_7053,(0,13):C.GC_2007,(0,41):C.GC_3450,(0,9):C.GC_7038,(0,20):C.GC_2874,(0,21):C.GC_2524,(0,23):C.GC_2516,(0,14):C.GC_2868,(0,17):C.GC_2514,(0,33):C.GC_2874,(0,34):C.GC_2524,(0,36):C.GC_2523,(0,38):C.GC_2516,(0,39):C.GC_2523,(0,24):C.GC_2868,(0,28):C.GC_2514,(0,44):C.GC_3421,(0,46):C.GC_3419,(0,49):C.GC_2871,(0,4):C.GC_2871,(0,45):C.GC_7037,(0,47):C.GC_7035,(0,50):C.GC_2509,(0,5):C.GC_2509})

V_489 = Vertex(name = 'V_489',
               particles = [ P.W__minus__, P.Z, P.G0, P.G__plus__, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS10, L.VVSSSS12, L.VVSSSS22, L.VVSSSS25, L.VVSSSS35, L.VVSSSS39, L.VVSSSS91 ],
               couplings = {(0,6):C.GC_3494,(0,0):C.GC_2941,(0,1):C.GC_3599,(0,2):C.GC_3637,(0,3):C.GC_3610,(0,4):C.GC_3637,(0,5):C.GC_3610})

V_490 = Vertex(name = 'V_490',
               particles = [ P.W__minus__, P.Z, P.G__plus__, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSS1, L.VVSSS11, L.VVSSS12, L.VVSSS13, L.VVSSS14, L.VVSSS16, L.VVSSS17, L.VVSSS21, L.VVSSS24, L.VVSSS25, L.VVSSS26, L.VVSSS28, L.VVSSS29, L.VVSSS3, L.VVSSS30, L.VVSSS39, L.VVSSS40, L.VVSSS42, L.VVSSS5, L.VVSSS50, L.VVSSS51, L.VVSSS58, L.VVSSS59, L.VVSSS6, L.VVSSS60, L.VVSSS61, L.VVSSS62, L.VVSSS63, L.VVSSS64, L.VVSSS65, L.VVSSS66, L.VVSSS67, L.VVSSS68, L.VVSSS7, L.VVSSS8 ],
               couplings = {(0,33):C.GC_3317,(0,34):C.GC_6979,(0,18):C.GC_3299,(0,23):C.GC_6971,(0,5):C.GC_3311,(0,6):C.GC_6977,(0,7):C.GC_1940,(0,1):C.GC_3295,(0,2):C.GC_1934,(0,3):C.GC_6969,(0,4):C.GC_1935,(0,15):C.GC_3311,(0,16):C.GC_6977,(0,17):C.GC_2434,(0,19):C.GC_1940,(0,20):C.GC_2434,(0,8):C.GC_3295,(0,9):C.GC_1934,(0,11):C.GC_6969,(0,12):C.GC_1935,(0,24):C.GC_3300,(0,26):C.GC_3289,(0,29):C.GC_3289,(0,25):C.GC_6958,(0,27):C.GC_6961,(0,30):C.GC_6961,(0,21):C.GC_2877,(0,13):C.GC_6951,(0,0):C.GC_6945,(0,22):C.GC_6946,(0,10):C.GC_3550,(0,14):C.GC_3550,(0,28):C.GC_3548,(0,31):C.GC_3548,(0,32):C.GC_3560})

V_491 = Vertex(name = 'V_491',
               particles = [ P.W__minus__, P.Z, P.G__plus__, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSS12, L.VVSSS25, L.VVSSS58 ],
               couplings = {(0,0):C.GC_3549,(0,1):C.GC_3549,(0,2):C.GC_3535})

V_492 = Vertex(name = 'V_492',
               particles = [ P.W__minus__, P.Z, P.G__plus__, P.H, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS1, L.VVSSSS10, L.VVSSSS100, L.VVSSSS101, L.VVSSSS102, L.VVSSSS103, L.VVSSSS104, L.VVSSSS105, L.VVSSSS106, L.VVSSSS11, L.VVSSSS12, L.VVSSSS14, L.VVSSSS15, L.VVSSSS19, L.VVSSSS21, L.VVSSSS22, L.VVSSSS23, L.VVSSSS24, L.VVSSSS25, L.VVSSSS26, L.VVSSSS28, L.VVSSSS29, L.VVSSSS3, L.VVSSSS31, L.VVSSSS32, L.VVSSSS33, L.VVSSSS34, L.VVSSSS35, L.VVSSSS36, L.VVSSSS37, L.VVSSSS38, L.VVSSSS39, L.VVSSSS40, L.VVSSSS41, L.VVSSSS5, L.VVSSSS56, L.VVSSSS57, L.VVSSSS59, L.VVSSSS6, L.VVSSSS60, L.VVSSSS7, L.VVSSSS73, L.VVSSSS74, L.VVSSSS75, L.VVSSSS8, L.VVSSSS9, L.VVSSSS91, L.VVSSSS92, L.VVSSSS93, L.VVSSSS94, L.VVSSSS95, L.VVSSSS96, L.VVSSSS97, L.VVSSSS98, L.VVSSSS99 ],
               couplings = {(0,22):C.GC_6911,(0,0):C.GC_6901,(0,46):C.GC_2882,(0,47):C.GC_6902,(0,1):C.GC_1997,(0,15):C.GC_1997,(0,16):C.GC_3607,(0,19):C.GC_3607,(0,27):C.GC_1997,(0,28):C.GC_3607,(0,29):C.GC_3607,(0,32):C.GC_3607,(0,33):C.GC_3607,(0,52):C.GC_3603,(0,2):C.GC_3603,(0,6):C.GC_3603,(0,3):C.GC_3633,(0,7):C.GC_3633,(0,8):C.GC_3633,(0,40):C.GC_3476,(0,44):C.GC_7064,(0,34):C.GC_3444,(0,38):C.GC_7049,(0,11):C.GC_3466,(0,12):C.GC_7061,(0,13):C.GC_2005,(0,45):C.GC_3436,(0,9):C.GC_7046,(0,10):C.GC_1998,(0,20):C.GC_3466,(0,21):C.GC_7061,(0,23):C.GC_2518,(0,24):C.GC_2005,(0,25):C.GC_2518,(0,14):C.GC_3436,(0,17):C.GC_7046,(0,18):C.GC_1998,(0,35):C.GC_3466,(0,36):C.GC_7061,(0,37):C.GC_2518,(0,39):C.GC_2518,(0,41):C.GC_2005,(0,42):C.GC_2518,(0,43):C.GC_2518,(0,26):C.GC_3436,(0,30):C.GC_7046,(0,31):C.GC_1998,(0,48):C.GC_3445,(0,50):C.GC_3426,(0,53):C.GC_3426,(0,4):C.GC_3426,(0,49):C.GC_7030,(0,51):C.GC_7034,(0,54):C.GC_7034,(0,5):C.GC_7034})

V_493 = Vertex(name = 'V_493',
               particles = [ P.W__minus__, P.Z, P.G__plus__, P.H, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS10, L.VVSSSS22, L.VVSSSS35, L.VVSSSS91 ],
               couplings = {(0,3):C.GC_3496,(0,0):C.GC_3605,(0,1):C.GC_3605,(0,2):C.GC_3605})

V_494 = Vertex(name = 'V_494',
               particles = [ P.W__plus__, P.Z, P.G0, P.G0, P.G0, P.G__minus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS1, L.VVSSSS10, L.VVSSSS100, L.VVSSSS101, L.VVSSSS102, L.VVSSSS103, L.VVSSSS104, L.VVSSSS105, L.VVSSSS106, L.VVSSSS11, L.VVSSSS12, L.VVSSSS14, L.VVSSSS15, L.VVSSSS16, L.VVSSSS19, L.VVSSSS21, L.VVSSSS22, L.VVSSSS23, L.VVSSSS24, L.VVSSSS25, L.VVSSSS26, L.VVSSSS28, L.VVSSSS29, L.VVSSSS3, L.VVSSSS30, L.VVSSSS31, L.VVSSSS32, L.VVSSSS33, L.VVSSSS34, L.VVSSSS35, L.VVSSSS36, L.VVSSSS37, L.VVSSSS38, L.VVSSSS39, L.VVSSSS40, L.VVSSSS41, L.VVSSSS5, L.VVSSSS56, L.VVSSSS57, L.VVSSSS6, L.VVSSSS7, L.VVSSSS73, L.VVSSSS74, L.VVSSSS75, L.VVSSSS8, L.VVSSSS9, L.VVSSSS91, L.VVSSSS92, L.VVSSSS93, L.VVSSSS94, L.VVSSSS95, L.VVSSSS96, L.VVSSSS97, L.VVSSSS98, L.VVSSSS99 ],
               couplings = {(0,23):C.GC_6906,(0,0):C.GC_6894,(0,46):C.GC_2879,(0,47):C.GC_6905,(0,1):C.GC_3614,(0,10):C.GC_3614,(0,16):C.GC_3614,(0,17):C.GC_3614,(0,19):C.GC_3614,(0,20):C.GC_3614,(0,33):C.GC_2000,(0,34):C.GC_2000,(0,35):C.GC_2000,(0,52):C.GC_3642,(0,2):C.GC_3642,(0,6):C.GC_3600,(0,3):C.GC_3642,(0,7):C.GC_3600,(0,8):C.GC_3600,(0,40):C.GC_3478,(0,44):C.GC_7052,(0,36):C.GC_3420,(0,39):C.GC_7037,(0,11):C.GC_3478,(0,12):C.GC_7052,(0,13):C.GC_2517,(0,14):C.GC_2517,(0,45):C.GC_3420,(0,9):C.GC_7037,(0,21):C.GC_3478,(0,22):C.GC_7052,(0,24):C.GC_2517,(0,25):C.GC_2517,(0,26):C.GC_2517,(0,27):C.GC_2517,(0,15):C.GC_3420,(0,18):C.GC_7037,(0,37):C.GC_3459,(0,38):C.GC_7058,(0,41):C.GC_2006,(0,42):C.GC_2006,(0,43):C.GC_2006,(0,28):C.GC_3456,(0,29):C.GC_1995,(0,30):C.GC_1995,(0,31):C.GC_1995,(0,32):C.GC_7043,(0,48):C.GC_3452,(0,50):C.GC_3452,(0,53):C.GC_3452,(0,4):C.GC_3415,(0,49):C.GC_7039,(0,51):C.GC_7039,(0,54):C.GC_7039,(0,5):C.GC_7044})

V_495 = Vertex(name = 'V_495',
               particles = [ P.W__plus__, P.Z, P.G0, P.G0, P.G0, P.G__minus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS39, L.VVSSSS40, L.VVSSSS41, L.VVSSSS91 ],
               couplings = {(0,3):C.GC_3498,(0,0):C.GC_3612,(0,1):C.GC_3612,(0,2):C.GC_3612})

V_496 = Vertex(name = 'V_496',
               particles = [ P.W__plus__, P.Z, P.G__minus__ ],
               color = [ '1' ],
               lorentz = [ L.VVS1, L.VVS11, L.VVS12, L.VVS13, L.VVS14, L.VVS3, L.VVS5, L.VVS6, L.VVS7, L.VVS8 ],
               couplings = {(0,8):C.GC_3331,(0,9):C.GC_5740,(0,6):C.GC_3330,(0,7):C.GC_5739,(0,3):C.GC_3327,(0,4):C.GC_5738,(0,1):C.GC_3481,(0,5):C.GC_5670,(0,0):C.GC_5668,(0,2):C.GC_5669})

V_497 = Vertex(name = 'V_497',
               particles = [ P.W__plus__, P.Z, P.G__minus__ ],
               color = [ '1' ],
               lorentz = [ L.VVS1, L.VVS11, L.VVS12, L.VVS3 ],
               couplings = {(0,1):C.GC_5841,(0,3):C.GC_5624,(0,0):C.GC_5622,(0,2):C.GC_5623})

V_498 = Vertex(name = 'V_498',
               particles = [ P.W__plus__, P.Z, P.G__minus__ ],
               color = [ '1' ],
               lorentz = [ L.VVS11 ],
               couplings = {(0,0):C.GC_5848})

V_499 = Vertex(name = 'V_499',
               particles = [ P.W__plus__, P.Z, P.G0, P.G__minus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSS1, L.VVSS10, L.VVSS11, L.VVSS12, L.VVSS14, L.VVSS15, L.VVSS16, L.VVSS17, L.VVSS18, L.VVSS19, L.VVSS21, L.VVSS22, L.VVSS23, L.VVSS25, L.VVSS26, L.VVSS27, L.VVSS28, L.VVSS3, L.VVSS30, L.VVSS32, L.VVSS33, L.VVSS40, L.VVSS41, L.VVSS42, L.VVSS5, L.VVSS55, L.VVSS56, L.VVSS57, L.VVSS58, L.VVSS59, L.VVSS6, L.VVSS60, L.VVSS61, L.VVSS62, L.VVSS63, L.VVSS64, L.VVSS7, L.VVSS8, L.VVSS9 ],
               couplings = {(0,13):C.GC_1921,(0,15):C.GC_5660,(0,4):C.GC_1926,(0,1):C.GC_1946,(0,9):C.GC_5661,(0,6):C.GC_1951,(0,2):C.GC_5644,(0,7):C.GC_5647,(0,23):C.GC_1921,(0,8):C.GC_5656,(0,20):C.GC_1926,(0,14):C.GC_5659,(0,22):C.GC_5660,(0,3):C.GC_5659,(0,33):C.GC_5644,(0,19):C.GC_5661,(0,12):C.GC_5656,(0,34):C.GC_5647,(0,32):C.GC_3492,(0,17):C.GC_5683,(0,0):C.GC_5679,(0,25):C.GC_3482,(0,26):C.GC_5682,(0,36):C.GC_3360,(0,37):C.GC_5760,(0,24):C.GC_3354,(0,30):C.GC_5751,(0,10):C.GC_3359,(0,11):C.GC_5759,(0,21):C.GC_1955,(0,38):C.GC_3353,(0,5):C.GC_5750,(0,27):C.GC_3344,(0,29):C.GC_3343,(0,28):C.GC_5755,(0,31):C.GC_5753,(0,18):C.GC_5643,(0,16):C.GC_5640,(0,35):C.GC_5637})

V_500 = Vertex(name = 'V_500',
               particles = [ P.W__plus__, P.Z, P.G0, P.G__minus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSS1, L.VVSS10, L.VVSS16, L.VVSS3, L.VVSS55, L.VVSS56 ],
               couplings = {(0,1):C.GC_2886,(0,2):C.GC_3492,(0,3):C.GC_5619,(0,0):C.GC_5615,(0,4):C.GC_5854,(0,5):C.GC_5618})

V_501 = Vertex(name = 'V_501',
               particles = [ P.W__plus__, P.Z, P.G0, P.G__minus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSS55 ],
               couplings = {(0,0):C.GC_5840})

V_502 = Vertex(name = 'V_502',
               particles = [ P.W__plus__, P.Z, P.G0, P.G0, P.G__minus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSSS1, L.VVSSS11, L.VVSSS12, L.VVSSS13, L.VVSSS14, L.VVSSS16, L.VVSSS17, L.VVSSS18, L.VVSSS21, L.VVSSS24, L.VVSSS25, L.VVSSS26, L.VVSSS28, L.VVSSS29, L.VVSSS3, L.VVSSS30, L.VVSSS39, L.VVSSS40, L.VVSSS5, L.VVSSS58, L.VVSSS59, L.VVSSS6, L.VVSSS60, L.VVSSS61, L.VVSSS62, L.VVSSS63, L.VVSSS64, L.VVSSS65, L.VVSSS66, L.VVSSS67, L.VVSSS68, L.VVSSS7, L.VVSSS8 ],
               couplings = {(0,31):C.GC_2848,(0,32):C.GC_2436,(0,18):C.GC_2844,(0,21):C.GC_2429,(0,5):C.GC_2848,(0,6):C.GC_2436,(0,7):C.GC_2434,(0,8):C.GC_2434,(0,1):C.GC_2844,(0,3):C.GC_2429,(0,16):C.GC_3310,(0,17):C.GC_6976,(0,9):C.GC_3294,(0,12):C.GC_6968,(0,22):C.GC_2845,(0,24):C.GC_2845,(0,27):C.GC_3288,(0,23):C.GC_2428,(0,25):C.GC_2428,(0,28):C.GC_6959,(0,19):C.GC_2876,(0,14):C.GC_6949,(0,0):C.GC_6941,(0,20):C.GC_6942,(0,2):C.GC_3558,(0,4):C.GC_3558,(0,10):C.GC_2896,(0,11):C.GC_2896,(0,13):C.GC_2889,(0,15):C.GC_2889,(0,26):C.GC_3561,(0,29):C.GC_2892,(0,30):C.GC_2892})

V_503 = Vertex(name = 'V_503',
               particles = [ P.W__plus__, P.Z, P.G0, P.G0, P.G__minus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSSS58 ],
               couplings = {(0,0):C.GC_3534})

V_504 = Vertex(name = 'V_504',
               particles = [ P.W__plus__, P.Z, P.G0, P.G__minus__, P.G__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS1, L.VVSSSS10, L.VVSSSS100, L.VVSSSS101, L.VVSSSS102, L.VVSSSS103, L.VVSSSS104, L.VVSSSS105, L.VVSSSS106, L.VVSSSS11, L.VVSSSS12, L.VVSSSS14, L.VVSSSS15, L.VVSSSS19, L.VVSSSS21, L.VVSSSS22, L.VVSSSS23, L.VVSSSS24, L.VVSSSS25, L.VVSSSS26, L.VVSSSS28, L.VVSSSS29, L.VVSSSS3, L.VVSSSS32, L.VVSSSS34, L.VVSSSS35, L.VVSSSS36, L.VVSSSS37, L.VVSSSS38, L.VVSSSS39, L.VVSSSS40, L.VVSSSS41, L.VVSSSS5, L.VVSSSS56, L.VVSSSS57, L.VVSSSS6, L.VVSSSS7, L.VVSSSS74, L.VVSSSS75, L.VVSSSS8, L.VVSSSS9, L.VVSSSS91, L.VVSSSS92, L.VVSSSS93, L.VVSSSS94, L.VVSSSS95, L.VVSSSS96, L.VVSSSS97, L.VVSSSS98, L.VVSSSS99 ],
               couplings = {(0,22):C.GC_6907,(0,0):C.GC_6895,(0,41):C.GC_3486,(0,42):C.GC_6904,(0,1):C.GC_2001,(0,10):C.GC_1994,(0,15):C.GC_2001,(0,16):C.GC_3622,(0,18):C.GC_1994,(0,19):C.GC_3622,(0,25):C.GC_3589,(0,26):C.GC_2514,(0,27):C.GC_2514,(0,29):C.GC_3617,(0,30):C.GC_2509,(0,31):C.GC_2509,(0,47):C.GC_3593,(0,2):C.GC_3593,(0,6):C.GC_3595,(0,3):C.GC_3595,(0,7):C.GC_3641,(0,8):C.GC_3641,(0,36):C.GC_3480,(0,39):C.GC_7056,(0,32):C.GC_3417,(0,35):C.GC_7041,(0,11):C.GC_3413,(0,12):C.GC_7050,(0,13):C.GC_2002,(0,40):C.GC_3404,(0,9):C.GC_7035,(0,20):C.GC_3413,(0,21):C.GC_7050,(0,23):C.GC_2002,(0,14):C.GC_3404,(0,17):C.GC_7035,(0,33):C.GC_3460,(0,34):C.GC_2525,(0,37):C.GC_2516,(0,38):C.GC_2516,(0,24):C.GC_3453,(0,28):C.GC_2515,(0,43):C.GC_3455,(0,45):C.GC_3407,(0,48):C.GC_3407,(0,4):C.GC_3416,(0,44):C.GC_7042,(0,46):C.GC_7038,(0,49):C.GC_7038,(0,5):C.GC_2508})

V_505 = Vertex(name = 'V_505',
               particles = [ P.W__plus__, P.Z, P.G0, P.G__minus__, P.G__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS10, L.VVSSSS12, L.VVSSSS22, L.VVSSSS25, L.VVSSSS36, L.VVSSSS37, L.VVSSSS40, L.VVSSSS41, L.VVSSSS91 ],
               couplings = {(0,8):C.GC_7166,(0,0):C.GC_3611,(0,1):C.GC_3635,(0,2):C.GC_3611,(0,3):C.GC_3635,(0,4):C.GC_3616,(0,5):C.GC_3616,(0,6):C.GC_3638,(0,7):C.GC_3638})

V_506 = Vertex(name = 'V_506',
               particles = [ P.W__plus__, P.Z, P.G__minus__, P.G__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSSS1, L.VVSSS11, L.VVSSS12, L.VVSSS13, L.VVSSS14, L.VVSSS16, L.VVSSS17, L.VVSSS24, L.VVSSS25, L.VVSSS26, L.VVSSS28, L.VVSSS29, L.VVSSS3, L.VVSSS30, L.VVSSS39, L.VVSSS40, L.VVSSS5, L.VVSSS50, L.VVSSS51, L.VVSSS58, L.VVSSS59, L.VVSSS6, L.VVSSS60, L.VVSSS61, L.VVSSS62, L.VVSSS63, L.VVSSS64, L.VVSSS65, L.VVSSS66, L.VVSSS67, L.VVSSS68, L.VVSSS7, L.VVSSS8 ],
               couplings = {(0,31):C.GC_3283,(0,32):C.GC_6976,(0,16):C.GC_3280,(0,21):C.GC_6968,(0,5):C.GC_3283,(0,6):C.GC_6976,(0,1):C.GC_3280,(0,3):C.GC_6968,(0,14):C.GC_3314,(0,15):C.GC_2438,(0,17):C.GC_2435,(0,18):C.GC_2435,(0,7):C.GC_3297,(0,8):C.GC_2429,(0,9):C.GC_2429,(0,10):C.GC_2431,(0,11):C.GC_2428,(0,13):C.GC_2428,(0,22):C.GC_3279,(0,24):C.GC_3279,(0,27):C.GC_3296,(0,23):C.GC_6959,(0,25):C.GC_6959,(0,28):C.GC_2430,(0,19):C.GC_3485,(0,12):C.GC_6950,(0,0):C.GC_6943,(0,20):C.GC_6944,(0,2):C.GC_3556,(0,4):C.GC_3556,(0,26):C.GC_3551,(0,29):C.GC_3559,(0,30):C.GC_3559})

V_507 = Vertex(name = 'V_507',
               particles = [ P.W__plus__, P.Z, P.G__minus__, P.G__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSSS25, L.VVSSS26, L.VVSSS29, L.VVSSS30, L.VVSSS58 ],
               couplings = {(0,0):C.GC_3552,(0,1):C.GC_3552,(0,2):C.GC_3557,(0,3):C.GC_3557,(0,4):C.GC_7173})

V_508 = Vertex(name = 'V_508',
               particles = [ P.W__plus__, P.Z, P.G0, P.G0, P.G__minus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS1, L.VVSSSS10, L.VVSSSS100, L.VVSSSS101, L.VVSSSS102, L.VVSSSS103, L.VVSSSS104, L.VVSSSS105, L.VVSSSS106, L.VVSSSS11, L.VVSSSS12, L.VVSSSS14, L.VVSSSS15, L.VVSSSS16, L.VVSSSS19, L.VVSSSS21, L.VVSSSS22, L.VVSSSS23, L.VVSSSS24, L.VVSSSS25, L.VVSSSS26, L.VVSSSS28, L.VVSSSS29, L.VVSSSS3, L.VVSSSS34, L.VVSSSS35, L.VVSSSS36, L.VVSSSS37, L.VVSSSS38, L.VVSSSS39, L.VVSSSS40, L.VVSSSS41, L.VVSSSS5, L.VVSSSS56, L.VVSSSS57, L.VVSSSS6, L.VVSSSS7, L.VVSSSS73, L.VVSSSS74, L.VVSSSS75, L.VVSSSS8, L.VVSSSS9, L.VVSSSS91, L.VVSSSS92, L.VVSSSS93, L.VVSSSS94, L.VVSSSS95, L.VVSSSS96, L.VVSSSS97, L.VVSSSS98, L.VVSSSS99 ],
               couplings = {(0,23):C.GC_6909,(0,0):C.GC_6897,(0,42):C.GC_2881,(0,43):C.GC_6898,(0,1):C.GC_3630,(0,10):C.GC_3630,(0,16):C.GC_2943,(0,17):C.GC_2943,(0,19):C.GC_2936,(0,20):C.GC_2936,(0,25):C.GC_2510,(0,26):C.GC_2510,(0,27):C.GC_1999,(0,29):C.GC_2511,(0,30):C.GC_2511,(0,31):C.GC_1996,(0,48):C.GC_3634,(0,2):C.GC_2939,(0,6):C.GC_2939,(0,3):C.GC_2939,(0,7):C.GC_2939,(0,8):C.GC_3606,(0,36):C.GC_2873,(0,40):C.GC_2520,(0,32):C.GC_2869,(0,35):C.GC_2511,(0,11):C.GC_2873,(0,12):C.GC_2520,(0,13):C.GC_2518,(0,14):C.GC_2518,(0,41):C.GC_2869,(0,9):C.GC_2511,(0,21):C.GC_3465,(0,22):C.GC_7060,(0,15):C.GC_3434,(0,18):C.GC_7045,(0,33):C.GC_3467,(0,34):C.GC_7061,(0,37):C.GC_2520,(0,38):C.GC_2520,(0,39):C.GC_2004,(0,24):C.GC_3435,(0,28):C.GC_7046,(0,44):C.GC_2870,(0,46):C.GC_2870,(0,49):C.GC_3425,(0,4):C.GC_3427,(0,45):C.GC_2510,(0,47):C.GC_2510,(0,50):C.GC_7032,(0,5):C.GC_7034})

V_509 = Vertex(name = 'V_509',
               particles = [ P.W__plus__, P.Z, P.G0, P.G0, P.G__minus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS35, L.VVSSSS36, L.VVSSSS37, L.VVSSSS39, L.VVSSSS40, L.VVSSSS41, L.VVSSSS91 ],
               couplings = {(0,6):C.GC_3495,(0,0):C.GC_3602,(0,1):C.GC_3602,(0,2):C.GC_3606,(0,3):C.GC_3627,(0,4):C.GC_3627,(0,5):C.GC_2944})

V_510 = Vertex(name = 'V_510',
               particles = [ P.W__plus__, P.Z, P.G__minus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSS1, L.VVSS10, L.VVSS11, L.VVSS12, L.VVSS14, L.VVSS15, L.VVSS16, L.VVSS17, L.VVSS18, L.VVSS19, L.VVSS21, L.VVSS22, L.VVSS23, L.VVSS25, L.VVSS26, L.VVSS27, L.VVSS28, L.VVSS3, L.VVSS30, L.VVSS32, L.VVSS33, L.VVSS40, L.VVSS41, L.VVSS42, L.VVSS5, L.VVSS55, L.VVSS56, L.VVSS57, L.VVSS58, L.VVSS59, L.VVSS6, L.VVSS60, L.VVSS61, L.VVSS62, L.VVSS63, L.VVSS64, L.VVSS7, L.VVSS8, L.VVSS9 ],
               couplings = {(0,13):C.GC_1924,(0,15):C.GC_5663,(0,4):C.GC_1922,(0,1):C.GC_1950,(0,9):C.GC_5664,(0,25):C.GC_3483,(0,2):C.GC_5649,(0,7):C.GC_5650,(0,23):C.GC_1924,(0,8):C.GC_5653,(0,20):C.GC_1922,(0,14):C.GC_5654,(0,22):C.GC_5663,(0,3):C.GC_5654,(0,33):C.GC_5649,(0,19):C.GC_5664,(0,12):C.GC_5653,(0,34):C.GC_5650,(0,32):C.GC_3490,(0,17):C.GC_5684,(0,0):C.GC_5680,(0,26):C.GC_5681,(0,36):C.GC_3363,(0,37):C.GC_5765,(0,24):C.GC_3352,(0,30):C.GC_5758,(0,10):C.GC_3362,(0,11):C.GC_5764,(0,21):C.GC_1953,(0,38):C.GC_3346,(0,5):C.GC_5757,(0,6):C.GC_1947,(0,27):C.GC_3349,(0,29):C.GC_3347,(0,28):C.GC_5747,(0,31):C.GC_5748,(0,18):C.GC_5642,(0,16):C.GC_5639,(0,35):C.GC_5638})

V_511 = Vertex(name = 'V_511',
               particles = [ P.W__plus__, P.Z, P.G__minus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSS1, L.VVSS10, L.VVSS3, L.VVSS55, L.VVSS56 ],
               couplings = {(0,1):C.GC_3491,(0,3):C.GC_5839,(0,2):C.GC_5620,(0,0):C.GC_5616,(0,4):C.GC_5617})

V_512 = Vertex(name = 'V_512',
               particles = [ P.W__plus__, P.Z, P.G__minus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSS55 ],
               couplings = {(0,0):C.GC_5853})

V_513 = Vertex(name = 'V_513',
               particles = [ P.W__plus__, P.Z, P.G0, P.G__minus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSS1, L.VVSSS11, L.VVSSS12, L.VVSSS13, L.VVSSS14, L.VVSSS16, L.VVSSS17, L.VVSSS21, L.VVSSS24, L.VVSSS25, L.VVSSS26, L.VVSSS28, L.VVSSS29, L.VVSSS3, L.VVSSS30, L.VVSSS39, L.VVSSS40, L.VVSSS5, L.VVSSS50, L.VVSSS58, L.VVSSS59, L.VVSSS6, L.VVSSS60, L.VVSSS61, L.VVSSS62, L.VVSSS63, L.VVSSS64, L.VVSSS65, L.VVSSS66, L.VVSSS67, L.VVSSS68, L.VVSSS7, L.VVSSS8 ],
               couplings = {(0,31):C.GC_3309,(0,32):C.GC_6973,(0,17):C.GC_3303,(0,21):C.GC_6963,(0,5):C.GC_3308,(0,6):C.GC_6972,(0,7):C.GC_1941,(0,1):C.GC_3302,(0,2):C.GC_1932,(0,3):C.GC_6962,(0,4):C.GC_1937,(0,15):C.GC_2849,(0,16):C.GC_2439,(0,18):C.GC_2433,(0,8):C.GC_2843,(0,9):C.GC_2432,(0,11):C.GC_2432,(0,12):C.GC_2427,(0,22):C.GC_3287,(0,24):C.GC_3286,(0,27):C.GC_2846,(0,23):C.GC_6967,(0,25):C.GC_6965,(0,28):C.GC_2427,(0,19):C.GC_2875,(0,13):C.GC_6948,(0,0):C.GC_6940,(0,20):C.GC_6947,(0,10):C.GC_2888,(0,14):C.GC_2895,(0,26):C.GC_3554,(0,29):C.GC_2891,(0,30):C.GC_2891})

V_514 = Vertex(name = 'V_514',
               particles = [ P.W__plus__, P.Z, P.G0, P.G__minus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSS12, L.VVSSS14, L.VVSSS25, L.VVSSS29, L.VVSSS58 ],
               couplings = {(0,0):C.GC_2898,(0,1):C.GC_3554,(0,2):C.GC_3555,(0,3):C.GC_3547,(0,4):C.GC_3536})

V_515 = Vertex(name = 'V_515',
               particles = [ P.W__plus__, P.Z, P.G__minus__, P.G__minus__, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS1, L.VVSSSS10, L.VVSSSS100, L.VVSSSS101, L.VVSSSS102, L.VVSSSS103, L.VVSSSS104, L.VVSSSS105, L.VVSSSS106, L.VVSSSS11, L.VVSSSS12, L.VVSSSS14, L.VVSSSS15, L.VVSSSS21, L.VVSSSS22, L.VVSSSS23, L.VVSSSS24, L.VVSSSS25, L.VVSSSS26, L.VVSSSS28, L.VVSSSS29, L.VVSSSS3, L.VVSSSS32, L.VVSSSS33, L.VVSSSS34, L.VVSSSS35, L.VVSSSS36, L.VVSSSS37, L.VVSSSS38, L.VVSSSS39, L.VVSSSS40, L.VVSSSS41, L.VVSSSS5, L.VVSSSS56, L.VVSSSS57, L.VVSSSS6, L.VVSSSS7, L.VVSSSS73, L.VVSSSS74, L.VVSSSS8, L.VVSSSS9, L.VVSSSS91, L.VVSSSS92, L.VVSSSS93, L.VVSSSS94, L.VVSSSS95, L.VVSSSS96, L.VVSSSS97, L.VVSSSS98, L.VVSSSS99 ],
               couplings = {(0,21):C.GC_6910,(0,0):C.GC_6899,(0,41):C.GC_3487,(0,42):C.GC_6900,(0,1):C.GC_3626,(0,10):C.GC_3626,(0,14):C.GC_2511,(0,15):C.GC_2511,(0,17):C.GC_2510,(0,18):C.GC_2510,(0,25):C.GC_1997,(0,26):C.GC_1997,(0,27):C.GC_3631,(0,29):C.GC_1998,(0,30):C.GC_1998,(0,31):C.GC_3592,(0,47):C.GC_3608,(0,2):C.GC_3632,(0,6):C.GC_3591,(0,3):C.GC_3632,(0,7):C.GC_3591,(0,8):C.GC_3608,(0,36):C.GC_3411,(0,39):C.GC_7060,(0,32):C.GC_3408,(0,35):C.GC_7045,(0,11):C.GC_3411,(0,12):C.GC_7060,(0,40):C.GC_3408,(0,9):C.GC_7045,(0,19):C.GC_3471,(0,20):C.GC_2522,(0,22):C.GC_2519,(0,23):C.GC_2519,(0,13):C.GC_3440,(0,16):C.GC_2513,(0,33):C.GC_3474,(0,34):C.GC_7063,(0,37):C.GC_2005,(0,38):C.GC_2005,(0,24):C.GC_3439,(0,28):C.GC_7048,(0,43):C.GC_3403,(0,45):C.GC_3403,(0,48):C.GC_3437,(0,4):C.GC_3441,(0,44):C.GC_7032,(0,46):C.GC_7032,(0,49):C.GC_2512,(0,5):C.GC_7031})

V_516 = Vertex(name = 'V_516',
               particles = [ P.W__plus__, P.Z, P.G__minus__, P.G__minus__, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS22, L.VVSSSS23, L.VVSSSS25, L.VVSSSS26, L.VVSSSS35, L.VVSSSS36, L.VVSSSS39, L.VVSSSS40, L.VVSSSS91 ],
               couplings = {(0,8):C.GC_7165,(0,0):C.GC_3609,(0,1):C.GC_3609,(0,2):C.GC_3629,(0,3):C.GC_3629,(0,4):C.GC_3628,(0,5):C.GC_3628,(0,6):C.GC_3604,(0,7):C.GC_3604})

V_517 = Vertex(name = 'V_517',
               particles = [ P.W__plus__, P.Z, P.G0, P.G__minus__, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS1, L.VVSSSS10, L.VVSSSS100, L.VVSSSS101, L.VVSSSS102, L.VVSSSS103, L.VVSSSS104, L.VVSSSS105, L.VVSSSS106, L.VVSSSS11, L.VVSSSS12, L.VVSSSS14, L.VVSSSS15, L.VVSSSS19, L.VVSSSS21, L.VVSSSS22, L.VVSSSS23, L.VVSSSS24, L.VVSSSS25, L.VVSSSS26, L.VVSSSS28, L.VVSSSS29, L.VVSSSS3, L.VVSSSS32, L.VVSSSS34, L.VVSSSS35, L.VVSSSS36, L.VVSSSS37, L.VVSSSS38, L.VVSSSS39, L.VVSSSS40, L.VVSSSS41, L.VVSSSS5, L.VVSSSS56, L.VVSSSS57, L.VVSSSS6, L.VVSSSS60, L.VVSSSS7, L.VVSSSS73, L.VVSSSS75, L.VVSSSS8, L.VVSSSS9, L.VVSSSS91, L.VVSSSS92, L.VVSSSS93, L.VVSSSS94, L.VVSSSS95, L.VVSSSS96, L.VVSSSS97, L.VVSSSS98, L.VVSSSS99 ],
               couplings = {(0,22):C.GC_6908,(0,0):C.GC_6896,(0,42):C.GC_2880,(0,43):C.GC_6903,(0,1):C.GC_1995,(0,10):C.GC_2000,(0,15):C.GC_2514,(0,16):C.GC_2935,(0,18):C.GC_2509,(0,19):C.GC_2942,(0,25):C.GC_2514,(0,26):C.GC_2935,(0,27):C.GC_3639,(0,29):C.GC_2509,(0,30):C.GC_2942,(0,31):C.GC_3639,(0,48):C.GC_3613,(0,2):C.GC_2938,(0,6):C.GC_2938,(0,3):C.GC_2938,(0,7):C.GC_2938,(0,8):C.GC_3643,(0,37):C.GC_3464,(0,40):C.GC_7051,(0,32):C.GC_3448,(0,35):C.GC_7036,(0,11):C.GC_3463,(0,12):C.GC_7050,(0,13):C.GC_2006,(0,41):C.GC_3447,(0,9):C.GC_7035,(0,20):C.GC_2874,(0,21):C.GC_2524,(0,23):C.GC_2516,(0,14):C.GC_2868,(0,17):C.GC_2514,(0,33):C.GC_2874,(0,34):C.GC_2524,(0,36):C.GC_2517,(0,38):C.GC_2516,(0,39):C.GC_2517,(0,24):C.GC_2868,(0,28):C.GC_2514,(0,44):C.GC_3424,(0,46):C.GC_3422,(0,49):C.GC_2871,(0,4):C.GC_2871,(0,45):C.GC_7040,(0,47):C.GC_7038,(0,50):C.GC_2509,(0,5):C.GC_2509})

V_518 = Vertex(name = 'V_518',
               particles = [ P.W__plus__, P.Z, P.G0, P.G__minus__, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS10, L.VVSSSS12, L.VVSSSS22, L.VVSSSS25, L.VVSSSS35, L.VVSSSS39, L.VVSSSS91 ],
               couplings = {(0,6):C.GC_3497,(0,0):C.GC_2946,(0,1):C.GC_3613,(0,2):C.GC_3625,(0,3):C.GC_3601,(0,4):C.GC_3625,(0,5):C.GC_3601})

V_519 = Vertex(name = 'V_519',
               particles = [ P.W__plus__, P.Z, P.G__minus__, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSS1, L.VVSSS11, L.VVSSS12, L.VVSSS13, L.VVSSS14, L.VVSSS16, L.VVSSS17, L.VVSSS21, L.VVSSS24, L.VVSSS25, L.VVSSS26, L.VVSSS28, L.VVSSS29, L.VVSSS3, L.VVSSS30, L.VVSSS39, L.VVSSS40, L.VVSSS42, L.VVSSS5, L.VVSSS50, L.VVSSS51, L.VVSSS58, L.VVSSS59, L.VVSSS6, L.VVSSS60, L.VVSSS61, L.VVSSS62, L.VVSSS63, L.VVSSS64, L.VVSSS65, L.VVSSS66, L.VVSSS67, L.VVSSS68, L.VVSSS7, L.VVSSS8 ],
               couplings = {(0,33):C.GC_3316,(0,34):C.GC_6979,(0,18):C.GC_3301,(0,23):C.GC_6971,(0,5):C.GC_3313,(0,6):C.GC_6978,(0,7):C.GC_1939,(0,1):C.GC_3291,(0,2):C.GC_1936,(0,3):C.GC_6970,(0,4):C.GC_1933,(0,15):C.GC_3313,(0,16):C.GC_6978,(0,17):C.GC_2434,(0,19):C.GC_1939,(0,20):C.GC_2434,(0,8):C.GC_3291,(0,9):C.GC_1936,(0,11):C.GC_6970,(0,12):C.GC_1933,(0,24):C.GC_3298,(0,26):C.GC_3293,(0,29):C.GC_3293,(0,25):C.GC_6958,(0,27):C.GC_6960,(0,30):C.GC_6960,(0,21):C.GC_2877,(0,13):C.GC_6951,(0,0):C.GC_6945,(0,22):C.GC_6946,(0,10):C.GC_3550,(0,14):C.GC_3550,(0,28):C.GC_3548,(0,31):C.GC_3548,(0,32):C.GC_3560})

V_520 = Vertex(name = 'V_520',
               particles = [ P.W__plus__, P.Z, P.G__minus__, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSS12, L.VVSSS25, L.VVSSS58 ],
               couplings = {(0,0):C.GC_3549,(0,1):C.GC_3549,(0,2):C.GC_3535})

V_521 = Vertex(name = 'V_521',
               particles = [ P.W__plus__, P.Z, P.G__minus__, P.H, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS1, L.VVSSSS10, L.VVSSSS100, L.VVSSSS101, L.VVSSSS102, L.VVSSSS103, L.VVSSSS104, L.VVSSSS105, L.VVSSSS106, L.VVSSSS11, L.VVSSSS12, L.VVSSSS14, L.VVSSSS15, L.VVSSSS19, L.VVSSSS21, L.VVSSSS22, L.VVSSSS23, L.VVSSSS24, L.VVSSSS25, L.VVSSSS26, L.VVSSSS28, L.VVSSSS29, L.VVSSSS3, L.VVSSSS31, L.VVSSSS32, L.VVSSSS33, L.VVSSSS34, L.VVSSSS35, L.VVSSSS36, L.VVSSSS37, L.VVSSSS38, L.VVSSSS39, L.VVSSSS40, L.VVSSSS41, L.VVSSSS5, L.VVSSSS56, L.VVSSSS57, L.VVSSSS59, L.VVSSSS6, L.VVSSSS60, L.VVSSSS7, L.VVSSSS73, L.VVSSSS74, L.VVSSSS75, L.VVSSSS8, L.VVSSSS9, L.VVSSSS91, L.VVSSSS92, L.VVSSSS93, L.VVSSSS94, L.VVSSSS95, L.VVSSSS96, L.VVSSSS97, L.VVSSSS98, L.VVSSSS99 ],
               couplings = {(0,22):C.GC_6911,(0,0):C.GC_6901,(0,46):C.GC_2882,(0,47):C.GC_6902,(0,1):C.GC_1999,(0,15):C.GC_1999,(0,16):C.GC_3607,(0,19):C.GC_3607,(0,27):C.GC_1999,(0,28):C.GC_3607,(0,29):C.GC_3607,(0,32):C.GC_3607,(0,33):C.GC_3607,(0,52):C.GC_3603,(0,2):C.GC_3603,(0,6):C.GC_3603,(0,3):C.GC_3633,(0,7):C.GC_3633,(0,8):C.GC_3633,(0,40):C.GC_3475,(0,44):C.GC_7064,(0,34):C.GC_3446,(0,38):C.GC_7049,(0,11):C.GC_3470,(0,12):C.GC_7062,(0,13):C.GC_2004,(0,45):C.GC_3429,(0,9):C.GC_7047,(0,10):C.GC_1996,(0,20):C.GC_3470,(0,21):C.GC_7062,(0,23):C.GC_2518,(0,24):C.GC_2004,(0,25):C.GC_2518,(0,14):C.GC_3429,(0,17):C.GC_7047,(0,18):C.GC_1996,(0,35):C.GC_3470,(0,36):C.GC_7062,(0,37):C.GC_2518,(0,39):C.GC_2518,(0,41):C.GC_2004,(0,42):C.GC_2518,(0,43):C.GC_2518,(0,26):C.GC_3429,(0,30):C.GC_7047,(0,31):C.GC_1996,(0,48):C.GC_3443,(0,50):C.GC_3433,(0,53):C.GC_3433,(0,4):C.GC_3433,(0,49):C.GC_7030,(0,51):C.GC_7033,(0,54):C.GC_7033,(0,5):C.GC_7033})

V_522 = Vertex(name = 'V_522',
               particles = [ P.W__plus__, P.Z, P.G__minus__, P.H, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS10, L.VVSSSS22, L.VVSSSS35, L.VVSSSS91 ],
               couplings = {(0,3):C.GC_3496,(0,0):C.GC_3605,(0,1):C.GC_3605,(0,2):C.GC_3605})

V_523 = Vertex(name = 'V_523',
               particles = [ P.A, P.W__minus__, P.W__plus__, P.Z ],
               color = [ '1' ],
               lorentz = [ L.VVVV1, L.VVVV101, L.VVVV103, L.VVVV104, L.VVVV108, L.VVVV11, L.VVVV110, L.VVVV112, L.VVVV113, L.VVVV115, L.VVVV116, L.VVVV120, L.VVVV122, L.VVVV123, L.VVVV124, L.VVVV125, L.VVVV126, L.VVVV128, L.VVVV13, L.VVVV130, L.VVVV131, L.VVVV132, L.VVVV133, L.VVVV134, L.VVVV137, L.VVVV139, L.VVVV140, L.VVVV141, L.VVVV142, L.VVVV146, L.VVVV147, L.VVVV148, L.VVVV15, L.VVVV150, L.VVVV151, L.VVVV152, L.VVVV153, L.VVVV155, L.VVVV156, L.VVVV157, L.VVVV158, L.VVVV159, L.VVVV16, L.VVVV160, L.VVVV161, L.VVVV165, L.VVVV167, L.VVVV168, L.VVVV169, L.VVVV17, L.VVVV170, L.VVVV171, L.VVVV173, L.VVVV174, L.VVVV175, L.VVVV176, L.VVVV177, L.VVVV178, L.VVVV179, L.VVVV18, L.VVVV181, L.VVVV183, L.VVVV184, L.VVVV186, L.VVVV188, L.VVVV189, L.VVVV191, L.VVVV193, L.VVVV194, L.VVVV195, L.VVVV196, L.VVVV197, L.VVVV199, L.VVVV2, L.VVVV200, L.VVVV201, L.VVVV202, L.VVVV203, L.VVVV204, L.VVVV205, L.VVVV207, L.VVVV208, L.VVVV210, L.VVVV24, L.VVVV25, L.VVVV26, L.VVVV28, L.VVVV29, L.VVVV3, L.VVVV30, L.VVVV31, L.VVVV32, L.VVVV34, L.VVVV35, L.VVVV36, L.VVVV37, L.VVVV39, L.VVVV4, L.VVVV40, L.VVVV41, L.VVVV42, L.VVVV45, L.VVVV46, L.VVVV47, L.VVVV48, L.VVVV49, L.VVVV5, L.VVVV51, L.VVVV53, L.VVVV54, L.VVVV58, L.VVVV59, L.VVVV6, L.VVVV60, L.VVVV62, L.VVVV68, L.VVVV7, L.VVVV70, L.VVVV72, L.VVVV73, L.VVVV74, L.VVVV75, L.VVVV79, L.VVVV8, L.VVVV81, L.VVVV82, L.VVVV84, L.VVVV88, L.VVVV89, L.VVVV9, L.VVVV92, L.VVVV93, L.VVVV95, L.VVVV96, L.VVVV98, L.VVVV99 ],
               couplings = {(0,112):C.GC_5221,(0,116):C.GC_5225,(0,32):C.GC_5221,(0,49):C.GC_5221,(0,99):C.GC_1629,(0,100):C.GC_1627,(0,87):C.GC_1625,(0,93):C.GC_1626,(0,118):C.GC_5216,(0,119):C.GC_5214,(0,122):C.GC_5221,(0,121):C.GC_5216,(0,127):C.GC_1629,(0,124):C.GC_5236,(0,132):C.GC_5221,(0,131):C.GC_5216,(0,133):C.GC_5216,(0,134):C.GC_5214,(0,4):C.GC_1627,(0,1):C.GC_5235,(0,9):C.GC_5225,(0,8):C.GC_5214,(0,11):C.GC_5221,(0,10):C.GC_5214,(0,12):C.GC_5234,(0,14):C.GC_5233,(0,21):C.GC_5214,(0,23):C.GC_5214,(0,29):C.GC_5239,(0,25):C.GC_5238,(0,34):C.GC_5232,(0,41):C.GC_5216,(0,45):C.GC_807,(0,44):C.GC_805,(0,53):C.GC_1630,(0,46):C.GC_5235,(0,56):C.GC_5231,(0,64):C.GC_807,(0,63):C.GC_805,(0,65):C.GC_5216,(0,74):C.GC_1628,(0,67):C.GC_5236,(0,77):C.GC_5231,(0,35):C.GC_5216,(0,57):C.GC_5214,(0,78):C.GC_806,(0,36):C.GC_5216,(0,58):C.GC_806,(0,79):C.GC_5214,(0,37):C.GC_5237,(0,60):C.GC_5234,(0,80):C.GC_5233,(0,106):C.GC_5221,(0,73):C.GC_5225,(0,42):C.GC_5221,(0,129):C.GC_5221,(0,103):C.GC_5226,(0,108):C.GC_5222,(0,83):C.GC_5226,(0,85):C.GC_5222,(0,89):C.GC_5226,(0,91):C.GC_5226,(0,94):C.GC_5226,(0,98):C.GC_5226,(0,120):C.GC_5221,(0,135):C.GC_5221,(0,19):C.GC_5222,(0,20):C.GC_5226,(0,54):C.GC_5222,(0,55):C.GC_5222,(0,75):C.GC_5222,(0,76):C.GC_5222,(0,123):C.GC_5221,(0,59):C.GC_5225,(0,104):C.GC_5226,(0,109):C.GC_5222,(0,88):C.GC_5223,(0,97):C.GC_5227,(0,5):C.GC_5223,(0,18):C.GC_5223,(0,101):C.GC_5228,(0,102):C.GC_5228,(0,105):C.GC_5224,(0,107):C.GC_5228,(0,128):C.GC_5228,(0,125):C.GC_5217,(0,6):C.GC_5228,(0,2):C.GC_5217,(0,13):C.GC_5215,(0,15):C.GC_5215,(0,22):C.GC_5223,(0,24):C.GC_5223,(0,30):C.GC_5224,(0,31):C.GC_5224,(0,26):C.GC_5215,(0,27):C.GC_5215,(0,43):C.GC_5227,(0,47):C.GC_5217,(0,48):C.GC_5215,(0,50):C.GC_5217,(0,66):C.GC_5227,(0,68):C.GC_5217,(0,69):C.GC_5217,(0,70):C.GC_5215,(0,38):C.GC_5217,(0,81):C.GC_5215,(0,39):C.GC_5217,(0,61):C.GC_5215,(0,113):C.GC_5206,(0,114):C.GC_5197,(0,110):C.GC_5206,(0,111):C.GC_5203,(0,115):C.GC_5200,(0,117):C.GC_5200,(0,86):C.GC_5204,(0,84):C.GC_5196,(0,92):C.GC_5206,(0,90):C.GC_5199,(0,96):C.GC_5206,(0,95):C.GC_5199,(0,130):C.GC_5205,(0,126):C.GC_5198,(0,7):C.GC_5205,(0,3):C.GC_5198,(0,17):C.GC_5202,(0,16):C.GC_5195,(0,33):C.GC_5201,(0,28):C.GC_5195,(0,40):C.GC_5196,(0,52):C.GC_5205,(0,51):C.GC_5198,(0,62):C.GC_5199,(0,72):C.GC_5205,(0,71):C.GC_5198,(0,82):C.GC_5199,(0,0):C.GC_5374})

V_524 = Vertex(name = 'V_524',
               particles = [ P.A, P.W__minus__, P.W__plus__, P.Z ],
               color = [ '1' ],
               lorentz = [ L.VVVV103, L.VVVV11, L.VVVV110, L.VVVV113, L.VVVV115, L.VVVV116, L.VVVV120, L.VVVV123, L.VVVV125, L.VVVV13, L.VVVV130, L.VVVV131, L.VVVV132, L.VVVV133, L.VVVV134, L.VVVV137, L.VVVV140, L.VVVV141, L.VVVV147, L.VVVV148, L.VVVV15, L.VVVV151, L.VVVV152, L.VVVV153, L.VVVV156, L.VVVV157, L.VVVV159, L.VVVV16, L.VVVV160, L.VVVV168, L.VVVV169, L.VVVV17, L.VVVV170, L.VVVV175, L.VVVV176, L.VVVV177, L.VVVV178, L.VVVV18, L.VVVV183, L.VVVV189, L.VVVV191, L.VVVV194, L.VVVV195, L.VVVV196, L.VVVV2, L.VVVV201, L.VVVV202, L.VVVV203, L.VVVV205, L.VVVV208, L.VVVV24, L.VVVV26, L.VVVV3, L.VVVV30, L.VVVV32, L.VVVV36, L.VVVV4, L.VVVV40, L.VVVV45, L.VVVV46, L.VVVV47, L.VVVV48, L.VVVV49, L.VVVV5, L.VVVV51, L.VVVV53, L.VVVV54, L.VVVV6, L.VVVV7, L.VVVV72, L.VVVV73, L.VVVV74, L.VVVV75, L.VVVV79, L.VVVV8, L.VVVV82, L.VVVV89, L.VVVV9, L.VVVV93, L.VVVV95, L.VVVV96, L.VVVV98, L.VVVV99 ],
               couplings = {(0,67):C.GC_5369,(0,68):C.GC_5364,(0,20):C.GC_5366,(0,31):C.GC_5368,(0,69):C.GC_5357,(0,70):C.GC_5360,(0,73):C.GC_5366,(0,72):C.GC_5354,(0,79):C.GC_5369,(0,78):C.GC_5355,(0,80):C.GC_5356,(0,81):C.GC_5361,(0,4):C.GC_5364,(0,3):C.GC_5358,(0,6):C.GC_5368,(0,5):C.GC_5359,(0,12):C.GC_5358,(0,14):C.GC_5359,(0,21):C.GC_5241,(0,26):C.GC_5355,(0,35):C.GC_5240,(0,39):C.GC_5354,(0,47):C.GC_5240,(0,22):C.GC_5357,(0,36):C.GC_5360,(0,23):C.GC_5356,(0,48):C.GC_5361,(0,63):C.GC_5212,(0,44):C.GC_5213,(0,27):C.GC_5212,(0,77):C.GC_5212,(0,60):C.GC_5213,(0,65):C.GC_5212,(0,50):C.GC_5213,(0,51):C.GC_5212,(0,53):C.GC_5213,(0,54):C.GC_5213,(0,55):C.GC_5213,(0,57):C.GC_5213,(0,71):C.GC_5212,(0,82):C.GC_5212,(0,10):C.GC_5212,(0,11):C.GC_5213,(0,33):C.GC_5212,(0,34):C.GC_5212,(0,45):C.GC_5212,(0,46):C.GC_5212,(0,74):C.GC_5212,(0,37):C.GC_5213,(0,61):C.GC_5213,(0,66):C.GC_5212,(0,52):C.GC_5212,(0,56):C.GC_5213,(0,1):C.GC_5212,(0,9):C.GC_5212,(0,58):C.GC_5213,(0,59):C.GC_5213,(0,62):C.GC_5212,(0,64):C.GC_5213,(0,76):C.GC_5213,(0,75):C.GC_5211,(0,2):C.GC_5213,(0,0):C.GC_5211,(0,7):C.GC_5210,(0,8):C.GC_5210,(0,13):C.GC_5212,(0,15):C.GC_5212,(0,18):C.GC_5212,(0,19):C.GC_5212,(0,16):C.GC_5210,(0,17):C.GC_5210,(0,28):C.GC_5213,(0,29):C.GC_5211,(0,30):C.GC_5210,(0,32):C.GC_5211,(0,40):C.GC_5213,(0,41):C.GC_5211,(0,42):C.GC_5211,(0,43):C.GC_5210,(0,24):C.GC_5211,(0,49):C.GC_5210,(0,25):C.GC_5211,(0,38):C.GC_5210})

V_525 = Vertex(name = 'V_525',
               particles = [ P.A, P.W__minus__, P.W__plus__, P.Z ],
               color = [ '1' ],
               lorentz = [ L.VVVV11, L.VVVV113, L.VVVV115, L.VVVV116, L.VVVV120, L.VVVV13, L.VVVV132, L.VVVV133, L.VVVV134, L.VVVV137, L.VVVV15, L.VVVV151, L.VVVV152, L.VVVV153, L.VVVV159, L.VVVV160, L.VVVV17, L.VVVV177, L.VVVV178, L.VVVV189, L.VVVV191, L.VVVV203, L.VVVV205, L.VVVV3, L.VVVV4, L.VVVV6, L.VVVV7, L.VVVV72, L.VVVV73, L.VVVV75, L.VVVV79, L.VVVV93, L.VVVV95, L.VVVV96, L.VVVV98 ],
               couplings = {(0,25):C.GC_5212,(0,26):C.GC_5213,(0,10):C.GC_5212,(0,16):C.GC_5212,(0,27):C.GC_5211,(0,28):C.GC_5210,(0,30):C.GC_5212,(0,29):C.GC_5211,(0,32):C.GC_5212,(0,31):C.GC_5211,(0,33):C.GC_5211,(0,34):C.GC_5210,(0,2):C.GC_5213,(0,1):C.GC_5210,(0,4):C.GC_5212,(0,3):C.GC_5210,(0,6):C.GC_5210,(0,8):C.GC_5210,(0,11):C.GC_5230,(0,14):C.GC_5211,(0,17):C.GC_5229,(0,19):C.GC_5211,(0,21):C.GC_5229,(0,12):C.GC_5211,(0,18):C.GC_5210,(0,13):C.GC_5211,(0,22):C.GC_5210,(0,23):C.GC_5367,(0,24):C.GC_5363,(0,0):C.GC_5365,(0,5):C.GC_5367,(0,7):C.GC_5367,(0,9):C.GC_5365,(0,15):C.GC_5363,(0,20):C.GC_5362})

V_526 = Vertex(name = 'V_526',
               particles = [ P.A, P.W__minus__, P.W__plus__, P.Z ],
               color = [ '1' ],
               lorentz = [ L.VVVV151, L.VVVV177, L.VVVV203 ],
               couplings = {(0,0):C.GC_5371,(0,1):C.GC_5372,(0,2):C.GC_5373})

V_527 = Vertex(name = 'V_527',
               particles = [ P.Z, P.Z, P.G0, P.G0, P.G0, P.G0 ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS1, L.VVSSSS10, L.VVSSSS100, L.VVSSSS101, L.VVSSSS102, L.VVSSSS103, L.VVSSSS104, L.VVSSSS105, L.VVSSSS106, L.VVSSSS11, L.VVSSSS12, L.VVSSSS14, L.VVSSSS15, L.VVSSSS2, L.VVSSSS21, L.VVSSSS22, L.VVSSSS23, L.VVSSSS24, L.VVSSSS25, L.VVSSSS26, L.VVSSSS28, L.VVSSSS29, L.VVSSSS3, L.VVSSSS34, L.VVSSSS35, L.VVSSSS36, L.VVSSSS37, L.VVSSSS38, L.VVSSSS39, L.VVSSSS40, L.VVSSSS41, L.VVSSSS5, L.VVSSSS56, L.VVSSSS57, L.VVSSSS6, L.VVSSSS7, L.VVSSSS8, L.VVSSSS9, L.VVSSSS91, L.VVSSSS92, L.VVSSSS93, L.VVSSSS94, L.VVSSSS95, L.VVSSSS96, L.VVSSSS97, L.VVSSSS98, L.VVSSSS99 ],
               couplings = {(0,13):C.GC_6230,(0,22):C.GC_6231,(0,0):C.GC_6223,(0,38):C.GC_3088,(0,39):C.GC_6221,(0,1):C.GC_3107,(0,10):C.GC_3107,(0,15):C.GC_3107,(0,16):C.GC_3107,(0,18):C.GC_3107,(0,19):C.GC_3107,(0,24):C.GC_3107,(0,25):C.GC_3107,(0,26):C.GC_3107,(0,28):C.GC_3107,(0,29):C.GC_3107,(0,30):C.GC_3107,(0,44):C.GC_4998,(0,2):C.GC_4998,(0,6):C.GC_4998,(0,3):C.GC_4998,(0,7):C.GC_4998,(0,8):C.GC_4998,(0,35):C.GC_6020,(0,36):C.GC_6017,(0,31):C.GC_6013,(0,34):C.GC_6013,(0,11):C.GC_6020,(0,12):C.GC_6017,(0,37):C.GC_6013,(0,9):C.GC_6013,(0,20):C.GC_6020,(0,21):C.GC_6017,(0,14):C.GC_6013,(0,17):C.GC_6013,(0,32):C.GC_6020,(0,33):C.GC_6017,(0,23):C.GC_6013,(0,27):C.GC_6013,(0,40):C.GC_6016,(0,42):C.GC_6016,(0,45):C.GC_6016,(0,4):C.GC_6016,(0,41):C.GC_6016,(0,43):C.GC_6016,(0,46):C.GC_6016,(0,5):C.GC_6016})

V_528 = Vertex(name = 'V_528',
               particles = [ P.Z, P.Z, P.G0, P.G0, P.G0, P.G0 ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS91 ],
               couplings = {(0,0):C.GC_4966})

V_529 = Vertex(name = 'V_529',
               particles = [ P.Z, P.Z, P.G0, P.G0 ],
               color = [ '1' ],
               lorentz = [ L.VVSS1, L.VVSS10, L.VVSS11, L.VVSS12, L.VVSS13, L.VVSS15, L.VVSS16, L.VVSS17, L.VVSS18, L.VVSS19, L.VVSS2, L.VVSS21, L.VVSS22, L.VVSS23, L.VVSS24, L.VVSS26, L.VVSS27, L.VVSS28, L.VVSS29, L.VVSS3, L.VVSS30, L.VVSS32, L.VVSS33, L.VVSS41, L.VVSS42, L.VVSS5, L.VVSS55, L.VVSS56, L.VVSS57, L.VVSS58, L.VVSS59, L.VVSS6, L.VVSS60, L.VVSS61, L.VVSS62, L.VVSS63, L.VVSS64, L.VVSS7, L.VVSS8, L.VVSS9 ],
               couplings = {(0,10):C.GC_5385,(0,19):C.GC_5384,(0,0):C.GC_5445,(0,1):C.GC_4963,(0,6):C.GC_4963,(0,2):C.GC_5416,(0,7):C.GC_5416,(0,27):C.GC_5446,(0,8):C.GC_5417,(0,15):C.GC_5417,(0,3):C.GC_5417,(0,34):C.GC_5416,(0,13):C.GC_5417,(0,35):C.GC_5416,(0,18):C.GC_5411,(0,20):C.GC_5412,(0,17):C.GC_5406,(0,33):C.GC_4963,(0,36):C.GC_5405,(0,26):C.GC_3084,(0,37):C.GC_5897,(0,38):C.GC_5894,(0,25):C.GC_5886,(0,31):C.GC_5886,(0,11):C.GC_5897,(0,12):C.GC_5894,(0,39):C.GC_5886,(0,5):C.GC_5886,(0,28):C.GC_5889,(0,30):C.GC_5889,(0,29):C.GC_5889,(0,32):C.GC_5889,(0,14):C.GC_5420,(0,16):C.GC_5420,(0,4):C.GC_5420,(0,9):C.GC_5420,(0,24):C.GC_5423,(0,22):C.GC_5423,(0,23):C.GC_5420,(0,21):C.GC_5420})

V_530 = Vertex(name = 'V_530',
               particles = [ P.Z, P.Z, P.G0, P.G0 ],
               color = [ '1' ],
               lorentz = [ L.VVSS1, L.VVSS2, L.VVSS3, L.VVSS55, L.VVSS56 ],
               couplings = {(0,1):C.GC_5450,(0,2):C.GC_5449,(0,0):C.GC_5379,(0,4):C.GC_5380,(0,3):C.GC_4971})

V_531 = Vertex(name = 'V_531',
               particles = [ P.Z, P.Z, P.G0, P.G0, P.G__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS1, L.VVSSSS10, L.VVSSSS100, L.VVSSSS101, L.VVSSSS102, L.VVSSSS103, L.VVSSSS104, L.VVSSSS105, L.VVSSSS106, L.VVSSSS11, L.VVSSSS12, L.VVSSSS14, L.VVSSSS15, L.VVSSSS2, L.VVSSSS21, L.VVSSSS22, L.VVSSSS23, L.VVSSSS24, L.VVSSSS25, L.VVSSSS26, L.VVSSSS28, L.VVSSSS29, L.VVSSSS3, L.VVSSSS34, L.VVSSSS35, L.VVSSSS36, L.VVSSSS37, L.VVSSSS38, L.VVSSSS39, L.VVSSSS40, L.VVSSSS41, L.VVSSSS5, L.VVSSSS56, L.VVSSSS57, L.VVSSSS6, L.VVSSSS7, L.VVSSSS8, L.VVSSSS9, L.VVSSSS91, L.VVSSSS92, L.VVSSSS93, L.VVSSSS94, L.VVSSSS95, L.VVSSSS96, L.VVSSSS97, L.VVSSSS98, L.VVSSSS99 ],
               couplings = {(0,13):C.GC_1478,(0,22):C.GC_1476,(0,0):C.GC_1473,(0,38):C.GC_4960,(0,39):C.GC_1474,(0,1):C.GC_4989,(0,10):C.GC_4989,(0,15):C.GC_4987,(0,16):C.GC_4987,(0,18):C.GC_4987,(0,19):C.GC_4987,(0,24):C.GC_4987,(0,25):C.GC_4987,(0,26):C.GC_4988,(0,28):C.GC_4987,(0,29):C.GC_4987,(0,30):C.GC_4988,(0,44):C.GC_4995,(0,2):C.GC_4990,(0,6):C.GC_4990,(0,3):C.GC_4990,(0,7):C.GC_4990,(0,8):C.GC_3109,(0,35):C.GC_6019,(0,36):C.GC_6018,(0,31):C.GC_6014,(0,34):C.GC_6014,(0,11):C.GC_6019,(0,12):C.GC_6018,(0,37):C.GC_6014,(0,9):C.GC_6014,(0,20):C.GC_6347,(0,21):C.GC_6351,(0,14):C.GC_6344,(0,17):C.GC_6344,(0,32):C.GC_6348,(0,33):C.GC_6350,(0,23):C.GC_6343,(0,27):C.GC_6343,(0,40):C.GC_6015,(0,42):C.GC_6015,(0,45):C.GC_6341,(0,4):C.GC_6342,(0,41):C.GC_6015,(0,43):C.GC_6015,(0,46):C.GC_6341,(0,5):C.GC_6342})

V_532 = Vertex(name = 'V_532',
               particles = [ P.Z, P.Z, P.G0, P.G0, P.G__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS91 ],
               couplings = {(0,0):C.GC_6057})

V_533 = Vertex(name = 'V_533',
               particles = [ P.Z, P.Z, P.G__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSS1, L.VVSS10, L.VVSS11, L.VVSS12, L.VVSS13, L.VVSS15, L.VVSS16, L.VVSS17, L.VVSS18, L.VVSS19, L.VVSS2, L.VVSS21, L.VVSS22, L.VVSS23, L.VVSS24, L.VVSS26, L.VVSS27, L.VVSS28, L.VVSS29, L.VVSS3, L.VVSS30, L.VVSS32, L.VVSS33, L.VVSS41, L.VVSS42, L.VVSS5, L.VVSS55, L.VVSS56, L.VVSS57, L.VVSS58, L.VVSS59, L.VVSS6, L.VVSS60, L.VVSS61, L.VVSS62, L.VVSS63, L.VVSS64, L.VVSS7, L.VVSS8, L.VVSS9 ],
               couplings = {(0,10):C.GC_5383,(0,19):C.GC_5386,(0,0):C.GC_5433,(0,1):C.GC_4962,(0,6):C.GC_4962,(0,26):C.GC_4956,(0,2):C.GC_5418,(0,7):C.GC_5418,(0,27):C.GC_5434,(0,8):C.GC_5414,(0,15):C.GC_5414,(0,3):C.GC_5414,(0,34):C.GC_5418,(0,13):C.GC_5414,(0,35):C.GC_5418,(0,18):C.GC_5413,(0,20):C.GC_5409,(0,17):C.GC_5404,(0,33):C.GC_3090,(0,36):C.GC_5407,(0,37):C.GC_5898,(0,38):C.GC_5896,(0,25):C.GC_5888,(0,31):C.GC_5888,(0,11):C.GC_5899,(0,12):C.GC_5895,(0,39):C.GC_5887,(0,5):C.GC_5887,(0,28):C.GC_5890,(0,30):C.GC_5891,(0,29):C.GC_5890,(0,32):C.GC_5891,(0,14):C.GC_5425,(0,16):C.GC_5425,(0,4):C.GC_5424,(0,9):C.GC_5424,(0,24):C.GC_5421,(0,22):C.GC_5422,(0,23):C.GC_5425,(0,21):C.GC_5424})

V_534 = Vertex(name = 'V_534',
               particles = [ P.Z, P.Z, P.G__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSS1, L.VVSS2, L.VVSS3, L.VVSS55, L.VVSS56 ],
               couplings = {(0,1):C.GC_5436,(0,2):C.GC_5437,(0,0):C.GC_5381,(0,3):C.GC_5962,(0,4):C.GC_5377})

V_535 = Vertex(name = 'V_535',
               particles = [ P.Z, P.Z, P.G__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSS55 ],
               couplings = {(0,0):C.GC_5982})

V_536 = Vertex(name = 'V_536',
               particles = [ P.Z, P.Z, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS1, L.VVSSSS10, L.VVSSSS100, L.VVSSSS101, L.VVSSSS102, L.VVSSSS103, L.VVSSSS104, L.VVSSSS105, L.VVSSSS106, L.VVSSSS11, L.VVSSSS12, L.VVSSSS14, L.VVSSSS15, L.VVSSSS2, L.VVSSSS21, L.VVSSSS22, L.VVSSSS23, L.VVSSSS24, L.VVSSSS25, L.VVSSSS26, L.VVSSSS28, L.VVSSSS29, L.VVSSSS3, L.VVSSSS34, L.VVSSSS35, L.VVSSSS36, L.VVSSSS37, L.VVSSSS38, L.VVSSSS39, L.VVSSSS40, L.VVSSSS41, L.VVSSSS5, L.VVSSSS56, L.VVSSSS57, L.VVSSSS6, L.VVSSSS7, L.VVSSSS8, L.VVSSSS9, L.VVSSSS91, L.VVSSSS92, L.VVSSSS93, L.VVSSSS94, L.VVSSSS95, L.VVSSSS96, L.VVSSSS97, L.VVSSSS98, L.VVSSSS99 ],
               couplings = {(0,13):C.GC_6229,(0,22):C.GC_6227,(0,0):C.GC_6218,(0,38):C.GC_4961,(0,39):C.GC_6219,(0,1):C.GC_4999,(0,10):C.GC_4999,(0,15):C.GC_4993,(0,16):C.GC_4993,(0,18):C.GC_4993,(0,19):C.GC_4993,(0,24):C.GC_4993,(0,25):C.GC_4993,(0,26):C.GC_4999,(0,28):C.GC_4993,(0,29):C.GC_4993,(0,30):C.GC_4999,(0,44):C.GC_4991,(0,2):C.GC_4996,(0,6):C.GC_4996,(0,3):C.GC_4996,(0,7):C.GC_4996,(0,8):C.GC_4991,(0,35):C.GC_6346,(0,36):C.GC_6353,(0,31):C.GC_6345,(0,34):C.GC_6345,(0,11):C.GC_6346,(0,12):C.GC_6353,(0,37):C.GC_6345,(0,9):C.GC_6345,(0,20):C.GC_6346,(0,21):C.GC_6353,(0,14):C.GC_6345,(0,17):C.GC_6345,(0,32):C.GC_6346,(0,33):C.GC_6353,(0,23):C.GC_6345,(0,27):C.GC_6345,(0,40):C.GC_6339,(0,42):C.GC_6339,(0,45):C.GC_6339,(0,4):C.GC_6339,(0,41):C.GC_6339,(0,43):C.GC_6339,(0,46):C.GC_6339,(0,5):C.GC_6339})

V_537 = Vertex(name = 'V_537',
               particles = [ P.Z, P.Z, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS91 ],
               couplings = {(0,0):C.GC_6554})

V_538 = Vertex(name = 'V_538',
               particles = [ P.Z, P.Z, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVS1, L.VVS11, L.VVS12, L.VVS13, L.VVS14, L.VVS2, L.VVS3, L.VVS5, L.VVS6, L.VVS7, L.VVS8 ],
               couplings = {(0,9):C.GC_5881,(0,10):C.GC_5880,(0,7):C.GC_5878,(0,8):C.GC_5878,(0,3):C.GC_5879,(0,4):C.GC_5879,(0,5):C.GC_5394,(0,6):C.GC_5393,(0,0):C.GC_5429,(0,1):C.GC_3083,(0,2):C.GC_5430})

V_539 = Vertex(name = 'V_539',
               particles = [ P.Z, P.Z, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVS1, L.VVS11, L.VVS12, L.VVS2, L.VVS3 ],
               couplings = {(0,3):C.GC_5432,(0,4):C.GC_5431,(0,0):C.GC_5390,(0,1):C.GC_4958,(0,2):C.GC_5391})

V_540 = Vertex(name = 'V_540',
               particles = [ P.Z, P.Z, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVS11 ],
               couplings = {(0,0):C.GC_4970})

V_541 = Vertex(name = 'V_541',
               particles = [ P.Z, P.Z, P.G0, P.G0, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSS1, L.VVSSS11, L.VVSSS12, L.VVSSS13, L.VVSSS14, L.VVSSS16, L.VVSSS17, L.VVSSS2, L.VVSSS24, L.VVSSS25, L.VVSSS26, L.VVSSS28, L.VVSSS29, L.VVSSS3, L.VVSSS30, L.VVSSS39, L.VVSSS40, L.VVSSS5, L.VVSSS58, L.VVSSS59, L.VVSSS6, L.VVSSS60, L.VVSSS61, L.VVSSS62, L.VVSSS63, L.VVSSS64, L.VVSSS65, L.VVSSS66, L.VVSSS67, L.VVSSS68, L.VVSSS7, L.VVSSS8 ],
               couplings = {(0,30):C.GC_5989,(0,31):C.GC_5988,(0,17):C.GC_5984,(0,20):C.GC_5984,(0,5):C.GC_5989,(0,6):C.GC_5988,(0,1):C.GC_5984,(0,3):C.GC_5984,(0,15):C.GC_5989,(0,16):C.GC_5988,(0,8):C.GC_5984,(0,11):C.GC_5984,(0,21):C.GC_5985,(0,23):C.GC_5985,(0,26):C.GC_5985,(0,22):C.GC_5985,(0,24):C.GC_5985,(0,27):C.GC_5985,(0,18):C.GC_3085,(0,7):C.GC_6245,(0,13):C.GC_6246,(0,0):C.GC_6241,(0,19):C.GC_6239,(0,2):C.GC_4981,(0,4):C.GC_4981,(0,9):C.GC_4980,(0,10):C.GC_4980,(0,12):C.GC_4980,(0,14):C.GC_4980,(0,25):C.GC_4981,(0,28):C.GC_3098,(0,29):C.GC_3098})

V_542 = Vertex(name = 'V_542',
               particles = [ P.Z, P.Z, P.G0, P.G0, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSS58 ],
               couplings = {(0,0):C.GC_4973})

V_543 = Vertex(name = 'V_543',
               particles = [ P.Z, P.Z, P.G__minus__, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSS1, L.VVSSS11, L.VVSSS12, L.VVSSS13, L.VVSSS14, L.VVSSS16, L.VVSSS17, L.VVSSS2, L.VVSSS24, L.VVSSS25, L.VVSSS26, L.VVSSS28, L.VVSSS29, L.VVSSS3, L.VVSSS30, L.VVSSS39, L.VVSSS40, L.VVSSS5, L.VVSSS58, L.VVSSS59, L.VVSSS6, L.VVSSS60, L.VVSSS61, L.VVSSS62, L.VVSSS63, L.VVSSS64, L.VVSSS65, L.VVSSS66, L.VVSSS67, L.VVSSS68, L.VVSSS7, L.VVSSS8 ],
               couplings = {(0,30):C.GC_6256,(0,31):C.GC_6260,(0,17):C.GC_6255,(0,20):C.GC_6255,(0,5):C.GC_6257,(0,6):C.GC_6259,(0,1):C.GC_6254,(0,3):C.GC_6254,(0,15):C.GC_5989,(0,16):C.GC_5988,(0,8):C.GC_5984,(0,11):C.GC_5984,(0,21):C.GC_6252,(0,23):C.GC_6253,(0,26):C.GC_5985,(0,22):C.GC_6252,(0,24):C.GC_6253,(0,27):C.GC_5985,(0,18):C.GC_4959,(0,7):C.GC_1537,(0,13):C.GC_1535,(0,0):C.GC_1532,(0,19):C.GC_1533,(0,2):C.GC_4977,(0,4):C.GC_4977,(0,9):C.GC_4976,(0,10):C.GC_4976,(0,12):C.GC_4976,(0,14):C.GC_4976,(0,25):C.GC_3099,(0,28):C.GC_4978,(0,29):C.GC_4978})

V_544 = Vertex(name = 'V_544',
               particles = [ P.Z, P.Z, P.G__minus__, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSS58 ],
               couplings = {(0,0):C.GC_6090})

V_545 = Vertex(name = 'V_545',
               particles = [ P.Z, P.Z, P.G0, P.G0, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS1, L.VVSSSS10, L.VVSSSS100, L.VVSSSS101, L.VVSSSS102, L.VVSSSS103, L.VVSSSS104, L.VVSSSS105, L.VVSSSS106, L.VVSSSS11, L.VVSSSS12, L.VVSSSS14, L.VVSSSS15, L.VVSSSS2, L.VVSSSS21, L.VVSSSS22, L.VVSSSS23, L.VVSSSS24, L.VVSSSS25, L.VVSSSS26, L.VVSSSS28, L.VVSSSS29, L.VVSSSS3, L.VVSSSS34, L.VVSSSS35, L.VVSSSS36, L.VVSSSS37, L.VVSSSS38, L.VVSSSS39, L.VVSSSS40, L.VVSSSS41, L.VVSSSS5, L.VVSSSS56, L.VVSSSS57, L.VVSSSS6, L.VVSSSS7, L.VVSSSS8, L.VVSSSS9, L.VVSSSS91, L.VVSSSS92, L.VVSSSS93, L.VVSSSS94, L.VVSSSS95, L.VVSSSS96, L.VVSSSS97, L.VVSSSS98, L.VVSSSS99 ],
               couplings = {(0,13):C.GC_6224,(0,22):C.GC_6225,(0,0):C.GC_6217,(0,38):C.GC_3087,(0,39):C.GC_6215,(0,1):C.GC_4997,(0,10):C.GC_4997,(0,15):C.GC_4994,(0,16):C.GC_4994,(0,18):C.GC_4994,(0,19):C.GC_4994,(0,24):C.GC_4994,(0,25):C.GC_4994,(0,26):C.GC_4997,(0,28):C.GC_4994,(0,29):C.GC_4994,(0,30):C.GC_4997,(0,44):C.GC_4997,(0,2):C.GC_3108,(0,6):C.GC_3108,(0,3):C.GC_3108,(0,7):C.GC_3108,(0,8):C.GC_4997,(0,35):C.GC_6019,(0,36):C.GC_6018,(0,31):C.GC_6014,(0,34):C.GC_6014,(0,11):C.GC_6019,(0,12):C.GC_6018,(0,37):C.GC_6014,(0,9):C.GC_6014,(0,20):C.GC_6019,(0,21):C.GC_6018,(0,14):C.GC_6014,(0,17):C.GC_6014,(0,32):C.GC_6019,(0,33):C.GC_6018,(0,23):C.GC_6014,(0,27):C.GC_6014,(0,40):C.GC_6015,(0,42):C.GC_6015,(0,45):C.GC_6015,(0,4):C.GC_6015,(0,41):C.GC_6015,(0,43):C.GC_6015,(0,46):C.GC_6015,(0,5):C.GC_6015})

V_546 = Vertex(name = 'V_546',
               particles = [ P.Z, P.Z, P.G0, P.G0, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS91 ],
               couplings = {(0,0):C.GC_4965})

V_547 = Vertex(name = 'V_547',
               particles = [ P.Z, P.Z, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSS1, L.VVSS10, L.VVSS11, L.VVSS12, L.VVSS13, L.VVSS15, L.VVSS16, L.VVSS17, L.VVSS18, L.VVSS19, L.VVSS2, L.VVSS21, L.VVSS22, L.VVSS23, L.VVSS24, L.VVSS26, L.VVSS27, L.VVSS28, L.VVSS29, L.VVSS3, L.VVSS30, L.VVSS32, L.VVSS33, L.VVSS41, L.VVSS42, L.VVSS5, L.VVSS55, L.VVSS56, L.VVSS57, L.VVSS58, L.VVSS59, L.VVSS6, L.VVSS60, L.VVSS61, L.VVSS62, L.VVSS63, L.VVSS64, L.VVSS7, L.VVSS8, L.VVSS9 ],
               couplings = {(0,10):C.GC_5385,(0,19):C.GC_5384,(0,0):C.GC_5447,(0,1):C.GC_3089,(0,6):C.GC_3089,(0,26):C.GC_3084,(0,2):C.GC_5416,(0,7):C.GC_5416,(0,27):C.GC_5448,(0,8):C.GC_5417,(0,15):C.GC_5417,(0,3):C.GC_5417,(0,34):C.GC_5416,(0,13):C.GC_5417,(0,35):C.GC_5416,(0,18):C.GC_5411,(0,20):C.GC_5412,(0,17):C.GC_5406,(0,33):C.GC_4964,(0,36):C.GC_5405,(0,37):C.GC_5900,(0,38):C.GC_5893,(0,25):C.GC_5885,(0,31):C.GC_5885,(0,11):C.GC_5900,(0,12):C.GC_5893,(0,39):C.GC_5885,(0,5):C.GC_5885,(0,28):C.GC_5892,(0,30):C.GC_5892,(0,29):C.GC_5892,(0,32):C.GC_5892,(0,14):C.GC_5420,(0,16):C.GC_5420,(0,4):C.GC_5420,(0,9):C.GC_5420,(0,24):C.GC_5423,(0,22):C.GC_5423,(0,23):C.GC_5420,(0,21):C.GC_5420})

V_548 = Vertex(name = 'V_548',
               particles = [ P.Z, P.Z, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSS1, L.VVSS2, L.VVSS3, L.VVSS55, L.VVSS56 ],
               couplings = {(0,1):C.GC_5452,(0,2):C.GC_5451,(0,0):C.GC_5379,(0,3):C.GC_4957,(0,4):C.GC_5380})

V_549 = Vertex(name = 'V_549',
               particles = [ P.Z, P.Z, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSS55 ],
               couplings = {(0,0):C.GC_4972})

V_550 = Vertex(name = 'V_550',
               particles = [ P.Z, P.Z, P.G__minus__, P.G__plus__, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS1, L.VVSSSS10, L.VVSSSS100, L.VVSSSS101, L.VVSSSS102, L.VVSSSS103, L.VVSSSS104, L.VVSSSS105, L.VVSSSS106, L.VVSSSS11, L.VVSSSS12, L.VVSSSS14, L.VVSSSS15, L.VVSSSS2, L.VVSSSS21, L.VVSSSS22, L.VVSSSS23, L.VVSSSS24, L.VVSSSS25, L.VVSSSS26, L.VVSSSS28, L.VVSSSS29, L.VVSSSS3, L.VVSSSS34, L.VVSSSS35, L.VVSSSS36, L.VVSSSS37, L.VVSSSS38, L.VVSSSS39, L.VVSSSS40, L.VVSSSS41, L.VVSSSS5, L.VVSSSS56, L.VVSSSS57, L.VVSSSS6, L.VVSSSS7, L.VVSSSS8, L.VVSSSS9, L.VVSSSS91, L.VVSSSS92, L.VVSSSS93, L.VVSSSS94, L.VVSSSS95, L.VVSSSS96, L.VVSSSS97, L.VVSSSS98, L.VVSSSS99 ],
               couplings = {(0,13):C.GC_1478,(0,22):C.GC_1476,(0,0):C.GC_1473,(0,38):C.GC_4960,(0,39):C.GC_1474,(0,1):C.GC_4988,(0,10):C.GC_4988,(0,15):C.GC_4987,(0,16):C.GC_4987,(0,18):C.GC_4987,(0,19):C.GC_4987,(0,24):C.GC_4987,(0,25):C.GC_4987,(0,26):C.GC_4989,(0,28):C.GC_4987,(0,29):C.GC_4987,(0,30):C.GC_4989,(0,44):C.GC_3109,(0,2):C.GC_4990,(0,6):C.GC_4990,(0,3):C.GC_4990,(0,7):C.GC_4990,(0,8):C.GC_4995,(0,35):C.GC_6347,(0,36):C.GC_6351,(0,31):C.GC_6344,(0,34):C.GC_6344,(0,11):C.GC_6348,(0,12):C.GC_6350,(0,37):C.GC_6343,(0,9):C.GC_6343,(0,20):C.GC_6019,(0,21):C.GC_6018,(0,14):C.GC_6014,(0,17):C.GC_6014,(0,32):C.GC_6019,(0,33):C.GC_6018,(0,23):C.GC_6014,(0,27):C.GC_6014,(0,40):C.GC_6341,(0,42):C.GC_6342,(0,45):C.GC_6015,(0,4):C.GC_6015,(0,41):C.GC_6341,(0,43):C.GC_6342,(0,46):C.GC_6015,(0,5):C.GC_6015})

V_551 = Vertex(name = 'V_551',
               particles = [ P.Z, P.Z, P.G__minus__, P.G__plus__, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS91 ],
               couplings = {(0,0):C.GC_6058})

V_552 = Vertex(name = 'V_552',
               particles = [ P.Z, P.Z, P.H, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSS1, L.VVSSS11, L.VVSSS12, L.VVSSS13, L.VVSSS14, L.VVSSS16, L.VVSSS17, L.VVSSS2, L.VVSSS24, L.VVSSS25, L.VVSSS26, L.VVSSS28, L.VVSSS29, L.VVSSS3, L.VVSSS30, L.VVSSS39, L.VVSSS40, L.VVSSS5, L.VVSSS58, L.VVSSS59, L.VVSSS6, L.VVSSS60, L.VVSSS61, L.VVSSS62, L.VVSSS63, L.VVSSS64, L.VVSSS65, L.VVSSS66, L.VVSSS67, L.VVSSS68, L.VVSSS7, L.VVSSS8 ],
               couplings = {(0,30):C.GC_5990,(0,31):C.GC_5987,(0,17):C.GC_5983,(0,20):C.GC_5983,(0,5):C.GC_5990,(0,6):C.GC_5987,(0,1):C.GC_5983,(0,3):C.GC_5983,(0,15):C.GC_5990,(0,16):C.GC_5987,(0,8):C.GC_5983,(0,11):C.GC_5983,(0,21):C.GC_5986,(0,23):C.GC_5986,(0,26):C.GC_5986,(0,22):C.GC_5986,(0,24):C.GC_5986,(0,27):C.GC_5986,(0,18):C.GC_3086,(0,7):C.GC_6248,(0,13):C.GC_6249,(0,0):C.GC_6244,(0,19):C.GC_6242,(0,2):C.GC_3097,(0,4):C.GC_3097,(0,9):C.GC_3097,(0,10):C.GC_3097,(0,12):C.GC_3097,(0,14):C.GC_3097,(0,25):C.GC_4982,(0,28):C.GC_4982,(0,29):C.GC_4982})

V_553 = Vertex(name = 'V_553',
               particles = [ P.Z, P.Z, P.H, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSS58 ],
               couplings = {(0,0):C.GC_4974})

V_554 = Vertex(name = 'V_554',
               particles = [ P.Z, P.Z, P.H, P.H, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS1, L.VVSSSS10, L.VVSSSS100, L.VVSSSS101, L.VVSSSS102, L.VVSSSS103, L.VVSSSS104, L.VVSSSS105, L.VVSSSS106, L.VVSSSS11, L.VVSSSS12, L.VVSSSS14, L.VVSSSS15, L.VVSSSS2, L.VVSSSS21, L.VVSSSS22, L.VVSSSS23, L.VVSSSS24, L.VVSSSS25, L.VVSSSS26, L.VVSSSS28, L.VVSSSS29, L.VVSSSS3, L.VVSSSS34, L.VVSSSS35, L.VVSSSS36, L.VVSSSS37, L.VVSSSS38, L.VVSSSS39, L.VVSSSS40, L.VVSSSS41, L.VVSSSS5, L.VVSSSS56, L.VVSSSS57, L.VVSSSS6, L.VVSSSS7, L.VVSSSS8, L.VVSSSS9, L.VVSSSS91, L.VVSSSS92, L.VVSSSS93, L.VVSSSS94, L.VVSSSS95, L.VVSSSS96, L.VVSSSS97, L.VVSSSS98, L.VVSSSS99 ],
               couplings = {(0,13):C.GC_6230,(0,22):C.GC_6231,(0,0):C.GC_6223,(0,38):C.GC_3088,(0,39):C.GC_6221,(0,1):C.GC_3107,(0,10):C.GC_3107,(0,15):C.GC_3107,(0,16):C.GC_3107,(0,18):C.GC_3107,(0,19):C.GC_3107,(0,24):C.GC_3107,(0,25):C.GC_3107,(0,26):C.GC_3107,(0,28):C.GC_3107,(0,29):C.GC_3107,(0,30):C.GC_3107,(0,44):C.GC_4998,(0,2):C.GC_4998,(0,6):C.GC_4998,(0,3):C.GC_4998,(0,7):C.GC_4998,(0,8):C.GC_4998,(0,35):C.GC_6020,(0,36):C.GC_6017,(0,31):C.GC_6013,(0,34):C.GC_6013,(0,11):C.GC_6020,(0,12):C.GC_6017,(0,37):C.GC_6013,(0,9):C.GC_6013,(0,20):C.GC_6020,(0,21):C.GC_6017,(0,14):C.GC_6013,(0,17):C.GC_6013,(0,32):C.GC_6020,(0,33):C.GC_6017,(0,23):C.GC_6013,(0,27):C.GC_6013,(0,40):C.GC_6016,(0,42):C.GC_6016,(0,45):C.GC_6016,(0,4):C.GC_6016,(0,41):C.GC_6016,(0,43):C.GC_6016,(0,46):C.GC_6016,(0,5):C.GC_6016})

V_555 = Vertex(name = 'V_555',
               particles = [ P.Z, P.Z, P.H, P.H, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS91 ],
               couplings = {(0,0):C.GC_4967})

V_556 = Vertex(name = 'V_556',
               particles = [ P.A, P.A, P.A, P.Z, P.G__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVVSS10, L.VVVVSS101, L.VVVVSS102, L.VVVVSS103, L.VVVVSS105, L.VVVVSS106, L.VVVVSS107, L.VVVVSS11, L.VVVVSS12, L.VVVVSS133, L.VVVVSS134, L.VVVVSS135, L.VVVVSS136, L.VVVVSS137, L.VVVVSS139, L.VVVVSS14, L.VVVVSS140, L.VVVVSS141, L.VVVVSS142, L.VVVVSS144, L.VVVVSS145, L.VVVVSS146, L.VVVVSS16, L.VVVVSS169, L.VVVVSS170, L.VVVVSS171, L.VVVVSS172, L.VVVVSS173, L.VVVVSS174, L.VVVVSS176, L.VVVVSS177, L.VVVVSS178, L.VVVVSS179, L.VVVVSS18, L.VVVVSS180, L.VVVVSS182, L.VVVVSS183, L.VVVVSS2, L.VVVVSS21, L.VVVVSS210, L.VVVVSS211, L.VVVVSS212, L.VVVVSS213, L.VVVVSS214, L.VVVVSS215, L.VVVVSS217, L.VVVVSS218, L.VVVVSS219, L.VVVVSS22, L.VVVVSS221, L.VVVVSS222, L.VVVVSS223, L.VVVVSS23, L.VVVVSS243, L.VVVVSS244, L.VVVVSS245, L.VVVVSS246, L.VVVVSS247, L.VVVVSS248, L.VVVVSS25, L.VVVVSS26, L.VVVVSS267, L.VVVVSS268, L.VVVVSS269, L.VVVVSS27, L.VVVVSS270, L.VVVVSS271, L.VVVVSS272, L.VVVVSS273, L.VVVVSS275, L.VVVVSS276, L.VVVVSS277, L.VVVVSS278, L.VVVVSS279, L.VVVVSS28, L.VVVVSS281, L.VVVVSS29, L.VVVVSS3, L.VVVVSS301, L.VVVVSS302, L.VVVVSS303, L.VVVVSS304, L.VVVVSS305, L.VVVVSS306, L.VVVVSS32, L.VVVVSS33, L.VVVVSS36, L.VVVVSS360, L.VVVVSS361, L.VVVVSS362, L.VVVVSS363, L.VVVVSS364, L.VVVVSS365, L.VVVVSS366, L.VVVVSS367, L.VVVVSS368, L.VVVVSS369, L.VVVVSS37, L.VVVVSS370, L.VVVVSS371, L.VVVVSS372, L.VVVVSS392, L.VVVVSS393, L.VVVVSS394, L.VVVVSS395, L.VVVVSS396, L.VVVVSS397, L.VVVVSS4, L.VVVVSS5, L.VVVVSS7, L.VVVVSS8, L.VVVVSS93, L.VVVVSS94, L.VVVVSS95, L.VVVVSS96, L.VVVVSS97, L.VVVVSS98 ],
               couplings = {(0,107):C.GC_1752,(0,108):C.GC_1752,(0,37):C.GC_1753,(0,77):C.GC_1753,(0,8):C.GC_1752,(0,15):C.GC_1753,(0,22):C.GC_1752,(0,33):C.GC_1752,(0,109):C.GC_1753,(0,110):C.GC_1753,(0,0):C.GC_1752,(0,7):C.GC_1753,(0,74):C.GC_1751,(0,76):C.GC_1751,(0,84):C.GC_1751,(0,85):C.GC_1750,(0,86):C.GC_1750,(0,97):C.GC_1750,(0,38):C.GC_1754,(0,48):C.GC_1755,(0,52):C.GC_1754,(0,59):C.GC_1755,(0,60):C.GC_1754,(0,64):C.GC_1755,(0,111):C.GC_6670,(0,112):C.GC_6670,(0,115):C.GC_1753,(0,116):C.GC_1753,(0,113):C.GC_6671,(0,114):C.GC_6671,(0,4):C.GC_1751,(0,5):C.GC_1751,(0,6):C.GC_6678,(0,1):C.GC_6669,(0,2):C.GC_6669,(0,3):C.GC_6673,(0,10):C.GC_1753,(0,9):C.GC_6671,(0,14):C.GC_1753,(0,11):C.GC_6670,(0,12):C.GC_6671,(0,13):C.GC_6670,(0,19):C.GC_1751,(0,20):C.GC_6678,(0,21):C.GC_1751,(0,16):C.GC_6669,(0,17):C.GC_6673,(0,18):C.GC_6669,(0,24):C.GC_1753,(0,23):C.GC_6671,(0,27):C.GC_1752,(0,28):C.GC_6676,(0,29):C.GC_6677,(0,25):C.GC_6671,(0,26):C.GC_6675,(0,35):C.GC_1755,(0,36):C.GC_1754,(0,30):C.GC_6668,(0,31):C.GC_6669,(0,32):C.GC_6668,(0,34):C.GC_6669,(0,40):C.GC_1753,(0,39):C.GC_6671,(0,44):C.GC_1753,(0,41):C.GC_6671,(0,42):C.GC_6670,(0,43):C.GC_6670,(0,49):C.GC_6678,(0,50):C.GC_1751,(0,51):C.GC_1751,(0,45):C.GC_6673,(0,46):C.GC_6669,(0,47):C.GC_6669,(0,62):C.GC_1753,(0,61):C.GC_6671,(0,66):C.GC_6676,(0,67):C.GC_1752,(0,68):C.GC_6677,(0,63):C.GC_6675,(0,65):C.GC_6671,(0,73):C.GC_1755,(0,75):C.GC_1754,(0,69):C.GC_6669,(0,70):C.GC_6668,(0,71):C.GC_6668,(0,72):C.GC_6669,(0,88):C.GC_6676,(0,89):C.GC_6677,(0,87):C.GC_6675,(0,92):C.GC_1753,(0,93):C.GC_1752,(0,90):C.GC_6671,(0,91):C.GC_6671,(0,99):C.GC_1755,(0,100):C.GC_1754,(0,94):C.GC_6669,(0,95):C.GC_6668,(0,96):C.GC_6669,(0,98):C.GC_6668,(0,53):C.GC_6670,(0,78):C.GC_6670,(0,101):C.GC_6674,(0,54):C.GC_6670,(0,79):C.GC_6674,(0,102):C.GC_6670,(0,56):C.GC_6672,(0,81):C.GC_6668,(0,104):C.GC_6668,(0,55):C.GC_6674,(0,80):C.GC_6670,(0,103):C.GC_6670,(0,57):C.GC_6668,(0,82):C.GC_6672,(0,105):C.GC_6668,(0,58):C.GC_6668,(0,83):C.GC_6668,(0,106):C.GC_6672})

V_557 = Vertex(name = 'V_557',
               particles = [ P.A, P.Z, P.G0, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSS11, L.VVSS12, L.VVSS14, L.VVSS17, L.VVSS18, L.VVSS19, L.VVSS23, L.VVSS25, L.VVSS26, L.VVSS27, L.VVSS32, L.VVSS33, L.VVSS41, L.VVSS42, L.VVSS62, L.VVSS63 ],
               couplings = {(0,7):C.GC_2123,(0,9):C.GC_1521,(0,2):C.GC_2122,(0,5):C.GC_1522,(0,0):C.GC_237,(0,3):C.GC_236,(0,13):C.GC_2123,(0,4):C.GC_237,(0,11):C.GC_2122,(0,8):C.GC_236,(0,12):C.GC_1521,(0,1):C.GC_236,(0,14):C.GC_237,(0,10):C.GC_1522,(0,6):C.GC_237,(0,15):C.GC_236})

V_558 = Vertex(name = 'V_558',
               particles = [ P.A, P.W__minus__, P.Z, P.G0, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVSS1, L.VVVSS10, L.VVVSS103, L.VVVSS104, L.VVVSS105, L.VVVSS106, L.VVVSS107, L.VVVSS109, L.VVVSS110, L.VVVSS112, L.VVVSS113, L.VVVSS116, L.VVVSS118, L.VVVSS119, L.VVVSS12, L.VVVSS121, L.VVVSS122, L.VVVSS124, L.VVVSS125, L.VVVSS127, L.VVVSS128, L.VVVSS130, L.VVVSS136, L.VVVSS138, L.VVVSS139, L.VVVSS14, L.VVVSS140, L.VVVSS141, L.VVVSS142, L.VVVSS145, L.VVVSS146, L.VVVSS147, L.VVVSS148, L.VVVSS149, L.VVVSS15, L.VVVSS150, L.VVVSS151, L.VVVSS152, L.VVVSS153, L.VVVSS155, L.VVVSS156, L.VVVSS158, L.VVVSS159, L.VVVSS16, L.VVVSS161, L.VVVSS163, L.VVVSS164, L.VVVSS165, L.VVVSS168, L.VVVSS17, L.VVVSS170, L.VVVSS172, L.VVVSS177, L.VVVSS178, L.VVVSS179, L.VVVSS18, L.VVVSS180, L.VVVSS182, L.VVVSS183, L.VVVSS184, L.VVVSS185, L.VVVSS186, L.VVVSS187, L.VVVSS189, L.VVVSS19, L.VVVSS190, L.VVVSS191, L.VVVSS192, L.VVVSS193, L.VVVSS194, L.VVVSS195, L.VVVSS196, L.VVVSS198, L.VVVSS199, L.VVVSS2, L.VVVSS200, L.VVVSS202, L.VVVSS203, L.VVVSS205, L.VVVSS207, L.VVVSS208, L.VVVSS209, L.VVVSS21, L.VVVSS210, L.VVVSS218, L.VVVSS219, L.VVVSS22, L.VVVSS220, L.VVVSS221, L.VVVSS223, L.VVVSS224, L.VVVSS225, L.VVVSS226, L.VVVSS227, L.VVVSS228, L.VVVSS229, L.VVVSS23, L.VVVSS230, L.VVVSS231, L.VVVSS232, L.VVVSS233, L.VVVSS234, L.VVVSS235, L.VVVSS236, L.VVVSS239, L.VVVSS240, L.VVVSS241, L.VVVSS242, L.VVVSS245, L.VVVSS247, L.VVVSS249, L.VVVSS25, L.VVVSS26, L.VVVSS27, L.VVVSS28, L.VVVSS29, L.VVVSS30, L.VVVSS32, L.VVVSS33, L.VVVSS34, L.VVVSS36, L.VVVSS37, L.VVVSS38, L.VVVSS39, L.VVVSS4, L.VVVSS40, L.VVVSS41, L.VVVSS42, L.VVVSS43, L.VVVSS44, L.VVVSS45, L.VVVSS46, L.VVVSS47, L.VVVSS48, L.VVVSS49, L.VVVSS50, L.VVVSS51, L.VVVSS52, L.VVVSS53, L.VVVSS54, L.VVVSS56, L.VVVSS57, L.VVVSS6, L.VVVSS60, L.VVVSS62, L.VVVSS64, L.VVVSS65, L.VVVSS66, L.VVVSS68, L.VVVSS7, L.VVVSS70, L.VVVSS71, L.VVVSS72, L.VVVSS75, L.VVVSS77, L.VVVSS8, L.VVVSS80, L.VVVSS81, L.VVVSS83, L.VVVSS85, L.VVVSS87, L.VVVSS88, L.VVVSS9, L.VVVSS90, L.VVVSS92, L.VVVSS93, L.VVVSS95, L.VVVSS96, L.VVVSS98 ],
               couplings = {(0,0):C.GC_2133,(0,162):C.GC_1548,(0,43):C.GC_1471,(0,49):C.GC_199,(0,25):C.GC_1466,(0,34):C.GC_1465,(0,142):C.GC_202,(0,124):C.GC_198,(0,155):C.GC_1472,(0,149):C.GC_195,(0,24):C.GC_2132,(0,29):C.GC_1466,(0,52):C.GC_2129,(0,57):C.GC_202,(0,53):C.GC_1542,(0,89):C.GC_1472,(0,85):C.GC_1545,(0,55):C.GC_1466,(0,54):C.GC_198,(0,87):C.GC_195,(0,14):C.GC_202,(0,27):C.GC_195,(0,88):C.GC_198,(0,1):C.GC_1472,(0,28):C.GC_198,(0,56):C.GC_195,(0,129):C.GC_6455,(0,135):C.GC_1611,(0,131):C.GC_6489,(0,132):C.GC_1599,(0,82):C.GC_6448,(0,64):C.GC_6438,(0,111):C.GC_1609,(0,112):C.GC_1594,(0,86):C.GC_6365,(0,96):C.GC_1586,(0,113):C.GC_6401,(0,117):C.GC_6387,(0,115):C.GC_6380,(0,116):C.GC_6394,(0,120):C.GC_1593,(0,119):C.GC_1585,(0,123):C.GC_1610,(0,125):C.GC_6445,(0,121):C.GC_6366,(0,122):C.GC_6432,(0,5):C.GC_6049,(0,9):C.GC_1609,(0,7):C.GC_1600,(0,11):C.GC_6491,(0,17):C.GC_6445,(0,140):C.GC_6047,(0,139):C.GC_6021,(0,143):C.GC_1611,(0,141):C.GC_6378,(0,147):C.GC_6450,(0,144):C.GC_6393,(0,145):C.GC_6435,(0,146):C.GC_6398,(0,150):C.GC_6034,(0,153):C.GC_6392,(0,152):C.GC_6386,(0,154):C.GC_6431,(0,156):C.GC_6432,(0,160):C.GC_728,(0,159):C.GC_724,(0,163):C.GC_1612,(0,161):C.GC_6377,(0,168):C.GC_6489,(0,164):C.GC_6397,(0,165):C.GC_6436,(0,166):C.GC_6394,(0,39):C.GC_1611,(0,48):C.GC_1609,(0,63):C.GC_6455,(0,68):C.GC_6489,(0,76):C.GC_6049,(0,100):C.GC_1599,(0,108):C.GC_1600,(0,31):C.GC_1592,(0,41):C.GC_727,(0,59):C.GC_6440,(0,70):C.GC_6023,(0,91):C.GC_6403,(0,102):C.GC_6036,(0,32):C.GC_6375,(0,42):C.GC_6364,(0,60):C.GC_6385,(0,71):C.GC_6379,(0,92):C.GC_6376,(0,103):C.GC_6363,(0,130):C.GC_6448,(0,136):C.GC_1609,(0,22):C.GC_6444,(0,35):C.GC_6403,(0,44):C.GC_6431,(0,65):C.GC_6376,(0,72):C.GC_6397,(0,94):C.GC_6438,(0,97):C.GC_6365,(0,6):C.GC_6047,(0,10):C.GC_1611,(0,20):C.GC_6488,(0,45):C.GC_6036,(0,50):C.GC_6393,(0,77):C.GC_6363,(0,79):C.GC_6435,(0,105):C.GC_6021,(0,107):C.GC_6378,(0,33):C.GC_6398,(0,61):C.GC_6436,(0,93):C.GC_1591,(0,36):C.GC_6440,(0,62):C.GC_6401,(0,66):C.GC_6394,(0,98):C.GC_6436,(0,46):C.GC_6023,(0,75):C.GC_6034,(0,133):C.GC_1600,(0,134):C.GC_6492,(0,23):C.GC_6492,(0,37):C.GC_6366,(0,38):C.GC_6432,(0,67):C.GC_6375,(0,73):C.GC_6398,(0,99):C.GC_6398,(0,104):C.GC_6432,(0,8):C.GC_1599,(0,21):C.GC_6451,(0,47):C.GC_6377,(0,78):C.GC_6364,(0,80):C.GC_6436,(0,109):C.GC_6394,(0,18):C.GC_2150,(0,19):C.GC_1594,(0,51):C.GC_2144,(0,81):C.GC_2147,(0,83):C.GC_1591,(0,110):C.GC_1586,(0,74):C.GC_6084,(0,126):C.GC_6084,(0,2):C.GC_6084,(0,26):C.GC_6076,(0,30):C.GC_3972,(0,58):C.GC_6581,(0,69):C.GC_6083,(0,84):C.GC_6083,(0,90):C.GC_6591,(0,101):C.GC_6076,(0,127):C.GC_6454,(0,137):C.GC_6485,(0,114):C.GC_6446,(0,118):C.GC_6441,(0,3):C.GC_6048,(0,12):C.GC_6490,(0,13):C.GC_6490,(0,15):C.GC_6441,(0,16):C.GC_6441,(0,148):C.GC_6449,(0,151):C.GC_6045,(0,157):C.GC_6449,(0,158):C.GC_6485,(0,167):C.GC_6485,(0,40):C.GC_6485,(0,95):C.GC_6454,(0,106):C.GC_6048,(0,128):C.GC_6446,(0,138):C.GC_6490,(0,4):C.GC_6045})

V_559 = Vertex(name = 'V_559',
               particles = [ P.A, P.W__minus__, P.Z, P.G0, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVSS1, L.VVVSS139, L.VVVSS146, L.VVVSS177, L.VVVSS178, L.VVVSS183, L.VVVSS219, L.VVVSS224, L.VVVSS9 ],
               couplings = {(0,0):C.GC_6337,(0,8):C.GC_6332,(0,1):C.GC_6324,(0,3):C.GC_6330,(0,4):C.GC_6331,(0,6):C.GC_6325,(0,2):C.GC_6590,(0,5):C.GC_6124,(0,7):C.GC_6124})

V_560 = Vertex(name = 'V_560',
               particles = [ P.A, P.W__minus__, P.Z, P.G0, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVSS1, L.VVVSS139, L.VVVSS177, L.VVVSS178, L.VVVSS219, L.VVVSS9 ],
               couplings = {(0,0):C.GC_6578,(0,5):C.GC_6576,(0,1):C.GC_6566,(0,2):C.GC_6570,(0,3):C.GC_6568,(0,4):C.GC_6565})

V_561 = Vertex(name = 'V_561',
               particles = [ P.A, P.W__minus__, P.Z, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVSS1, L.VVVSS10, L.VVVSS103, L.VVVSS104, L.VVVSS105, L.VVVSS106, L.VVVSS107, L.VVVSS108, L.VVVSS109, L.VVVSS110, L.VVVSS111, L.VVVSS112, L.VVVSS113, L.VVVSS114, L.VVVSS115, L.VVVSS116, L.VVVSS118, L.VVVSS119, L.VVVSS12, L.VVVSS121, L.VVVSS122, L.VVVSS124, L.VVVSS125, L.VVVSS127, L.VVVSS128, L.VVVSS130, L.VVVSS136, L.VVVSS138, L.VVVSS139, L.VVVSS14, L.VVVSS140, L.VVVSS141, L.VVVSS142, L.VVVSS145, L.VVVSS147, L.VVVSS148, L.VVVSS15, L.VVVSS150, L.VVVSS151, L.VVVSS152, L.VVVSS155, L.VVVSS157, L.VVVSS158, L.VVVSS159, L.VVVSS16, L.VVVSS160, L.VVVSS161, L.VVVSS163, L.VVVSS164, L.VVVSS165, L.VVVSS166, L.VVVSS168, L.VVVSS169, L.VVVSS17, L.VVVSS170, L.VVVSS172, L.VVVSS177, L.VVVSS178, L.VVVSS179, L.VVVSS18, L.VVVSS180, L.VVVSS182, L.VVVSS183, L.VVVSS184, L.VVVSS185, L.VVVSS187, L.VVVSS189, L.VVVSS19, L.VVVSS190, L.VVVSS192, L.VVVSS194, L.VVVSS195, L.VVVSS196, L.VVVSS197, L.VVVSS198, L.VVVSS199, L.VVVSS2, L.VVVSS200, L.VVVSS202, L.VVVSS203, L.VVVSS204, L.VVVSS205, L.VVVSS206, L.VVVSS207, L.VVVSS208, L.VVVSS209, L.VVVSS21, L.VVVSS210, L.VVVSS218, L.VVVSS219, L.VVVSS22, L.VVVSS220, L.VVVSS221, L.VVVSS223, L.VVVSS224, L.VVVSS225, L.VVVSS226, L.VVVSS228, L.VVVSS229, L.VVVSS230, L.VVVSS233, L.VVVSS234, L.VVVSS235, L.VVVSS236, L.VVVSS237, L.VVVSS239, L.VVVSS240, L.VVVSS241, L.VVVSS242, L.VVVSS243, L.VVVSS244, L.VVVSS245, L.VVVSS247, L.VVVSS249, L.VVVSS25, L.VVVSS27, L.VVVSS28, L.VVVSS29, L.VVVSS32, L.VVVSS34, L.VVVSS36, L.VVVSS37, L.VVVSS39, L.VVVSS4, L.VVVSS41, L.VVVSS42, L.VVVSS43, L.VVVSS44, L.VVVSS45, L.VVVSS47, L.VVVSS48, L.VVVSS50, L.VVVSS51, L.VVVSS54, L.VVVSS56, L.VVVSS57, L.VVVSS58, L.VVVSS6, L.VVVSS60, L.VVVSS61, L.VVVSS62, L.VVVSS64, L.VVVSS65, L.VVVSS66, L.VVVSS68, L.VVVSS7, L.VVVSS70, L.VVVSS71, L.VVVSS72, L.VVVSS73, L.VVVSS75, L.VVVSS76, L.VVVSS77, L.VVVSS8, L.VVVSS80, L.VVVSS81, L.VVVSS83, L.VVVSS85, L.VVVSS87, L.VVVSS88, L.VVVSS89, L.VVVSS9, L.VVVSS90, L.VVVSS91, L.VVVSS92, L.VVVSS93, L.VVVSS95, L.VVVSS96, L.VVVSS98 ],
               couplings = {(0,0):C.GC_2135,(0,161):C.GC_1546,(0,44):C.GC_1468,(0,53):C.GC_201,(0,29):C.GC_1470,(0,36):C.GC_1469,(0,137):C.GC_200,(0,123):C.GC_196,(0,153):C.GC_1467,(0,145):C.GC_197,(0,28):C.GC_2130,(0,33):C.GC_1470,(0,56):C.GC_2131,(0,61):C.GC_200,(0,57):C.GC_1544,(0,93):C.GC_1467,(0,89):C.GC_1543,(0,59):C.GC_1470,(0,58):C.GC_196,(0,91):C.GC_197,(0,18):C.GC_200,(0,31):C.GC_197,(0,92):C.GC_196,(0,1):C.GC_1467,(0,32):C.GC_196,(0,60):C.GC_197,(0,127):C.GC_6040,(0,131):C.GC_1601,(0,129):C.GC_1608,(0,86):C.GC_6038,(0,67):C.GC_6031,(0,114):C.GC_1603,(0,90):C.GC_6368,(0,115):C.GC_6028,(0,118):C.GC_6388,(0,117):C.GC_6381,(0,120):C.GC_730,(0,119):C.GC_726,(0,122):C.GC_1604,(0,121):C.GC_6367,(0,5):C.GC_6484,(0,11):C.GC_1603,(0,7):C.GC_6459,(0,8):C.GC_1606,(0,15):C.GC_6481,(0,21):C.GC_6459,(0,134):C.GC_6477,(0,133):C.GC_6416,(0,138):C.GC_1601,(0,139):C.GC_1598,(0,135):C.GC_6371,(0,136):C.GC_1590,(0,143):C.GC_6467,(0,140):C.GC_6411,(0,141):C.GC_6417,(0,142):C.GC_6408,(0,146):C.GC_6427,(0,150):C.GC_6390,(0,148):C.GC_6383,(0,149):C.GC_6422,(0,152):C.GC_6421,(0,154):C.GC_6422,(0,158):C.GC_1597,(0,157):C.GC_1589,(0,162):C.GC_1602,(0,163):C.GC_6473,(0,159):C.GC_6372,(0,160):C.GC_6412,(0,168):C.GC_6473,(0,164):C.GC_6407,(0,165):C.GC_6418,(0,166):C.GC_6412,(0,40):C.GC_1601,(0,51):C.GC_1603,(0,66):C.GC_6040,(0,78):C.GC_6484,(0,82):C.GC_6459,(0,100):C.GC_1608,(0,111):C.GC_1606,(0,34):C.GC_725,(0,42):C.GC_1587,(0,63):C.GC_6029,(0,71):C.GC_6414,(0,95):C.GC_6026,(0,102):C.GC_6425,(0,35):C.GC_6374,(0,43):C.GC_6369,(0,64):C.GC_6384,(0,72):C.GC_6382,(0,96):C.GC_6373,(0,103):C.GC_6370,(0,128):C.GC_6038,(0,132):C.GC_1603,(0,26):C.GC_6458,(0,37):C.GC_6026,(0,46):C.GC_6421,(0,68):C.GC_6373,(0,74):C.GC_6407,(0,97):C.GC_6031,(0,99):C.GC_6368,(0,6):C.GC_6477,(0,12):C.GC_1601,(0,24):C.GC_6472,(0,47):C.GC_6425,(0,54):C.GC_6411,(0,79):C.GC_6370,(0,83):C.GC_6417,(0,106):C.GC_6416,(0,108):C.GC_6371,(0,45):C.GC_6418,(0,73):C.GC_6408,(0,104):C.GC_1588,(0,38):C.GC_6029,(0,65):C.GC_6028,(0,48):C.GC_6414,(0,77):C.GC_6427,(0,80):C.GC_6422,(0,109):C.GC_6408,(0,130):C.GC_1606,(0,27):C.GC_6482,(0,39):C.GC_6367,(0,69):C.GC_6374,(0,75):C.GC_6408,(0,105):C.GC_6422,(0,9):C.GC_1608,(0,10):C.GC_6468,(0,25):C.GC_6468,(0,49):C.GC_6372,(0,50):C.GC_6412,(0,81):C.GC_6369,(0,84):C.GC_6418,(0,110):C.GC_6418,(0,112):C.GC_6412,(0,22):C.GC_2148,(0,23):C.GC_1598,(0,55):C.GC_2146,(0,85):C.GC_2145,(0,87):C.GC_1588,(0,113):C.GC_1590,(0,76):C.GC_6087,(0,124):C.GC_6087,(0,2):C.GC_6085,(0,30):C.GC_6080,(0,41):C.GC_6586,(0,62):C.GC_6079,(0,70):C.GC_6588,(0,88):C.GC_6079,(0,94):C.GC_6080,(0,101):C.GC_6587,(0,125):C.GC_6039,(0,116):C.GC_6037,(0,3):C.GC_6483,(0,13):C.GC_6457,(0,16):C.GC_6478,(0,17):C.GC_6478,(0,19):C.GC_6457,(0,20):C.GC_6457,(0,144):C.GC_6464,(0,147):C.GC_6476,(0,151):C.GC_6471,(0,155):C.GC_6464,(0,156):C.GC_6471,(0,167):C.GC_6471,(0,52):C.GC_6457,(0,98):C.GC_6039,(0,107):C.GC_6483,(0,126):C.GC_6037,(0,4):C.GC_6476,(0,14):C.GC_6464})

V_562 = Vertex(name = 'V_562',
               particles = [ P.A, P.W__minus__, P.Z, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVSS1, L.VVVSS139, L.VVVSS177, L.VVVSS178, L.VVVSS194, L.VVVSS219, L.VVVSS234, L.VVVSS9 ],
               couplings = {(0,0):C.GC_6333,(0,7):C.GC_6336,(0,1):C.GC_6328,(0,2):C.GC_6326,(0,3):C.GC_6327,(0,5):C.GC_6329,(0,4):C.GC_6122,(0,6):C.GC_6123})

V_563 = Vertex(name = 'V_563',
               particles = [ P.A, P.W__minus__, P.Z, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVSS1, L.VVVSS139, L.VVVSS177, L.VVVSS178, L.VVVSS219, L.VVVSS9 ],
               couplings = {(0,0):C.GC_6580,(0,5):C.GC_6574,(0,1):C.GC_6564,(0,2):C.GC_6572,(0,3):C.GC_6571,(0,4):C.GC_6562})

V_564 = Vertex(name = 'V_564',
               particles = [ P.A, P.W__minus__, P.Z, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVS1, L.VVVS10, L.VVVS100, L.VVVS101, L.VVVS102, L.VVVS104, L.VVVS105, L.VVVS106, L.VVVS107, L.VVVS109, L.VVVS110, L.VVVS111, L.VVVS114, L.VVVS12, L.VVVS14, L.VVVS15, L.VVVS16, L.VVVS17, L.VVVS18, L.VVVS19, L.VVVS2, L.VVVS21, L.VVVS22, L.VVVS25, L.VVVS27, L.VVVS28, L.VVVS29, L.VVVS32, L.VVVS35, L.VVVS37, L.VVVS38, L.VVVS4, L.VVVS40, L.VVVS45, L.VVVS46, L.VVVS47, L.VVVS48, L.VVVS49, L.VVVS51, L.VVVS52, L.VVVS54, L.VVVS55, L.VVVS58, L.VVVS59, L.VVVS6, L.VVVS60, L.VVVS61, L.VVVS64, L.VVVS66, L.VVVS67, L.VVVS69, L.VVVS7, L.VVVS70, L.VVVS71, L.VVVS74, L.VVVS77, L.VVVS78, L.VVVS79, L.VVVS8, L.VVVS80, L.VVVS82, L.VVVS83, L.VVVS84, L.VVVS85, L.VVVS87, L.VVVS89, L.VVVS9, L.VVVS90, L.VVVS92, L.VVVS99 ],
               couplings = {(0,0):C.GC_2128,(0,66):C.GC_1540,(0,36):C.GC_6002,(0,40):C.GC_1554,(0,38):C.GC_1561,(0,21):C.GC_6000,(0,19):C.GC_5997,(0,23):C.GC_1556,(0,22):C.GC_6264,(0,24):C.GC_5994,(0,27):C.GC_6269,(0,26):C.GC_6267,(0,29):C.GC_586,(0,28):C.GC_584,(0,32):C.GC_1557,(0,30):C.GC_6263,(0,42):C.GC_2125,(0,54):C.GC_1554,(0,55):C.GC_2126,(0,56):C.GC_1539,(0,65):C.GC_6002,(0,2):C.GC_1538,(0,12):C.GC_1561,(0,48):C.GC_583,(0,62):C.GC_5995,(0,7):C.GC_5992,(0,49):C.GC_6266,(0,63):C.GC_6268,(0,8):C.GC_6265,(0,37):C.GC_6000,(0,41):C.GC_1556,(0,50):C.GC_5992,(0,67):C.GC_6265,(0,9):C.GC_5997,(0,11):C.GC_6264,(0,52):C.GC_5995,(0,64):C.GC_5994,(0,39):C.GC_1559,(0,53):C.GC_6263,(0,68):C.GC_6266,(0,16):C.GC_1529,(0,17):C.GC_293,(0,14):C.GC_1531,(0,15):C.GC_1530,(0,44):C.GC_292,(0,58):C.GC_1528,(0,47):C.GC_1531,(0,60):C.GC_292,(0,5):C.GC_1528,(0,18):C.GC_1531,(0,13):C.GC_292,(0,1):C.GC_1528,(0,31):C.GC_290,(0,51):C.GC_291,(0,57):C.GC_290,(0,3):C.GC_291,(0,45):C.GC_291,(0,4):C.GC_290,(0,46):C.GC_290,(0,59):C.GC_291,(0,34):C.GC_6001,(0,25):C.GC_5999,(0,10):C.GC_6001,(0,35):C.GC_5999,(0,20):C.GC_6095,(0,33):C.GC_6095,(0,43):C.GC_6093,(0,61):C.GC_6092,(0,69):C.GC_6092,(0,6):C.GC_6093})

V_565 = Vertex(name = 'V_565',
               particles = [ P.A, P.W__minus__, P.Z, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVS1, L.VVVS100, L.VVVS58, L.VVVS77, L.VVVS78, L.VVVS9 ],
               couplings = {(0,0):C.GC_6320,(0,5):C.GC_6323,(0,2):C.GC_6318,(0,3):C.GC_6316,(0,4):C.GC_6317,(0,1):C.GC_6319})

V_566 = Vertex(name = 'V_566',
               particles = [ P.A, P.W__minus__, P.Z, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVS1, L.VVVS100, L.VVVS58, L.VVVS77, L.VVVS78, L.VVVS9 ],
               couplings = {(0,0):C.GC_6604,(0,5):C.GC_6601,(0,2):C.GC_6597,(0,3):C.GC_6599,(0,4):C.GC_6598,(0,1):C.GC_6595})

V_567 = Vertex(name = 'V_567',
               particles = [ P.A, P.W__plus__, P.Z, P.G0, P.G__minus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVSS1, L.VVVSS10, L.VVVSS103, L.VVVSS104, L.VVVSS105, L.VVVSS106, L.VVVSS107, L.VVVSS109, L.VVVSS110, L.VVVSS112, L.VVVSS113, L.VVVSS116, L.VVVSS118, L.VVVSS119, L.VVVSS12, L.VVVSS121, L.VVVSS122, L.VVVSS124, L.VVVSS125, L.VVVSS127, L.VVVSS128, L.VVVSS130, L.VVVSS136, L.VVVSS138, L.VVVSS139, L.VVVSS14, L.VVVSS140, L.VVVSS141, L.VVVSS142, L.VVVSS145, L.VVVSS146, L.VVVSS147, L.VVVSS148, L.VVVSS149, L.VVVSS15, L.VVVSS150, L.VVVSS151, L.VVVSS152, L.VVVSS153, L.VVVSS155, L.VVVSS156, L.VVVSS158, L.VVVSS159, L.VVVSS16, L.VVVSS161, L.VVVSS163, L.VVVSS164, L.VVVSS165, L.VVVSS168, L.VVVSS17, L.VVVSS170, L.VVVSS172, L.VVVSS177, L.VVVSS178, L.VVVSS179, L.VVVSS18, L.VVVSS180, L.VVVSS182, L.VVVSS183, L.VVVSS184, L.VVVSS185, L.VVVSS186, L.VVVSS187, L.VVVSS189, L.VVVSS19, L.VVVSS190, L.VVVSS191, L.VVVSS192, L.VVVSS193, L.VVVSS194, L.VVVSS195, L.VVVSS196, L.VVVSS198, L.VVVSS199, L.VVVSS2, L.VVVSS200, L.VVVSS202, L.VVVSS203, L.VVVSS205, L.VVVSS207, L.VVVSS208, L.VVVSS209, L.VVVSS21, L.VVVSS210, L.VVVSS218, L.VVVSS219, L.VVVSS22, L.VVVSS220, L.VVVSS221, L.VVVSS223, L.VVVSS224, L.VVVSS225, L.VVVSS226, L.VVVSS227, L.VVVSS228, L.VVVSS229, L.VVVSS23, L.VVVSS230, L.VVVSS231, L.VVVSS232, L.VVVSS233, L.VVVSS234, L.VVVSS235, L.VVVSS236, L.VVVSS239, L.VVVSS240, L.VVVSS241, L.VVVSS242, L.VVVSS245, L.VVVSS247, L.VVVSS249, L.VVVSS25, L.VVVSS26, L.VVVSS27, L.VVVSS28, L.VVVSS29, L.VVVSS30, L.VVVSS32, L.VVVSS33, L.VVVSS34, L.VVVSS36, L.VVVSS37, L.VVVSS38, L.VVVSS39, L.VVVSS4, L.VVVSS40, L.VVVSS41, L.VVVSS42, L.VVVSS43, L.VVVSS44, L.VVVSS45, L.VVVSS46, L.VVVSS47, L.VVVSS48, L.VVVSS49, L.VVVSS50, L.VVVSS51, L.VVVSS52, L.VVVSS53, L.VVVSS54, L.VVVSS56, L.VVVSS57, L.VVVSS6, L.VVVSS60, L.VVVSS62, L.VVVSS64, L.VVVSS65, L.VVVSS66, L.VVVSS68, L.VVVSS7, L.VVVSS70, L.VVVSS71, L.VVVSS72, L.VVVSS75, L.VVVSS77, L.VVVSS8, L.VVVSS80, L.VVVSS81, L.VVVSS83, L.VVVSS85, L.VVVSS87, L.VVVSS88, L.VVVSS9, L.VVVSS90, L.VVVSS92, L.VVVSS93, L.VVVSS95, L.VVVSS96, L.VVVSS98 ],
               couplings = {(0,0):C.GC_2133,(0,162):C.GC_1548,(0,43):C.GC_1471,(0,49):C.GC_199,(0,25):C.GC_1466,(0,34):C.GC_1465,(0,142):C.GC_202,(0,124):C.GC_198,(0,155):C.GC_1472,(0,149):C.GC_195,(0,24):C.GC_2132,(0,29):C.GC_1466,(0,52):C.GC_2129,(0,57):C.GC_202,(0,53):C.GC_1542,(0,89):C.GC_1472,(0,85):C.GC_1545,(0,55):C.GC_1466,(0,54):C.GC_198,(0,87):C.GC_195,(0,14):C.GC_202,(0,27):C.GC_195,(0,88):C.GC_198,(0,1):C.GC_1472,(0,28):C.GC_198,(0,56):C.GC_195,(0,129):C.GC_6447,(0,135):C.GC_1609,(0,131):C.GC_6494,(0,132):C.GC_1600,(0,82):C.GC_6456,(0,64):C.GC_6437,(0,111):C.GC_1611,(0,112):C.GC_1594,(0,86):C.GC_6366,(0,96):C.GC_1586,(0,113):C.GC_6402,(0,117):C.GC_6387,(0,115):C.GC_6380,(0,116):C.GC_6396,(0,120):C.GC_1593,(0,119):C.GC_1585,(0,123):C.GC_1612,(0,125):C.GC_6453,(0,121):C.GC_6365,(0,122):C.GC_6430,(0,5):C.GC_6046,(0,9):C.GC_1611,(0,7):C.GC_1599,(0,11):C.GC_6486,(0,17):C.GC_6453,(0,140):C.GC_6050,(0,139):C.GC_6022,(0,143):C.GC_1609,(0,141):C.GC_6377,(0,147):C.GC_6442,(0,144):C.GC_6395,(0,145):C.GC_6433,(0,146):C.GC_6400,(0,150):C.GC_6033,(0,153):C.GC_6392,(0,152):C.GC_6386,(0,154):C.GC_6429,(0,156):C.GC_6430,(0,160):C.GC_728,(0,159):C.GC_724,(0,163):C.GC_1610,(0,161):C.GC_6378,(0,168):C.GC_6494,(0,164):C.GC_6399,(0,165):C.GC_6434,(0,166):C.GC_6396,(0,39):C.GC_1609,(0,48):C.GC_1611,(0,63):C.GC_6447,(0,68):C.GC_6494,(0,76):C.GC_6046,(0,100):C.GC_1600,(0,108):C.GC_1599,(0,31):C.GC_1592,(0,41):C.GC_727,(0,59):C.GC_6439,(0,70):C.GC_6024,(0,91):C.GC_6404,(0,102):C.GC_6035,(0,32):C.GC_6376,(0,42):C.GC_6363,(0,60):C.GC_6385,(0,71):C.GC_6379,(0,92):C.GC_6375,(0,103):C.GC_6364,(0,130):C.GC_6456,(0,136):C.GC_1611,(0,22):C.GC_6452,(0,35):C.GC_6404,(0,44):C.GC_6429,(0,65):C.GC_6375,(0,72):C.GC_6399,(0,94):C.GC_6437,(0,97):C.GC_6366,(0,6):C.GC_6050,(0,10):C.GC_1609,(0,20):C.GC_6493,(0,45):C.GC_6035,(0,50):C.GC_6395,(0,77):C.GC_6364,(0,79):C.GC_6433,(0,105):C.GC_6022,(0,107):C.GC_6377,(0,33):C.GC_6400,(0,61):C.GC_6434,(0,93):C.GC_1591,(0,36):C.GC_6439,(0,62):C.GC_6402,(0,66):C.GC_6396,(0,98):C.GC_6434,(0,46):C.GC_6024,(0,75):C.GC_6033,(0,133):C.GC_1599,(0,134):C.GC_6487,(0,23):C.GC_6487,(0,37):C.GC_6365,(0,38):C.GC_6430,(0,67):C.GC_6376,(0,73):C.GC_6400,(0,99):C.GC_6400,(0,104):C.GC_6430,(0,8):C.GC_1600,(0,21):C.GC_6443,(0,47):C.GC_6378,(0,78):C.GC_6363,(0,80):C.GC_6434,(0,109):C.GC_6396,(0,18):C.GC_2150,(0,19):C.GC_1594,(0,51):C.GC_2144,(0,81):C.GC_2147,(0,83):C.GC_1591,(0,110):C.GC_1586,(0,74):C.GC_6089,(0,126):C.GC_6089,(0,2):C.GC_6089,(0,26):C.GC_6082,(0,30):C.GC_3972,(0,58):C.GC_6592,(0,69):C.GC_6077,(0,84):C.GC_6077,(0,90):C.GC_6583,(0,101):C.GC_6082,(0,127):C.GC_6446,(0,137):C.GC_6490,(0,114):C.GC_6454,(0,118):C.GC_6449,(0,3):C.GC_6045,(0,12):C.GC_6485,(0,13):C.GC_6485,(0,15):C.GC_6449,(0,16):C.GC_6449,(0,148):C.GC_6441,(0,151):C.GC_6048,(0,157):C.GC_6441,(0,158):C.GC_6490,(0,167):C.GC_6490,(0,40):C.GC_6490,(0,95):C.GC_6446,(0,106):C.GC_6045,(0,128):C.GC_6454,(0,138):C.GC_6485,(0,4):C.GC_6048})

V_568 = Vertex(name = 'V_568',
               particles = [ P.A, P.W__plus__, P.Z, P.G0, P.G__minus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVSS1, L.VVVSS139, L.VVVSS146, L.VVVSS177, L.VVVSS178, L.VVVSS183, L.VVVSS219, L.VVVSS224, L.VVVSS9 ],
               couplings = {(0,0):C.GC_6337,(0,8):C.GC_6332,(0,1):C.GC_6324,(0,3):C.GC_6330,(0,4):C.GC_6331,(0,6):C.GC_6325,(0,2):C.GC_6582,(0,5):C.GC_6124,(0,7):C.GC_6124})

V_569 = Vertex(name = 'V_569',
               particles = [ P.A, P.W__plus__, P.Z, P.G0, P.G__minus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVSS1, L.VVVSS139, L.VVVSS177, L.VVVSS178, L.VVVSS219, L.VVVSS9 ],
               couplings = {(0,0):C.GC_6577,(0,5):C.GC_6576,(0,1):C.GC_6567,(0,2):C.GC_6569,(0,3):C.GC_6568,(0,4):C.GC_6565})

V_570 = Vertex(name = 'V_570',
               particles = [ P.A, P.W__plus__, P.Z, P.G__minus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVSS1, L.VVVSS10, L.VVVSS103, L.VVVSS104, L.VVVSS105, L.VVVSS106, L.VVVSS107, L.VVVSS108, L.VVVSS109, L.VVVSS110, L.VVVSS111, L.VVVSS112, L.VVVSS113, L.VVVSS114, L.VVVSS115, L.VVVSS116, L.VVVSS118, L.VVVSS119, L.VVVSS12, L.VVVSS121, L.VVVSS122, L.VVVSS124, L.VVVSS125, L.VVVSS127, L.VVVSS128, L.VVVSS130, L.VVVSS136, L.VVVSS138, L.VVVSS139, L.VVVSS14, L.VVVSS140, L.VVVSS141, L.VVVSS142, L.VVVSS145, L.VVVSS147, L.VVVSS148, L.VVVSS15, L.VVVSS150, L.VVVSS151, L.VVVSS152, L.VVVSS155, L.VVVSS157, L.VVVSS158, L.VVVSS159, L.VVVSS16, L.VVVSS160, L.VVVSS161, L.VVVSS163, L.VVVSS164, L.VVVSS165, L.VVVSS166, L.VVVSS168, L.VVVSS169, L.VVVSS17, L.VVVSS170, L.VVVSS172, L.VVVSS177, L.VVVSS178, L.VVVSS179, L.VVVSS18, L.VVVSS180, L.VVVSS182, L.VVVSS183, L.VVVSS184, L.VVVSS185, L.VVVSS187, L.VVVSS189, L.VVVSS19, L.VVVSS190, L.VVVSS192, L.VVVSS194, L.VVVSS195, L.VVVSS196, L.VVVSS197, L.VVVSS198, L.VVVSS199, L.VVVSS2, L.VVVSS200, L.VVVSS202, L.VVVSS203, L.VVVSS204, L.VVVSS205, L.VVVSS206, L.VVVSS207, L.VVVSS208, L.VVVSS209, L.VVVSS21, L.VVVSS210, L.VVVSS218, L.VVVSS219, L.VVVSS22, L.VVVSS220, L.VVVSS221, L.VVVSS223, L.VVVSS224, L.VVVSS225, L.VVVSS226, L.VVVSS228, L.VVVSS229, L.VVVSS230, L.VVVSS233, L.VVVSS234, L.VVVSS235, L.VVVSS236, L.VVVSS237, L.VVVSS239, L.VVVSS240, L.VVVSS241, L.VVVSS242, L.VVVSS243, L.VVVSS244, L.VVVSS245, L.VVVSS247, L.VVVSS249, L.VVVSS25, L.VVVSS27, L.VVVSS28, L.VVVSS29, L.VVVSS32, L.VVVSS34, L.VVVSS36, L.VVVSS37, L.VVVSS39, L.VVVSS4, L.VVVSS41, L.VVVSS42, L.VVVSS43, L.VVVSS44, L.VVVSS45, L.VVVSS47, L.VVVSS48, L.VVVSS50, L.VVVSS51, L.VVVSS54, L.VVVSS56, L.VVVSS57, L.VVVSS58, L.VVVSS6, L.VVVSS60, L.VVVSS61, L.VVVSS62, L.VVVSS64, L.VVVSS65, L.VVVSS66, L.VVVSS68, L.VVVSS7, L.VVVSS70, L.VVVSS71, L.VVVSS72, L.VVVSS73, L.VVVSS75, L.VVVSS76, L.VVVSS77, L.VVVSS8, L.VVVSS80, L.VVVSS81, L.VVVSS83, L.VVVSS85, L.VVVSS87, L.VVVSS88, L.VVVSS89, L.VVVSS9, L.VVVSS90, L.VVVSS91, L.VVVSS92, L.VVVSS93, L.VVVSS95, L.VVVSS96, L.VVVSS98 ],
               couplings = {(0,0):C.GC_2134,(0,161):C.GC_1547,(0,44):C.GC_1470,(0,53):C.GC_200,(0,29):C.GC_1468,(0,36):C.GC_1467,(0,137):C.GC_201,(0,123):C.GC_197,(0,153):C.GC_1469,(0,145):C.GC_196,(0,28):C.GC_2131,(0,33):C.GC_1468,(0,56):C.GC_2130,(0,61):C.GC_201,(0,57):C.GC_1543,(0,93):C.GC_1469,(0,89):C.GC_1544,(0,59):C.GC_1468,(0,58):C.GC_197,(0,91):C.GC_196,(0,18):C.GC_201,(0,31):C.GC_196,(0,92):C.GC_197,(0,1):C.GC_1469,(0,32):C.GC_197,(0,60):C.GC_196,(0,127):C.GC_6044,(0,131):C.GC_1605,(0,129):C.GC_1604,(0,86):C.GC_6042,(0,67):C.GC_6025,(0,114):C.GC_1607,(0,90):C.GC_6374,(0,115):C.GC_6030,(0,118):C.GC_6391,(0,117):C.GC_6384,(0,120):C.GC_729,(0,119):C.GC_725,(0,122):C.GC_1608,(0,121):C.GC_6373,(0,5):C.GC_6470,(0,11):C.GC_1607,(0,7):C.GC_6475,(0,8):C.GC_1602,(0,15):C.GC_6465,(0,21):C.GC_6475,(0,134):C.GC_6463,(0,133):C.GC_6426,(0,138):C.GC_1605,(0,139):C.GC_1596,(0,135):C.GC_6369,(0,136):C.GC_1588,(0,143):C.GC_6479,(0,140):C.GC_6419,(0,141):C.GC_6409,(0,142):C.GC_6424,(0,146):C.GC_6413,(0,150):C.GC_6389,(0,148):C.GC_6382,(0,149):C.GC_6406,(0,152):C.GC_6405,(0,154):C.GC_6406,(0,158):C.GC_1595,(0,157):C.GC_1587,(0,162):C.GC_1606,(0,163):C.GC_6461,(0,159):C.GC_6370,(0,160):C.GC_6420,(0,168):C.GC_6461,(0,164):C.GC_6423,(0,165):C.GC_6410,(0,166):C.GC_6420,(0,40):C.GC_1605,(0,51):C.GC_1607,(0,66):C.GC_6044,(0,78):C.GC_6470,(0,82):C.GC_6475,(0,100):C.GC_1604,(0,111):C.GC_1602,(0,34):C.GC_726,(0,42):C.GC_1589,(0,63):C.GC_6027,(0,71):C.GC_6428,(0,95):C.GC_6032,(0,102):C.GC_6415,(0,35):C.GC_6368,(0,43):C.GC_6371,(0,64):C.GC_6381,(0,72):C.GC_6383,(0,96):C.GC_6367,(0,103):C.GC_6372,(0,128):C.GC_6042,(0,132):C.GC_1607,(0,26):C.GC_6474,(0,37):C.GC_6032,(0,46):C.GC_6405,(0,68):C.GC_6367,(0,74):C.GC_6423,(0,97):C.GC_6025,(0,99):C.GC_6374,(0,6):C.GC_6463,(0,12):C.GC_1605,(0,24):C.GC_6460,(0,47):C.GC_6415,(0,54):C.GC_6419,(0,79):C.GC_6372,(0,83):C.GC_6409,(0,106):C.GC_6426,(0,108):C.GC_6369,(0,45):C.GC_6410,(0,73):C.GC_6424,(0,104):C.GC_1590,(0,38):C.GC_6027,(0,65):C.GC_6030,(0,48):C.GC_6428,(0,77):C.GC_6413,(0,80):C.GC_6406,(0,109):C.GC_6424,(0,130):C.GC_1602,(0,27):C.GC_6466,(0,39):C.GC_6373,(0,69):C.GC_6368,(0,75):C.GC_6424,(0,105):C.GC_6406,(0,9):C.GC_1604,(0,10):C.GC_6480,(0,25):C.GC_6480,(0,49):C.GC_6370,(0,50):C.GC_6420,(0,81):C.GC_6371,(0,84):C.GC_6410,(0,110):C.GC_6410,(0,112):C.GC_6420,(0,22):C.GC_2149,(0,23):C.GC_1596,(0,55):C.GC_2145,(0,85):C.GC_2146,(0,87):C.GC_1590,(0,113):C.GC_1588,(0,76):C.GC_6088,(0,124):C.GC_6088,(0,2):C.GC_6086,(0,30):C.GC_6081,(0,41):C.GC_6584,(0,62):C.GC_6078,(0,70):C.GC_6589,(0,88):C.GC_6078,(0,94):C.GC_6081,(0,101):C.GC_6585,(0,125):C.GC_6043,(0,116):C.GC_6041,(0,3):C.GC_6469,(0,13):C.GC_6471,(0,16):C.GC_6464,(0,17):C.GC_6464,(0,19):C.GC_6471,(0,20):C.GC_6471,(0,144):C.GC_6478,(0,147):C.GC_6462,(0,151):C.GC_6457,(0,155):C.GC_6478,(0,156):C.GC_6457,(0,167):C.GC_6457,(0,52):C.GC_6471,(0,98):C.GC_6043,(0,107):C.GC_6469,(0,126):C.GC_6041,(0,4):C.GC_6462,(0,14):C.GC_6478})

V_571 = Vertex(name = 'V_571',
               particles = [ P.A, P.W__plus__, P.Z, P.G__minus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVSS1, L.VVVSS139, L.VVVSS177, L.VVVSS178, L.VVVSS194, L.VVVSS219, L.VVVSS234, L.VVVSS9 ],
               couplings = {(0,0):C.GC_6335,(0,7):C.GC_6334,(0,1):C.GC_6326,(0,2):C.GC_6328,(0,3):C.GC_6329,(0,5):C.GC_6327,(0,4):C.GC_6123,(0,6):C.GC_6122})

V_572 = Vertex(name = 'V_572',
               particles = [ P.A, P.W__plus__, P.Z, P.G__minus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVSS1, L.VVVSS139, L.VVVSS177, L.VVVSS178, L.VVVSS219, L.VVVSS9 ],
               couplings = {(0,0):C.GC_6575,(0,5):C.GC_6579,(0,1):C.GC_6573,(0,2):C.GC_6563,(0,3):C.GC_6562,(0,4):C.GC_6571})

V_573 = Vertex(name = 'V_573',
               particles = [ P.A, P.W__plus__, P.Z, P.G__minus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVS1, L.VVVS10, L.VVVS100, L.VVVS101, L.VVVS102, L.VVVS104, L.VVVS105, L.VVVS106, L.VVVS107, L.VVVS109, L.VVVS110, L.VVVS111, L.VVVS114, L.VVVS12, L.VVVS14, L.VVVS15, L.VVVS16, L.VVVS17, L.VVVS18, L.VVVS19, L.VVVS2, L.VVVS21, L.VVVS22, L.VVVS25, L.VVVS27, L.VVVS28, L.VVVS29, L.VVVS32, L.VVVS35, L.VVVS37, L.VVVS38, L.VVVS4, L.VVVS40, L.VVVS45, L.VVVS46, L.VVVS47, L.VVVS48, L.VVVS49, L.VVVS51, L.VVVS52, L.VVVS54, L.VVVS55, L.VVVS58, L.VVVS59, L.VVVS6, L.VVVS60, L.VVVS61, L.VVVS64, L.VVVS66, L.VVVS67, L.VVVS69, L.VVVS7, L.VVVS70, L.VVVS71, L.VVVS74, L.VVVS77, L.VVVS78, L.VVVS79, L.VVVS8, L.VVVS80, L.VVVS82, L.VVVS83, L.VVVS84, L.VVVS85, L.VVVS87, L.VVVS89, L.VVVS9, L.VVVS90, L.VVVS92, L.VVVS99 ],
               couplings = {(0,0):C.GC_2127,(0,66):C.GC_1541,(0,36):C.GC_6006,(0,40):C.GC_1558,(0,38):C.GC_1557,(0,21):C.GC_6004,(0,19):C.GC_5991,(0,23):C.GC_1560,(0,22):C.GC_6266,(0,24):C.GC_5996,(0,27):C.GC_6270,(0,26):C.GC_6268,(0,29):C.GC_585,(0,28):C.GC_583,(0,32):C.GC_1561,(0,30):C.GC_6265,(0,42):C.GC_2126,(0,54):C.GC_1558,(0,55):C.GC_2125,(0,56):C.GC_1538,(0,65):C.GC_6006,(0,2):C.GC_1539,(0,12):C.GC_1557,(0,48):C.GC_584,(0,62):C.GC_5993,(0,7):C.GC_5998,(0,49):C.GC_6264,(0,63):C.GC_6267,(0,8):C.GC_6263,(0,37):C.GC_6004,(0,41):C.GC_1560,(0,50):C.GC_5998,(0,67):C.GC_6263,(0,9):C.GC_5991,(0,11):C.GC_6266,(0,52):C.GC_5993,(0,64):C.GC_5996,(0,39):C.GC_1555,(0,53):C.GC_6265,(0,68):C.GC_6264,(0,16):C.GC_1531,(0,17):C.GC_292,(0,14):C.GC_1529,(0,15):C.GC_1528,(0,44):C.GC_293,(0,58):C.GC_1530,(0,47):C.GC_1529,(0,60):C.GC_293,(0,5):C.GC_1530,(0,18):C.GC_1529,(0,13):C.GC_293,(0,1):C.GC_1530,(0,31):C.GC_291,(0,51):C.GC_290,(0,57):C.GC_291,(0,3):C.GC_290,(0,45):C.GC_290,(0,4):C.GC_291,(0,46):C.GC_291,(0,59):C.GC_290,(0,34):C.GC_6005,(0,25):C.GC_6003,(0,10):C.GC_6005,(0,35):C.GC_6003,(0,20):C.GC_6096,(0,33):C.GC_6096,(0,43):C.GC_6094,(0,61):C.GC_6091,(0,69):C.GC_6091,(0,6):C.GC_6094})

V_574 = Vertex(name = 'V_574',
               particles = [ P.A, P.W__plus__, P.Z, P.G__minus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVS1, L.VVVS100, L.VVVS58, L.VVVS77, L.VVVS78, L.VVVS9 ],
               couplings = {(0,0):C.GC_6322,(0,5):C.GC_6321,(0,2):C.GC_6316,(0,3):C.GC_6318,(0,4):C.GC_6319,(0,1):C.GC_6317})

V_575 = Vertex(name = 'V_575',
               particles = [ P.A, P.W__plus__, P.Z, P.G__minus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVS1, L.VVVS100, L.VVVS58, L.VVVS77, L.VVVS78, L.VVVS9 ],
               couplings = {(0,0):C.GC_6602,(0,5):C.GC_6603,(0,2):C.GC_6600,(0,3):C.GC_6596,(0,4):C.GC_6595,(0,1):C.GC_6598})

V_576 = Vertex(name = 'V_576',
               particles = [ P.W__minus__, P.W__plus__, P.Z ],
               color = [ '1' ],
               lorentz = [ L.VVV1, L.VVV10, L.VVV11, L.VVV12, L.VVV13, L.VVV14, L.VVV15, L.VVV16, L.VVV17, L.VVV18, L.VVV19, L.VVV2, L.VVV20, L.VVV21, L.VVV22, L.VVV23, L.VVV24, L.VVV25, L.VVV26, L.VVV27, L.VVV28, L.VVV29, L.VVV3, L.VVV4, L.VVV5, L.VVV6, L.VVV7, L.VVV8, L.VVV9 ],
               couplings = {(0,3):C.GC_2349,(0,4):C.GC_2349,(0,1):C.GC_2348,(0,2):C.GC_2349,(0,23):C.GC_2348,(0,22):C.GC_2347,(0,25):C.GC_2348,(0,24):C.GC_2346,(0,10):C.GC_2348,(0,16):C.GC_2348,(0,21):C.GC_2348,(0,5):C.GC_2348,(0,14):C.GC_2347,(0,19):C.GC_2346,(0,28):C.GC_2348,(0,8):C.GC_2346,(0,20):C.GC_2347,(0,27):C.GC_2348,(0,9):C.GC_2347,(0,15):C.GC_2346,(0,0):C.GC_2392,(0,11):C.GC_2392,(0,26):C.GC_5705,(0,6):C.GC_2385,(0,7):C.GC_2386,(0,12):C.GC_2386,(0,13):C.GC_2385,(0,17):C.GC_2385,(0,18):C.GC_2386})

V_577 = Vertex(name = 'V_577',
               particles = [ P.W__minus__, P.W__plus__, P.Z ],
               color = [ '1' ],
               lorentz = [ L.VVV1, L.VVV10, L.VVV11, L.VVV12, L.VVV13, L.VVV14, L.VVV15, L.VVV16, L.VVV17, L.VVV18, L.VVV19, L.VVV2, L.VVV20, L.VVV21, L.VVV22, L.VVV23, L.VVV24, L.VVV25, L.VVV26, L.VVV27, L.VVV28, L.VVV29, L.VVV3, L.VVV4, L.VVV5, L.VVV6, L.VVV7, L.VVV8, L.VVV9 ],
               couplings = {(0,3):C.GC_5689,(0,4):C.GC_5688,(0,1):C.GC_5687,(0,2):C.GC_5688,(0,23):C.GC_5686,(0,22):C.GC_5678,(0,25):C.GC_5686,(0,24):C.GC_5677,(0,10):C.GC_5687,(0,16):C.GC_5686,(0,21):C.GC_5686,(0,5):C.GC_5687,(0,14):C.GC_5678,(0,19):C.GC_5677,(0,28):C.GC_5686,(0,8):C.GC_5677,(0,20):C.GC_5678,(0,27):C.GC_5686,(0,9):C.GC_5678,(0,15):C.GC_5677,(0,0):C.GC_5730,(0,11):C.GC_5730,(0,26):C.GC_5737,(0,6):C.GC_5701,(0,7):C.GC_5703,(0,12):C.GC_5703,(0,13):C.GC_2390,(0,17):C.GC_5701,(0,18):C.GC_2391})

V_578 = Vertex(name = 'V_578',
               particles = [ P.W__minus__, P.W__plus__, P.Z ],
               color = [ '1' ],
               lorentz = [ L.VVV1, L.VVV15, L.VVV16, L.VVV2, L.VVV20, L.VVV21, L.VVV25, L.VVV26, L.VVV7 ],
               couplings = {(0,0):C.GC_3531,(0,3):C.GC_3532,(0,8):C.GC_5851,(0,1):C.GC_5732,(0,2):C.GC_5734,(0,4):C.GC_5734,(0,5):C.GC_1944,(0,6):C.GC_5732,(0,7):C.GC_1943})

V_579 = Vertex(name = 'V_579',
               particles = [ P.W__minus__, P.W__plus__, P.Z ],
               color = [ '1' ],
               lorentz = [ L.VVV15, L.VVV16, L.VVV20, L.VVV21, L.VVV25, L.VVV26 ],
               couplings = {(0,0):C.GC_3529,(0,1):C.GC_3530,(0,2):C.GC_3528,(0,3):C.GC_5850,(0,4):C.GC_3527,(0,5):C.GC_5849})

V_580 = Vertex(name = 'V_580',
               particles = [ P.W__minus__, P.W__plus__, P.Z, P.G0, P.G0 ],
               color = [ '1' ],
               lorentz = [ L.VVVSS1, L.VVVSS10, L.VVVSS103, L.VVVSS104, L.VVVSS105, L.VVVSS106, L.VVVSS107, L.VVVSS108, L.VVVSS109, L.VVVSS110, L.VVVSS111, L.VVVSS112, L.VVVSS113, L.VVVSS114, L.VVVSS115, L.VVVSS116, L.VVVSS117, L.VVVSS119, L.VVVSS12, L.VVVSS120, L.VVVSS122, L.VVVSS123, L.VVVSS124, L.VVVSS125, L.VVVSS126, L.VVVSS127, L.VVVSS128, L.VVVSS129, L.VVVSS130, L.VVVSS136, L.VVVSS137, L.VVVSS138, L.VVVSS139, L.VVVSS14, L.VVVSS140, L.VVVSS141, L.VVVSS142, L.VVVSS145, L.VVVSS146, L.VVVSS148, L.VVVSS149, L.VVVSS15, L.VVVSS150, L.VVVSS151, L.VVVSS152, L.VVVSS153, L.VVVSS155, L.VVVSS156, L.VVVSS157, L.VVVSS159, L.VVVSS16, L.VVVSS160, L.VVVSS161, L.VVVSS162, L.VVVSS163, L.VVVSS164, L.VVVSS165, L.VVVSS166, L.VVVSS168, L.VVVSS169, L.VVVSS17, L.VVVSS170, L.VVVSS171, L.VVVSS172, L.VVVSS173, L.VVVSS177, L.VVVSS178, L.VVVSS179, L.VVVSS18, L.VVVSS180, L.VVVSS182, L.VVVSS183, L.VVVSS184, L.VVVSS185, L.VVVSS186, L.VVVSS187, L.VVVSS189, L.VVVSS19, L.VVVSS190, L.VVVSS191, L.VVVSS192, L.VVVSS193, L.VVVSS194, L.VVVSS195, L.VVVSS196, L.VVVSS197, L.VVVSS198, L.VVVSS199, L.VVVSS2, L.VVVSS200, L.VVVSS202, L.VVVSS203, L.VVVSS204, L.VVVSS205, L.VVVSS206, L.VVVSS207, L.VVVSS208, L.VVVSS209, L.VVVSS21, L.VVVSS210, L.VVVSS218, L.VVVSS219, L.VVVSS22, L.VVVSS220, L.VVVSS221, L.VVVSS223, L.VVVSS224, L.VVVSS225, L.VVVSS226, L.VVVSS227, L.VVVSS228, L.VVVSS229, L.VVVSS23, L.VVVSS230, L.VVVSS231, L.VVVSS232, L.VVVSS233, L.VVVSS234, L.VVVSS235, L.VVVSS236, L.VVVSS237, L.VVVSS238, L.VVVSS239, L.VVVSS240, L.VVVSS241, L.VVVSS242, L.VVVSS243, L.VVVSS244, L.VVVSS245, L.VVVSS246, L.VVVSS247, L.VVVSS248, L.VVVSS249, L.VVVSS25, L.VVVSS26, L.VVVSS27, L.VVVSS28, L.VVVSS29, L.VVVSS30, L.VVVSS32, L.VVVSS33, L.VVVSS37, L.VVVSS38, L.VVVSS39, L.VVVSS4, L.VVVSS40, L.VVVSS41, L.VVVSS42, L.VVVSS43, L.VVVSS44, L.VVVSS45, L.VVVSS46, L.VVVSS47, L.VVVSS48, L.VVVSS49, L.VVVSS50, L.VVVSS51, L.VVVSS52, L.VVVSS53, L.VVVSS54, L.VVVSS56, L.VVVSS57, L.VVVSS58, L.VVVSS6, L.VVVSS60, L.VVVSS61, L.VVVSS62, L.VVVSS63, L.VVVSS64, L.VVVSS65, L.VVVSS66, L.VVVSS67, L.VVVSS7, L.VVVSS70, L.VVVSS71, L.VVVSS72, L.VVVSS73, L.VVVSS75, L.VVVSS76, L.VVVSS77, L.VVVSS78, L.VVVSS79, L.VVVSS8, L.VVVSS80, L.VVVSS81, L.VVVSS82, L.VVVSS88, L.VVVSS89, L.VVVSS9, L.VVVSS90, L.VVVSS91, L.VVVSS92, L.VVVSS93, L.VVVSS94, L.VVVSS95, L.VVVSS96, L.VVVSS97, L.VVVSS98 ],
               couplings = {(0,0):C.GC_2395,(0,88):C.GC_2395,(0,188):C.GC_5710,(0,50):C.GC_5634,(0,60):C.GC_5630,(0,33):C.GC_5635,(0,41):C.GC_5630,(0,163):C.GC_5631,(0,144):C.GC_5628,(0,182):C.GC_5631,(0,172):C.GC_5625,(0,146):C.GC_3503,(0,2):C.GC_3503,(0,32):C.GC_2394,(0,34):C.GC_2393,(0,37):C.GC_5635,(0,38):C.GC_2536,(0,48):C.GC_2536,(0,65):C.GC_2393,(0,70):C.GC_5631,(0,66):C.GC_5709,(0,71):C.GC_3500,(0,82):C.GC_3500,(0,100):C.GC_2394,(0,105):C.GC_5631,(0,101):C.GC_5706,(0,106):C.GC_3501,(0,117):C.GC_3501,(0,68):C.GC_5635,(0,67):C.GC_5628,(0,103):C.GC_5625,(0,18):C.GC_5631,(0,35):C.GC_5625,(0,104):C.GC_5628,(0,1):C.GC_5631,(0,36):C.GC_5628,(0,69):C.GC_5625,(0,149):C.GC_2864,(0,147):C.GC_2864,(0,155):C.GC_1971,(0,157):C.GC_1972,(0,151):C.GC_5821,(0,152):C.GC_5823,(0,98):C.GC_2864,(0,77):C.GC_2861,(0,133):C.GC_1972,(0,102):C.GC_5801,(0,136):C.GC_2864,(0,135):C.GC_2862,(0,140):C.GC_1971,(0,138):C.GC_5804,(0,143):C.GC_5820,(0,145):C.GC_5822,(0,141):C.GC_5798,(0,142):C.GC_5803,(0,5):C.GC_2864,(0,3):C.GC_2864,(0,11):C.GC_1971,(0,13):C.GC_1972,(0,7):C.GC_5821,(0,8):C.GC_5823,(0,15):C.GC_2479,(0,16):C.GC_2479,(0,17):C.GC_2479,(0,19):C.GC_2479,(0,20):C.GC_2477,(0,21):C.GC_2479,(0,160):C.GC_2864,(0,159):C.GC_2861,(0,164):C.GC_1972,(0,161):C.GC_5801,(0,170):C.GC_2479,(0,171):C.GC_2479,(0,166):C.GC_2471,(0,167):C.GC_2472,(0,168):C.GC_2472,(0,169):C.GC_5806,(0,174):C.GC_2864,(0,173):C.GC_2862,(0,178):C.GC_1971,(0,176):C.GC_5804,(0,184):C.GC_2479,(0,185):C.GC_2479,(0,179):C.GC_2471,(0,180):C.GC_2472,(0,181):C.GC_2471,(0,183):C.GC_5813,(0,189):C.GC_5820,(0,190):C.GC_5822,(0,186):C.GC_5798,(0,187):C.GC_5803,(0,195):C.GC_2477,(0,196):C.GC_2479,(0,191):C.GC_2472,(0,192):C.GC_5806,(0,193):C.GC_2471,(0,194):C.GC_5813,(0,46):C.GC_1971,(0,47):C.GC_1972,(0,58):C.GC_1971,(0,59):C.GC_1972,(0,76):C.GC_2864,(0,81):C.GC_5821,(0,90):C.GC_2864,(0,94):C.GC_5821,(0,111):C.GC_2864,(0,116):C.GC_5823,(0,124):C.GC_2864,(0,128):C.GC_5823,(0,72):C.GC_2861,(0,83):C.GC_2861,(0,107):C.GC_2862,(0,118):C.GC_2862,(0,39):C.GC_5805,(0,49):C.GC_5805,(0,108):C.GC_5802,(0,119):C.GC_5802,(0,150):C.GC_2864,(0,156):C.GC_1972,(0,29):C.GC_2477,(0,42):C.GC_2862,(0,52):C.GC_2471,(0,78):C.GC_5802,(0,86):C.GC_2472,(0,110):C.GC_2861,(0,113):C.GC_5801,(0,6):C.GC_2864,(0,12):C.GC_1972,(0,26):C.GC_2477,(0,54):C.GC_2862,(0,61):C.GC_2471,(0,91):C.GC_5802,(0,95):C.GC_2472,(0,123):C.GC_2861,(0,125):C.GC_5801,(0,40):C.GC_5800,(0,51):C.GC_5800,(0,74):C.GC_5799,(0,85):C.GC_5799,(0,148):C.GC_2864,(0,158):C.GC_1973,(0,30):C.GC_2479,(0,43):C.GC_2861,(0,53):C.GC_2472,(0,75):C.GC_2862,(0,79):C.GC_5804,(0,114):C.GC_5799,(0,121):C.GC_2471,(0,4):C.GC_2864,(0,14):C.GC_1973,(0,27):C.GC_2479,(0,55):C.GC_2861,(0,62):C.GC_2472,(0,89):C.GC_2862,(0,92):C.GC_5804,(0,126):C.GC_5799,(0,129):C.GC_2471,(0,153):C.GC_5825,(0,154):C.GC_5824,(0,44):C.GC_5798,(0,45):C.GC_5803,(0,80):C.GC_5805,(0,87):C.GC_5806,(0,115):C.GC_5800,(0,122):C.GC_5813,(0,9):C.GC_5825,(0,10):C.GC_5824,(0,56):C.GC_5798,(0,57):C.GC_5803,(0,93):C.GC_5805,(0,96):C.GC_5806,(0,127):C.GC_5800,(0,130):C.GC_5813,(0,23):C.GC_2475,(0,24):C.GC_2475,(0,25):C.GC_5797,(0,63):C.GC_2473,(0,64):C.GC_2474,(0,97):C.GC_2474,(0,99):C.GC_5787,(0,131):C.GC_2473,(0,132):C.GC_5791,(0,134):C.GC_5793,(0,112):C.GC_5785,(0,139):C.GC_5792,(0,137):C.GC_5784,(0,22):C.GC_5826,(0,165):C.GC_5793,(0,162):C.GC_5785,(0,177):C.GC_5792,(0,175):C.GC_5784,(0,197):C.GC_5826,(0,73):C.GC_5785,(0,84):C.GC_5785,(0,109):C.GC_5784,(0,120):C.GC_5784,(0,31):C.GC_5832,(0,28):C.GC_5832})

V_581 = Vertex(name = 'V_581',
               particles = [ P.W__minus__, P.W__plus__, P.Z, P.G0, P.G0 ],
               color = [ '1' ],
               lorentz = [ L.VVVSS1, L.VVVSS139, L.VVVSS140, L.VVVSS177, L.VVVSS178, L.VVVSS183, L.VVVSS194, L.VVVSS2, L.VVVSS218, L.VVVSS219, L.VVVSS224, L.VVVSS234, L.VVVSS9 ],
               couplings = {(0,0):C.GC_5774,(0,7):C.GC_5774,(0,12):C.GC_5782,(0,1):C.GC_5771,(0,2):C.GC_5768,(0,3):C.GC_5768,(0,4):C.GC_5779,(0,5):C.GC_3669,(0,6):C.GC_3669,(0,8):C.GC_5771,(0,9):C.GC_5778,(0,10):C.GC_3668,(0,11):C.GC_3668})

V_582 = Vertex(name = 'V_582',
               particles = [ P.W__minus__, P.W__plus__, P.Z, P.G0, P.G0 ],
               color = [ '1' ],
               lorentz = [ L.VVVSS1, L.VVVSS139, L.VVVSS140, L.VVVSS177, L.VVVSS178, L.VVVSS2, L.VVVSS218, L.VVVSS219, L.VVVSS9 ],
               couplings = {(0,0):C.GC_3520,(0,5):C.GC_3522,(0,8):C.GC_5847,(0,1):C.GC_3509,(0,2):C.GC_3512,(0,3):C.GC_3508,(0,4):C.GC_5844,(0,6):C.GC_3505,(0,7):C.GC_5843})

V_583 = Vertex(name = 'V_583',
               particles = [ P.W__minus__, P.W__plus__, P.Z, P.G__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVSS1, L.VVVSS10, L.VVVSS103, L.VVVSS104, L.VVVSS105, L.VVVSS106, L.VVVSS107, L.VVVSS109, L.VVVSS110, L.VVVSS112, L.VVVSS113, L.VVVSS116, L.VVVSS117, L.VVVSS119, L.VVVSS12, L.VVVSS120, L.VVVSS122, L.VVVSS123, L.VVVSS124, L.VVVSS125, L.VVVSS126, L.VVVSS127, L.VVVSS128, L.VVVSS129, L.VVVSS130, L.VVVSS136, L.VVVSS137, L.VVVSS138, L.VVVSS139, L.VVVSS14, L.VVVSS140, L.VVVSS141, L.VVVSS142, L.VVVSS145, L.VVVSS146, L.VVVSS147, L.VVVSS149, L.VVVSS15, L.VVVSS150, L.VVVSS151, L.VVVSS153, L.VVVSS156, L.VVVSS157, L.VVVSS158, L.VVVSS159, L.VVVSS16, L.VVVSS161, L.VVVSS162, L.VVVSS163, L.VVVSS164, L.VVVSS165, L.VVVSS168, L.VVVSS17, L.VVVSS170, L.VVVSS171, L.VVVSS172, L.VVVSS173, L.VVVSS177, L.VVVSS178, L.VVVSS179, L.VVVSS18, L.VVVSS180, L.VVVSS182, L.VVVSS183, L.VVVSS184, L.VVVSS186, L.VVVSS187, L.VVVSS189, L.VVVSS19, L.VVVSS191, L.VVVSS193, L.VVVSS194, L.VVVSS195, L.VVVSS196, L.VVVSS198, L.VVVSS199, L.VVVSS2, L.VVVSS200, L.VVVSS202, L.VVVSS203, L.VVVSS205, L.VVVSS207, L.VVVSS208, L.VVVSS209, L.VVVSS21, L.VVVSS210, L.VVVSS218, L.VVVSS219, L.VVVSS220, L.VVVSS221, L.VVVSS223, L.VVVSS224, L.VVVSS225, L.VVVSS227, L.VVVSS228, L.VVVSS229, L.VVVSS23, L.VVVSS231, L.VVVSS232, L.VVVSS234, L.VVVSS235, L.VVVSS236, L.VVVSS238, L.VVVSS239, L.VVVSS240, L.VVVSS241, L.VVVSS242, L.VVVSS245, L.VVVSS246, L.VVVSS247, L.VVVSS248, L.VVVSS249, L.VVVSS26, L.VVVSS27, L.VVVSS28, L.VVVSS30, L.VVVSS33, L.VVVSS34, L.VVVSS36, L.VVVSS38, L.VVVSS4, L.VVVSS40, L.VVVSS41, L.VVVSS42, L.VVVSS43, L.VVVSS44, L.VVVSS45, L.VVVSS46, L.VVVSS49, L.VVVSS52, L.VVVSS53, L.VVVSS54, L.VVVSS56, L.VVVSS57, L.VVVSS6, L.VVVSS60, L.VVVSS62, L.VVVSS63, L.VVVSS64, L.VVVSS65, L.VVVSS66, L.VVVSS67, L.VVVSS7, L.VVVSS70, L.VVVSS71, L.VVVSS72, L.VVVSS75, L.VVVSS77, L.VVVSS78, L.VVVSS79, L.VVVSS8, L.VVVSS80, L.VVVSS81, L.VVVSS82, L.VVVSS85, L.VVVSS87, L.VVVSS88, L.VVVSS9, L.VVVSS90, L.VVVSS92, L.VVVSS93, L.VVVSS94, L.VVVSS95, L.VVVSS96, L.VVVSS97, L.VVVSS98 ],
               couplings = {(0,0):C.GC_2395,(0,76):C.GC_2395,(0,157):C.GC_5711,(0,45):C.GC_5636,(0,52):C.GC_5632,(0,29):C.GC_5633,(0,37):C.GC_5632,(0,134):C.GC_5629,(0,120):C.GC_5626,(0,150):C.GC_5629,(0,142):C.GC_5627,(0,122):C.GC_3519,(0,2):C.GC_3521,(0,28):C.GC_2394,(0,30):C.GC_2393,(0,33):C.GC_5633,(0,34):C.GC_2011,(0,42):C.GC_2012,(0,57):C.GC_2393,(0,62):C.GC_5629,(0,58):C.GC_5707,(0,63):C.GC_3511,(0,71):C.GC_3507,(0,86):C.GC_2394,(0,90):C.GC_5629,(0,87):C.GC_5708,(0,91):C.GC_3506,(0,99):C.GC_3510,(0,60):C.GC_5633,(0,59):C.GC_5626,(0,88):C.GC_5627,(0,14):C.GC_5629,(0,31):C.GC_5627,(0,89):C.GC_5626,(0,1):C.GC_5629,(0,32):C.GC_5626,(0,61):C.GC_5627,(0,125):C.GC_3396,(0,123):C.GC_3396,(0,129):C.GC_1977,(0,127):C.GC_5835,(0,84):C.GC_3397,(0,68):C.GC_3394,(0,114):C.GC_3397,(0,113):C.GC_3392,(0,116):C.GC_1975,(0,115):C.GC_5811,(0,118):C.GC_3390,(0,117):C.GC_3388,(0,121):C.GC_5837,(0,119):C.GC_5809,(0,5):C.GC_3397,(0,3):C.GC_3397,(0,9):C.GC_1975,(0,7):C.GC_5828,(0,11):C.GC_1976,(0,12):C.GC_1976,(0,13):C.GC_1976,(0,15):C.GC_1976,(0,16):C.GC_1975,(0,17):C.GC_1976,(0,132):C.GC_3396,(0,131):C.GC_3395,(0,135):C.GC_1977,(0,133):C.GC_5819,(0,140):C.GC_1974,(0,141):C.GC_1974,(0,136):C.GC_1967,(0,137):C.GC_1970,(0,138):C.GC_1970,(0,139):C.GC_5817,(0,144):C.GC_3396,(0,143):C.GC_3393,(0,152):C.GC_1974,(0,153):C.GC_1974,(0,147):C.GC_1969,(0,148):C.GC_1968,(0,149):C.GC_1969,(0,151):C.GC_5807,(0,155):C.GC_3391,(0,154):C.GC_3389,(0,158):C.GC_5834,(0,156):C.GC_5815,(0,163):C.GC_1977,(0,164):C.GC_1974,(0,159):C.GC_1968,(0,160):C.GC_5814,(0,161):C.GC_1967,(0,162):C.GC_5810,(0,41):C.GC_1977,(0,51):C.GC_1975,(0,67):C.GC_3396,(0,70):C.GC_5835,(0,78):C.GC_3397,(0,95):C.GC_3396,(0,105):C.GC_3397,(0,107):C.GC_5828,(0,35):C.GC_3389,(0,43):C.GC_3388,(0,64):C.GC_3395,(0,72):C.GC_3394,(0,92):C.GC_3393,(0,100):C.GC_3392,(0,44):C.GC_5812,(0,101):C.GC_5808,(0,126):C.GC_3397,(0,25):C.GC_1975,(0,38):C.GC_3393,(0,46):C.GC_1969,(0,74):C.GC_1968,(0,94):C.GC_3394,(0,6):C.GC_3396,(0,10):C.GC_1977,(0,22):C.GC_1977,(0,48):C.GC_3392,(0,53):C.GC_1967,(0,79):C.GC_5808,(0,81):C.GC_1970,(0,104):C.GC_3395,(0,106):C.GC_5819,(0,36):C.GC_5818,(0,65):C.GC_5816,(0,124):C.GC_3397,(0,130):C.GC_1976,(0,26):C.GC_1976,(0,39):C.GC_3395,(0,47):C.GC_1970,(0,66):C.GC_3392,(0,69):C.GC_5811,(0,97):C.GC_5816,(0,102):C.GC_1967,(0,4):C.GC_3396,(0,23):C.GC_1974,(0,49):C.GC_3394,(0,54):C.GC_1968,(0,77):C.GC_3393,(0,108):C.GC_1969,(0,128):C.GC_5829,(0,40):C.GC_5809,(0,75):C.GC_5817,(0,98):C.GC_5818,(0,103):C.GC_5807,(0,8):C.GC_5831,(0,50):C.GC_5815,(0,80):C.GC_5812,(0,82):C.GC_5814,(0,109):C.GC_5810,(0,19):C.GC_2475,(0,20):C.GC_2475,(0,21):C.GC_5795,(0,55):C.GC_2473,(0,56):C.GC_2474,(0,83):C.GC_2474,(0,85):C.GC_5790,(0,110):C.GC_2473,(0,111):C.GC_5788,(0,112):C.GC_5794,(0,96):C.GC_5786,(0,18):C.GC_5836,(0,146):C.GC_5796,(0,145):C.GC_5789,(0,165):C.GC_5833,(0,73):C.GC_5786,(0,93):C.GC_5789,(0,27):C.GC_5827,(0,24):C.GC_5830})

V_584 = Vertex(name = 'V_584',
               particles = [ P.W__minus__, P.W__plus__, P.Z, P.G__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVSS1, L.VVVSS139, L.VVVSS140, L.VVVSS146, L.VVVSS157, L.VVVSS177, L.VVVSS178, L.VVVSS183, L.VVVSS194, L.VVVSS2, L.VVVSS218, L.VVVSS219, L.VVVSS224, L.VVVSS234, L.VVVSS9 ],
               couplings = {(0,0):C.GC_5776,(0,9):C.GC_5776,(0,14):C.GC_5777,(0,1):C.GC_5773,(0,2):C.GC_5770,(0,3):C.GC_3677,(0,4):C.GC_3678,(0,5):C.GC_5770,(0,6):C.GC_5767,(0,7):C.GC_3680,(0,8):C.GC_3674,(0,10):C.GC_5773,(0,11):C.GC_5766,(0,12):C.GC_3672,(0,13):C.GC_3682})

V_585 = Vertex(name = 'V_585',
               particles = [ P.W__minus__, P.W__plus__, P.Z, P.G__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVSS1, L.VVVSS139, L.VVVSS140, L.VVVSS177, L.VVVSS178, L.VVVSS2, L.VVVSS218, L.VVVSS219, L.VVVSS9 ],
               couplings = {(0,0):C.GC_2535,(0,5):C.GC_2535,(0,8):C.GC_2535,(0,1):C.GC_2532,(0,2):C.GC_2534,(0,3):C.GC_2534,(0,4):C.GC_2532,(0,6):C.GC_2532,(0,7):C.GC_2534})

V_586 = Vertex(name = 'V_586',
               particles = [ P.W__minus__, P.W__plus__, P.Z, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVS1, L.VVVS10, L.VVVS100, L.VVVS101, L.VVVS102, L.VVVS104, L.VVVS105, L.VVVS106, L.VVVS107, L.VVVS108, L.VVVS109, L.VVVS110, L.VVVS111, L.VVVS112, L.VVVS113, L.VVVS114, L.VVVS12, L.VVVS14, L.VVVS15, L.VVVS16, L.VVVS17, L.VVVS18, L.VVVS19, L.VVVS2, L.VVVS21, L.VVVS22, L.VVVS23, L.VVVS25, L.VVVS26, L.VVVS27, L.VVVS28, L.VVVS29, L.VVVS30, L.VVVS32, L.VVVS33, L.VVVS38, L.VVVS39, L.VVVS4, L.VVVS40, L.VVVS41, L.VVVS45, L.VVVS46, L.VVVS47, L.VVVS48, L.VVVS49, L.VVVS50, L.VVVS51, L.VVVS52, L.VVVS53, L.VVVS54, L.VVVS55, L.VVVS56, L.VVVS57, L.VVVS58, L.VVVS59, L.VVVS6, L.VVVS60, L.VVVS61, L.VVVS64, L.VVVS65, L.VVVS67, L.VVVS68, L.VVVS69, L.VVVS7, L.VVVS70, L.VVVS71, L.VVVS72, L.VVVS74, L.VVVS75, L.VVVS77, L.VVVS78, L.VVVS79, L.VVVS8, L.VVVS80, L.VVVS82, L.VVVS83, L.VVVS84, L.VVVS85, L.VVVS86, L.VVVS87, L.VVVS89, L.VVVS9, L.VVVS90, L.VVVS91, L.VVVS92, L.VVVS93, L.VVVS99 ],
               couplings = {(0,0):C.GC_2389,(0,23):C.GC_2389,(0,81):C.GC_5698,(0,43):C.GC_2839,(0,41):C.GC_2839,(0,49):C.GC_1928,(0,51):C.GC_1929,(0,45):C.GC_5725,(0,46):C.GC_5727,(0,24):C.GC_2839,(0,22):C.GC_2836,(0,27):C.GC_1929,(0,25):C.GC_5719,(0,30):C.GC_2839,(0,29):C.GC_2837,(0,34):C.GC_1928,(0,32):C.GC_5722,(0,38):C.GC_5724,(0,39):C.GC_5726,(0,35):C.GC_5716,(0,36):C.GC_5721,(0,53):C.GC_2388,(0,54):C.GC_2387,(0,67):C.GC_1928,(0,68):C.GC_1929,(0,69):C.GC_2387,(0,70):C.GC_5697,(0,80):C.GC_2839,(0,85):C.GC_5725,(0,75):C.GC_3537,(0,86):C.GC_2388,(0,2):C.GC_5696,(0,11):C.GC_2839,(0,15):C.GC_5727,(0,6):C.GC_3538,(0,76):C.GC_2836,(0,7):C.GC_2837,(0,60):C.GC_5723,(0,8):C.GC_5720,(0,44):C.GC_2839,(0,50):C.GC_1929,(0,62):C.GC_2837,(0,82):C.GC_5720,(0,10):C.GC_2836,(0,12):C.GC_5719,(0,61):C.GC_5718,(0,78):C.GC_5717,(0,42):C.GC_2839,(0,52):C.GC_1930,(0,64):C.GC_2836,(0,79):C.GC_2837,(0,83):C.GC_5722,(0,13):C.GC_5717,(0,47):C.GC_5729,(0,48):C.GC_5728,(0,65):C.GC_5716,(0,66):C.GC_5721,(0,84):C.GC_5723,(0,14):C.GC_5718,(0,40):C.GC_3539,(0,19):C.GC_5694,(0,20):C.GC_5692,(0,17):C.GC_5695,(0,18):C.GC_5692,(0,55):C.GC_5693,(0,37):C.GC_5691,(0,72):C.GC_5693,(0,63):C.GC_5690,(0,58):C.GC_5695,(0,59):C.GC_2546,(0,74):C.GC_5693,(0,5):C.GC_5693,(0,21):C.GC_5695,(0,71):C.GC_5691,(0,3):C.GC_5690,(0,16):C.GC_5693,(0,56):C.GC_5690,(0,4):C.GC_5691,(0,1):C.GC_5693,(0,57):C.GC_5691,(0,73):C.GC_5690,(0,28):C.GC_5715,(0,26):C.GC_5713,(0,33):C.GC_5714,(0,31):C.GC_5712,(0,77):C.GC_5713,(0,9):C.GC_5712})

V_587 = Vertex(name = 'V_587',
               particles = [ P.W__minus__, P.W__plus__, P.Z, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVS1, L.VVVS100, L.VVVS105, L.VVVS2, L.VVVS58, L.VVVS59, L.VVVS77, L.VVVS78, L.VVVS83, L.VVVS9, L.VVVS99 ],
               couplings = {(0,0):C.GC_5743,(0,3):C.GC_5743,(0,9):C.GC_5746,(0,4):C.GC_5742,(0,5):C.GC_5741,(0,6):C.GC_5741,(0,7):C.GC_5745,(0,8):C.GC_3662,(0,10):C.GC_5742,(0,1):C.GC_5744,(0,2):C.GC_3661})

V_588 = Vertex(name = 'V_588',
               particles = [ P.W__minus__, P.W__plus__, P.Z, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVS1, L.VVVS100, L.VVVS2, L.VVVS58, L.VVVS59, L.VVVS77, L.VVVS78, L.VVVS9, L.VVVS99 ],
               couplings = {(0,0):C.GC_3544,(0,2):C.GC_3545,(0,7):C.GC_5857,(0,3):C.GC_3542,(0,4):C.GC_3543,(0,5):C.GC_3541,(0,6):C.GC_5856,(0,8):C.GC_3540,(0,1):C.GC_5855})

V_589 = Vertex(name = 'V_589',
               particles = [ P.W__minus__, P.W__plus__, P.Z, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVSS1, L.VVVSS10, L.VVVSS103, L.VVVSS104, L.VVVSS105, L.VVVSS106, L.VVVSS107, L.VVVSS108, L.VVVSS109, L.VVVSS110, L.VVVSS111, L.VVVSS112, L.VVVSS113, L.VVVSS114, L.VVVSS115, L.VVVSS116, L.VVVSS117, L.VVVSS119, L.VVVSS12, L.VVVSS120, L.VVVSS122, L.VVVSS123, L.VVVSS124, L.VVVSS125, L.VVVSS126, L.VVVSS127, L.VVVSS128, L.VVVSS129, L.VVVSS130, L.VVVSS136, L.VVVSS137, L.VVVSS138, L.VVVSS139, L.VVVSS14, L.VVVSS140, L.VVVSS141, L.VVVSS142, L.VVVSS145, L.VVVSS146, L.VVVSS148, L.VVVSS149, L.VVVSS15, L.VVVSS150, L.VVVSS151, L.VVVSS152, L.VVVSS153, L.VVVSS155, L.VVVSS156, L.VVVSS157, L.VVVSS159, L.VVVSS16, L.VVVSS160, L.VVVSS161, L.VVVSS162, L.VVVSS163, L.VVVSS164, L.VVVSS165, L.VVVSS166, L.VVVSS168, L.VVVSS169, L.VVVSS17, L.VVVSS170, L.VVVSS171, L.VVVSS172, L.VVVSS173, L.VVVSS177, L.VVVSS178, L.VVVSS179, L.VVVSS18, L.VVVSS180, L.VVVSS182, L.VVVSS183, L.VVVSS184, L.VVVSS185, L.VVVSS186, L.VVVSS187, L.VVVSS189, L.VVVSS19, L.VVVSS190, L.VVVSS191, L.VVVSS192, L.VVVSS193, L.VVVSS194, L.VVVSS195, L.VVVSS196, L.VVVSS197, L.VVVSS198, L.VVVSS199, L.VVVSS2, L.VVVSS200, L.VVVSS202, L.VVVSS203, L.VVVSS204, L.VVVSS205, L.VVVSS206, L.VVVSS207, L.VVVSS208, L.VVVSS209, L.VVVSS21, L.VVVSS210, L.VVVSS218, L.VVVSS219, L.VVVSS22, L.VVVSS220, L.VVVSS221, L.VVVSS223, L.VVVSS224, L.VVVSS225, L.VVVSS226, L.VVVSS227, L.VVVSS228, L.VVVSS229, L.VVVSS23, L.VVVSS230, L.VVVSS231, L.VVVSS232, L.VVVSS233, L.VVVSS234, L.VVVSS235, L.VVVSS236, L.VVVSS237, L.VVVSS238, L.VVVSS239, L.VVVSS240, L.VVVSS241, L.VVVSS242, L.VVVSS243, L.VVVSS244, L.VVVSS245, L.VVVSS246, L.VVVSS247, L.VVVSS248, L.VVVSS249, L.VVVSS25, L.VVVSS26, L.VVVSS27, L.VVVSS28, L.VVVSS29, L.VVVSS30, L.VVVSS32, L.VVVSS33, L.VVVSS37, L.VVVSS38, L.VVVSS39, L.VVVSS4, L.VVVSS40, L.VVVSS41, L.VVVSS42, L.VVVSS43, L.VVVSS44, L.VVVSS45, L.VVVSS46, L.VVVSS47, L.VVVSS48, L.VVVSS49, L.VVVSS50, L.VVVSS51, L.VVVSS52, L.VVVSS53, L.VVVSS54, L.VVVSS56, L.VVVSS57, L.VVVSS58, L.VVVSS6, L.VVVSS60, L.VVVSS61, L.VVVSS62, L.VVVSS63, L.VVVSS64, L.VVVSS65, L.VVVSS66, L.VVVSS67, L.VVVSS7, L.VVVSS70, L.VVVSS71, L.VVVSS72, L.VVVSS73, L.VVVSS75, L.VVVSS76, L.VVVSS77, L.VVVSS78, L.VVVSS79, L.VVVSS8, L.VVVSS80, L.VVVSS81, L.VVVSS82, L.VVVSS88, L.VVVSS89, L.VVVSS9, L.VVVSS90, L.VVVSS91, L.VVVSS92, L.VVVSS93, L.VVVSS94, L.VVVSS95, L.VVVSS96, L.VVVSS97, L.VVVSS98 ],
               couplings = {(0,0):C.GC_2395,(0,88):C.GC_2395,(0,188):C.GC_5710,(0,50):C.GC_5634,(0,60):C.GC_5630,(0,33):C.GC_5635,(0,41):C.GC_5630,(0,163):C.GC_5631,(0,144):C.GC_5628,(0,182):C.GC_5631,(0,172):C.GC_5625,(0,146):C.GC_3504,(0,2):C.GC_3504,(0,32):C.GC_2394,(0,34):C.GC_2393,(0,37):C.GC_5635,(0,38):C.GC_2538,(0,48):C.GC_2538,(0,65):C.GC_2393,(0,70):C.GC_5631,(0,66):C.GC_5709,(0,71):C.GC_3499,(0,82):C.GC_3499,(0,100):C.GC_2394,(0,105):C.GC_5631,(0,101):C.GC_5706,(0,106):C.GC_3502,(0,117):C.GC_3502,(0,68):C.GC_5635,(0,67):C.GC_5628,(0,103):C.GC_5625,(0,18):C.GC_5631,(0,35):C.GC_5625,(0,104):C.GC_5628,(0,1):C.GC_5631,(0,36):C.GC_5628,(0,69):C.GC_5625,(0,149):C.GC_2864,(0,147):C.GC_2864,(0,155):C.GC_1971,(0,157):C.GC_1972,(0,151):C.GC_5821,(0,152):C.GC_5823,(0,98):C.GC_2864,(0,77):C.GC_2861,(0,133):C.GC_1972,(0,102):C.GC_5801,(0,136):C.GC_2864,(0,135):C.GC_2862,(0,140):C.GC_1971,(0,138):C.GC_5804,(0,143):C.GC_5820,(0,145):C.GC_5822,(0,141):C.GC_5798,(0,142):C.GC_5803,(0,5):C.GC_2864,(0,3):C.GC_2864,(0,11):C.GC_1971,(0,13):C.GC_1972,(0,7):C.GC_5821,(0,8):C.GC_5823,(0,15):C.GC_2479,(0,16):C.GC_2479,(0,17):C.GC_2479,(0,19):C.GC_2479,(0,20):C.GC_2477,(0,21):C.GC_2479,(0,160):C.GC_2864,(0,159):C.GC_2861,(0,164):C.GC_1972,(0,161):C.GC_5801,(0,170):C.GC_2479,(0,171):C.GC_2479,(0,166):C.GC_2471,(0,167):C.GC_2472,(0,168):C.GC_2472,(0,169):C.GC_5806,(0,174):C.GC_2864,(0,173):C.GC_2862,(0,178):C.GC_1971,(0,176):C.GC_5804,(0,184):C.GC_2479,(0,185):C.GC_2479,(0,179):C.GC_2471,(0,180):C.GC_2472,(0,181):C.GC_2471,(0,183):C.GC_5813,(0,189):C.GC_5820,(0,190):C.GC_5822,(0,186):C.GC_5798,(0,187):C.GC_5803,(0,195):C.GC_2477,(0,196):C.GC_2479,(0,191):C.GC_2472,(0,192):C.GC_5806,(0,193):C.GC_2471,(0,194):C.GC_5813,(0,46):C.GC_1971,(0,47):C.GC_1972,(0,58):C.GC_1971,(0,59):C.GC_1972,(0,76):C.GC_2864,(0,81):C.GC_5821,(0,90):C.GC_2864,(0,94):C.GC_5821,(0,111):C.GC_2864,(0,116):C.GC_5823,(0,124):C.GC_2864,(0,128):C.GC_5823,(0,72):C.GC_2861,(0,83):C.GC_2861,(0,107):C.GC_2862,(0,118):C.GC_2862,(0,39):C.GC_5805,(0,49):C.GC_5805,(0,108):C.GC_5802,(0,119):C.GC_5802,(0,150):C.GC_2864,(0,156):C.GC_1972,(0,29):C.GC_2477,(0,42):C.GC_2862,(0,52):C.GC_2471,(0,78):C.GC_5802,(0,86):C.GC_2472,(0,110):C.GC_2861,(0,113):C.GC_5801,(0,6):C.GC_2864,(0,12):C.GC_1972,(0,26):C.GC_2477,(0,54):C.GC_2862,(0,61):C.GC_2471,(0,91):C.GC_5802,(0,95):C.GC_2472,(0,123):C.GC_2861,(0,125):C.GC_5801,(0,40):C.GC_5800,(0,51):C.GC_5800,(0,74):C.GC_5799,(0,85):C.GC_5799,(0,148):C.GC_2864,(0,158):C.GC_1973,(0,30):C.GC_2479,(0,43):C.GC_2861,(0,53):C.GC_2472,(0,75):C.GC_2862,(0,79):C.GC_5804,(0,114):C.GC_5799,(0,121):C.GC_2471,(0,4):C.GC_2864,(0,14):C.GC_1973,(0,27):C.GC_2479,(0,55):C.GC_2861,(0,62):C.GC_2472,(0,89):C.GC_2862,(0,92):C.GC_5804,(0,126):C.GC_5799,(0,129):C.GC_2471,(0,153):C.GC_5825,(0,154):C.GC_5824,(0,44):C.GC_5798,(0,45):C.GC_5803,(0,80):C.GC_5805,(0,87):C.GC_5806,(0,115):C.GC_5800,(0,122):C.GC_5813,(0,9):C.GC_5825,(0,10):C.GC_5824,(0,56):C.GC_5798,(0,57):C.GC_5803,(0,93):C.GC_5805,(0,96):C.GC_5806,(0,127):C.GC_5800,(0,130):C.GC_5813,(0,23):C.GC_2475,(0,24):C.GC_2475,(0,25):C.GC_5797,(0,63):C.GC_2473,(0,64):C.GC_2474,(0,97):C.GC_2474,(0,99):C.GC_5787,(0,131):C.GC_2473,(0,132):C.GC_5791,(0,134):C.GC_5793,(0,112):C.GC_5785,(0,139):C.GC_5792,(0,137):C.GC_5784,(0,22):C.GC_5826,(0,165):C.GC_5793,(0,162):C.GC_5785,(0,177):C.GC_5792,(0,175):C.GC_5784,(0,197):C.GC_5826,(0,73):C.GC_5785,(0,84):C.GC_5785,(0,109):C.GC_5784,(0,120):C.GC_5784,(0,31):C.GC_5832,(0,28):C.GC_5832})

V_590 = Vertex(name = 'V_590',
               particles = [ P.W__minus__, P.W__plus__, P.Z, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVSS1, L.VVVSS139, L.VVVSS140, L.VVVSS177, L.VVVSS178, L.VVVSS183, L.VVVSS194, L.VVVSS2, L.VVVSS218, L.VVVSS219, L.VVVSS224, L.VVVSS234, L.VVVSS9 ],
               couplings = {(0,0):C.GC_5775,(0,7):C.GC_5775,(0,12):C.GC_5783,(0,1):C.GC_5772,(0,2):C.GC_5769,(0,3):C.GC_5769,(0,4):C.GC_5781,(0,5):C.GC_3671,(0,6):C.GC_3671,(0,8):C.GC_5772,(0,9):C.GC_5780,(0,10):C.GC_3670,(0,11):C.GC_3670})

V_591 = Vertex(name = 'V_591',
               particles = [ P.W__minus__, P.W__plus__, P.Z, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVSS1, L.VVVSS139, L.VVVSS140, L.VVVSS177, L.VVVSS178, L.VVVSS2, L.VVVSS218, L.VVVSS219, L.VVVSS9 ],
               couplings = {(0,0):C.GC_3525,(0,5):C.GC_3526,(0,8):C.GC_5846,(0,1):C.GC_3517,(0,2):C.GC_3518,(0,3):C.GC_3516,(0,4):C.GC_5845,(0,6):C.GC_3515,(0,7):C.GC_5842})

V_592 = Vertex(name = 'V_592',
               particles = [ P.A, P.A, P.Z, P.Z, P.G__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVVSS10, L.VVVVSS100, L.VVVVSS101, L.VVVVSS102, L.VVVVSS103, L.VVVVSS104, L.VVVVSS105, L.VVVVSS106, L.VVVVSS107, L.VVVVSS11, L.VVVVSS12, L.VVVVSS133, L.VVVVSS134, L.VVVVSS135, L.VVVVSS136, L.VVVVSS137, L.VVVVSS139, L.VVVVSS14, L.VVVVSS140, L.VVVVSS141, L.VVVVSS142, L.VVVVSS143, L.VVVVSS144, L.VVVVSS145, L.VVVVSS16, L.VVVVSS169, L.VVVVSS170, L.VVVVSS171, L.VVVVSS172, L.VVVVSS175, L.VVVVSS176, L.VVVVSS177, L.VVVVSS178, L.VVVVSS179, L.VVVVSS18, L.VVVVSS180, L.VVVVSS182, L.VVVVSS183, L.VVVVSS2, L.VVVVSS21, L.VVVVSS210, L.VVVVSS211, L.VVVVSS212, L.VVVVSS213, L.VVVVSS214, L.VVVVSS215, L.VVVVSS217, L.VVVVSS218, L.VVVVSS219, L.VVVVSS22, L.VVVVSS220, L.VVVVSS221, L.VVVVSS222, L.VVVVSS23, L.VVVVSS242, L.VVVVSS243, L.VVVVSS244, L.VVVVSS245, L.VVVVSS246, L.VVVVSS247, L.VVVVSS248, L.VVVVSS25, L.VVVVSS26, L.VVVVSS267, L.VVVVSS268, L.VVVVSS269, L.VVVVSS27, L.VVVVSS270, L.VVVVSS273, L.VVVVSS274, L.VVVVSS275, L.VVVVSS276, L.VVVVSS277, L.VVVVSS278, L.VVVVSS279, L.VVVVSS28, L.VVVVSS281, L.VVVVSS29, L.VVVVSS3, L.VVVVSS300, L.VVVVSS301, L.VVVVSS302, L.VVVVSS303, L.VVVVSS304, L.VVVVSS305, L.VVVVSS306, L.VVVVSS32, L.VVVVSS33, L.VVVVSS36, L.VVVVSS360, L.VVVVSS361, L.VVVVSS362, L.VVVVSS363, L.VVVVSS364, L.VVVVSS365, L.VVVVSS366, L.VVVVSS367, L.VVVVSS368, L.VVVVSS369, L.VVVVSS37, L.VVVVSS370, L.VVVVSS371, L.VVVVSS372, L.VVVVSS391, L.VVVVSS392, L.VVVVSS393, L.VVVVSS394, L.VVVVSS395, L.VVVVSS396, L.VVVVSS397, L.VVVVSS4, L.VVVVSS5, L.VVVVSS7, L.VVVVSS8, L.VVVVSS93, L.VVVVSS94, L.VVVVSS95, L.VVVVSS96, L.VVVVSS99 ],
               couplings = {(0,114):C.GC_6739,(0,115):C.GC_6739,(0,116):C.GC_6734,(0,117):C.GC_6734,(0,5):C.GC_6703,(0,8):C.GC_6699,(0,2):C.GC_6734,(0,3):C.GC_6734,(0,4):C.GC_6687,(0,11):C.GC_6736,(0,13):C.GC_6738,(0,14):C.GC_6734,(0,15):C.GC_6738,(0,23):C.GC_6705,(0,18):C.GC_6734,(0,19):C.GC_6688,(0,20):C.GC_6732,(0,25):C.GC_6736,(0,30):C.GC_6705,(0,27):C.GC_6734,(0,28):C.GC_6688,(0,31):C.GC_6738,(0,32):C.GC_6734,(0,33):C.GC_6738,(0,35):C.GC_6732,(0,40):C.GC_6736,(0,42):C.GC_6734,(0,43):C.GC_6738,(0,44):C.GC_6738,(0,51):C.GC_6705,(0,46):C.GC_6688,(0,47):C.GC_6734,(0,48):C.GC_6732,(0,54):C.GC_5036,(0,63):C.GC_6736,(0,68):C.GC_6705,(0,65):C.GC_6688,(0,67):C.GC_6734,(0,70):C.GC_6734,(0,71):C.GC_6738,(0,72):C.GC_6738,(0,73):C.GC_6732,(0,79):C.GC_5036,(0,90):C.GC_6704,(0,91):C.GC_6702,(0,89):C.GC_6689,(0,92):C.GC_6734,(0,93):C.GC_6734,(0,96):C.GC_6734,(0,97):C.GC_6737,(0,98):C.GC_6734,(0,100):C.GC_6737,(0,103):C.GC_5040,(0,55):C.GC_6739,(0,80):C.GC_6739,(0,104):C.GC_6694,(0,56):C.GC_6738,(0,81):C.GC_6692,(0,105):C.GC_6738,(0,58):C.GC_6692,(0,83):C.GC_6738,(0,107):C.GC_6738,(0,57):C.GC_6692,(0,82):C.GC_6738,(0,106):C.GC_6738,(0,59):C.GC_6738,(0,84):C.GC_6692,(0,108):C.GC_6738,(0,60):C.GC_6737,(0,85):C.GC_6737,(0,109):C.GC_6690,(0,110):C.GC_6761,(0,111):C.GC_6761,(0,38):C.GC_6757,(0,78):C.GC_6757,(0,10):C.GC_6750,(0,17):C.GC_6744,(0,24):C.GC_6750,(0,34):C.GC_6750,(0,112):C.GC_6764,(0,113):C.GC_6764,(0,0):C.GC_6765,(0,9):C.GC_6764,(0,75):C.GC_6744,(0,77):C.GC_6744,(0,86):C.GC_6744,(0,87):C.GC_6750,(0,88):C.GC_6760,(0,99):C.GC_6760,(0,39):C.GC_6765,(0,49):C.GC_6756,(0,53):C.GC_6765,(0,61):C.GC_6756,(0,62):C.GC_6765,(0,66):C.GC_6764,(0,118):C.GC_6750,(0,1):C.GC_6750,(0,6):C.GC_6744,(0,7):C.GC_6744,(0,12):C.GC_6757,(0,16):C.GC_6764,(0,21):C.GC_6760,(0,22):C.GC_6744,(0,26):C.GC_6757,(0,29):C.GC_6744,(0,36):C.GC_6764,(0,37):C.GC_6760,(0,41):C.GC_6757,(0,45):C.GC_6764,(0,50):C.GC_6760,(0,52):C.GC_6744,(0,64):C.GC_6757,(0,69):C.GC_6744,(0,74):C.GC_6764,(0,76):C.GC_6760,(0,94):C.GC_6764,(0,95):C.GC_6765,(0,101):C.GC_6764,(0,102):C.GC_6765})

V_593 = Vertex(name = 'V_593',
               particles = [ P.A, P.Z, P.Z, P.G__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVSS104, L.VVVSS105, L.VVVSS106, L.VVVSS107, L.VVVSS108, L.VVVSS109, L.VVVSS110, L.VVVSS111, L.VVVSS112, L.VVVSS113, L.VVVSS114, L.VVVSS115, L.VVVSS140, L.VVVSS146, L.VVVSS147, L.VVVSS148, L.VVVSS149, L.VVVSS150, L.VVVSS151, L.VVVSS152, L.VVVSS153, L.VVVSS154, L.VVVSS155, L.VVVSS157, L.VVVSS158, L.VVVSS159, L.VVVSS160, L.VVVSS163, L.VVVSS164, L.VVVSS165, L.VVVSS166, L.VVVSS167, L.VVVSS168, L.VVVSS178, L.VVVSS183, L.VVVSS184, L.VVVSS185, L.VVVSS186, L.VVVSS187, L.VVVSS189, L.VVVSS19, L.VVVSS190, L.VVVSS191, L.VVVSS192, L.VVVSS193, L.VVVSS194, L.VVVSS195, L.VVVSS196, L.VVVSS197, L.VVVSS2, L.VVVSS200, L.VVVSS202, L.VVVSS203, L.VVVSS204, L.VVVSS205, L.VVVSS206, L.VVVSS21, L.VVVSS218, L.VVVSS219, L.VVVSS22, L.VVVSS224, L.VVVSS225, L.VVVSS226, L.VVVSS227, L.VVVSS228, L.VVVSS229, L.VVVSS23, L.VVVSS230, L.VVVSS231, L.VVVSS232, L.VVVSS233, L.VVVSS234, L.VVVSS235, L.VVVSS236, L.VVVSS237, L.VVVSS24, L.VVVSS240, L.VVVSS241, L.VVVSS242, L.VVVSS243, L.VVVSS244, L.VVVSS245, L.VVVSS25, L.VVVSS26, L.VVVSS27, L.VVVSS28, L.VVVSS29, L.VVVSS30, L.VVVSS31, L.VVVSS32, L.VVVSS34, L.VVVSS36, L.VVVSS37, L.VVVSS38, L.VVVSS39, L.VVVSS40, L.VVVSS42, L.VVVSS43, L.VVVSS44, L.VVVSS45, L.VVVSS46, L.VVVSS47, L.VVVSS48, L.VVVSS49, L.VVVSS50, L.VVVSS51, L.VVVSS52, L.VVVSS53, L.VVVSS54, L.VVVSS56, L.VVVSS57, L.VVVSS58, L.VVVSS59, L.VVVSS60, L.VVVSS61, L.VVVSS70, L.VVVSS71, L.VVVSS72, L.VVVSS73, L.VVVSS74, L.VVVSS75, L.VVVSS85, L.VVVSS87, L.VVVSS88, L.VVVSS89, L.VVVSS9, L.VVVSS90, L.VVVSS91 ],
               couplings = {(0,98):C.GC_1986,(0,96):C.GC_3399,(0,104):C.GC_1986,(0,106):C.GC_1990,(0,100):C.GC_1992,(0,101):C.GC_3399,(0,56):C.GC_1988,(0,40):C.GC_7066,(0,75):C.GC_7028,(0,82):C.GC_1985,(0,83):C.GC_7029,(0,59):C.GC_7066,(0,66):C.GC_7027,(0,85):C.GC_3401,(0,84):C.GC_7067,(0,88):C.GC_1993,(0,89):C.GC_7077,(0,86):C.GC_7072,(0,87):C.GC_7025,(0,91):C.GC_7077,(0,90):C.GC_7072,(0,94):C.GC_3401,(0,95):C.GC_1993,(0,92):C.GC_7067,(0,93):C.GC_7025,(0,2):C.GC_1988,(0,0):C.GC_3401,(0,8):C.GC_1988,(0,10):C.GC_1993,(0,4):C.GC_1989,(0,5):C.GC_3401,(0,109):C.GC_1986,(0,108):C.GC_7068,(0,112):C.GC_7029,(0,113):C.GC_1987,(0,114):C.GC_7028,(0,110):C.GC_7068,(0,111):C.GC_7026,(0,116):C.GC_3399,(0,115):C.GC_7069,(0,119):C.GC_1990,(0,120):C.GC_7078,(0,117):C.GC_7073,(0,118):C.GC_7024,(0,122):C.GC_7078,(0,121):C.GC_7073,(0,126):C.GC_3399,(0,127):C.GC_1990,(0,123):C.GC_7069,(0,124):C.GC_7024,(0,21):C.GC_1992,(0,22):C.GC_1986,(0,31):C.GC_1989,(0,32):C.GC_1988,(0,39):C.GC_1986,(0,44):C.GC_1992,(0,51):C.GC_1988,(0,55):C.GC_1989,(0,65):C.GC_3399,(0,70):C.GC_3399,(0,77):C.GC_3401,(0,81):C.GC_3401,(0,14):C.GC_7073,(0,24):C.GC_7072,(0,35):C.GC_7068,(0,46):C.GC_7066,(0,61):C.GC_7069,(0,72):C.GC_7067,(0,15):C.GC_7068,(0,25):C.GC_7066,(0,36):C.GC_7073,(0,47):C.GC_7072,(0,62):C.GC_7069,(0,73):C.GC_7067,(0,99):C.GC_1988,(0,105):C.GC_1985,(0,17):C.GC_7069,(0,41):C.GC_7069,(0,64):C.GC_7066,(0,67):C.GC_7066,(0,3):C.GC_1986,(0,9):C.GC_1987,(0,27):C.GC_7067,(0,52):C.GC_7067,(0,76):C.GC_7068,(0,78):C.GC_7068,(0,16):C.GC_7024,(0,26):C.GC_7025,(0,37):C.GC_7024,(0,48):C.GC_7025,(0,63):C.GC_7026,(0,74):C.GC_7027,(0,97):C.GC_3401,(0,107):C.GC_1993,(0,18):C.GC_7068,(0,38):C.GC_7067,(0,42):C.GC_7025,(0,68):C.GC_7024,(0,1):C.GC_3399,(0,11):C.GC_1990,(0,28):C.GC_7066,(0,50):C.GC_7069,(0,53):C.GC_7024,(0,79):C.GC_7025,(0,102):C.GC_3398,(0,103):C.GC_1989,(0,19):C.GC_7067,(0,20):C.GC_7025,(0,43):C.GC_7068,(0,69):C.GC_7024,(0,6):C.GC_3400,(0,7):C.GC_1992,(0,29):C.GC_7069,(0,30):C.GC_7024,(0,54):C.GC_7066,(0,80):C.GC_7025,(0,49):C.GC_4507,(0,125):C.GC_4506,(0,12):C.GC_4504,(0,33):C.GC_4504,(0,57):C.GC_4503,(0,58):C.GC_4503,(0,13):C.GC_7327,(0,23):C.GC_7326,(0,34):C.GC_7327,(0,45):C.GC_7326,(0,60):C.GC_4864,(0,71):C.GC_4863})

V_594 = Vertex(name = 'V_594',
               particles = [ P.A, P.A, P.Z, P.Z ],
               color = [ '1' ],
               lorentz = [ L.VVVV104, L.VVVV112, L.VVVV113, L.VVVV114, L.VVVV126, L.VVVV128, L.VVVV132, L.VVVV133, L.VVVV142, L.VVVV150, L.VVVV152, L.VVVV158, L.VVVV159, L.VVVV160, L.VVVV171, L.VVVV173, L.VVVV178, L.VVVV184, L.VVVV186, L.VVVV187, L.VVVV188, L.VVVV197, L.VVVV198, L.VVVV199, L.VVVV204, L.VVVV210, L.VVVV25, L.VVVV28, L.VVVV3, L.VVVV31, L.VVVV34, L.VVVV37, L.VVVV38, L.VVVV39, L.VVVV4, L.VVVV55, L.VVVV58, L.VVVV59, L.VVVV6, L.VVVV60, L.VVVV62, L.VVVV65, L.VVVV66, L.VVVV68, L.VVVV69, L.VVVV7, L.VVVV70, L.VVVV72, L.VVVV73, L.VVVV84, L.VVVV91, L.VVVV92, L.VVVV93, L.VVVV94 ],
               couplings = {(0,35):C.GC_1512,(0,39):C.GC_1516,(0,40):C.GC_1501,(0,36):C.GC_1520,(0,37):C.GC_1520,(0,41):C.GC_1497,(0,42):C.GC_1496,(0,43):C.GC_1501,(0,44):C.GC_1496,(0,46):C.GC_1497,(0,27):C.GC_1520,(0,26):C.GC_1494,(0,30):C.GC_1520,(0,29):C.GC_1494,(0,32):C.GC_1513,(0,33):C.GC_1517,(0,31):C.GC_1493,(0,47):C.GC_6075,(0,48):C.GC_6075,(0,52):C.GC_6073,(0,2):C.GC_6073,(0,6):C.GC_6073,(0,12):C.GC_6073,(0,19):C.GC_6071,(0,20):C.GC_6069,(0,18):C.GC_6065,(0,50):C.GC_1516,(0,51):C.GC_1512,(0,49):C.GC_1491,(0,10):C.GC_6075,(0,16):C.GC_6075,(0,24):C.GC_6067,(0,1):C.GC_1518,(0,0):C.GC_1492,(0,5):C.GC_1518,(0,4):C.GC_1492,(0,9):C.GC_1518,(0,8):C.GC_1492,(0,11):C.GC_1494,(0,15):C.GC_1518,(0,14):C.GC_1492,(0,17):C.GC_1494,(0,22):C.GC_1517,(0,23):C.GC_1513,(0,21):C.GC_1491,(0,25):C.GC_1493,(0,38):C.GC_3867,(0,45):C.GC_3867,(0,28):C.GC_3866,(0,34):C.GC_3866,(0,53):C.GC_3866,(0,3):C.GC_3866,(0,7):C.GC_3866,(0,13):C.GC_3866})

V_595 = Vertex(name = 'V_595',
               particles = [ P.W__minus__, P.W__plus__, P.Z, P.Z ],
               color = [ '1' ],
               lorentz = [ L.VVVV10, L.VVVV100, L.VVVV101, L.VVVV102, L.VVVV103, L.VVVV104, L.VVVV107, L.VVVV108, L.VVVV109, L.VVVV11, L.VVVV112, L.VVVV113, L.VVVV115, L.VVVV116, L.VVVV117, L.VVVV12, L.VVVV120, L.VVVV121, L.VVVV122, L.VVVV123, L.VVVV124, L.VVVV125, L.VVVV126, L.VVVV128, L.VVVV129, L.VVVV13, L.VVVV130, L.VVVV131, L.VVVV132, L.VVVV133, L.VVVV134, L.VVVV135, L.VVVV136, L.VVVV137, L.VVVV138, L.VVVV139, L.VVVV14, L.VVVV140, L.VVVV141, L.VVVV142, L.VVVV145, L.VVVV146, L.VVVV147, L.VVVV15, L.VVVV150, L.VVVV151, L.VVVV152, L.VVVV153, L.VVVV154, L.VVVV155, L.VVVV156, L.VVVV157, L.VVVV158, L.VVVV159, L.VVVV16, L.VVVV160, L.VVVV161, L.VVVV162, L.VVVV165, L.VVVV166, L.VVVV167, L.VVVV168, L.VVVV169, L.VVVV17, L.VVVV170, L.VVVV171, L.VVVV173, L.VVVV174, L.VVVV175, L.VVVV176, L.VVVV177, L.VVVV178, L.VVVV179, L.VVVV18, L.VVVV180, L.VVVV181, L.VVVV182, L.VVVV183, L.VVVV184, L.VVVV186, L.VVVV188, L.VVVV189, L.VVVV19, L.VVVV190, L.VVVV191, L.VVVV192, L.VVVV193, L.VVVV194, L.VVVV195, L.VVVV196, L.VVVV197, L.VVVV199, L.VVVV20, L.VVVV200, L.VVVV201, L.VVVV203, L.VVVV204, L.VVVV205, L.VVVV206, L.VVVV207, L.VVVV208, L.VVVV209, L.VVVV21, L.VVVV210, L.VVVV22, L.VVVV23, L.VVVV24, L.VVVV25, L.VVVV26, L.VVVV28, L.VVVV29, L.VVVV3, L.VVVV30, L.VVVV31, L.VVVV32, L.VVVV34, L.VVVV35, L.VVVV36, L.VVVV37, L.VVVV39, L.VVVV4, L.VVVV41, L.VVVV42, L.VVVV43, L.VVVV44, L.VVVV45, L.VVVV46, L.VVVV47, L.VVVV48, L.VVVV49, L.VVVV51, L.VVVV55, L.VVVV58, L.VVVV59, L.VVVV6, L.VVVV60, L.VVVV62, L.VVVV66, L.VVVV68, L.VVVV7, L.VVVV70, L.VVVV72, L.VVVV73, L.VVVV75, L.VVVV76, L.VVVV79, L.VVVV80, L.VVVV81, L.VVVV82, L.VVVV83, L.VVVV84, L.VVVV87, L.VVVV88, L.VVVV89, L.VVVV9, L.VVVV90, L.VVVV91, L.VVVV92, L.VVVV93, L.VVVV95, L.VVVV96, L.VVVV97, L.VVVV98, L.VVVV99 ],
               couplings = {(0,134):C.GC_3096,(0,139):C.GC_3096,(0,111):C.GC_3096,(0,120):C.GC_3096,(0,43):C.GC_1357,(0,63):C.GC_1358,(0,82):C.GC_1358,(0,102):C.GC_1360,(0,0):C.GC_5980,(0,9):C.GC_5978,(0,25):C.GC_5974,(0,36):C.GC_5979,(0,121):C.GC_1360,(0,122):C.GC_1358,(0,125):C.GC_1359,(0,126):C.GC_1360,(0,131):C.GC_1502,(0,135):C.GC_1504,(0,136):C.GC_1500,(0,132):C.GC_1514,(0,133):C.GC_1514,(0,137):C.GC_1483,(0,138):C.GC_1500,(0,140):C.GC_1485,(0,106):C.GC_5975,(0,109):C.GC_1514,(0,107):C.GC_1489,(0,110):C.GC_5977,(0,115):C.GC_1514,(0,113):C.GC_1489,(0,116):C.GC_5974,(0,117):C.GC_5979,(0,119):C.GC_1508,(0,118):C.GC_1481,(0,141):C.GC_3091,(0,142):C.GC_3091,(0,145):C.GC_1357,(0,146):C.GC_1358,(0,143):C.GC_5973,(0,144):C.GC_5971,(0,151):C.GC_5590,(0,152):C.GC_1360,(0,153):C.GC_1359,(0,155):C.GC_5592,(0,147):C.GC_5973,(0,148):C.GC_5971,(0,149):C.GC_5588,(0,159):C.GC_3096,(0,158):C.GC_3092,(0,1):C.GC_5980,(0,160):C.GC_5969,(0,161):C.GC_5972,(0,162):C.GC_5966,(0,7):C.GC_1358,(0,2):C.GC_5970,(0,4):C.GC_5596,(0,12):C.GC_3096,(0,11):C.GC_3092,(0,16):C.GC_1358,(0,13):C.GC_5970,(0,26):C.GC_5980,(0,18):C.GC_5969,(0,19):C.GC_5972,(0,20):C.GC_5966,(0,21):C.GC_5596,(0,29):C.GC_3096,(0,28):C.GC_3092,(0,33):C.GC_5978,(0,30):C.GC_5970,(0,31):C.GC_5967,(0,32):C.GC_5968,(0,42):C.GC_1357,(0,37):C.GC_5972,(0,38):C.GC_5596,(0,45):C.GC_5602,(0,55):C.GC_3096,(0,53):C.GC_3092,(0,59):C.GC_1357,(0,57):C.GC_5972,(0,67):C.GC_5978,(0,60):C.GC_5970,(0,61):C.GC_5967,(0,62):C.GC_5968,(0,64):C.GC_5596,(0,70):C.GC_5602,(0,80):C.GC_3095,(0,79):C.GC_3094,(0,84):C.GC_5981,(0,85):C.GC_5976,(0,81):C.GC_5973,(0,83):C.GC_5971,(0,93):C.GC_5981,(0,94):C.GC_5976,(0,86):C.GC_5973,(0,87):C.GC_5594,(0,88):C.GC_5971,(0,89):C.GC_5594,(0,95):C.GC_5605,(0,156):C.GC_1504,(0,157):C.GC_1502,(0,150):C.GC_1479,(0,46):C.GC_3091,(0,71):C.GC_3091,(0,96):C.GC_3093,(0,10):C.GC_1510,(0,5):C.GC_1487,(0,47):C.GC_5969,(0,97):C.GC_5966,(0,23):C.GC_1510,(0,22):C.GC_1487,(0,75):C.GC_5969,(0,99):C.GC_5966,(0,44):C.GC_1510,(0,39):C.GC_1487,(0,74):C.GC_5967,(0,98):C.GC_5968,(0,52):C.GC_1489,(0,50):C.GC_5967,(0,66):C.GC_1510,(0,65):C.GC_1487,(0,100):C.GC_5968,(0,78):C.GC_1489,(0,51):C.GC_5594,(0,77):C.GC_5594,(0,91):C.GC_1506,(0,90):C.GC_1479,(0,101):C.GC_5586,(0,103):C.GC_1481,(0,54):C.GC_2139,(0,92):C.GC_2138,(0,154):C.GC_2139,(0,15):C.GC_2139,(0,123):C.GC_2139,(0,127):C.GC_2138,(0,105):C.GC_2138,(0,112):C.GC_2138,(0,163):C.GC_2139,(0,24):C.GC_2139,(0,34):C.GC_2139,(0,68):C.GC_2139,(0,73):C.GC_2138,(0,124):C.GC_2139,(0,104):C.GC_2139,(0,128):C.GC_2138,(0,129):C.GC_5598,(0,130):C.GC_5599,(0,108):C.GC_5601,(0,114):C.GC_5600,(0,6):C.GC_5598,(0,8):C.GC_5965,(0,3):C.GC_5964,(0,17):C.GC_5965,(0,14):C.GC_5964,(0,27):C.GC_5598,(0,40):C.GC_5599,(0,41):C.GC_5965,(0,35):C.GC_5964,(0,58):C.GC_5965,(0,56):C.GC_5964,(0,69):C.GC_5599,(0,72):C.GC_5963,(0,49):C.GC_5963,(0,48):C.GC_5963,(0,76):C.GC_5963})

V_596 = Vertex(name = 'V_596',
               particles = [ P.W__minus__, P.W__plus__, P.Z, P.Z ],
               color = [ '1' ],
               lorentz = [ L.VVVV10, L.VVVV100, L.VVVV101, L.VVVV108, L.VVVV11, L.VVVV116, L.VVVV12, L.VVVV120, L.VVVV122, L.VVVV123, L.VVVV124, L.VVVV129, L.VVVV13, L.VVVV130, L.VVVV134, L.VVVV135, L.VVVV136, L.VVVV137, L.VVVV138, L.VVVV14, L.VVVV140, L.VVVV147, L.VVVV15, L.VVVV151, L.VVVV153, L.VVVV156, L.VVVV16, L.VVVV162, L.VVVV166, L.VVVV167, L.VVVV168, L.VVVV169, L.VVVV17, L.VVVV174, L.VVVV175, L.VVVV177, L.VVVV18, L.VVVV180, L.VVVV181, L.VVVV189, L.VVVV19, L.VVVV190, L.VVVV191, L.VVVV192, L.VVVV193, L.VVVV195, L.VVVV20, L.VVVV200, L.VVVV201, L.VVVV203, L.VVVV205, L.VVVV206, L.VVVV207, L.VVVV208, L.VVVV21, L.VVVV22, L.VVVV23, L.VVVV24, L.VVVV29, L.VVVV30, L.VVVV35, L.VVVV36, L.VVVV41, L.VVVV42, L.VVVV43, L.VVVV44, L.VVVV45, L.VVVV46, L.VVVV47, L.VVVV48, L.VVVV75, L.VVVV76, L.VVVV79, L.VVVV80, L.VVVV81, L.VVVV82, L.VVVV88, L.VVVV89, L.VVVV9, L.VVVV96, L.VVVV97, L.VVVV98, L.VVVV99 ],
               couplings = {(0,22):C.GC_2139,(0,32):C.GC_2139,(0,40):C.GC_2139,(0,54):C.GC_2138,(0,0):C.GC_2139,(0,4):C.GC_2139,(0,12):C.GC_2139,(0,19):C.GC_2138,(0,62):C.GC_2138,(0,63):C.GC_2139,(0,66):C.GC_2138,(0,67):C.GC_2138,(0,57):C.GC_2138,(0,58):C.GC_2138,(0,60):C.GC_2139,(0,61):C.GC_2138,(0,72):C.GC_2139,(0,73):C.GC_2139,(0,70):C.GC_2136,(0,71):C.GC_2136,(0,76):C.GC_2138,(0,77):C.GC_2138,(0,74):C.GC_2136,(0,75):C.GC_2136,(0,1):C.GC_2139,(0,79):C.GC_2136,(0,80):C.GC_2137,(0,81):C.GC_2137,(0,3):C.GC_2139,(0,2):C.GC_2137,(0,7):C.GC_2139,(0,5):C.GC_2137,(0,13):C.GC_2139,(0,8):C.GC_2136,(0,9):C.GC_2137,(0,10):C.GC_2137,(0,17):C.GC_2139,(0,14):C.GC_2137,(0,15):C.GC_2136,(0,16):C.GC_2137,(0,21):C.GC_2139,(0,20):C.GC_2137,(0,23):C.GC_1047,(0,28):C.GC_2139,(0,27):C.GC_2137,(0,33):C.GC_2139,(0,29):C.GC_2137,(0,30):C.GC_2136,(0,31):C.GC_2137,(0,35):C.GC_1047,(0,42):C.GC_2138,(0,43):C.GC_2139,(0,39):C.GC_2136,(0,41):C.GC_2136,(0,47):C.GC_2138,(0,48):C.GC_2139,(0,44):C.GC_2136,(0,45):C.GC_2136,(0,49):C.GC_1045,(0,24):C.GC_2136,(0,50):C.GC_2137,(0,38):C.GC_2136,(0,52):C.GC_2137,(0,37):C.GC_2136,(0,51):C.GC_2137,(0,25):C.GC_2136,(0,53):C.GC_2137,(0,26):C.GC_5495,(0,46):C.GC_5499,(0,78):C.GC_5495,(0,6):C.GC_5495,(0,64):C.GC_5495,(0,68):C.GC_5499,(0,56):C.GC_5499,(0,59):C.GC_5499,(0,82):C.GC_5495,(0,11):C.GC_5495,(0,18):C.GC_5495,(0,34):C.GC_5495,(0,36):C.GC_5499,(0,65):C.GC_5495,(0,55):C.GC_5495,(0,69):C.GC_5499})

V_597 = Vertex(name = 'V_597',
               particles = [ P.W__minus__, P.W__plus__, P.Z, P.Z ],
               color = [ '1' ],
               lorentz = [ L.VVVV10, L.VVVV100, L.VVVV101, L.VVVV108, L.VVVV11, L.VVVV116, L.VVVV120, L.VVVV122, L.VVVV123, L.VVVV124, L.VVVV13, L.VVVV130, L.VVVV134, L.VVVV135, L.VVVV136, L.VVVV137, L.VVVV14, L.VVVV140, L.VVVV147, L.VVVV15, L.VVVV151, L.VVVV153, L.VVVV156, L.VVVV162, L.VVVV166, L.VVVV167, L.VVVV168, L.VVVV169, L.VVVV17, L.VVVV174, L.VVVV177, L.VVVV180, L.VVVV181, L.VVVV189, L.VVVV19, L.VVVV190, L.VVVV191, L.VVVV192, L.VVVV193, L.VVVV195, L.VVVV200, L.VVVV201, L.VVVV203, L.VVVV205, L.VVVV206, L.VVVV207, L.VVVV208, L.VVVV21, L.VVVV24, L.VVVV29, L.VVVV35, L.VVVV36, L.VVVV41, L.VVVV42, L.VVVV45, L.VVVV46, L.VVVV75, L.VVVV76, L.VVVV79, L.VVVV80, L.VVVV81, L.VVVV82, L.VVVV88, L.VVVV89, L.VVVV96, L.VVVV97, L.VVVV98 ],
               couplings = {(0,19):C.GC_5497,(0,28):C.GC_5497,(0,34):C.GC_5497,(0,47):C.GC_5501,(0,0):C.GC_5495,(0,4):C.GC_5495,(0,10):C.GC_5495,(0,16):C.GC_5499,(0,52):C.GC_5501,(0,53):C.GC_5497,(0,54):C.GC_5501,(0,55):C.GC_5501,(0,48):C.GC_5499,(0,49):C.GC_5499,(0,50):C.GC_5495,(0,51):C.GC_5499,(0,58):C.GC_5497,(0,59):C.GC_5497,(0,56):C.GC_5485,(0,57):C.GC_5485,(0,62):C.GC_5501,(0,63):C.GC_5501,(0,60):C.GC_5485,(0,61):C.GC_5485,(0,1):C.GC_5495,(0,64):C.GC_5485,(0,65):C.GC_5483,(0,66):C.GC_5483,(0,3):C.GC_5497,(0,2):C.GC_5483,(0,6):C.GC_5497,(0,5):C.GC_5483,(0,11):C.GC_5495,(0,7):C.GC_5485,(0,8):C.GC_5483,(0,9):C.GC_5483,(0,15):C.GC_5495,(0,12):C.GC_5483,(0,13):C.GC_5485,(0,14):C.GC_5483,(0,18):C.GC_5497,(0,17):C.GC_5483,(0,20):C.GC_2151,(0,24):C.GC_5497,(0,23):C.GC_5483,(0,29):C.GC_5495,(0,25):C.GC_5483,(0,26):C.GC_5485,(0,27):C.GC_5483,(0,30):C.GC_2151,(0,36):C.GC_5499,(0,37):C.GC_5495,(0,33):C.GC_5485,(0,35):C.GC_5485,(0,40):C.GC_5499,(0,41):C.GC_5495,(0,38):C.GC_5485,(0,39):C.GC_5485,(0,42):C.GC_2152,(0,21):C.GC_5485,(0,43):C.GC_5483,(0,32):C.GC_5485,(0,45):C.GC_5483,(0,31):C.GC_5485,(0,44):C.GC_5483,(0,22):C.GC_5485,(0,46):C.GC_5483})

V_598 = Vertex(name = 'V_598',
               particles = [ P.W__minus__, P.W__plus__, P.Z, P.Z ],
               color = [ '1' ],
               lorentz = [ L.VVVV151, L.VVVV177, L.VVVV203 ],
               couplings = {(0,0):C.GC_5568,(0,1):C.GC_5568,(0,2):C.GC_5571})

V_599 = Vertex(name = 'V_599',
               particles = [ P.W__minus__, P.W__plus__, P.Z, P.Z ],
               color = [ '1' ],
               lorentz = [ L.VVVV151, L.VVVV177, L.VVVV203 ],
               couplings = {(0,0):C.GC_5033,(0,1):C.GC_5033,(0,2):C.GC_3159})

V_600 = Vertex(name = 'V_600',
               particles = [ P.A, P.Z, P.Z, P.Z ],
               color = [ '1' ],
               lorentz = [ L.VVVV101, L.VVVV104, L.VVVV108, L.VVVV11, L.VVVV111, L.VVVV112, L.VVVV113, L.VVVV115, L.VVVV116, L.VVVV120, L.VVVV122, L.VVVV124, L.VVVV126, L.VVVV127, L.VVVV128, L.VVVV13, L.VVVV132, L.VVVV133, L.VVVV134, L.VVVV137, L.VVVV139, L.VVVV142, L.VVVV146, L.VVVV15, L.VVVV150, L.VVVV152, L.VVVV153, L.VVVV155, L.VVVV158, L.VVVV159, L.VVVV160, L.VVVV161, L.VVVV165, L.VVVV167, L.VVVV17, L.VVVV171, L.VVVV173, L.VVVV174, L.VVVV178, L.VVVV179, L.VVVV181, L.VVVV184, L.VVVV186, L.VVVV188, L.VVVV189, L.VVVV191, L.VVVV193, L.VVVV197, L.VVVV199, L.VVVV200, L.VVVV204, L.VVVV205, L.VVVV207, L.VVVV210, L.VVVV25, L.VVVV27, L.VVVV28, L.VVVV29, L.VVVV3, L.VVVV31, L.VVVV34, L.VVVV35, L.VVVV37, L.VVVV39, L.VVVV4, L.VVVV41, L.VVVV42, L.VVVV50, L.VVVV55, L.VVVV58, L.VVVV59, L.VVVV6, L.VVVV60, L.VVVV61, L.VVVV62, L.VVVV64, L.VVVV66, L.VVVV68, L.VVVV7, L.VVVV70, L.VVVV72, L.VVVV73, L.VVVV75, L.VVVV79, L.VVVV81, L.VVVV84, L.VVVV88, L.VVVV91, L.VVVV92, L.VVVV93, L.VVVV95, L.VVVV96, L.VVVV98 ],
               couplings = {(0,71):C.GC_809,(0,78):C.GC_809,(0,58):C.GC_4969,(0,64):C.GC_4969,(0,23):C.GC_809,(0,34):C.GC_808,(0,3):C.GC_4969,(0,15):C.GC_4968,(0,65):C.GC_808,(0,66):C.GC_808,(0,57):C.GC_4968,(0,61):C.GC_4968,(0,80):C.GC_6059,(0,81):C.GC_6059,(0,83):C.GC_809,(0,82):C.GC_6060,(0,86):C.GC_808,(0,84):C.GC_6060,(0,90):C.GC_809,(0,89):C.GC_6060,(0,91):C.GC_6059,(0,92):C.GC_6059,(0,2):C.GC_808,(0,0):C.GC_6060,(0,7):C.GC_809,(0,6):C.GC_6060,(0,9):C.GC_808,(0,8):C.GC_6060,(0,10):C.GC_6059,(0,11):C.GC_6059,(0,17):C.GC_4969,(0,16):C.GC_6060,(0,19):C.GC_4969,(0,18):C.GC_6060,(0,22):C.GC_6063,(0,20):C.GC_6062,(0,30):C.GC_4969,(0,29):C.GC_6060,(0,32):C.GC_6063,(0,31):C.GC_6062,(0,37):C.GC_4969,(0,33):C.GC_6060,(0,43):C.GC_6063,(0,42):C.GC_6062,(0,45):C.GC_4969,(0,44):C.GC_6060,(0,49):C.GC_4969,(0,46):C.GC_6060,(0,25):C.GC_6059,(0,38):C.GC_6059,(0,50):C.GC_6061,(0,26):C.GC_6059,(0,39):C.GC_6061,(0,51):C.GC_6059,(0,27):C.GC_6061,(0,40):C.GC_6059,(0,52):C.GC_6059,(0,68):C.GC_6197,(0,67):C.GC_6197,(0,72):C.GC_6198,(0,73):C.GC_6195,(0,74):C.GC_6196,(0,69):C.GC_6198,(0,70):C.GC_6200,(0,75):C.GC_6195,(0,76):C.GC_6195,(0,77):C.GC_6196,(0,79):C.GC_6196,(0,55):C.GC_6197,(0,56):C.GC_6198,(0,54):C.GC_6194,(0,60):C.GC_6200,(0,59):C.GC_6194,(0,63):C.GC_6200,(0,62):C.GC_6194,(0,87):C.GC_6198,(0,88):C.GC_6197,(0,85):C.GC_6193,(0,4):C.GC_6198,(0,5):C.GC_6197,(0,1):C.GC_6193,(0,13):C.GC_6198,(0,14):C.GC_6197,(0,12):C.GC_6193,(0,24):C.GC_6199,(0,21):C.GC_6193,(0,28):C.GC_6194,(0,36):C.GC_6199,(0,35):C.GC_6193,(0,41):C.GC_6194,(0,48):C.GC_6199,(0,47):C.GC_6193,(0,53):C.GC_6194})

V_601 = Vertex(name = 'V_601',
               particles = [ P.Z, P.Z, P.Z, P.Z ],
               color = [ '1' ],
               lorentz = [ L.VVVV10, L.VVVV100, L.VVVV101, L.VVVV102, L.VVVV103, L.VVVV104, L.VVVV105, L.VVVV106, L.VVVV107, L.VVVV109, L.VVVV11, L.VVVV111, L.VVVV112, L.VVVV113, L.VVVV114, L.VVVV116, L.VVVV117, L.VVVV118, L.VVVV119, L.VVVV121, L.VVVV122, L.VVVV123, L.VVVV124, L.VVVV125, L.VVVV126, L.VVVV127, L.VVVV128, L.VVVV13, L.VVVV130, L.VVVV131, L.VVVV132, L.VVVV133, L.VVVV134, L.VVVV135, L.VVVV136, L.VVVV137, L.VVVV139, L.VVVV14, L.VVVV140, L.VVVV141, L.VVVV142, L.VVVV143, L.VVVV144, L.VVVV145, L.VVVV146, L.VVVV149, L.VVVV15, L.VVVV150, L.VVVV151, L.VVVV152, L.VVVV153, L.VVVV154, L.VVVV155, L.VVVV156, L.VVVV157, L.VVVV158, L.VVVV159, L.VVVV160, L.VVVV161, L.VVVV162, L.VVVV163, L.VVVV164, L.VVVV165, L.VVVV167, L.VVVV168, L.VVVV169, L.VVVV17, L.VVVV170, L.VVVV171, L.VVVV172, L.VVVV173, L.VVVV174, L.VVVV176, L.VVVV177, L.VVVV178, L.VVVV179, L.VVVV180, L.VVVV181, L.VVVV182, L.VVVV183, L.VVVV184, L.VVVV186, L.VVVV187, L.VVVV188, L.VVVV189, L.VVVV19, L.VVVV190, L.VVVV191, L.VVVV192, L.VVVV193, L.VVVV194, L.VVVV195, L.VVVV196, L.VVVV197, L.VVVV198, L.VVVV199, L.VVVV200, L.VVVV201, L.VVVV203, L.VVVV204, L.VVVV205, L.VVVV206, L.VVVV207, L.VVVV208, L.VVVV209, L.VVVV21, L.VVVV210, L.VVVV24, L.VVVV25, L.VVVV26, L.VVVV27, L.VVVV28, L.VVVV29, L.VVVV3, L.VVVV31, L.VVVV32, L.VVVV33, L.VVVV34, L.VVVV35, L.VVVV36, L.VVVV37, L.VVVV38, L.VVVV39, L.VVVV4, L.VVVV41, L.VVVV42, L.VVVV45, L.VVVV46, L.VVVV49, L.VVVV50, L.VVVV51, L.VVVV52, L.VVVV55, L.VVVV56, L.VVVV57, L.VVVV58, L.VVVV59, L.VVVV6, L.VVVV60, L.VVVV61, L.VVVV62, L.VVVV63, L.VVVV64, L.VVVV65, L.VVVV66, L.VVVV67, L.VVVV68, L.VVVV69, L.VVVV7, L.VVVV70, L.VVVV72, L.VVVV73, L.VVVV75, L.VVVV76, L.VVVV77, L.VVVV78, L.VVVV81, L.VVVV82, L.VVVV83, L.VVVV84, L.VVVV85, L.VVVV86, L.VVVV87, L.VVVV90, L.VVVV91, L.VVVV92, L.VVVV93, L.VVVV94, L.VVVV96, L.VVVV97, L.VVVV98 ],
               couplings = {(0,132):C.GC_1463,(0,133):C.GC_1462,(0,134):C.GC_1461,(0,129):C.GC_1463,(0,131):C.GC_1463,(0,138):C.GC_1464,(0,139):C.GC_1461,(0,140):C.GC_1462,(0,135):C.GC_1464,(0,136):C.GC_1464,(0,141):C.GC_1462,(0,142):C.GC_1461,(0,143):C.GC_1462,(0,144):C.GC_1461,(0,145):C.GC_1461,(0,146):C.GC_1462,(0,147):C.GC_1461,(0,149):C.GC_1462,(0,110):C.GC_1463,(0,111):C.GC_1464,(0,108):C.GC_1460,(0,116):C.GC_1463,(0,117):C.GC_1464,(0,114):C.GC_1460,(0,121):C.GC_1463,(0,122):C.GC_1464,(0,120):C.GC_1460,(0,150):C.GC_6072,(0,151):C.GC_6072,(0,152):C.GC_6074,(0,153):C.GC_6074,(0,162):C.GC_6068,(0,163):C.GC_6070,(0,156):C.GC_6074,(0,157):C.GC_6074,(0,158):C.GC_6066,(0,166):C.GC_6074,(0,168):C.GC_6072,(0,169):C.GC_6074,(0,170):C.GC_6072,(0,7):C.GC_6068,(0,9):C.GC_6070,(0,2):C.GC_6074,(0,3):C.GC_6066,(0,4):C.GC_6074,(0,13):C.GC_6074,(0,18):C.GC_6068,(0,19):C.GC_6070,(0,15):C.GC_6074,(0,16):C.GC_6066,(0,20):C.GC_6072,(0,21):C.GC_6074,(0,22):C.GC_6072,(0,23):C.GC_6074,(0,30):C.GC_6074,(0,32):C.GC_6074,(0,33):C.GC_6072,(0,34):C.GC_6072,(0,41):C.GC_6068,(0,44):C.GC_6070,(0,36):C.GC_6066,(0,38):C.GC_6074,(0,39):C.GC_6074,(0,48):C.GC_5113,(0,56):C.GC_6074,(0,60):C.GC_6068,(0,62):C.GC_6070,(0,58):C.GC_6066,(0,59):C.GC_6074,(0,63):C.GC_6074,(0,64):C.GC_6072,(0,65):C.GC_6072,(0,67):C.GC_6074,(0,73):C.GC_5113,(0,82):C.GC_6068,(0,83):C.GC_6070,(0,81):C.GC_6066,(0,84):C.GC_6074,(0,86):C.GC_6074,(0,89):C.GC_6074,(0,90):C.GC_6072,(0,91):C.GC_6074,(0,92):C.GC_6072,(0,98):C.GC_5113,(0,164):C.GC_1464,(0,165):C.GC_1463,(0,159):C.GC_1459,(0,49):C.GC_6072,(0,74):C.GC_6072,(0,99):C.GC_6064,(0,11):C.GC_1464,(0,12):C.GC_1463,(0,5):C.GC_1459,(0,50):C.GC_6072,(0,75):C.GC_6064,(0,100):C.GC_6072,(0,25):C.GC_1464,(0,26):C.GC_1463,(0,24):C.GC_1459,(0,52):C.GC_6064,(0,77):C.GC_6072,(0,102):C.GC_6072,(0,45):C.GC_1464,(0,47):C.GC_1463,(0,40):C.GC_1459,(0,51):C.GC_6064,(0,76):C.GC_6072,(0,101):C.GC_6072,(0,55):C.GC_1460,(0,53):C.GC_6072,(0,69):C.GC_1464,(0,70):C.GC_1463,(0,68):C.GC_1459,(0,78):C.GC_6064,(0,103):C.GC_6072,(0,80):C.GC_1460,(0,54):C.GC_6072,(0,79):C.GC_6072,(0,94):C.GC_1464,(0,95):C.GC_1463,(0,93):C.GC_1459,(0,104):C.GC_6064,(0,106):C.GC_1460,(0,137):C.GC_3866,(0,148):C.GC_3866,(0,113):C.GC_3867,(0,123):C.GC_3867,(0,46):C.GC_3866,(0,66):C.GC_3867,(0,85):C.GC_3866,(0,105):C.GC_3866,(0,0):C.GC_3867,(0,10):C.GC_3867,(0,27):C.GC_3866,(0,37):C.GC_3867,(0,124):C.GC_3867,(0,125):C.GC_3867,(0,126):C.GC_3867,(0,127):C.GC_3866,(0,128):C.GC_3866,(0,130):C.GC_3866,(0,107):C.GC_3866,(0,109):C.GC_3867,(0,112):C.GC_3866,(0,115):C.GC_3867,(0,118):C.GC_3866,(0,119):C.GC_3867,(0,154):C.GC_3867,(0,155):C.GC_3867,(0,160):C.GC_3866,(0,161):C.GC_3866,(0,167):C.GC_3867,(0,1):C.GC_3867,(0,6):C.GC_3866,(0,8):C.GC_3866,(0,14):C.GC_3867,(0,17):C.GC_3866,(0,28):C.GC_3867,(0,29):C.GC_3866,(0,31):C.GC_3867,(0,35):C.GC_3867,(0,42):C.GC_3866,(0,43):C.GC_3866,(0,57):C.GC_3867,(0,61):C.GC_3866,(0,71):C.GC_3867,(0,72):C.GC_3866,(0,87):C.GC_3867,(0,88):C.GC_3866,(0,96):C.GC_3867,(0,97):C.GC_3866})

V_602 = Vertex(name = 'V_602',
               particles = [ P.A, P.A, P.G0, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSS13, L.VVSS19, L.VVSS24, L.VVSS27, L.VVSS32, L.VVSS33, L.VVSS41, L.VVSS42 ],
               couplings = {(0,2):C.GC_4130,(0,3):C.GC_4130,(0,0):C.GC_4131,(0,1):C.GC_4131,(0,7):C.GC_4131,(0,5):C.GC_4130,(0,6):C.GC_4130,(0,4):C.GC_4131})

V_603 = Vertex(name = 'V_603',
               particles = [ P.Z, P.Z, P.G0, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSS13, L.VVSS19, L.VVSS24, L.VVSS27, L.VVSS32, L.VVSS33, L.VVSS41, L.VVSS42 ],
               couplings = {(0,2):C.GC_4131,(0,3):C.GC_4131,(0,0):C.GC_4130,(0,1):C.GC_4130,(0,7):C.GC_4130,(0,5):C.GC_4131,(0,6):C.GC_4131,(0,4):C.GC_4130})

V_604 = Vertex(name = 'V_604',
               particles = [ P.W__minus__, P.Z, P.Z, P.G0, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVSS104, L.VVVSS105, L.VVVSS106, L.VVVSS107, L.VVVSS108, L.VVVSS109, L.VVVSS11, L.VVVSS110, L.VVVSS111, L.VVVSS112, L.VVVSS113, L.VVVSS114, L.VVVSS115, L.VVVSS117, L.VVVSS118, L.VVVSS12, L.VVVSS120, L.VVVSS121, L.VVVSS123, L.VVVSS124, L.VVVSS126, L.VVVSS127, L.VVVSS129, L.VVVSS130, L.VVVSS137, L.VVVSS138, L.VVVSS14, L.VVVSS140, L.VVVSS143, L.VVVSS146, L.VVVSS147, L.VVVSS148, L.VVVSS149, L.VVVSS150, L.VVVSS151, L.VVVSS152, L.VVVSS153, L.VVVSS154, L.VVVSS155, L.VVVSS157, L.VVVSS158, L.VVVSS159, L.VVVSS160, L.VVVSS162, L.VVVSS163, L.VVVSS164, L.VVVSS165, L.VVVSS166, L.VVVSS167, L.VVVSS168, L.VVVSS17, L.VVVSS171, L.VVVSS173, L.VVVSS178, L.VVVSS18, L.VVVSS182, L.VVVSS183, L.VVVSS184, L.VVVSS185, L.VVVSS186, L.VVVSS187, L.VVVSS189, L.VVVSS19, L.VVVSS190, L.VVVSS191, L.VVVSS192, L.VVVSS193, L.VVVSS194, L.VVVSS195, L.VVVSS196, L.VVVSS197, L.VVVSS199, L.VVVSS2, L.VVVSS200, L.VVVSS202, L.VVVSS203, L.VVVSS204, L.VVVSS205, L.VVVSS206, L.VVVSS208, L.VVVSS21, L.VVVSS210, L.VVVSS218, L.VVVSS219, L.VVVSS22, L.VVVSS222, L.VVVSS223, L.VVVSS224, L.VVVSS225, L.VVVSS226, L.VVVSS227, L.VVVSS228, L.VVVSS229, L.VVVSS23, L.VVVSS230, L.VVVSS231, L.VVVSS232, L.VVVSS233, L.VVVSS234, L.VVVSS235, L.VVVSS236, L.VVVSS237, L.VVVSS238, L.VVVSS239, L.VVVSS24, L.VVVSS240, L.VVVSS241, L.VVVSS242, L.VVVSS243, L.VVVSS244, L.VVVSS245, L.VVVSS246, L.VVVSS247, L.VVVSS248, L.VVVSS249, L.VVVSS25, L.VVVSS26, L.VVVSS27, L.VVVSS28, L.VVVSS29, L.VVVSS30, L.VVVSS31, L.VVVSS32, L.VVVSS34, L.VVVSS36, L.VVVSS37, L.VVVSS38, L.VVVSS39, L.VVVSS40, L.VVVSS42, L.VVVSS43, L.VVVSS44, L.VVVSS45, L.VVVSS46, L.VVVSS47, L.VVVSS48, L.VVVSS49, L.VVVSS50, L.VVVSS51, L.VVVSS52, L.VVVSS53, L.VVVSS54, L.VVVSS56, L.VVVSS57, L.VVVSS58, L.VVVSS59, L.VVVSS6, L.VVVSS60, L.VVVSS61, L.VVVSS63, L.VVVSS65, L.VVVSS67, L.VVVSS68, L.VVVSS70, L.VVVSS71, L.VVVSS72, L.VVVSS73, L.VVVSS74, L.VVVSS75, L.VVVSS78, L.VVVSS79, L.VVVSS80, L.VVVSS82, L.VVVSS83, L.VVVSS85, L.VVVSS87, L.VVVSS88, L.VVVSS89, L.VVVSS9, L.VVVSS90, L.VVVSS91, L.VVVSS93, L.VVVSS94, L.VVVSS95, L.VVVSS97, L.VVVSS98 ],
               couplings = {(0,72):C.GC_5494,(0,168):C.GC_5491,(0,27):C.GC_5490,(0,29):C.GC_1635,(0,39):C.GC_1365,(0,53):C.GC_5490,(0,56):C.GC_1635,(0,67):C.GC_1365,(0,82):C.GC_5487,(0,83):C.GC_5487,(0,87):C.GC_1631,(0,98):C.GC_1369,(0,131):C.GC_1581,(0,129):C.GC_5961,(0,137):C.GC_1581,(0,134):C.GC_5961,(0,80):C.GC_1583,(0,62):C.GC_5922,(0,104):C.GC_5517,(0,115):C.GC_1570,(0,116):C.GC_5524,(0,84):C.GC_5922,(0,93):C.GC_5513,(0,118):C.GC_5949,(0,117):C.GC_5927,(0,120):C.GC_5542,(0,127):C.GC_5949,(0,125):C.GC_5927,(0,126):C.GC_5542,(0,2):C.GC_1304,(0,0):C.GC_5947,(0,9):C.GC_1304,(0,5):C.GC_5947,(0,13):C.GC_1582,(0,14):C.GC_1569,(0,16):C.GC_5551,(0,17):C.GC_1582,(0,18):C.GC_1582,(0,19):C.GC_5551,(0,142):C.GC_1305,(0,141):C.GC_5937,(0,145):C.GC_5516,(0,147):C.GC_1309,(0,148):C.GC_5525,(0,143):C.GC_5937,(0,144):C.GC_5514,(0,151):C.GC_1571,(0,152):C.GC_1580,(0,149):C.GC_5533,(0,150):C.GC_5533,(0,154):C.GC_5959,(0,153):C.GC_5940,(0,156):C.GC_5543,(0,162):C.GC_5548,(0,163):C.GC_1571,(0,159):C.GC_5530,(0,160):C.GC_5547,(0,161):C.GC_5544,(0,169):C.GC_5959,(0,166):C.GC_5940,(0,167):C.GC_5543,(0,174):C.GC_1571,(0,175):C.GC_5548,(0,171):C.GC_5530,(0,172):C.GC_5544,(0,173):C.GC_5547,(0,38):C.GC_1581,(0,49):C.GC_1304,(0,61):C.GC_1581,(0,74):C.GC_1304,(0,92):C.GC_5961,(0,97):C.GC_5961,(0,106):C.GC_5947,(0,110):C.GC_5947,(0,57):C.GC_5938,(0,68):C.GC_5921,(0,88):C.GC_5943,(0,99):C.GC_5924,(0,31):C.GC_5938,(0,41):C.GC_5921,(0,89):C.GC_5943,(0,100):C.GC_5924,(0,132):C.GC_1583,(0,138):C.GC_1570,(0,33):C.GC_5943,(0,63):C.GC_5943,(0,91):C.GC_5922,(0,94):C.GC_5922,(0,3):C.GC_1305,(0,10):C.GC_1309,(0,44):C.GC_5924,(0,75):C.GC_5924,(0,105):C.GC_5937,(0,107):C.GC_5937,(0,32):C.GC_5529,(0,42):C.GC_5528,(0,59):C.GC_5529,(0,70):C.GC_5528,(0,90):C.GC_5505,(0,101):C.GC_5504,(0,130):C.GC_5949,(0,24):C.GC_5551,(0,34):C.GC_5938,(0,43):C.GC_5533,(0,60):C.GC_5927,(0,64):C.GC_5542,(0,95):C.GC_5529,(0,102):C.GC_5544,(0,1):C.GC_5959,(0,22):C.GC_5548,(0,45):C.GC_5921,(0,51):C.GC_5530,(0,73):C.GC_5940,(0,76):C.GC_5543,(0,108):C.GC_5528,(0,111):C.GC_5547,(0,135):C.GC_5957,(0,25):C.GC_5564,(0,35):C.GC_5927,(0,36):C.GC_5542,(0,65):C.GC_5938,(0,71):C.GC_5533,(0,96):C.GC_5529,(0,103):C.GC_5544,(0,7):C.GC_5945,(0,23):C.GC_5567,(0,46):C.GC_5940,(0,47):C.GC_5543,(0,77):C.GC_5921,(0,79):C.GC_5530,(0,109):C.GC_5528,(0,112):C.GC_5547,(0,6):C.GC_5398,(0,50):C.GC_5398,(0,26):C.GC_5398,(0,146):C.GC_5395,(0,28):C.GC_5395,(0,55):C.GC_5395,(0,85):C.GC_5395,(0,86):C.GC_5395,(0,54):C.GC_5398,(0,15):C.GC_5395,(0,139):C.GC_5563,(0,133):C.GC_5552,(0,121):C.GC_5553,(0,122):C.GC_5915,(0,119):C.GC_5908,(0,124):C.GC_5915,(0,123):C.GC_5908,(0,128):C.GC_5553,(0,11):C.GC_5562,(0,4):C.GC_5553,(0,157):C.GC_5552,(0,158):C.GC_5918,(0,155):C.GC_5913,(0,165):C.GC_5918,(0,164):C.GC_5913,(0,170):C.GC_5552,(0,37):C.GC_5552,(0,48):C.GC_5553,(0,66):C.GC_5552,(0,78):C.GC_5553,(0,30):C.GC_5914,(0,40):C.GC_5907,(0,58):C.GC_5914,(0,69):C.GC_5907,(0,140):C.GC_5553,(0,12):C.GC_5552,(0,136):C.GC_5562,(0,8):C.GC_5563,(0,20):C.GC_5515,(0,21):C.GC_5526,(0,52):C.GC_5503,(0,81):C.GC_5503,(0,113):C.GC_5512,(0,114):C.GC_5512})

V_605 = Vertex(name = 'V_605',
               particles = [ P.W__minus__, P.Z, P.Z, P.G0, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVSS140, L.VVVSS146, L.VVVSS157, L.VVVSS178, L.VVVSS183, L.VVVSS194, L.VVVSS2, L.VVVSS218, L.VVVSS219, L.VVVSS224, L.VVVSS234, L.VVVSS9 ],
               couplings = {(0,6):C.GC_5580,(0,11):C.GC_5583,(0,0):C.GC_5573,(0,1):C.GC_5010,(0,2):C.GC_5009,(0,3):C.GC_5573,(0,4):C.GC_5010,(0,5):C.GC_5009,(0,7):C.GC_5576,(0,8):C.GC_5576,(0,9):C.GC_5011,(0,10):C.GC_3123})

V_606 = Vertex(name = 'V_606',
               particles = [ P.W__minus__, P.Z, P.Z, P.G0, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVSS140, L.VVVSS178, L.VVVSS2, L.VVVSS218, L.VVVSS219, L.VVVSS9 ],
               couplings = {(0,2):C.GC_5466,(0,5):C.GC_5463,(0,0):C.GC_5462,(0,1):C.GC_5462,(0,3):C.GC_5459,(0,4):C.GC_5459})

V_607 = Vertex(name = 'V_607',
               particles = [ P.W__minus__, P.Z, P.Z, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVS100, L.VVVS103, L.VVVS104, L.VVVS105, L.VVVS106, L.VVVS107, L.VVVS108, L.VVVS109, L.VVVS11, L.VVVS110, L.VVVS111, L.VVVS112, L.VVVS113, L.VVVS114, L.VVVS12, L.VVVS14, L.VVVS17, L.VVVS18, L.VVVS19, L.VVVS2, L.VVVS21, L.VVVS22, L.VVVS23, L.VVVS24, L.VVVS25, L.VVVS26, L.VVVS27, L.VVVS28, L.VVVS29, L.VVVS30, L.VVVS31, L.VVVS32, L.VVVS35, L.VVVS37, L.VVVS38, L.VVVS39, L.VVVS40, L.VVVS41, L.VVVS46, L.VVVS47, L.VVVS48, L.VVVS49, L.VVVS50, L.VVVS51, L.VVVS52, L.VVVS53, L.VVVS54, L.VVVS55, L.VVVS56, L.VVVS57, L.VVVS59, L.VVVS6, L.VVVS62, L.VVVS65, L.VVVS66, L.VVVS67, L.VVVS68, L.VVVS69, L.VVVS70, L.VVVS71, L.VVVS72, L.VVVS73, L.VVVS74, L.VVVS78, L.VVVS82, L.VVVS83, L.VVVS84, L.VVVS85, L.VVVS86, L.VVVS87, L.VVVS89, L.VVVS9, L.VVVS90, L.VVVS91, L.VVVS92, L.VVVS93, L.VVVS99 ],
               couplings = {(0,40):C.GC_1204,(0,38):C.GC_5877,(0,46):C.GC_1204,(0,43):C.GC_5877,(0,20):C.GC_1205,(0,18):C.GC_5864,(0,23):C.GC_5470,(0,24):C.GC_1202,(0,25):C.GC_5469,(0,21):C.GC_5864,(0,22):C.GC_5467,(0,27):C.GC_5874,(0,26):C.GC_5867,(0,29):C.GC_5471,(0,36):C.GC_5874,(0,34):C.GC_5867,(0,35):C.GC_5471,(0,62):C.GC_1204,(0,53):C.GC_1378,(0,70):C.GC_1204,(0,65):C.GC_1378,(0,9):C.GC_5877,(0,13):C.GC_5877,(0,3):C.GC_1381,(0,66):C.GC_5868,(0,4):C.GC_5871,(0,55):C.GC_5868,(0,5):C.GC_5871,(0,41):C.GC_1205,(0,47):C.GC_1202,(0,57):C.GC_5871,(0,72):C.GC_5871,(0,7):C.GC_5864,(0,10):C.GC_5864,(0,56):C.GC_5472,(0,68):C.GC_5472,(0,6):C.GC_5468,(0,39):C.GC_5874,(0,58):C.GC_5868,(0,69):C.GC_5867,(0,73):C.GC_5471,(0,11):C.GC_5472,(0,44):C.GC_5875,(0,59):C.GC_5867,(0,60):C.GC_5471,(0,74):C.GC_5868,(0,12):C.GC_5472,(0,19):C.GC_5479,(0,71):C.GC_5480,(0,50):C.GC_5477,(0,63):C.GC_5477,(0,76):C.GC_5478,(0,0):C.GC_5478,(0,48):C.GC_5473,(0,42):C.GC_5476,(0,30):C.GC_5475,(0,31):C.GC_5862,(0,28):C.GC_5860,(0,33):C.GC_5862,(0,32):C.GC_5860,(0,37):C.GC_5475,(0,61):C.GC_5476,(0,75):C.GC_5476,(0,54):C.GC_5861,(0,67):C.GC_5861,(0,49):C.GC_5475,(0,45):C.GC_5474,(0,8):C.GC_5453,(0,16):C.GC_5453,(0,15):C.GC_5453,(0,51):C.GC_5454,(0,52):C.GC_5454,(0,64):C.GC_5454,(0,1):C.GC_5454,(0,2):C.GC_5454,(0,17):C.GC_5453,(0,14):C.GC_5454})

V_608 = Vertex(name = 'V_608',
               particles = [ P.W__minus__, P.Z, P.Z, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVS100, L.VVVS105, L.VVVS2, L.VVVS59, L.VVVS65, L.VVVS78, L.VVVS83, L.VVVS9, L.VVVS99 ],
               couplings = {(0,4):C.GC_5004,(0,6):C.GC_5004,(0,1):C.GC_3119,(0,2):C.GC_5612,(0,7):C.GC_5613,(0,3):C.GC_5608,(0,5):C.GC_5608,(0,8):C.GC_5609,(0,0):C.GC_5609})

V_609 = Vertex(name = 'V_609',
               particles = [ P.W__minus__, P.Z, P.Z, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVS100, L.VVVS2, L.VVVS59, L.VVVS78, L.VVVS9, L.VVVS99 ],
               couplings = {(0,1):C.GC_5457,(0,4):C.GC_5458,(0,2):C.GC_5455,(0,3):C.GC_5455,(0,5):C.GC_5456,(0,0):C.GC_5456})

V_610 = Vertex(name = 'V_610',
               particles = [ P.W__minus__, P.Z, P.Z, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVSS104, L.VVVSS105, L.VVVSS106, L.VVVSS107, L.VVVSS108, L.VVVSS109, L.VVVSS11, L.VVVSS110, L.VVVSS111, L.VVVSS112, L.VVVSS113, L.VVVSS114, L.VVVSS115, L.VVVSS117, L.VVVSS118, L.VVVSS12, L.VVVSS120, L.VVVSS121, L.VVVSS123, L.VVVSS124, L.VVVSS126, L.VVVSS127, L.VVVSS129, L.VVVSS130, L.VVVSS137, L.VVVSS138, L.VVVSS14, L.VVVSS140, L.VVVSS143, L.VVVSS146, L.VVVSS147, L.VVVSS148, L.VVVSS149, L.VVVSS150, L.VVVSS151, L.VVVSS152, L.VVVSS153, L.VVVSS154, L.VVVSS155, L.VVVSS157, L.VVVSS158, L.VVVSS159, L.VVVSS160, L.VVVSS162, L.VVVSS163, L.VVVSS164, L.VVVSS165, L.VVVSS166, L.VVVSS167, L.VVVSS168, L.VVVSS17, L.VVVSS171, L.VVVSS173, L.VVVSS178, L.VVVSS18, L.VVVSS182, L.VVVSS183, L.VVVSS184, L.VVVSS185, L.VVVSS186, L.VVVSS187, L.VVVSS189, L.VVVSS19, L.VVVSS190, L.VVVSS191, L.VVVSS192, L.VVVSS193, L.VVVSS194, L.VVVSS195, L.VVVSS196, L.VVVSS197, L.VVVSS199, L.VVVSS2, L.VVVSS200, L.VVVSS202, L.VVVSS203, L.VVVSS204, L.VVVSS205, L.VVVSS206, L.VVVSS208, L.VVVSS21, L.VVVSS210, L.VVVSS218, L.VVVSS219, L.VVVSS22, L.VVVSS222, L.VVVSS223, L.VVVSS224, L.VVVSS225, L.VVVSS226, L.VVVSS227, L.VVVSS228, L.VVVSS229, L.VVVSS23, L.VVVSS230, L.VVVSS231, L.VVVSS232, L.VVVSS233, L.VVVSS234, L.VVVSS235, L.VVVSS236, L.VVVSS237, L.VVVSS238, L.VVVSS239, L.VVVSS24, L.VVVSS240, L.VVVSS241, L.VVVSS242, L.VVVSS243, L.VVVSS244, L.VVVSS245, L.VVVSS246, L.VVVSS247, L.VVVSS248, L.VVVSS249, L.VVVSS25, L.VVVSS26, L.VVVSS27, L.VVVSS28, L.VVVSS29, L.VVVSS30, L.VVVSS31, L.VVVSS32, L.VVVSS34, L.VVVSS36, L.VVVSS37, L.VVVSS38, L.VVVSS39, L.VVVSS40, L.VVVSS42, L.VVVSS43, L.VVVSS44, L.VVVSS45, L.VVVSS46, L.VVVSS47, L.VVVSS48, L.VVVSS49, L.VVVSS50, L.VVVSS51, L.VVVSS52, L.VVVSS53, L.VVVSS54, L.VVVSS56, L.VVVSS57, L.VVVSS58, L.VVVSS59, L.VVVSS6, L.VVVSS60, L.VVVSS61, L.VVVSS63, L.VVVSS65, L.VVVSS67, L.VVVSS68, L.VVVSS70, L.VVVSS71, L.VVVSS72, L.VVVSS73, L.VVVSS74, L.VVVSS75, L.VVVSS78, L.VVVSS79, L.VVVSS80, L.VVVSS82, L.VVVSS83, L.VVVSS85, L.VVVSS87, L.VVVSS88, L.VVVSS89, L.VVVSS9, L.VVVSS90, L.VVVSS91, L.VVVSS93, L.VVVSS94, L.VVVSS95, L.VVVSS97, L.VVVSS98 ],
               couplings = {(0,72):C.GC_5492,(0,168):C.GC_5493,(0,27):C.GC_5488,(0,29):C.GC_1366,(0,39):C.GC_1633,(0,53):C.GC_5488,(0,56):C.GC_1366,(0,67):C.GC_1633,(0,82):C.GC_5489,(0,83):C.GC_5489,(0,87):C.GC_1367,(0,98):C.GC_1634,(0,131):C.GC_1307,(0,129):C.GC_5954,(0,137):C.GC_1307,(0,134):C.GC_5954,(0,80):C.GC_1308,(0,62):C.GC_5928,(0,104):C.GC_5521,(0,115):C.GC_1306,(0,116):C.GC_5518,(0,84):C.GC_5928,(0,93):C.GC_5507,(0,118):C.GC_5951,(0,117):C.GC_5930,(0,120):C.GC_5534,(0,127):C.GC_5951,(0,125):C.GC_5930,(0,126):C.GC_5534,(0,2):C.GC_1574,(0,0):C.GC_5952,(0,9):C.GC_1574,(0,5):C.GC_5952,(0,13):C.GC_1579,(0,14):C.GC_1573,(0,16):C.GC_5560,(0,17):C.GC_1579,(0,18):C.GC_1579,(0,19):C.GC_5560,(0,142):C.GC_1576,(0,141):C.GC_5933,(0,145):C.GC_5520,(0,147):C.GC_1578,(0,148):C.GC_5519,(0,143):C.GC_5933,(0,144):C.GC_5508,(0,151):C.GC_1575,(0,152):C.GC_1577,(0,149):C.GC_5540,(0,150):C.GC_5540,(0,154):C.GC_5955,(0,153):C.GC_5935,(0,156):C.GC_5535,(0,162):C.GC_5561,(0,163):C.GC_1575,(0,159):C.GC_5541,(0,160):C.GC_5536,(0,161):C.GC_5537,(0,169):C.GC_5955,(0,166):C.GC_5935,(0,167):C.GC_5535,(0,174):C.GC_1575,(0,175):C.GC_5561,(0,171):C.GC_5541,(0,172):C.GC_5537,(0,173):C.GC_5536,(0,38):C.GC_1307,(0,49):C.GC_1574,(0,61):C.GC_1307,(0,74):C.GC_1574,(0,92):C.GC_5954,(0,97):C.GC_5954,(0,106):C.GC_5952,(0,110):C.GC_5952,(0,57):C.GC_5932,(0,68):C.GC_5929,(0,88):C.GC_5934,(0,99):C.GC_5931,(0,31):C.GC_5932,(0,41):C.GC_5929,(0,89):C.GC_5934,(0,100):C.GC_5931,(0,132):C.GC_1308,(0,138):C.GC_1306,(0,33):C.GC_5934,(0,63):C.GC_5934,(0,91):C.GC_5928,(0,94):C.GC_5928,(0,3):C.GC_1576,(0,10):C.GC_1578,(0,44):C.GC_5931,(0,75):C.GC_5931,(0,105):C.GC_5933,(0,107):C.GC_5933,(0,32):C.GC_5539,(0,42):C.GC_5538,(0,59):C.GC_5539,(0,70):C.GC_5538,(0,90):C.GC_5511,(0,101):C.GC_5510,(0,130):C.GC_5951,(0,24):C.GC_5560,(0,34):C.GC_5932,(0,43):C.GC_5540,(0,60):C.GC_5930,(0,64):C.GC_5534,(0,95):C.GC_5539,(0,102):C.GC_5537,(0,1):C.GC_5955,(0,22):C.GC_5561,(0,45):C.GC_5929,(0,51):C.GC_5541,(0,73):C.GC_5935,(0,76):C.GC_5535,(0,108):C.GC_5538,(0,111):C.GC_5536,(0,135):C.GC_5953,(0,25):C.GC_5559,(0,35):C.GC_5930,(0,36):C.GC_5534,(0,65):C.GC_5932,(0,71):C.GC_5540,(0,96):C.GC_5539,(0,103):C.GC_5537,(0,7):C.GC_5950,(0,23):C.GC_5558,(0,46):C.GC_5935,(0,47):C.GC_5535,(0,77):C.GC_5929,(0,79):C.GC_5541,(0,109):C.GC_5538,(0,112):C.GC_5536,(0,6):C.GC_5396,(0,50):C.GC_5396,(0,26):C.GC_5396,(0,146):C.GC_5397,(0,28):C.GC_5397,(0,55):C.GC_5397,(0,85):C.GC_5397,(0,86):C.GC_5397,(0,54):C.GC_5396,(0,15):C.GC_5397,(0,139):C.GC_5554,(0,133):C.GC_5557,(0,121):C.GC_5556,(0,122):C.GC_5916,(0,119):C.GC_5909,(0,124):C.GC_5916,(0,123):C.GC_5909,(0,128):C.GC_5556,(0,11):C.GC_5555,(0,4):C.GC_5556,(0,157):C.GC_5557,(0,158):C.GC_5917,(0,155):C.GC_5912,(0,165):C.GC_5917,(0,164):C.GC_5912,(0,170):C.GC_5557,(0,37):C.GC_5557,(0,48):C.GC_5556,(0,66):C.GC_5557,(0,78):C.GC_5556,(0,30):C.GC_5911,(0,40):C.GC_5910,(0,58):C.GC_5911,(0,69):C.GC_5910,(0,140):C.GC_5556,(0,12):C.GC_5557,(0,136):C.GC_5555,(0,8):C.GC_5554,(0,20):C.GC_5523,(0,21):C.GC_5522,(0,52):C.GC_5509,(0,81):C.GC_5509,(0,113):C.GC_5506,(0,114):C.GC_5506})

V_611 = Vertex(name = 'V_611',
               particles = [ P.W__minus__, P.Z, P.Z, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVSS140, L.VVVSS146, L.VVVSS157, L.VVVSS178, L.VVVSS183, L.VVVSS194, L.VVVSS2, L.VVVSS218, L.VVVSS219, L.VVVSS224, L.VVVSS234, L.VVVSS9 ],
               couplings = {(0,6):C.GC_5579,(0,11):C.GC_5584,(0,0):C.GC_5572,(0,1):C.GC_5007,(0,2):C.GC_5006,(0,3):C.GC_5572,(0,4):C.GC_5007,(0,5):C.GC_5006,(0,7):C.GC_5578,(0,8):C.GC_5578,(0,9):C.GC_3121,(0,10):C.GC_5012})

V_612 = Vertex(name = 'V_612',
               particles = [ P.W__minus__, P.Z, P.Z, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVSS140, L.VVVSS178, L.VVVSS2, L.VVVSS218, L.VVVSS219, L.VVVSS9 ],
               couplings = {(0,2):C.GC_5464,(0,5):C.GC_5465,(0,0):C.GC_5460,(0,1):C.GC_5460,(0,3):C.GC_5461,(0,4):C.GC_5461})

V_613 = Vertex(name = 'V_613',
               particles = [ P.W__plus__, P.Z, P.Z, P.G0, P.G__minus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVSS104, L.VVVSS105, L.VVVSS106, L.VVVSS107, L.VVVSS108, L.VVVSS109, L.VVVSS11, L.VVVSS110, L.VVVSS111, L.VVVSS112, L.VVVSS113, L.VVVSS114, L.VVVSS115, L.VVVSS117, L.VVVSS118, L.VVVSS12, L.VVVSS120, L.VVVSS121, L.VVVSS123, L.VVVSS124, L.VVVSS126, L.VVVSS127, L.VVVSS129, L.VVVSS130, L.VVVSS137, L.VVVSS138, L.VVVSS14, L.VVVSS140, L.VVVSS143, L.VVVSS146, L.VVVSS147, L.VVVSS148, L.VVVSS149, L.VVVSS150, L.VVVSS151, L.VVVSS152, L.VVVSS153, L.VVVSS154, L.VVVSS155, L.VVVSS157, L.VVVSS158, L.VVVSS159, L.VVVSS160, L.VVVSS162, L.VVVSS163, L.VVVSS164, L.VVVSS165, L.VVVSS166, L.VVVSS167, L.VVVSS168, L.VVVSS17, L.VVVSS171, L.VVVSS173, L.VVVSS178, L.VVVSS18, L.VVVSS182, L.VVVSS183, L.VVVSS184, L.VVVSS185, L.VVVSS186, L.VVVSS187, L.VVVSS189, L.VVVSS19, L.VVVSS190, L.VVVSS191, L.VVVSS192, L.VVVSS193, L.VVVSS194, L.VVVSS195, L.VVVSS196, L.VVVSS197, L.VVVSS199, L.VVVSS2, L.VVVSS200, L.VVVSS202, L.VVVSS203, L.VVVSS204, L.VVVSS205, L.VVVSS206, L.VVVSS208, L.VVVSS21, L.VVVSS210, L.VVVSS218, L.VVVSS219, L.VVVSS22, L.VVVSS222, L.VVVSS223, L.VVVSS224, L.VVVSS225, L.VVVSS226, L.VVVSS227, L.VVVSS228, L.VVVSS229, L.VVVSS23, L.VVVSS230, L.VVVSS231, L.VVVSS232, L.VVVSS233, L.VVVSS234, L.VVVSS235, L.VVVSS236, L.VVVSS237, L.VVVSS238, L.VVVSS239, L.VVVSS24, L.VVVSS240, L.VVVSS241, L.VVVSS242, L.VVVSS243, L.VVVSS244, L.VVVSS245, L.VVVSS246, L.VVVSS247, L.VVVSS248, L.VVVSS249, L.VVVSS25, L.VVVSS26, L.VVVSS27, L.VVVSS28, L.VVVSS29, L.VVVSS30, L.VVVSS31, L.VVVSS32, L.VVVSS34, L.VVVSS36, L.VVVSS37, L.VVVSS38, L.VVVSS39, L.VVVSS40, L.VVVSS42, L.VVVSS43, L.VVVSS44, L.VVVSS45, L.VVVSS46, L.VVVSS47, L.VVVSS48, L.VVVSS49, L.VVVSS50, L.VVVSS51, L.VVVSS52, L.VVVSS53, L.VVVSS54, L.VVVSS56, L.VVVSS57, L.VVVSS58, L.VVVSS59, L.VVVSS6, L.VVVSS60, L.VVVSS61, L.VVVSS63, L.VVVSS65, L.VVVSS67, L.VVVSS68, L.VVVSS70, L.VVVSS71, L.VVVSS72, L.VVVSS73, L.VVVSS74, L.VVVSS75, L.VVVSS78, L.VVVSS79, L.VVVSS80, L.VVVSS82, L.VVVSS83, L.VVVSS85, L.VVVSS87, L.VVVSS88, L.VVVSS89, L.VVVSS9, L.VVVSS90, L.VVVSS91, L.VVVSS93, L.VVVSS94, L.VVVSS95, L.VVVSS97, L.VVVSS98 ],
               couplings = {(0,72):C.GC_5494,(0,168):C.GC_5491,(0,27):C.GC_5490,(0,29):C.GC_1632,(0,39):C.GC_1368,(0,53):C.GC_5490,(0,56):C.GC_1632,(0,67):C.GC_1368,(0,82):C.GC_5487,(0,83):C.GC_5487,(0,87):C.GC_1636,(0,98):C.GC_1364,(0,131):C.GC_1583,(0,129):C.GC_5958,(0,137):C.GC_1583,(0,134):C.GC_5958,(0,80):C.GC_1581,(0,62):C.GC_5926,(0,104):C.GC_5517,(0,115):C.GC_1572,(0,116):C.GC_5524,(0,84):C.GC_5926,(0,93):C.GC_5513,(0,118):C.GC_5946,(0,117):C.GC_5923,(0,120):C.GC_5542,(0,127):C.GC_5946,(0,125):C.GC_5923,(0,126):C.GC_5542,(0,2):C.GC_1305,(0,0):C.GC_5944,(0,9):C.GC_1305,(0,5):C.GC_5944,(0,13):C.GC_1580,(0,14):C.GC_1571,(0,16):C.GC_5549,(0,17):C.GC_1580,(0,18):C.GC_1580,(0,19):C.GC_5549,(0,142):C.GC_1304,(0,141):C.GC_5941,(0,145):C.GC_5516,(0,147):C.GC_1310,(0,148):C.GC_5525,(0,143):C.GC_5941,(0,144):C.GC_5514,(0,151):C.GC_1569,(0,152):C.GC_1582,(0,149):C.GC_5531,(0,150):C.GC_5531,(0,154):C.GC_5956,(0,153):C.GC_5936,(0,156):C.GC_5543,(0,162):C.GC_5550,(0,163):C.GC_1569,(0,159):C.GC_5532,(0,160):C.GC_5545,(0,161):C.GC_5546,(0,169):C.GC_5956,(0,166):C.GC_5936,(0,167):C.GC_5543,(0,174):C.GC_1569,(0,175):C.GC_5550,(0,171):C.GC_5532,(0,172):C.GC_5546,(0,173):C.GC_5545,(0,38):C.GC_1583,(0,49):C.GC_1305,(0,61):C.GC_1583,(0,74):C.GC_1305,(0,92):C.GC_5958,(0,97):C.GC_5958,(0,106):C.GC_5944,(0,110):C.GC_5944,(0,57):C.GC_5942,(0,68):C.GC_5925,(0,88):C.GC_5939,(0,99):C.GC_5920,(0,31):C.GC_5942,(0,41):C.GC_5925,(0,89):C.GC_5939,(0,100):C.GC_5920,(0,132):C.GC_1581,(0,138):C.GC_1572,(0,33):C.GC_5939,(0,63):C.GC_5939,(0,91):C.GC_5926,(0,94):C.GC_5926,(0,3):C.GC_1304,(0,10):C.GC_1310,(0,44):C.GC_5920,(0,75):C.GC_5920,(0,105):C.GC_5941,(0,107):C.GC_5941,(0,32):C.GC_5529,(0,42):C.GC_5528,(0,59):C.GC_5529,(0,70):C.GC_5528,(0,90):C.GC_5505,(0,101):C.GC_5504,(0,130):C.GC_5946,(0,24):C.GC_5549,(0,34):C.GC_5942,(0,43):C.GC_5531,(0,60):C.GC_5923,(0,64):C.GC_5542,(0,95):C.GC_5529,(0,102):C.GC_5546,(0,1):C.GC_5956,(0,22):C.GC_5550,(0,45):C.GC_5925,(0,51):C.GC_5532,(0,73):C.GC_5936,(0,76):C.GC_5543,(0,108):C.GC_5528,(0,111):C.GC_5545,(0,135):C.GC_5960,(0,25):C.GC_5566,(0,35):C.GC_5923,(0,36):C.GC_5542,(0,65):C.GC_5942,(0,71):C.GC_5531,(0,96):C.GC_5529,(0,103):C.GC_5546,(0,7):C.GC_5948,(0,23):C.GC_5565,(0,46):C.GC_5936,(0,47):C.GC_5543,(0,77):C.GC_5925,(0,79):C.GC_5532,(0,109):C.GC_5528,(0,112):C.GC_5545,(0,6):C.GC_5398,(0,50):C.GC_5398,(0,26):C.GC_5398,(0,146):C.GC_5395,(0,28):C.GC_5395,(0,55):C.GC_5395,(0,85):C.GC_5395,(0,86):C.GC_5395,(0,54):C.GC_5398,(0,15):C.GC_5395,(0,139):C.GC_5562,(0,133):C.GC_5553,(0,121):C.GC_5552,(0,122):C.GC_5915,(0,119):C.GC_5908,(0,124):C.GC_5915,(0,123):C.GC_5908,(0,128):C.GC_5552,(0,11):C.GC_5563,(0,4):C.GC_5552,(0,157):C.GC_5553,(0,158):C.GC_5918,(0,155):C.GC_5913,(0,165):C.GC_5918,(0,164):C.GC_5913,(0,170):C.GC_5553,(0,37):C.GC_5553,(0,48):C.GC_5552,(0,66):C.GC_5553,(0,78):C.GC_5552,(0,30):C.GC_5914,(0,40):C.GC_5907,(0,58):C.GC_5914,(0,69):C.GC_5907,(0,140):C.GC_5552,(0,12):C.GC_5553,(0,136):C.GC_5563,(0,8):C.GC_5562,(0,20):C.GC_5515,(0,21):C.GC_5526,(0,52):C.GC_5503,(0,81):C.GC_5503,(0,113):C.GC_5512,(0,114):C.GC_5512})

V_614 = Vertex(name = 'V_614',
               particles = [ P.W__plus__, P.Z, P.Z, P.G0, P.G__minus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVSS140, L.VVVSS146, L.VVVSS157, L.VVVSS178, L.VVVSS183, L.VVVSS194, L.VVVSS2, L.VVVSS218, L.VVVSS219, L.VVVSS224, L.VVVSS234, L.VVVSS9 ],
               couplings = {(0,6):C.GC_5581,(0,11):C.GC_5582,(0,0):C.GC_5574,(0,1):C.GC_5010,(0,2):C.GC_5009,(0,3):C.GC_5574,(0,4):C.GC_5010,(0,5):C.GC_5009,(0,7):C.GC_5575,(0,8):C.GC_5575,(0,9):C.GC_5011,(0,10):C.GC_3123})

V_615 = Vertex(name = 'V_615',
               particles = [ P.W__plus__, P.Z, P.Z, P.G0, P.G__minus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVSS140, L.VVVSS178, L.VVVSS2, L.VVVSS218, L.VVVSS219, L.VVVSS9 ],
               couplings = {(0,2):C.GC_5466,(0,5):C.GC_5463,(0,0):C.GC_5462,(0,1):C.GC_5462,(0,3):C.GC_5459,(0,4):C.GC_5459})

V_616 = Vertex(name = 'V_616',
               particles = [ P.W__plus__, P.Z, P.Z, P.G__minus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVS100, L.VVVS103, L.VVVS104, L.VVVS105, L.VVVS106, L.VVVS107, L.VVVS108, L.VVVS109, L.VVVS11, L.VVVS110, L.VVVS111, L.VVVS112, L.VVVS113, L.VVVS114, L.VVVS12, L.VVVS14, L.VVVS17, L.VVVS18, L.VVVS19, L.VVVS2, L.VVVS21, L.VVVS22, L.VVVS23, L.VVVS24, L.VVVS25, L.VVVS26, L.VVVS27, L.VVVS28, L.VVVS29, L.VVVS30, L.VVVS31, L.VVVS32, L.VVVS35, L.VVVS37, L.VVVS38, L.VVVS39, L.VVVS40, L.VVVS41, L.VVVS46, L.VVVS47, L.VVVS48, L.VVVS49, L.VVVS50, L.VVVS51, L.VVVS52, L.VVVS53, L.VVVS54, L.VVVS55, L.VVVS56, L.VVVS57, L.VVVS59, L.VVVS6, L.VVVS62, L.VVVS65, L.VVVS66, L.VVVS67, L.VVVS68, L.VVVS69, L.VVVS70, L.VVVS71, L.VVVS72, L.VVVS73, L.VVVS74, L.VVVS78, L.VVVS82, L.VVVS83, L.VVVS84, L.VVVS85, L.VVVS86, L.VVVS87, L.VVVS89, L.VVVS9, L.VVVS90, L.VVVS91, L.VVVS92, L.VVVS93, L.VVVS99 ],
               couplings = {(0,40):C.GC_1202,(0,38):C.GC_5873,(0,46):C.GC_1202,(0,43):C.GC_5873,(0,20):C.GC_1203,(0,18):C.GC_5869,(0,23):C.GC_5469,(0,24):C.GC_1204,(0,25):C.GC_5470,(0,21):C.GC_5869,(0,22):C.GC_5468,(0,27):C.GC_5876,(0,26):C.GC_5870,(0,29):C.GC_5472,(0,36):C.GC_5876,(0,34):C.GC_5870,(0,35):C.GC_5472,(0,62):C.GC_1202,(0,53):C.GC_1379,(0,70):C.GC_1202,(0,65):C.GC_1379,(0,9):C.GC_5873,(0,13):C.GC_5873,(0,3):C.GC_1380,(0,66):C.GC_5865,(0,4):C.GC_5866,(0,55):C.GC_5865,(0,5):C.GC_5866,(0,41):C.GC_1203,(0,47):C.GC_1204,(0,57):C.GC_5866,(0,72):C.GC_5866,(0,7):C.GC_5869,(0,10):C.GC_5869,(0,56):C.GC_5471,(0,68):C.GC_5471,(0,6):C.GC_5467,(0,39):C.GC_5876,(0,58):C.GC_5865,(0,69):C.GC_5870,(0,73):C.GC_5472,(0,11):C.GC_5471,(0,44):C.GC_5872,(0,59):C.GC_5870,(0,60):C.GC_5472,(0,74):C.GC_5865,(0,12):C.GC_5471,(0,19):C.GC_5480,(0,71):C.GC_5479,(0,50):C.GC_5478,(0,63):C.GC_5478,(0,76):C.GC_5477,(0,0):C.GC_5477,(0,48):C.GC_5475,(0,42):C.GC_5474,(0,30):C.GC_5473,(0,31):C.GC_5863,(0,28):C.GC_5861,(0,33):C.GC_5863,(0,32):C.GC_5861,(0,37):C.GC_5473,(0,61):C.GC_5474,(0,75):C.GC_5474,(0,54):C.GC_5860,(0,67):C.GC_5860,(0,49):C.GC_5473,(0,45):C.GC_5476,(0,8):C.GC_5454,(0,16):C.GC_5454,(0,15):C.GC_5454,(0,51):C.GC_5453,(0,52):C.GC_5453,(0,64):C.GC_5453,(0,1):C.GC_5453,(0,2):C.GC_5453,(0,17):C.GC_5454,(0,14):C.GC_5453})

V_617 = Vertex(name = 'V_617',
               particles = [ P.W__plus__, P.Z, P.Z, P.G__minus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVS100, L.VVVS105, L.VVVS2, L.VVVS59, L.VVVS65, L.VVVS78, L.VVVS83, L.VVVS9, L.VVVS99 ],
               couplings = {(0,4):C.GC_5005,(0,6):C.GC_5005,(0,1):C.GC_3120,(0,2):C.GC_5614,(0,7):C.GC_5611,(0,3):C.GC_5610,(0,5):C.GC_5610,(0,8):C.GC_5607,(0,0):C.GC_5607})

V_618 = Vertex(name = 'V_618',
               particles = [ P.W__plus__, P.Z, P.Z, P.G__minus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVS100, L.VVVS2, L.VVVS59, L.VVVS78, L.VVVS9, L.VVVS99 ],
               couplings = {(0,1):C.GC_5458,(0,4):C.GC_5457,(0,2):C.GC_5456,(0,3):C.GC_5456,(0,5):C.GC_5455,(0,0):C.GC_5455})

V_619 = Vertex(name = 'V_619',
               particles = [ P.W__plus__, P.Z, P.Z, P.G__minus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVSS100, L.VVVSS13, L.VVVSS134, L.VVVSS135, L.VVVSS212, L.VVVSS215, L.VVVSS251, L.VVVSS252, L.VVVSS265, L.VVVSS271, L.VVVSS282, L.VVVSS283, L.VVVSS287, L.VVVSS289, L.VVVSS300, L.VVVSS302, L.VVVSS303, L.VVVSS306, L.VVVSS307, L.VVVSS313, L.VVVSS314, L.VVVSS321, L.VVVSS322, L.VVVSS325, L.VVVSS326, L.VVVSS328, L.VVVSS329, L.VVVSS337, L.VVVSS338, L.VVVSS339, L.VVVSS340, L.VVVSS343, L.VVVSS344, L.VVVSS69 ],
               couplings = {(0,1):C.GC_5493,(0,11):C.GC_811,(0,10):C.GC_816,(0,12):C.GC_2156,(0,8):C.GC_1407,(0,6):C.GC_5489,(0,20):C.GC_697,(0,24):C.GC_701,(0,15):C.GC_5919,(0,33):C.GC_1568,(0,13):C.GC_1567,(0,16):C.GC_1566,(0,22):C.GC_2141,(0,21):C.GC_2142,(0,27):C.GC_5527,(0,4):C.GC_5008,(0,9):C.GC_3122,(0,7):C.GC_5397,(0,26):C.GC_3854,(0,17):C.GC_3855,(0,23):C.GC_3864,(0,19):C.GC_3865,(0,18):C.GC_3859,(0,25):C.GC_3860,(0,29):C.GC_3852,(0,30):C.GC_3853,(0,14):C.GC_3863,(0,3):C.GC_3851,(0,2):C.GC_3857,(0,32):C.GC_3850,(0,31):C.GC_3856,(0,0):C.GC_3862,(0,5):C.GC_3861,(0,28):C.GC_3858})

V_620 = Vertex(name = 'V_620',
               particles = [ P.W__plus__, P.Z, P.Z, P.G__minus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVSS13, L.VVVSS251, L.VVVSS265 ],
               couplings = {(0,0):C.GC_5585,(0,2):C.GC_2157,(0,1):C.GC_5461})

V_621 = Vertex(name = 'V_621',
               particles = [ P.W__plus__, P.Z, P.Z, P.G__minus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVSS13, L.VVVSS251 ],
               couplings = {(0,0):C.GC_5465,(0,1):C.GC_5577})

V_622 = Vertex(name = 'V_622',
               particles = [ P.g, P.g, P.g ],
               color = [ 'f(1,2,3)' ],
               lorentz = [ L.VVV30 ],
               couplings = {(0,0):C.GC_513})

V_623 = Vertex(name = 'V_623',
               particles = [ P.g, P.g, P.g, P.g ],
               color = [ 'f(-1,1,2)*f(3,4,-1)', 'f(-1,1,3)*f(2,4,-1)', 'f(-1,1,4)*f(2,3,-1)' ],
               lorentz = [ L.VVVV185, L.VVVV212, L.VVVV213 ],
               couplings = {(1,1):C.GC_514,(0,0):C.GC_514,(2,2):C.GC_514})

V_624 = Vertex(name = 'V_624',
               particles = [ P.ghG, P.ghG__tilde__, P.g ],
               color = [ 'f(1,2,3)' ],
               lorentz = [ L.UUV1 ],
               couplings = {(0,0):C.GC_513})

V_625 = Vertex(name = 'V_625',
               particles = [ P.d__tilde__, P.d, P.G0 ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_2})

V_626 = Vertex(name = 'V_626',
               particles = [ P.d__tilde__, P.d, P.G0 ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_143})

V_627 = Vertex(name = 'V_627',
               particles = [ P.d__tilde__, P.d, P.G0 ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_406})

V_628 = Vertex(name = 'V_628',
               particles = [ P.s__tilde__, P.d, P.G0 ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_4})

V_629 = Vertex(name = 'V_629',
               particles = [ P.s__tilde__, P.d, P.G0 ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_144})

V_630 = Vertex(name = 'V_630',
               particles = [ P.s__tilde__, P.d, P.G0 ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_408})

V_631 = Vertex(name = 'V_631',
               particles = [ P.b__tilde__, P.d, P.G0 ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_6})

V_632 = Vertex(name = 'V_632',
               particles = [ P.b__tilde__, P.d, P.G0 ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_145})

V_633 = Vertex(name = 'V_633',
               particles = [ P.b__tilde__, P.d, P.G0 ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_410})

V_634 = Vertex(name = 'V_634',
               particles = [ P.d__tilde__, P.s, P.G0 ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_8})

V_635 = Vertex(name = 'V_635',
               particles = [ P.d__tilde__, P.s, P.G0 ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_146})

V_636 = Vertex(name = 'V_636',
               particles = [ P.d__tilde__, P.s, P.G0 ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_412})

V_637 = Vertex(name = 'V_637',
               particles = [ P.s__tilde__, P.s, P.G0 ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_10})

V_638 = Vertex(name = 'V_638',
               particles = [ P.s__tilde__, P.s, P.G0 ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_147})

V_639 = Vertex(name = 'V_639',
               particles = [ P.s__tilde__, P.s, P.G0 ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_414})

V_640 = Vertex(name = 'V_640',
               particles = [ P.b__tilde__, P.s, P.G0 ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_12})

V_641 = Vertex(name = 'V_641',
               particles = [ P.b__tilde__, P.s, P.G0 ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_148})

V_642 = Vertex(name = 'V_642',
               particles = [ P.b__tilde__, P.s, P.G0 ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_416})

V_643 = Vertex(name = 'V_643',
               particles = [ P.d__tilde__, P.b, P.G0 ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_14})

V_644 = Vertex(name = 'V_644',
               particles = [ P.d__tilde__, P.b, P.G0 ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_149})

V_645 = Vertex(name = 'V_645',
               particles = [ P.d__tilde__, P.b, P.G0 ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_418})

V_646 = Vertex(name = 'V_646',
               particles = [ P.s__tilde__, P.b, P.G0 ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_16})

V_647 = Vertex(name = 'V_647',
               particles = [ P.s__tilde__, P.b, P.G0 ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_150})

V_648 = Vertex(name = 'V_648',
               particles = [ P.s__tilde__, P.b, P.G0 ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_420})

V_649 = Vertex(name = 'V_649',
               particles = [ P.b__tilde__, P.b, P.G0 ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_18})

V_650 = Vertex(name = 'V_650',
               particles = [ P.b__tilde__, P.b, P.G0 ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_151})

V_651 = Vertex(name = 'V_651',
               particles = [ P.b__tilde__, P.b, P.G0 ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_422})

V_652 = Vertex(name = 'V_652',
               particles = [ P.d__tilde__, P.d, P.H ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_1})

V_653 = Vertex(name = 'V_653',
               particles = [ P.d__tilde__, P.d, P.H ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_322})

V_654 = Vertex(name = 'V_654',
               particles = [ P.d__tilde__, P.d, P.H ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_405})

V_655 = Vertex(name = 'V_655',
               particles = [ P.s__tilde__, P.d, P.H ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_3})

V_656 = Vertex(name = 'V_656',
               particles = [ P.s__tilde__, P.d, P.H ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_323})

V_657 = Vertex(name = 'V_657',
               particles = [ P.s__tilde__, P.d, P.H ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_407})

V_658 = Vertex(name = 'V_658',
               particles = [ P.b__tilde__, P.d, P.H ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_5})

V_659 = Vertex(name = 'V_659',
               particles = [ P.b__tilde__, P.d, P.H ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_324})

V_660 = Vertex(name = 'V_660',
               particles = [ P.b__tilde__, P.d, P.H ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_409})

V_661 = Vertex(name = 'V_661',
               particles = [ P.d__tilde__, P.s, P.H ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_7})

V_662 = Vertex(name = 'V_662',
               particles = [ P.d__tilde__, P.s, P.H ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_325})

V_663 = Vertex(name = 'V_663',
               particles = [ P.d__tilde__, P.s, P.H ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_411})

V_664 = Vertex(name = 'V_664',
               particles = [ P.s__tilde__, P.s, P.H ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_9})

V_665 = Vertex(name = 'V_665',
               particles = [ P.s__tilde__, P.s, P.H ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_326})

V_666 = Vertex(name = 'V_666',
               particles = [ P.s__tilde__, P.s, P.H ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_413})

V_667 = Vertex(name = 'V_667',
               particles = [ P.b__tilde__, P.s, P.H ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_11})

V_668 = Vertex(name = 'V_668',
               particles = [ P.b__tilde__, P.s, P.H ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_327})

V_669 = Vertex(name = 'V_669',
               particles = [ P.b__tilde__, P.s, P.H ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_415})

V_670 = Vertex(name = 'V_670',
               particles = [ P.d__tilde__, P.b, P.H ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_13})

V_671 = Vertex(name = 'V_671',
               particles = [ P.d__tilde__, P.b, P.H ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_328})

V_672 = Vertex(name = 'V_672',
               particles = [ P.d__tilde__, P.b, P.H ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_417})

V_673 = Vertex(name = 'V_673',
               particles = [ P.s__tilde__, P.b, P.H ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_15})

V_674 = Vertex(name = 'V_674',
               particles = [ P.s__tilde__, P.b, P.H ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_329})

V_675 = Vertex(name = 'V_675',
               particles = [ P.s__tilde__, P.b, P.H ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_419})

V_676 = Vertex(name = 'V_676',
               particles = [ P.b__tilde__, P.b, P.H ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_17})

V_677 = Vertex(name = 'V_677',
               particles = [ P.b__tilde__, P.b, P.H ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_330})

V_678 = Vertex(name = 'V_678',
               particles = [ P.b__tilde__, P.b, P.H ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_421})

V_679 = Vertex(name = 'V_679',
               particles = [ P.u__tilde__, P.d, P.G__plus__ ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS3, L.FFS4 ],
               couplings = {(0,0):C.GC_60,(0,1):C.GC_69})

V_680 = Vertex(name = 'V_680',
               particles = [ P.c__tilde__, P.d, P.G__plus__ ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS3, L.FFS4 ],
               couplings = {(0,0):C.GC_61,(0,1):C.GC_70})

V_681 = Vertex(name = 'V_681',
               particles = [ P.t__tilde__, P.d, P.G__plus__ ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS3, L.FFS4 ],
               couplings = {(0,0):C.GC_62,(0,1):C.GC_71})

V_682 = Vertex(name = 'V_682',
               particles = [ P.u__tilde__, P.s, P.G__plus__ ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS3, L.FFS4 ],
               couplings = {(0,0):C.GC_63,(0,1):C.GC_72})

V_683 = Vertex(name = 'V_683',
               particles = [ P.c__tilde__, P.s, P.G__plus__ ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS3, L.FFS4 ],
               couplings = {(0,0):C.GC_64,(0,1):C.GC_73})

V_684 = Vertex(name = 'V_684',
               particles = [ P.t__tilde__, P.s, P.G__plus__ ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS3, L.FFS4 ],
               couplings = {(0,0):C.GC_65,(0,1):C.GC_74})

V_685 = Vertex(name = 'V_685',
               particles = [ P.u__tilde__, P.b, P.G__plus__ ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS3, L.FFS4 ],
               couplings = {(0,0):C.GC_66,(0,1):C.GC_75})

V_686 = Vertex(name = 'V_686',
               particles = [ P.c__tilde__, P.b, P.G__plus__ ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS3, L.FFS4 ],
               couplings = {(0,0):C.GC_67,(0,1):C.GC_76})

V_687 = Vertex(name = 'V_687',
               particles = [ P.t__tilde__, P.b, P.G__plus__ ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS3, L.FFS4 ],
               couplings = {(0,0):C.GC_68,(0,1):C.GC_77})

V_688 = Vertex(name = 'V_688',
               particles = [ P.e__plus__, P.e__minus__, P.G0 ],
               color = [ '1' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_20})

V_689 = Vertex(name = 'V_689',
               particles = [ P.e__plus__, P.e__minus__, P.G0 ],
               color = [ '1' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_152})

V_690 = Vertex(name = 'V_690',
               particles = [ P.e__plus__, P.e__minus__, P.G0 ],
               color = [ '1' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_424})

V_691 = Vertex(name = 'V_691',
               particles = [ P.mu__plus__, P.e__minus__, P.G0 ],
               color = [ '1' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_22})

V_692 = Vertex(name = 'V_692',
               particles = [ P.mu__plus__, P.e__minus__, P.G0 ],
               color = [ '1' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_153})

V_693 = Vertex(name = 'V_693',
               particles = [ P.mu__plus__, P.e__minus__, P.G0 ],
               color = [ '1' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_426})

V_694 = Vertex(name = 'V_694',
               particles = [ P.ta__plus__, P.e__minus__, P.G0 ],
               color = [ '1' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_24})

V_695 = Vertex(name = 'V_695',
               particles = [ P.ta__plus__, P.e__minus__, P.G0 ],
               color = [ '1' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_154})

V_696 = Vertex(name = 'V_696',
               particles = [ P.ta__plus__, P.e__minus__, P.G0 ],
               color = [ '1' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_428})

V_697 = Vertex(name = 'V_697',
               particles = [ P.e__plus__, P.mu__minus__, P.G0 ],
               color = [ '1' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_26})

V_698 = Vertex(name = 'V_698',
               particles = [ P.e__plus__, P.mu__minus__, P.G0 ],
               color = [ '1' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_155})

V_699 = Vertex(name = 'V_699',
               particles = [ P.e__plus__, P.mu__minus__, P.G0 ],
               color = [ '1' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_430})

V_700 = Vertex(name = 'V_700',
               particles = [ P.mu__plus__, P.mu__minus__, P.G0 ],
               color = [ '1' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_28})

V_701 = Vertex(name = 'V_701',
               particles = [ P.mu__plus__, P.mu__minus__, P.G0 ],
               color = [ '1' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_156})

V_702 = Vertex(name = 'V_702',
               particles = [ P.mu__plus__, P.mu__minus__, P.G0 ],
               color = [ '1' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_432})

V_703 = Vertex(name = 'V_703',
               particles = [ P.ta__plus__, P.mu__minus__, P.G0 ],
               color = [ '1' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_30})

V_704 = Vertex(name = 'V_704',
               particles = [ P.ta__plus__, P.mu__minus__, P.G0 ],
               color = [ '1' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_157})

V_705 = Vertex(name = 'V_705',
               particles = [ P.ta__plus__, P.mu__minus__, P.G0 ],
               color = [ '1' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_434})

V_706 = Vertex(name = 'V_706',
               particles = [ P.e__plus__, P.ta__minus__, P.G0 ],
               color = [ '1' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_32})

V_707 = Vertex(name = 'V_707',
               particles = [ P.e__plus__, P.ta__minus__, P.G0 ],
               color = [ '1' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_158})

V_708 = Vertex(name = 'V_708',
               particles = [ P.e__plus__, P.ta__minus__, P.G0 ],
               color = [ '1' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_436})

V_709 = Vertex(name = 'V_709',
               particles = [ P.mu__plus__, P.ta__minus__, P.G0 ],
               color = [ '1' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_34})

V_710 = Vertex(name = 'V_710',
               particles = [ P.mu__plus__, P.ta__minus__, P.G0 ],
               color = [ '1' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_159})

V_711 = Vertex(name = 'V_711',
               particles = [ P.mu__plus__, P.ta__minus__, P.G0 ],
               color = [ '1' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_438})

V_712 = Vertex(name = 'V_712',
               particles = [ P.ta__plus__, P.ta__minus__, P.G0 ],
               color = [ '1' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_36})

V_713 = Vertex(name = 'V_713',
               particles = [ P.ta__plus__, P.ta__minus__, P.G0 ],
               color = [ '1' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_160})

V_714 = Vertex(name = 'V_714',
               particles = [ P.ta__plus__, P.ta__minus__, P.G0 ],
               color = [ '1' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_440})

V_715 = Vertex(name = 'V_715',
               particles = [ P.e__plus__, P.e__minus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_19})

V_716 = Vertex(name = 'V_716',
               particles = [ P.e__plus__, P.e__minus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_331})

V_717 = Vertex(name = 'V_717',
               particles = [ P.e__plus__, P.e__minus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_423})

V_718 = Vertex(name = 'V_718',
               particles = [ P.mu__plus__, P.e__minus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_21})

V_719 = Vertex(name = 'V_719',
               particles = [ P.mu__plus__, P.e__minus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_332})

V_720 = Vertex(name = 'V_720',
               particles = [ P.mu__plus__, P.e__minus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_425})

V_721 = Vertex(name = 'V_721',
               particles = [ P.ta__plus__, P.e__minus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_23})

V_722 = Vertex(name = 'V_722',
               particles = [ P.ta__plus__, P.e__minus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_333})

V_723 = Vertex(name = 'V_723',
               particles = [ P.ta__plus__, P.e__minus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_427})

V_724 = Vertex(name = 'V_724',
               particles = [ P.e__plus__, P.mu__minus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_25})

V_725 = Vertex(name = 'V_725',
               particles = [ P.e__plus__, P.mu__minus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_334})

V_726 = Vertex(name = 'V_726',
               particles = [ P.e__plus__, P.mu__minus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_429})

V_727 = Vertex(name = 'V_727',
               particles = [ P.mu__plus__, P.mu__minus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_27})

V_728 = Vertex(name = 'V_728',
               particles = [ P.mu__plus__, P.mu__minus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_335})

V_729 = Vertex(name = 'V_729',
               particles = [ P.mu__plus__, P.mu__minus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_431})

V_730 = Vertex(name = 'V_730',
               particles = [ P.ta__plus__, P.mu__minus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_29})

V_731 = Vertex(name = 'V_731',
               particles = [ P.ta__plus__, P.mu__minus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_336})

V_732 = Vertex(name = 'V_732',
               particles = [ P.ta__plus__, P.mu__minus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_433})

V_733 = Vertex(name = 'V_733',
               particles = [ P.e__plus__, P.ta__minus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_31})

V_734 = Vertex(name = 'V_734',
               particles = [ P.e__plus__, P.ta__minus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_337})

V_735 = Vertex(name = 'V_735',
               particles = [ P.e__plus__, P.ta__minus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_435})

V_736 = Vertex(name = 'V_736',
               particles = [ P.mu__plus__, P.ta__minus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_33})

V_737 = Vertex(name = 'V_737',
               particles = [ P.mu__plus__, P.ta__minus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_338})

V_738 = Vertex(name = 'V_738',
               particles = [ P.mu__plus__, P.ta__minus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_437})

V_739 = Vertex(name = 'V_739',
               particles = [ P.ta__plus__, P.ta__minus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_35})

V_740 = Vertex(name = 'V_740',
               particles = [ P.ta__plus__, P.ta__minus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_339})

V_741 = Vertex(name = 'V_741',
               particles = [ P.ta__plus__, P.ta__minus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_439})

V_742 = Vertex(name = 'V_742',
               particles = [ P.u__tilde__, P.u, P.G0 ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_37})

V_743 = Vertex(name = 'V_743',
               particles = [ P.u__tilde__, P.u, P.G0 ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_161})

V_744 = Vertex(name = 'V_744',
               particles = [ P.u__tilde__, P.u, P.G0 ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_441})

V_745 = Vertex(name = 'V_745',
               particles = [ P.c__tilde__, P.u, P.G0 ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_39})

V_746 = Vertex(name = 'V_746',
               particles = [ P.c__tilde__, P.u, P.G0 ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_162})

V_747 = Vertex(name = 'V_747',
               particles = [ P.c__tilde__, P.u, P.G0 ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_443})

V_748 = Vertex(name = 'V_748',
               particles = [ P.t__tilde__, P.u, P.G0 ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_41})

V_749 = Vertex(name = 'V_749',
               particles = [ P.t__tilde__, P.u, P.G0 ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_163})

V_750 = Vertex(name = 'V_750',
               particles = [ P.t__tilde__, P.u, P.G0 ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_445})

V_751 = Vertex(name = 'V_751',
               particles = [ P.u__tilde__, P.c, P.G0 ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_43})

V_752 = Vertex(name = 'V_752',
               particles = [ P.u__tilde__, P.c, P.G0 ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_164})

V_753 = Vertex(name = 'V_753',
               particles = [ P.u__tilde__, P.c, P.G0 ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_447})

V_754 = Vertex(name = 'V_754',
               particles = [ P.c__tilde__, P.c, P.G0 ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_45})

V_755 = Vertex(name = 'V_755',
               particles = [ P.c__tilde__, P.c, P.G0 ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_165})

V_756 = Vertex(name = 'V_756',
               particles = [ P.c__tilde__, P.c, P.G0 ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_449})

V_757 = Vertex(name = 'V_757',
               particles = [ P.t__tilde__, P.c, P.G0 ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_47})

V_758 = Vertex(name = 'V_758',
               particles = [ P.t__tilde__, P.c, P.G0 ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_166})

V_759 = Vertex(name = 'V_759',
               particles = [ P.t__tilde__, P.c, P.G0 ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_451})

V_760 = Vertex(name = 'V_760',
               particles = [ P.u__tilde__, P.t, P.G0 ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_49})

V_761 = Vertex(name = 'V_761',
               particles = [ P.u__tilde__, P.t, P.G0 ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_167})

V_762 = Vertex(name = 'V_762',
               particles = [ P.u__tilde__, P.t, P.G0 ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_453})

V_763 = Vertex(name = 'V_763',
               particles = [ P.c__tilde__, P.t, P.G0 ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_51})

V_764 = Vertex(name = 'V_764',
               particles = [ P.c__tilde__, P.t, P.G0 ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_168})

V_765 = Vertex(name = 'V_765',
               particles = [ P.c__tilde__, P.t, P.G0 ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_455})

V_766 = Vertex(name = 'V_766',
               particles = [ P.t__tilde__, P.t, P.G0 ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_53})

V_767 = Vertex(name = 'V_767',
               particles = [ P.t__tilde__, P.t, P.G0 ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_169})

V_768 = Vertex(name = 'V_768',
               particles = [ P.t__tilde__, P.t, P.G0 ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_457})

V_769 = Vertex(name = 'V_769',
               particles = [ P.u__tilde__, P.u, P.H ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_38})

V_770 = Vertex(name = 'V_770',
               particles = [ P.u__tilde__, P.u, P.H ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_340})

V_771 = Vertex(name = 'V_771',
               particles = [ P.u__tilde__, P.u, P.H ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_442})

V_772 = Vertex(name = 'V_772',
               particles = [ P.c__tilde__, P.u, P.H ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_40})

V_773 = Vertex(name = 'V_773',
               particles = [ P.c__tilde__, P.u, P.H ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_341})

V_774 = Vertex(name = 'V_774',
               particles = [ P.c__tilde__, P.u, P.H ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_444})

V_775 = Vertex(name = 'V_775',
               particles = [ P.t__tilde__, P.u, P.H ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_42})

V_776 = Vertex(name = 'V_776',
               particles = [ P.t__tilde__, P.u, P.H ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_342})

V_777 = Vertex(name = 'V_777',
               particles = [ P.t__tilde__, P.u, P.H ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_446})

V_778 = Vertex(name = 'V_778',
               particles = [ P.u__tilde__, P.c, P.H ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_44})

V_779 = Vertex(name = 'V_779',
               particles = [ P.u__tilde__, P.c, P.H ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_343})

V_780 = Vertex(name = 'V_780',
               particles = [ P.u__tilde__, P.c, P.H ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_448})

V_781 = Vertex(name = 'V_781',
               particles = [ P.c__tilde__, P.c, P.H ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_46})

V_782 = Vertex(name = 'V_782',
               particles = [ P.c__tilde__, P.c, P.H ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_344})

V_783 = Vertex(name = 'V_783',
               particles = [ P.c__tilde__, P.c, P.H ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_450})

V_784 = Vertex(name = 'V_784',
               particles = [ P.t__tilde__, P.c, P.H ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_48})

V_785 = Vertex(name = 'V_785',
               particles = [ P.t__tilde__, P.c, P.H ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_345})

V_786 = Vertex(name = 'V_786',
               particles = [ P.t__tilde__, P.c, P.H ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_452})

V_787 = Vertex(name = 'V_787',
               particles = [ P.u__tilde__, P.t, P.H ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_50})

V_788 = Vertex(name = 'V_788',
               particles = [ P.u__tilde__, P.t, P.H ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_346})

V_789 = Vertex(name = 'V_789',
               particles = [ P.u__tilde__, P.t, P.H ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_454})

V_790 = Vertex(name = 'V_790',
               particles = [ P.c__tilde__, P.t, P.H ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_52})

V_791 = Vertex(name = 'V_791',
               particles = [ P.c__tilde__, P.t, P.H ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_347})

V_792 = Vertex(name = 'V_792',
               particles = [ P.c__tilde__, P.t, P.H ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_456})

V_793 = Vertex(name = 'V_793',
               particles = [ P.t__tilde__, P.t, P.H ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_54})

V_794 = Vertex(name = 'V_794',
               particles = [ P.t__tilde__, P.t, P.H ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_348})

V_795 = Vertex(name = 'V_795',
               particles = [ P.t__tilde__, P.t, P.H ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS2 ],
               couplings = {(0,0):C.GC_458})

V_796 = Vertex(name = 'V_796',
               particles = [ P.d__tilde__, P.u, P.G__minus__ ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS3, L.FFS4 ],
               couplings = {(0,0):C.GC_78,(0,1):C.GC_87})

V_797 = Vertex(name = 'V_797',
               particles = [ P.s__tilde__, P.u, P.G__minus__ ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS3, L.FFS4 ],
               couplings = {(0,0):C.GC_79,(0,1):C.GC_88})

V_798 = Vertex(name = 'V_798',
               particles = [ P.b__tilde__, P.u, P.G__minus__ ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS3, L.FFS4 ],
               couplings = {(0,0):C.GC_80,(0,1):C.GC_89})

V_799 = Vertex(name = 'V_799',
               particles = [ P.d__tilde__, P.c, P.G__minus__ ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS3, L.FFS4 ],
               couplings = {(0,0):C.GC_81,(0,1):C.GC_90})

V_800 = Vertex(name = 'V_800',
               particles = [ P.s__tilde__, P.c, P.G__minus__ ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS3, L.FFS4 ],
               couplings = {(0,0):C.GC_82,(0,1):C.GC_91})

V_801 = Vertex(name = 'V_801',
               particles = [ P.b__tilde__, P.c, P.G__minus__ ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS3, L.FFS4 ],
               couplings = {(0,0):C.GC_83,(0,1):C.GC_92})

V_802 = Vertex(name = 'V_802',
               particles = [ P.d__tilde__, P.t, P.G__minus__ ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS3, L.FFS4 ],
               couplings = {(0,0):C.GC_84,(0,1):C.GC_93})

V_803 = Vertex(name = 'V_803',
               particles = [ P.s__tilde__, P.t, P.G__minus__ ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS3, L.FFS4 ],
               couplings = {(0,0):C.GC_85,(0,1):C.GC_94})

V_804 = Vertex(name = 'V_804',
               particles = [ P.b__tilde__, P.t, P.G__minus__ ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS3, L.FFS4 ],
               couplings = {(0,0):C.GC_86,(0,1):C.GC_95})

V_805 = Vertex(name = 'V_805',
               particles = [ P.e__plus__, P.ve, P.G__minus__ ],
               color = [ '1' ],
               lorentz = [ L.FFS4 ],
               couplings = {(0,0):C.GC_96})

V_806 = Vertex(name = 'V_806',
               particles = [ P.mu__plus__, P.ve, P.G__minus__ ],
               color = [ '1' ],
               lorentz = [ L.FFS4 ],
               couplings = {(0,0):C.GC_97})

V_807 = Vertex(name = 'V_807',
               particles = [ P.ta__plus__, P.ve, P.G__minus__ ],
               color = [ '1' ],
               lorentz = [ L.FFS4 ],
               couplings = {(0,0):C.GC_98})

V_808 = Vertex(name = 'V_808',
               particles = [ P.e__plus__, P.vm, P.G__minus__ ],
               color = [ '1' ],
               lorentz = [ L.FFS4 ],
               couplings = {(0,0):C.GC_99})

V_809 = Vertex(name = 'V_809',
               particles = [ P.mu__plus__, P.vm, P.G__minus__ ],
               color = [ '1' ],
               lorentz = [ L.FFS4 ],
               couplings = {(0,0):C.GC_100})

V_810 = Vertex(name = 'V_810',
               particles = [ P.ta__plus__, P.vm, P.G__minus__ ],
               color = [ '1' ],
               lorentz = [ L.FFS4 ],
               couplings = {(0,0):C.GC_101})

V_811 = Vertex(name = 'V_811',
               particles = [ P.e__plus__, P.vt, P.G__minus__ ],
               color = [ '1' ],
               lorentz = [ L.FFS4 ],
               couplings = {(0,0):C.GC_102})

V_812 = Vertex(name = 'V_812',
               particles = [ P.mu__plus__, P.vt, P.G__minus__ ],
               color = [ '1' ],
               lorentz = [ L.FFS4 ],
               couplings = {(0,0):C.GC_103})

V_813 = Vertex(name = 'V_813',
               particles = [ P.ta__plus__, P.vt, P.G__minus__ ],
               color = [ '1' ],
               lorentz = [ L.FFS4 ],
               couplings = {(0,0):C.GC_104})

V_814 = Vertex(name = 'V_814',
               particles = [ P.ve__tilde__, P.e__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.FFS3 ],
               couplings = {(0,0):C.GC_105})

V_815 = Vertex(name = 'V_815',
               particles = [ P.vm__tilde__, P.e__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.FFS3 ],
               couplings = {(0,0):C.GC_106})

V_816 = Vertex(name = 'V_816',
               particles = [ P.vt__tilde__, P.e__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.FFS3 ],
               couplings = {(0,0):C.GC_107})

V_817 = Vertex(name = 'V_817',
               particles = [ P.ve__tilde__, P.mu__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.FFS3 ],
               couplings = {(0,0):C.GC_108})

V_818 = Vertex(name = 'V_818',
               particles = [ P.vm__tilde__, P.mu__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.FFS3 ],
               couplings = {(0,0):C.GC_109})

V_819 = Vertex(name = 'V_819',
               particles = [ P.vt__tilde__, P.mu__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.FFS3 ],
               couplings = {(0,0):C.GC_110})

V_820 = Vertex(name = 'V_820',
               particles = [ P.ve__tilde__, P.ta__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.FFS3 ],
               couplings = {(0,0):C.GC_111})

V_821 = Vertex(name = 'V_821',
               particles = [ P.vm__tilde__, P.ta__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.FFS3 ],
               couplings = {(0,0):C.GC_112})

V_822 = Vertex(name = 'V_822',
               particles = [ P.vt__tilde__, P.ta__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.FFS3 ],
               couplings = {(0,0):C.GC_113})

V_823 = Vertex(name = 'V_823',
               particles = [ P.A, P.W__minus__, P.G0, P.G0, P.G__minus__, P.G__plus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSSSSS1 ],
               couplings = {(0,0):C.GC_4521})

V_824 = Vertex(name = 'V_824',
               particles = [ P.A, P.W__minus__, P.G0, P.G0, P.G0, P.G__minus__, P.G__plus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSSSSSS1 ],
               couplings = {(0,0):C.GC_4599})

V_825 = Vertex(name = 'V_825',
               particles = [ P.A, P.W__minus__, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSSSSS1 ],
               couplings = {(0,0):C.GC_4523})

V_826 = Vertex(name = 'V_826',
               particles = [ P.A, P.W__minus__, P.G0, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSSSSSS1 ],
               couplings = {(0,0):C.GC_4598})

V_827 = Vertex(name = 'V_827',
               particles = [ P.A, P.W__minus__, P.G0, P.G__minus__, P.G__plus__, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSSSS1 ],
               couplings = {(0,0):C.GC_4520})

V_828 = Vertex(name = 'V_828',
               particles = [ P.A, P.W__minus__, P.G0, P.G0, P.G__minus__, P.G__plus__, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSSSSS1 ],
               couplings = {(0,0):C.GC_4601})

V_829 = Vertex(name = 'V_829',
               particles = [ P.A, P.W__minus__, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSSSSS1 ],
               couplings = {(0,0):C.GC_4603})

V_830 = Vertex(name = 'V_830',
               particles = [ P.A, P.W__minus__, P.G__minus__, P.G__plus__, P.G__plus__, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSSSS1 ],
               couplings = {(0,0):C.GC_4522})

V_831 = Vertex(name = 'V_831',
               particles = [ P.A, P.W__minus__, P.G0, P.G__minus__, P.G__plus__, P.G__plus__, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSSSSS1 ],
               couplings = {(0,0):C.GC_4600})

V_832 = Vertex(name = 'V_832',
               particles = [ P.A, P.W__minus__, P.G__minus__, P.G__plus__, P.G__plus__, P.H, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSSSSS1 ],
               couplings = {(0,0):C.GC_4602})

V_833 = Vertex(name = 'V_833',
               particles = [ P.A, P.A, P.A, P.W__minus__, P.G__minus__, P.G__plus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVVSSS13 ],
               couplings = {(0,0):C.GC_7301})

V_834 = Vertex(name = 'V_834',
               particles = [ P.A, P.A, P.A, P.W__minus__, P.G0, P.G__minus__, P.G__plus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVVSSSS13 ],
               couplings = {(0,0):C.GC_7308})

V_835 = Vertex(name = 'V_835',
               particles = [ P.A, P.A, P.A, P.W__minus__, P.G__minus__, P.G__plus__, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVVSSSS13 ],
               couplings = {(0,0):C.GC_7315})

V_836 = Vertex(name = 'V_836',
               particles = [ P.W__minus__, P.G0, P.G0, P.G0, P.G0, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VSSSSS8 ],
               couplings = {(0,0):C.GC_555})

V_837 = Vertex(name = 'V_837',
               particles = [ P.W__minus__, P.G0, P.G0, P.G__minus__, P.G__plus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VSSSSS20 ],
               couplings = {(0,0):C.GC_553})

V_838 = Vertex(name = 'V_838',
               particles = [ P.W__minus__, P.G0, P.G0, P.G0, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VSSSSS9 ],
               couplings = {(0,0):C.GC_552})

V_839 = Vertex(name = 'V_839',
               particles = [ P.W__minus__, P.G0, P.G0, P.G0, P.G0, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VSSSSSS9 ],
               couplings = {(0,0):C.GC_679})

V_840 = Vertex(name = 'V_840',
               particles = [ P.W__minus__, P.G0, P.G__minus__, P.G__plus__, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VSSSSS15 ],
               couplings = {(0,0):C.GC_551})

V_841 = Vertex(name = 'V_841',
               particles = [ P.W__minus__, P.G0, P.G0, P.G__minus__, P.G__plus__, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VSSSSSS12 ],
               couplings = {(0,0):C.GC_677})

V_842 = Vertex(name = 'V_842',
               particles = [ P.W__minus__, P.G0, P.G0, P.G__plus__, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VSSSSS13 ],
               couplings = {(0,0):C.GC_555})

V_843 = Vertex(name = 'V_843',
               particles = [ P.W__minus__, P.G0, P.G0, P.G0, P.G__plus__, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VSSSSSS14 ],
               couplings = {(0,0):C.GC_676})

V_844 = Vertex(name = 'V_844',
               particles = [ P.W__minus__, P.G0, P.G__minus__, P.G__plus__, P.G__plus__, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VSSSSSS22 ],
               couplings = {(0,0):C.GC_675})

V_845 = Vertex(name = 'V_845',
               particles = [ P.W__minus__, P.G0, P.G__plus__, P.H, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VSSSSS18 ],
               couplings = {(0,0):C.GC_550})

V_846 = Vertex(name = 'V_846',
               particles = [ P.W__minus__, P.G0, P.G0, P.G__plus__, P.H, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VSSSSSS20 ],
               couplings = {(0,0):C.GC_679})

V_847 = Vertex(name = 'V_847',
               particles = [ P.W__minus__, P.G0, P.G__plus__, P.H, P.H, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VSSSSSS26 ],
               couplings = {(0,0):C.GC_673})

V_848 = Vertex(name = 'V_848',
               particles = [ P.A, P.A, P.W__minus__, P.G0, P.G0, P.G0, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVSSSS154, L.VVVSSSS160, L.VVVSSSS3, L.VVVSSSS82 ],
               couplings = {(0,2):C.GC_6548,(0,1):C.GC_1761,(0,0):C.GC_1771,(0,3):C.GC_6514})

V_849 = Vertex(name = 'V_849',
               particles = [ P.A, P.A, P.W__minus__, P.G0, P.G0, P.G0, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVSSSS3, L.VVVSSSS82 ],
               couplings = {(0,0):C.GC_6657,(0,1):C.GC_4199})

V_850 = Vertex(name = 'V_850',
               particles = [ P.A, P.A, P.W__minus__, P.G0, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVSSS3, L.VVVSSS57, L.VVVSSS73, L.VVVSSS82 ],
               couplings = {(0,0):C.GC_6312,(0,1):C.GC_6286,(0,3):C.GC_1658,(0,2):C.GC_1663})

V_851 = Vertex(name = 'V_851',
               particles = [ P.A, P.A, P.W__minus__, P.G0, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVSSS3, L.VVVSSS57 ],
               couplings = {(0,0):C.GC_6619,(0,1):C.GC_4146})

V_852 = Vertex(name = 'V_852',
               particles = [ P.A, P.A, P.W__minus__, P.G0, P.G__plus__, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVSSSS103, L.VVVSSSS3, L.VVVSSSS82, L.VVVSSSS98 ],
               couplings = {(0,1):C.GC_6546,(0,0):C.GC_1759,(0,3):C.GC_1771,(0,2):C.GC_6518})

V_853 = Vertex(name = 'V_853',
               particles = [ P.A, P.A, P.W__minus__, P.G0, P.G__plus__, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVSSSS3, L.VVVSSSS82 ],
               couplings = {(0,0):C.GC_6650,(0,1):C.GC_4197})

V_854 = Vertex(name = 'V_854',
               particles = [ P.ghA, P.ghWm__tilde__, P.W__minus__ ],
               color = [ '1' ],
               lorentz = [ L.UUV1 ],
               couplings = {(0,0):C.GC_5289})

V_855 = Vertex(name = 'V_855',
               particles = [ P.ghA, P.ghWm__tilde__, P.W__minus__ ],
               color = [ '1' ],
               lorentz = [ L.UUV1 ],
               couplings = {(0,0):C.GC_5179})

V_856 = Vertex(name = 'V_856',
               particles = [ P.ghA, P.ghWm__tilde__, P.W__minus__ ],
               color = [ '1' ],
               lorentz = [ L.UUV1 ],
               couplings = {(0,0):C.GC_5294})

V_857 = Vertex(name = 'V_857',
               particles = [ P.ghWp, P.ghZ__tilde__, P.W__minus__ ],
               color = [ '1' ],
               lorentz = [ L.UUV1 ],
               couplings = {(0,0):C.GC_2385})

V_858 = Vertex(name = 'V_858',
               particles = [ P.ghWp, P.ghZ__tilde__, P.W__minus__ ],
               color = [ '1' ],
               lorentz = [ L.UUV1 ],
               couplings = {(0,0):C.GC_5701})

V_859 = Vertex(name = 'V_859',
               particles = [ P.ghWp, P.ghZ__tilde__, P.W__minus__ ],
               color = [ '1' ],
               lorentz = [ L.UUV1 ],
               couplings = {(0,0):C.GC_5732})

V_860 = Vertex(name = 'V_860',
               particles = [ P.ghWp, P.ghA__tilde__, P.W__minus__ ],
               color = [ '1' ],
               lorentz = [ L.UUV1 ],
               couplings = {(0,0):C.GC_5182})

V_861 = Vertex(name = 'V_861',
               particles = [ P.ghWp, P.ghA__tilde__, P.W__minus__ ],
               color = [ '1' ],
               lorentz = [ L.UUV1 ],
               couplings = {(0,0):C.GC_5295})

V_862 = Vertex(name = 'V_862',
               particles = [ P.ghWp, P.ghA__tilde__, P.W__minus__ ],
               color = [ '1' ],
               lorentz = [ L.UUV1 ],
               couplings = {(0,0):C.GC_5288})

V_863 = Vertex(name = 'V_863',
               particles = [ P.ghZ, P.ghWm__tilde__, P.W__minus__ ],
               color = [ '1' ],
               lorentz = [ L.UUV1 ],
               couplings = {(0,0):C.GC_2386})

V_864 = Vertex(name = 'V_864',
               particles = [ P.ghZ, P.ghWm__tilde__, P.W__minus__ ],
               color = [ '1' ],
               lorentz = [ L.UUV1 ],
               couplings = {(0,0):C.GC_2391})

V_865 = Vertex(name = 'V_865',
               particles = [ P.ghZ, P.ghWm__tilde__, P.W__minus__ ],
               color = [ '1' ],
               lorentz = [ L.UUV1 ],
               couplings = {(0,0):C.GC_1943})

V_866 = Vertex(name = 'V_866',
               particles = [ P.W__minus__, P.G0, P.G0, P.G0, P.G__minus__, P.G__plus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VSSSSSS24 ],
               couplings = {(0,0):C.GC_674})

V_867 = Vertex(name = 'V_867',
               particles = [ P.W__minus__, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VSSSSS14 ],
               couplings = {(0,0):C.GC_558})

V_868 = Vertex(name = 'V_868',
               particles = [ P.W__minus__, P.G0, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VSSSSSS21 ],
               couplings = {(0,0):C.GC_674})

V_869 = Vertex(name = 'V_869',
               particles = [ P.W__minus__, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VSSSSSS7 ],
               couplings = {(0,0):C.GC_682})

V_870 = Vertex(name = 'V_870',
               particles = [ P.W__minus__, P.G__minus__, P.G__plus__, P.G__plus__, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VSSSSS4 ],
               couplings = {(0,0):C.GC_558})

V_871 = Vertex(name = 'V_871',
               particles = [ P.W__minus__, P.G__minus__, P.G__plus__, P.G__plus__, P.H, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VSSSSSS3 ],
               couplings = {(0,0):C.GC_682})

V_872 = Vertex(name = 'V_872',
               particles = [ P.A, P.A, P.W__minus__, P.G0, P.G0, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVSSSS252, L.VVVSSSS3, L.VVVSSSS329, L.VVVSSSS82 ],
               couplings = {(0,1):C.GC_6535,(0,2):C.GC_1758,(0,0):C.GC_1766,(0,3):C.GC_6522})

V_873 = Vertex(name = 'V_873',
               particles = [ P.A, P.A, P.W__minus__, P.G0, P.G0, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVSSSS3, L.VVVSSSS82 ],
               couplings = {(0,0):C.GC_6648,(0,1):C.GC_4200})

V_874 = Vertex(name = 'V_874',
               particles = [ P.A, P.A, P.W__minus__, P.G__plus__, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVSSS152, L.VVVSSS178, L.VVVSSS3, L.VVVSSS57 ],
               couplings = {(0,2):C.GC_6309,(0,3):C.GC_6298,(0,1):C.GC_1657,(0,0):C.GC_1661})

V_875 = Vertex(name = 'V_875',
               particles = [ P.A, P.A, P.W__minus__, P.G__plus__, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVSSS3, L.VVVSSS57 ],
               couplings = {(0,0):C.GC_6613,(0,1):C.GC_4147})

V_876 = Vertex(name = 'V_876',
               particles = [ P.A, P.A, P.W__minus__, P.G__plus__, P.H, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVSSSS261, L.VVVSSSS296, L.VVVSSSS3, L.VVVSSSS82 ],
               couplings = {(0,2):C.GC_6543,(0,1):C.GC_1756,(0,0):C.GC_1766,(0,3):C.GC_6530})

V_877 = Vertex(name = 'V_877',
               particles = [ P.A, P.A, P.W__minus__, P.G__plus__, P.H, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVSSSS3, L.VVVSSSS82 ],
               couplings = {(0,0):C.GC_6643,(0,1):C.GC_4202})

V_878 = Vertex(name = 'V_878',
               particles = [ P.A, P.A, P.A, P.W__minus__, P.G0, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVVSS424, L.VVVVSS428, L.VVVVSS442, L.VVVVSS443, L.VVVVSS445, L.VVVVSS480, L.VVVVSS481, L.VVVVSS619, L.VVVVSS624, L.VVVVSS636, L.VVVVSS684, L.VVVVSS685 ],
               couplings = {(0,3):C.GC_2040,(0,4):C.GC_2044,(0,1):C.GC_2035,(0,11):C.GC_2038,(0,8):C.GC_2030,(0,10):C.GC_7212,(0,2):C.GC_1966,(0,6):C.GC_7217,(0,5):C.GC_7221,(0,9):C.GC_7205,(0,0):C.GC_7211,(0,7):C.GC_7206})

V_879 = Vertex(name = 'V_879',
               particles = [ P.A, P.A, P.A, P.W__minus__, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVVSS424, L.VVVVSS429, L.VVVVSS442, L.VVVVSS444, L.VVVVSS446, L.VVVVSS515, L.VVVVSS516, L.VVVVSS619, L.VVVVSS626, L.VVVVSS636, L.VVVVSS723, L.VVVVSS724 ],
               couplings = {(0,3):C.GC_2041,(0,4):C.GC_2043,(0,1):C.GC_2034,(0,11):C.GC_2037,(0,8):C.GC_2031,(0,10):C.GC_7213,(0,2):C.GC_1965,(0,6):C.GC_7216,(0,5):C.GC_7220,(0,9):C.GC_7204,(0,0):C.GC_7210,(0,7):C.GC_7207})

V_880 = Vertex(name = 'V_880',
               particles = [ P.A, P.A, P.A, P.W__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVVS183, L.VVVVS193, L.VVVVS71, L.VVVVS82, L.VVVVS83, L.VVVVS85 ],
               couplings = {(0,4):C.GC_1927,(0,3):C.GC_2016,(0,5):C.GC_2017,(0,1):C.GC_7180,(0,2):C.GC_7182,(0,0):C.GC_7181})

V_881 = Vertex(name = 'V_881',
               particles = [ P.A, P.A, P.A, P.W__minus__, P.W__plus__, P.G__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVVVSS1, L.VVVVVSS260, L.VVVVVSS271, L.VVVVVSS4, L.VVVVVSS41, L.VVVVVSS42, L.VVVVVSS43, L.VVVVVSS44, L.VVVVVSS45, L.VVVVVSS66 ],
               couplings = {(0,7):C.GC_2028,(0,9):C.GC_7222,(0,0):C.GC_2058,(0,5):C.GC_2055,(0,6):C.GC_7224,(0,8):C.GC_7266,(0,3):C.GC_7263,(0,4):C.GC_7265,(0,2):C.GC_7262,(0,1):C.GC_7261})

V_882 = Vertex(name = 'V_882',
               particles = [ P.A, P.A, P.A, P.W__minus__, P.W__plus__, P.G__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVVVSS66 ],
               couplings = {(0,0):C.GC_7264})

V_883 = Vertex(name = 'V_883',
               particles = [ P.A, P.W__minus__, P.W__plus__, P.G0 ],
               color = [ '1' ],
               lorentz = [ L.VVVS105, L.VVVS127, L.VVVS128, L.VVVS129, L.VVVS139, L.VVVS146, L.VVVS44, L.VVVS45, L.VVVS94, L.VVVS95, L.VVVS96, L.VVVS97, L.VVVS98 ],
               couplings = {(0,11):C.GC_2425,(0,12):C.GC_2426,(0,1):C.GC_2422,(0,2):C.GC_2423,(0,6):C.GC_2421,(0,10):C.GC_2420,(0,4):C.GC_4400,(0,5):C.GC_4401,(0,3):C.GC_4399,(0,9):C.GC_4511,(0,8):C.GC_4513,(0,7):C.GC_4514,(0,0):C.GC_4512})

V_884 = Vertex(name = 'V_884',
               particles = [ P.A, P.W__minus__, P.W__plus__, P.G0, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVSS100, L.VVVSS131, L.VVVSS213, L.VVVSS215, L.VVVSS216, L.VVVSS217, L.VVVSS281, L.VVVSS300, L.VVVSS301, L.VVVSS315, L.VVVSS320, L.VVVSS336 ],
               couplings = {(0,5):C.GC_2506,(0,4):C.GC_2507,(0,8):C.GC_2503,(0,7):C.GC_2504,(0,0):C.GC_2502,(0,3):C.GC_2501,(0,1):C.GC_4508,(0,6):C.GC_4502,(0,2):C.GC_4505,(0,10):C.GC_4455,(0,9):C.GC_4456,(0,11):C.GC_4454})

V_885 = Vertex(name = 'V_885',
               particles = [ P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVVS12, L.VVVVS13, L.VVVVS14, L.VVVVS148, L.VVVVS154, L.VVVVS172, L.VVVVS174, L.VVVVS190, L.VVVVS20, L.VVVVS216, L.VVVVS22, L.VVVVS221, L.VVVVS224, L.VVVVS250, L.VVVVS258, L.VVVVS26, L.VVVVS80 ],
               couplings = {(0,16):C.GC_2402,(0,7):C.GC_2400,(0,2):C.GC_2589,(0,1):C.GC_2587,(0,10):C.GC_2581,(0,12):C.GC_2585,(0,15):C.GC_2577,(0,11):C.GC_2582,(0,5):C.GC_4510,(0,4):C.GC_4535,(0,3):C.GC_4538,(0,0):C.GC_4532,(0,14):C.GC_4528,(0,13):C.GC_4534,(0,9):C.GC_4530,(0,8):C.GC_4804,(0,6):C.GC_7292})

V_886 = Vertex(name = 'V_886',
               particles = [ P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVVS172 ],
               couplings = {(0,0):C.GC_7232})

V_887 = Vertex(name = 'V_887',
               particles = [ P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.G0, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVVSS165, L.VVVVSS167, L.VVVVSS168, L.VVVVSS242, L.VVVVSS261, L.VVVVSS266, L.VVVVSS440, L.VVVVSS553, L.VVVVSS561, L.VVVVSS605, L.VVVVSS608, L.VVVVSS633, L.VVVVSS671, L.VVVVSS695, L.VVVVSS696, L.VVVVSS749, L.VVVVSS767 ],
               couplings = {(0,1):C.GC_2681,(0,2):C.GC_2678,(0,4):C.GC_2665,(0,13):C.GC_2673,(0,5):C.GC_2662,(0,14):C.GC_2671,(0,6):C.GC_2469,(0,11):C.GC_2464,(0,9):C.GC_4501,(0,8):C.GC_4628,(0,7):C.GC_4631,(0,0):C.GC_4622,(0,16):C.GC_4611,(0,15):C.GC_4623,(0,12):C.GC_4615,(0,3):C.GC_4805,(0,10):C.GC_7293})

V_888 = Vertex(name = 'V_888',
               particles = [ P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.G0, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVVSS605 ],
               couplings = {(0,0):C.GC_7236})

V_889 = Vertex(name = 'V_889',
               particles = [ P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVVSS166, L.VVVVSS167, L.VVVVSS168, L.VVVVSS242, L.VVVVSS261, L.VVVVSS266, L.VVVVSS440, L.VVVVSS562, L.VVVVSS581, L.VVVVSS605, L.VVVVSS608, L.VVVVSS633, L.VVVVSS668, L.VVVVSS695, L.VVVVSS696, L.VVVVSS751, L.VVVVSS765 ],
               couplings = {(0,1):C.GC_2683,(0,2):C.GC_2680,(0,4):C.GC_2667,(0,13):C.GC_2675,(0,5):C.GC_2659,(0,14):C.GC_2669,(0,6):C.GC_2466,(0,11):C.GC_2462,(0,9):C.GC_4499,(0,7):C.GC_4627,(0,8):C.GC_4633,(0,0):C.GC_4621,(0,15):C.GC_4613,(0,16):C.GC_4625,(0,12):C.GC_4617,(0,3):C.GC_4806,(0,10):C.GC_7294})

V_890 = Vertex(name = 'V_890',
               particles = [ P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVVSS605 ],
               couplings = {(0,0):C.GC_7240})

V_891 = Vertex(name = 'V_891',
               particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.G0, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVSS250, L.VVVSS257, L.VVVSS260, L.VVVSS266, L.VVVSS269, L.VVVSS277, L.VVVSS290, L.VVVSS3, L.VVVSS304, L.VVVSS309, L.VVVSS319, L.VVVSS330, L.VVVSS84 ],
               couplings = {(0,7):C.GC_645,(0,1):C.GC_814,(0,5):C.GC_813,(0,0):C.GC_644,(0,10):C.GC_698,(0,9):C.GC_703,(0,12):C.GC_691,(0,8):C.GC_685,(0,11):C.GC_694,(0,6):C.GC_688,(0,4):C.GC_1049,(0,2):C.GC_1056,(0,3):C.GC_1057})

V_892 = Vertex(name = 'V_892',
               particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.G0, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVSS3 ],
               couplings = {(0,0):C.GC_819})

V_893 = Vertex(name = 'V_893',
               particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVS115, L.VVVS119, L.VVVS121, L.VVVS130, L.VVVS133, L.VVVS142, L.VVVS143, L.VVVS3, L.VVVS34, L.VVVS65 ],
               couplings = {(0,5):C.GC_566,(0,6):C.GC_568,(0,8):C.GC_563,(0,3):C.GC_559,(0,4):C.GC_565,(0,2):C.GC_561,(0,9):C.GC_826,(0,1):C.GC_825,(0,7):C.GC_629,(0,0):C.GC_627})

V_894 = Vertex(name = 'V_894',
               particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVS115, L.VVVS119, L.VVVS3, L.VVVS65 ],
               couplings = {(0,3):C.GC_1041,(0,1):C.GC_1405,(0,2):C.GC_830,(0,0):C.GC_829})

V_895 = Vertex(name = 'V_895',
               particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVSS250, L.VVVSS258, L.VVVSS272, L.VVVSS274, L.VVVSS275, L.VVVSS280, L.VVVSS290, L.VVVSS3, L.VVVSS304, L.VVVSS309, L.VVVSS319, L.VVVSS330, L.VVVSS84 ],
               couplings = {(0,7):C.GC_647,(0,5):C.GC_816,(0,4):C.GC_810,(0,0):C.GC_643,(0,10):C.GC_697,(0,9):C.GC_702,(0,12):C.GC_692,(0,8):C.GC_686,(0,11):C.GC_695,(0,6):C.GC_689,(0,3):C.GC_1055,(0,1):C.GC_1050,(0,2):C.GC_1058})

V_896 = Vertex(name = 'V_896',
               particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVSS3 ],
               couplings = {(0,0):C.GC_818})

V_897 = Vertex(name = 'V_897',
               particles = [ P.A, P.A, P.W__minus__, P.Z, P.G0, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVVSS323, L.VVVVSS350, L.VVVVSS422, L.VVVVSS430, L.VVVVSS431, L.VVVVSS438, L.VVVVSS453, L.VVVVSS455, L.VVVVSS456, L.VVVVSS457, L.VVVVSS458, L.VVVVSS459, L.VVVVSS478, L.VVVVSS482, L.VVVVSS483, L.VVVVSS517, L.VVVVSS518, L.VVVVSS525, L.VVVVSS527, L.VVVVSS603, L.VVVVSS615, L.VVVVSS617, L.VVVVSS621, L.VVVVSS625, L.VVVVSS647, L.VVVVSS652, L.VVVVSS658, L.VVVVSS690, L.VVVVSS691, L.VVVVSS706, L.VVVVSS707, L.VVVVSS708, L.VVVVSS709 ],
               couplings = {(0,17):C.GC_2636,(0,15):C.GC_2644,(0,18):C.GC_2972,(0,16):C.GC_2974,(0,13):C.GC_2087,(0,14):C.GC_2091,(0,26):C.GC_2018,(0,25):C.GC_2621,(0,1):C.GC_2953,(0,31):C.GC_2630,(0,29):C.GC_2969,(0,27):C.GC_6180,(0,3):C.GC_2026,(0,5):C.GC_2626,(0,22):C.GC_2023,(0,20):C.GC_2622,(0,2):C.GC_2961,(0,21):C.GC_2959,(0,19):C.GC_3688,(0,9):C.GC_4111,(0,8):C.GC_4117,(0,11):C.GC_4675,(0,10):C.GC_4678,(0,4):C.GC_4104,(0,0):C.GC_4654,(0,28):C.GC_4109,(0,32):C.GC_4663,(0,30):C.GC_4671,(0,23):C.GC_4100,(0,12):C.GC_4652,(0,7):C.GC_4078,(0,6):C.GC_4453,(0,24):C.GC_4446})

V_898 = Vertex(name = 'V_898',
               particles = [ P.A, P.A, P.W__minus__, P.Z, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVVSS328, L.VVVVSS350, L.VVVVSS422, L.VVVVSS430, L.VVVVSS432, L.VVVVSS438, L.VVVVSS453, L.VVVVSS455, L.VVVVSS460, L.VVVVSS461, L.VVVVSS462, L.VVVVSS463, L.VVVVSS503, L.VVVVSS508, L.VVVVSS509, L.VVVVSS518, L.VVVVSS519, L.VVVVSS523, L.VVVVSS524, L.VVVVSS603, L.VVVVSS615, L.VVVVSS617, L.VVVVSS621, L.VVVVSS628, L.VVVVSS647, L.VVVVSS652, L.VVVVSS658, L.VVVVSS706, L.VVVVSS725, L.VVVVSS775, L.VVVVSS776, L.VVVVSS778, L.VVVVSS779 ],
               couplings = {(0,14):C.GC_2635,(0,13):C.GC_2642,(0,16):C.GC_2973,(0,15):C.GC_2976,(0,17):C.GC_2086,(0,18):C.GC_2090,(0,26):C.GC_2019,(0,25):C.GC_2620,(0,1):C.GC_2955,(0,31):C.GC_2632,(0,27):C.GC_2967,(0,29):C.GC_6178,(0,3):C.GC_2025,(0,5):C.GC_2628,(0,22):C.GC_2022,(0,20):C.GC_2624,(0,2):C.GC_2962,(0,21):C.GC_2958,(0,19):C.GC_3691,(0,11):C.GC_4110,(0,8):C.GC_4115,(0,10):C.GC_4676,(0,9):C.GC_4679,(0,0):C.GC_4656,(0,4):C.GC_4105,(0,30):C.GC_4108,(0,32):C.GC_4665,(0,28):C.GC_4668,(0,12):C.GC_4650,(0,23):C.GC_4102,(0,7):C.GC_4080,(0,6):C.GC_4451,(0,24):C.GC_4448})

V_899 = Vertex(name = 'V_899',
               particles = [ P.A, P.A, P.W__minus__, P.Z, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVVS100, L.VVVVS101, L.VVVVS102, L.VVVVS103, L.VVVVS132, L.VVVVS134, L.VVVVS170, L.VVVVS179, L.VVVVS181, L.VVVVS185, L.VVVVS203, L.VVVVS206, L.VVVVS209, L.VVVVS233, L.VVVVS234, L.VVVVS235, L.VVVVS34, L.VVVVS55, L.VVVVS60, L.VVVVS69, L.VVVVS73, L.VVVVS78, L.VVVVS96, L.VVVVS99 ],
               couplings = {(0,6):C.GC_3665,(0,5):C.GC_3570,(0,4):C.GC_3571,(0,12):C.GC_6166,(0,11):C.GC_2556,(0,17):C.GC_2904,(0,13):C.GC_3568,(0,20):C.GC_6165,(0,21):C.GC_2560,(0,9):C.GC_6163,(0,7):C.GC_2558,(0,19):C.GC_2906,(0,8):C.GC_2905,(0,1):C.GC_4075,(0,22):C.GC_4397,(0,10):C.GC_4396,(0,0):C.GC_4087,(0,23):C.GC_4089,(0,3):C.GC_4560,(0,2):C.GC_4561,(0,16):C.GC_4551,(0,15):C.GC_4555,(0,14):C.GC_4556,(0,18):C.GC_4549})

V_900 = Vertex(name = 'V_900',
               particles = [ P.A, P.W__minus__, P.W__plus__, P.Z, P.G__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVVSS1, L.VVVVSS202, L.VVVVSS221, L.VVVVSS259, L.VVVVSS260, L.VVVVSS264, L.VVVVSS265, L.VVVVSS420, L.VVVVSS426, L.VVVVSS427, L.VVVVSS472, L.VVVVSS475, L.VVVVSS476, L.VVVVSS477, L.VVVVSS536, L.VVVVSS538, L.VVVVSS572, L.VVVVSS573, L.VVVVSS574, L.VVVVSS575, L.VVVVSS582, L.VVVVSS583, L.VVVVSS596, L.VVVVSS597, L.VVVVSS598, L.VVVVSS599, L.VVVVSS604, L.VVVVSS605, L.VVVVSS606, L.VVVVSS607, L.VVVVSS608, L.VVVVSS609, L.VVVVSS611, L.VVVVSS637, L.VVVVSS643, L.VVVVSS644, L.VVVVSS645, L.VVVVSS678, L.VVVVSS680, L.VVVVSS683, L.VVVVSS704, L.VVVVSS712, L.VVVVSS718, L.VVVVSS720, L.VVVVSS726, L.VVVVSS727, L.VVVVSS734, L.VVVVSS735, L.VVVVSS736, L.VVVVSS737, L.VVVVSS755, L.VVVVSS756, L.VVVVSS783, L.VVVVSS784 ],
               couplings = {(0,27):C.GC_7530,(0,22):C.GC_3197,(0,23):C.GC_3199,(0,18):C.GC_3218,(0,19):C.GC_3221,(0,24):C.GC_3253,(0,25):C.GC_3255,(0,8):C.GC_3191,(0,7):C.GC_3213,(0,9):C.GC_3249,(0,47):C.GC_3192,(0,46):C.GC_3195,(0,49):C.GC_3215,(0,48):C.GC_3216,(0,45):C.GC_3251,(0,44):C.GC_3252,(0,38):C.GC_3189,(0,37):C.GC_3211,(0,39):C.GC_3247,(0,13):C.GC_3180,(0,11):C.GC_3203,(0,10):C.GC_3238,(0,34):C.GC_3178,(0,36):C.GC_7443,(0,35):C.GC_3237,(0,17):C.GC_4909,(0,16):C.GC_4911,(0,21):C.GC_4923,(0,20):C.GC_4926,(0,15):C.GC_4952,(0,14):C.GC_4954,(0,3):C.GC_4905,(0,4):C.GC_4920,(0,1):C.GC_4949,(0,43):C.GC_4907,(0,42):C.GC_4922,(0,40):C.GC_4950,(0,50):C.GC_4903,(0,51):C.GC_4918,(0,41):C.GC_4947,(0,33):C.GC_7539,(0,52):C.GC_4904,(0,53):C.GC_4919,(0,5):C.GC_4948,(0,2):C.GC_7541,(0,6):C.GC_7540,(0,29):C.GC_7371,(0,32):C.GC_4912,(0,28):C.GC_7559,(0,31):C.GC_7915,(0,30):C.GC_4927,(0,0):C.GC_7913,(0,12):C.GC_7444,(0,26):C.GC_7911})

V_901 = Vertex(name = 'V_901',
               particles = [ P.A, P.W__minus__, P.W__plus__, P.Z, P.G__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVVSS605 ],
               couplings = {(0,0):C.GC_7517})

V_902 = Vertex(name = 'V_902',
               particles = [ P.A, P.W__minus__, P.W__plus__, P.Z, P.G__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVVSS605 ],
               couplings = {(0,0):C.GC_7558})

V_903 = Vertex(name = 'V_903',
               particles = [ P.W__minus__, P.W__plus__, P.Z, P.G0 ],
               color = [ '1' ],
               lorentz = [ L.VVVS118, L.VVVS119, L.VVVS121, L.VVVS123, L.VVVS126, L.VVVS130, L.VVVS132, L.VVVS133, L.VVVS134, L.VVVS140, L.VVVS141, L.VVVS143, L.VVVS34, L.VVVS37, L.VVVS45, L.VVVS65, L.VVVS76 ],
               couplings = {(0,4):C.GC_2838,(0,9):C.GC_2406,(0,11):C.GC_2407,(0,3):C.GC_2833,(0,7):C.GC_2405,(0,13):C.GC_2835,(0,16):C.GC_2834,(0,15):C.GC_2544,(0,1):C.GC_2543,(0,0):C.GC_2545,(0,14):C.GC_2547,(0,8):C.GC_4419,(0,10):C.GC_4421,(0,12):C.GC_4415,(0,6):C.GC_4416,(0,5):C.GC_4417,(0,2):C.GC_4414})

V_904 = Vertex(name = 'V_904',
               particles = [ P.W__minus__, P.W__plus__, P.Z, P.G0 ],
               color = [ '1' ],
               lorentz = [ L.VVVS119, L.VVVS65 ],
               couplings = {(0,1):C.GC_3015,(0,0):C.GC_3663})

V_905 = Vertex(name = 'V_905',
               particles = [ P.W__minus__, P.W__plus__, P.Z, P.G0, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVSS131, L.VVVSS174, L.VVVSS176, L.VVVSS272, L.VVVSS275, L.VVVSS276, L.VVVSS290, L.VVVSS292, L.VVVSS296, L.VVVSS304, L.VVVSS308, L.VVVSS309, L.VVVSS310, L.VVVSS318, L.VVVSS330, L.VVVSS335, L.VVVSS84, L.VVVSS99 ],
               couplings = {(0,0):C.GC_2540,(0,4):C.GC_2533,(0,5):C.GC_2539,(0,8):C.GC_2863,(0,12):C.GC_2478,(0,11):C.GC_2480,(0,7):C.GC_2858,(0,14):C.GC_2476,(0,17):C.GC_2860,(0,2):C.GC_2859,(0,1):C.GC_3016,(0,3):C.GC_3676,(0,13):C.GC_4476,(0,10):C.GC_4478,(0,16):C.GC_4472,(0,15):C.GC_4473,(0,9):C.GC_4474,(0,6):C.GC_4471})

V_906 = Vertex(name = 'V_906',
               particles = [ P.A, P.W__minus__, P.Z, P.Z, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVVS110, L.VVVVS111, L.VVVVS156, L.VVVVS157, L.VVVVS165, L.VVVVS166, L.VVVVS167, L.VVVVS168, L.VVVVS170, L.VVVVS186, L.VVVVS195, L.VVVVS196, L.VVVVS197, L.VVVVS207, L.VVVVS208, L.VVVVS212, L.VVVVS218, L.VVVVS220, L.VVVVS223, L.VVVVS225, L.VVVVS28, L.VVVVS29, L.VVVVS32, L.VVVVS54, L.VVVVS57, L.VVVVS64, L.VVVVS66, L.VVVVS74, L.VVVVS90, L.VVVVS93 ],
               couplings = {(0,1):C.GC_2070,(0,0):C.GC_2404,(0,11):C.GC_2400,(0,2):C.GC_2589,(0,4):C.GC_2921,(0,29):C.GC_2081,(0,28):C.GC_2083,(0,6):C.GC_2587,(0,5):C.GC_2919,(0,26):C.GC_2581,(0,27):C.GC_2915,(0,18):C.GC_2585,(0,13):C.GC_2918,(0,12):C.GC_7174,(0,19):C.GC_2583,(0,14):C.GC_2916,(0,21):C.GC_7176,(0,15):C.GC_7175,(0,16):C.GC_2579,(0,9):C.GC_2914,(0,8):C.GC_7229,(0,3):C.GC_4536,(0,20):C.GC_4842,(0,7):C.GC_4537,(0,10):C.GC_4527,(0,17):C.GC_4534,(0,22):C.GC_4531,(0,24):C.GC_4529,(0,23):C.GC_7345,(0,25):C.GC_4882})

V_907 = Vertex(name = 'V_907',
               particles = [ P.A, P.W__minus__, P.Z, P.Z, P.G0, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVVSS317, L.VVVVSS318, L.VVVVSS320, L.VVVVSS326, L.VVVVSS349, L.VVVVSS352, L.VVVVSS391, L.VVVVSS416, L.VVVVSS421, L.VVVVSS473, L.VVVVSS474, L.VVVVSS485, L.VVVVSS487, L.VVVVSS488, L.VVVVSS491, L.VVVVSS566, L.VVVVSS568, L.VVVVSS585, L.VVVVSS586, L.VVVVSS588, L.VVVVSS591, L.VVVVSS603, L.VVVVSS623, L.VVVVSS639, L.VVVVSS640, L.VVVVSS641, L.VVVVSS655, L.VVVVSS657, L.VVVVSS663, L.VVVVSS665, L.VVVVSS677, L.VVVVSS686, L.VVVVSS687, L.VVVVSS692, L.VVVVSS694, L.VVVVSS698 ],
               couplings = {(0,15):C.GC_2681,(0,17):C.GC_2995,(0,14):C.GC_2103,(0,11):C.GC_2107,(0,19):C.GC_2679,(0,18):C.GC_2991,(0,2):C.GC_2098,(0,8):C.GC_2664,(0,7):C.GC_2983,(0,34):C.GC_2673,(0,26):C.GC_2989,(0,32):C.GC_2099,(0,35):C.GC_2671,(0,27):C.GC_2985,(0,29):C.GC_2093,(0,30):C.GC_2663,(0,31):C.GC_6175,(0,22):C.GC_2978,(0,10):C.GC_2073,(0,9):C.GC_2470,(0,24):C.GC_2464,(0,16):C.GC_4629,(0,0):C.GC_4849,(0,20):C.GC_4634,(0,13):C.GC_4094,(0,12):C.GC_4096,(0,25):C.GC_7187,(0,23):C.GC_4614,(0,33):C.GC_4623,(0,1):C.GC_7195,(0,28):C.GC_7190,(0,3):C.GC_4622,(0,5):C.GC_4618,(0,4):C.GC_7346,(0,6):C.GC_4883,(0,21):C.GC_7242})

V_908 = Vertex(name = 'V_908',
               particles = [ P.A, P.W__minus__, P.Z, P.Z, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVVSS317, L.VVVVSS318, L.VVVVSS321, L.VVVVSS326, L.VVVVSS349, L.VVVVSS352, L.VVVVSS391, L.VVVVSS414, L.VVVVSS433, L.VVVVSS473, L.VVVVSS474, L.VVVVSS542, L.VVVVSS544, L.VVVVSS557, L.VVVVSS564, L.VVVVSS586, L.VVVVSS589, L.VVVVSS590, L.VVVVSS591, L.VVVVSS600, L.VVVVSS602, L.VVVVSS603, L.VVVVSS622, L.VVVVSS639, L.VVVVSS640, L.VVVVSS641, L.VVVVSS656, L.VVVVSS657, L.VVVVSS663, L.VVVVSS667, L.VVVVSS679, L.VVVVSS692, L.VVVVSS729, L.VVVVSS747, L.VVVVSS769, L.VVVVSS770 ],
               couplings = {(0,12):C.GC_2683,(0,13):C.GC_2994,(0,19):C.GC_2102,(0,11):C.GC_2106,(0,20):C.GC_2680,(0,15):C.GC_2990,(0,7):C.GC_2667,(0,8):C.GC_2982,(0,2):C.GC_2097,(0,33):C.GC_2675,(0,26):C.GC_2988,(0,35):C.GC_2100,(0,32):C.GC_2672,(0,27):C.GC_2984,(0,29):C.GC_2094,(0,30):C.GC_2661,(0,34):C.GC_6174,(0,22):C.GC_2979,(0,10):C.GC_2074,(0,9):C.GC_2468,(0,24):C.GC_2462,(0,14):C.GC_4630,(0,0):C.GC_4848,(0,18):C.GC_4632,(0,17):C.GC_4095,(0,16):C.GC_4097,(0,25):C.GC_7188,(0,23):C.GC_4612,(0,31):C.GC_4625,(0,1):C.GC_7194,(0,28):C.GC_7191,(0,3):C.GC_4620,(0,5):C.GC_4616,(0,4):C.GC_7347,(0,6):C.GC_4884,(0,21):C.GC_7237})

V_909 = Vertex(name = 'V_909',
               particles = [ P.W__minus__, P.W__minus__, P.G0, P.G0, P.G0, P.G__plus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSSSSS1 ],
               couplings = {(0,0):C.GC_862})

V_910 = Vertex(name = 'V_910',
               particles = [ P.W__minus__, P.W__minus__, P.G0, P.G0, P.G0, P.G0, P.G__plus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSSSSSS1 ],
               couplings = {(0,0):C.GC_957})

V_911 = Vertex(name = 'V_911',
               particles = [ P.W__minus__, P.W__minus__, P.G__minus__, P.G__plus__, P.G__plus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS91 ],
               couplings = {(0,0):C.GC_800})

V_912 = Vertex(name = 'V_912',
               particles = [ P.W__minus__, P.W__minus__, P.G0, P.G__minus__, P.G__plus__, P.G__plus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSSSSS1 ],
               couplings = {(0,0):C.GC_862})

V_913 = Vertex(name = 'V_913',
               particles = [ P.W__minus__, P.W__minus__, P.G0, P.G0, P.G__minus__, P.G__plus__, P.G__plus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSSSSSS1 ],
               couplings = {(0,0):C.GC_955})

V_914 = Vertex(name = 'V_914',
               particles = [ P.W__minus__, P.W__minus__, P.G0, P.G0, P.G0, P.G__plus__, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSSSSS1 ],
               couplings = {(0,0):C.GC_952})

V_915 = Vertex(name = 'V_915',
               particles = [ P.W__minus__, P.W__minus__, P.G__minus__, P.G__plus__, P.G__plus__, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSSSS1 ],
               couplings = {(0,0):C.GC_865})

V_916 = Vertex(name = 'V_916',
               particles = [ P.W__minus__, P.W__minus__, P.G0, P.G__minus__, P.G__plus__, P.G__plus__, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSSSSS1 ],
               couplings = {(0,0):C.GC_952})

V_917 = Vertex(name = 'V_917',
               particles = [ P.W__minus__, P.W__minus__, P.G0, P.G__plus__, P.G__plus__, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSSSS1 ],
               couplings = {(0,0):C.GC_862})

V_918 = Vertex(name = 'V_918',
               particles = [ P.W__minus__, P.W__minus__, P.G__minus__, P.G__plus__, P.G__plus__, P.G__plus__, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSSSSS1 ],
               couplings = {(0,0):C.GC_956})

V_919 = Vertex(name = 'V_919',
               particles = [ P.W__minus__, P.W__minus__, P.G__plus__, P.G__plus__, P.H, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSSSS1 ],
               couplings = {(0,0):C.GC_866})

V_920 = Vertex(name = 'V_920',
               particles = [ P.W__minus__, P.W__minus__, P.G0, P.G__plus__, P.G__plus__, P.H, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSSSSS1 ],
               couplings = {(0,0):C.GC_952})

V_921 = Vertex(name = 'V_921',
               particles = [ P.W__minus__, P.W__minus__, P.G__plus__, P.G__plus__, P.H, P.H, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSSSSS1 ],
               couplings = {(0,0):C.GC_958})

V_922 = Vertex(name = 'V_922',
               particles = [ P.A, P.A, P.W__minus__, P.G0, P.G0, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVSSS3, L.VVVSSS57 ],
               couplings = {(0,0):C.GC_6301,(0,1):C.GC_6290})

V_923 = Vertex(name = 'V_923',
               particles = [ P.A, P.A, P.W__minus__, P.G0, P.G0, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVSSS3, L.VVVSSS57 ],
               couplings = {(0,0):C.GC_6617,(0,1):C.GC_6610})

V_924 = Vertex(name = 'V_924',
               particles = [ P.A, P.W__minus__, P.W__minus__, P.G0, P.G__plus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVSSS117, L.VVVSSS192, L.VVVSSS47, L.VVVSSS59, L.VVVSSS67, L.VVVSSS7 ],
               couplings = {(0,5):C.GC_4410,(0,3):C.GC_4406,(0,0):C.GC_4722,(0,2):C.GC_4726,(0,4):C.GC_4721,(0,1):C.GC_4578})

V_925 = Vertex(name = 'V_925',
               particles = [ P.A, P.W__minus__, P.W__minus__, P.G0, P.G__plus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVSSS7 ],
               couplings = {(0,0):C.GC_4583})

V_926 = Vertex(name = 'V_926',
               particles = [ P.A, P.W__minus__, P.W__minus__, P.G__plus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVSS13, L.VVVSS214, L.VVVSS251, L.VVVSS284, L.VVVSS286 ],
               couplings = {(0,0):C.GC_4439,(0,4):C.GC_4503,(0,2):C.GC_4437,(0,1):C.GC_7233,(0,3):C.GC_4710})

V_927 = Vertex(name = 'V_927',
               particles = [ P.A, P.W__minus__, P.W__minus__, P.G__plus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVSS13 ],
               couplings = {(0,0):C.GC_4506})

V_928 = Vertex(name = 'V_928',
               particles = [ P.A, P.W__minus__, P.W__minus__, P.G0, P.G0, P.G__plus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVSSSS106, L.VVVSSSS190, L.VVVSSSS322, L.VVVSSSS68, L.VVVSSSS7, L.VVVSSSS84 ],
               couplings = {(0,4):C.GC_4469,(0,2):C.GC_4698,(0,5):C.GC_4465,(0,1):C.GC_4755,(0,3):C.GC_4761,(0,0):C.GC_4751})

V_929 = Vertex(name = 'V_929',
               particles = [ P.A, P.W__minus__, P.W__minus__, P.G0, P.G0, P.G__plus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVSSSS7 ],
               couplings = {(0,0):C.GC_4705})

V_930 = Vertex(name = 'V_930',
               particles = [ P.A, P.W__minus__, P.W__minus__, P.G__plus__, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVSSS114, L.VVVSSS143, L.VVVSSS48, L.VVVSSS59, L.VVVSSS7, L.VVVSSS87 ],
               couplings = {(0,4):C.GC_4413,(0,3):C.GC_4409,(0,0):C.GC_4719,(0,2):C.GC_4727,(0,5):C.GC_4724,(0,1):C.GC_4574})

V_931 = Vertex(name = 'V_931',
               particles = [ P.A, P.W__minus__, P.W__minus__, P.G__plus__, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVSSS7 ],
               couplings = {(0,0):C.GC_4580})

V_932 = Vertex(name = 'V_932',
               particles = [ P.A, P.W__minus__, P.W__minus__, P.G0, P.G__plus__, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVSSSS132, L.VVVSSSS184, L.VVVSSSS246, L.VVVSSSS7, L.VVVSSSS75, L.VVVSSSS84 ],
               couplings = {(0,3):C.GC_4467,(0,2):C.GC_4702,(0,5):C.GC_4463,(0,0):C.GC_4754,(0,4):C.GC_4759,(0,1):C.GC_4753})

V_933 = Vertex(name = 'V_933',
               particles = [ P.A, P.W__minus__, P.W__minus__, P.G0, P.G__plus__, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVSSSS7 ],
               couplings = {(0,0):C.GC_4708})

V_934 = Vertex(name = 'V_934',
               particles = [ P.A, P.W__minus__, P.W__minus__, P.G__plus__, P.G__plus__, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVSSSS106, L.VVVSSSS190, L.VVVSSSS232, L.VVVSSSS68, L.VVVSSSS7, L.VVVSSSS84 ],
               couplings = {(0,4):C.GC_4470,(0,2):C.GC_4697,(0,5):C.GC_4466,(0,1):C.GC_4750,(0,3):C.GC_4761,(0,0):C.GC_4756})

V_935 = Vertex(name = 'V_935',
               particles = [ P.A, P.W__minus__, P.W__minus__, P.G__plus__, P.G__plus__, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVSSSS7 ],
               couplings = {(0,0):C.GC_4704})

V_936 = Vertex(name = 'V_936',
               particles = [ P.A, P.W__minus__, P.W__plus__, P.G0, P.G0, P.G0, P.G0 ],
               color = [ '1' ],
               lorentz = [ L.VVVSSSS1, L.VVVSSSS193, L.VVVSSSS35, L.VVVSSSS58, L.VVVSSSS73, L.VVVSSSS85, L.VVVSSSS9 ],
               couplings = {(0,0):C.GC_7085,(0,3):C.GC_7082,(0,2):C.GC_4691,(0,4):C.GC_4684,(0,1):C.GC_4696,(0,6):C.GC_4462,(0,5):C.GC_4459})

V_937 = Vertex(name = 'V_937',
               particles = [ P.A, P.W__minus__, P.W__plus__, P.G0, P.G0, P.G0, P.G0 ],
               color = [ '1' ],
               lorentz = [ L.VVVSSSS1, L.VVVSSSS58 ],
               couplings = {(0,0):C.GC_2611,(0,1):C.GC_2606})

V_938 = Vertex(name = 'V_938',
               particles = [ P.A, P.W__minus__, P.W__plus__, P.G0, P.G0, P.G__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVSSSS200, L.VVVSSSS244, L.VVVSSSS335, L.VVVSSSS344, L.VVVSSSS39, L.VVVSSSS6, L.VVVSSSS62, L.VVVSSSS85, L.VVVSSSS87, L.VVVSSSS9 ],
               couplings = {(0,4):C.GC_4689,(0,1):C.GC_4686,(0,3):C.GC_4694,(0,9):C.GC_4460,(0,5):C.GC_4468,(0,7):C.GC_4457,(0,8):C.GC_4464,(0,0):C.GC_4749,(0,2):C.GC_4760,(0,6):C.GC_4757})

V_939 = Vertex(name = 'V_939',
               particles = [ P.A, P.W__minus__, P.W__plus__, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVSSSS1, L.VVVSSSS227, L.VVVSSSS231, L.VVVSSSS27, L.VVVSSSS294, L.VVVSSSS40, L.VVVSSSS58, L.VVVSSSS60, L.VVVSSSS67, L.VVVSSSS85, L.VVVSSSS9 ],
               couplings = {(0,0):C.GC_7084,(0,6):C.GC_7081,(0,5):C.GC_4690,(0,3):C.GC_4706,(0,2):C.GC_4685,(0,4):C.GC_4699,(0,10):C.GC_4461,(0,9):C.GC_4458,(0,8):C.GC_4758,(0,7):C.GC_4752,(0,1):C.GC_4763})

V_940 = Vertex(name = 'V_940',
               particles = [ P.A, P.W__minus__, P.W__plus__, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVSSSS1, L.VVVSSSS58 ],
               couplings = {(0,0):C.GC_2609,(0,1):C.GC_2608})

V_941 = Vertex(name = 'V_941',
               particles = [ P.A, P.W__minus__, P.W__plus__, P.G0, P.G0, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVSSS1, L.VVVSSS119, L.VVVSSS26, L.VVVSSS39, L.VVVSSS52, L.VVVSSS60, L.VVVSSS9 ],
               couplings = {(0,0):C.GC_6985,(0,3):C.GC_6983,(0,6):C.GC_4404,(0,5):C.GC_4402,(0,2):C.GC_4568,(0,4):C.GC_4565,(0,1):C.GC_4571})

V_942 = Vertex(name = 'V_942',
               particles = [ P.A, P.W__minus__, P.W__plus__, P.G0, P.G0, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVSSS1, L.VVVSSS39 ],
               couplings = {(0,0):C.GC_2550,(0,1):C.GC_2549})

V_943 = Vertex(name = 'V_943',
               particles = [ P.A, P.W__minus__, P.W__plus__, P.G__minus__, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVSSS199, L.VVVSSS28, L.VVVSSS41, L.VVVSSS6, L.VVVSSS60, L.VVVSSS62, L.VVVSSS9, L.VVVSSS92, L.VVVSSS93, L.VVVSSS94 ],
               couplings = {(0,6):C.GC_4404,(0,3):C.GC_4411,(0,4):C.GC_4402,(0,5):C.GC_4407,(0,7):C.GC_4720,(0,8):C.GC_4728,(0,2):C.GC_4725,(0,1):C.GC_4568,(0,9):C.GC_4565,(0,0):C.GC_4572})

V_944 = Vertex(name = 'V_944',
               particles = [ P.A, P.W__minus__, P.W__plus__, P.G0, P.G0, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVSSSS1, L.VVVSSSS193, L.VVVSSSS35, L.VVVSSSS58, L.VVVSSSS73, L.VVVSSSS85, L.VVVSSSS9 ],
               couplings = {(0,0):C.GC_7083,(0,3):C.GC_7080,(0,2):C.GC_4689,(0,4):C.GC_4686,(0,1):C.GC_4693,(0,6):C.GC_4460,(0,5):C.GC_4457})

V_945 = Vertex(name = 'V_945',
               particles = [ P.A, P.W__minus__, P.W__plus__, P.G0, P.G0, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVSSSS1, L.VVVSSSS58 ],
               couplings = {(0,0):C.GC_2610,(0,1):C.GC_2607})

V_946 = Vertex(name = 'V_946',
               particles = [ P.A, P.W__minus__, P.W__plus__, P.G__minus__, P.G__plus__, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVSSSS113, L.VVVSSSS114, L.VVVSSSS116, L.VVVSSSS344, L.VVVSSSS38, L.VVVSSSS59, L.VVVSSSS6, L.VVVSSSS85, L.VVVSSSS87, L.VVVSSSS9 ],
               couplings = {(0,4):C.GC_4689,(0,2):C.GC_4686,(0,3):C.GC_4695,(0,9):C.GC_4460,(0,6):C.GC_4468,(0,7):C.GC_4457,(0,8):C.GC_4464,(0,0):C.GC_4751,(0,1):C.GC_4762,(0,5):C.GC_4757})

V_947 = Vertex(name = 'V_947',
               particles = [ P.A, P.W__minus__, P.W__plus__, P.H, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVSSS1, L.VVVSSS119, L.VVVSSS26, L.VVVSSS39, L.VVVSSS52, L.VVVSSS60, L.VVVSSS9 ],
               couplings = {(0,0):C.GC_6986,(0,3):C.GC_6984,(0,6):C.GC_4405,(0,5):C.GC_4403,(0,2):C.GC_4569,(0,4):C.GC_4564,(0,1):C.GC_4573})

V_948 = Vertex(name = 'V_948',
               particles = [ P.A, P.W__minus__, P.W__plus__, P.H, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVSSS1, L.VVVSSS39 ],
               couplings = {(0,0):C.GC_2551,(0,1):C.GC_2548})

V_949 = Vertex(name = 'V_949',
               particles = [ P.A, P.W__minus__, P.W__plus__, P.H, P.H, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVSSSS1, L.VVVSSSS193, L.VVVSSSS35, L.VVVSSSS58, L.VVVSSSS73, L.VVVSSSS85, L.VVVSSSS9 ],
               couplings = {(0,0):C.GC_7085,(0,3):C.GC_7082,(0,2):C.GC_4691,(0,4):C.GC_4684,(0,1):C.GC_4696,(0,6):C.GC_4462,(0,5):C.GC_4459})

V_950 = Vertex(name = 'V_950',
               particles = [ P.A, P.W__minus__, P.W__plus__, P.H, P.H, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVSSSS1, L.VVVSSSS58 ],
               couplings = {(0,0):C.GC_2611,(0,1):C.GC_2606})

V_951 = Vertex(name = 'V_951',
               particles = [ P.W__minus__, P.W__plus__, P.G0, P.G0, P.G0 ],
               color = [ '1' ],
               lorentz = [ L.VVSSS45, L.VVSSS49, L.VVSSS80, L.VVSSS86 ],
               couplings = {(0,1):C.GC_607,(0,0):C.GC_618,(0,3):C.GC_602,(0,2):C.GC_611})

V_952 = Vertex(name = 'V_952',
               particles = [ P.W__minus__, P.W__plus__, P.G0 ],
               color = [ '1' ],
               lorentz = [ L.VVS10, L.VVS17, L.VVS18, L.VVS9 ],
               couplings = {(0,0):C.GC_631,(0,3):C.GC_633,(0,2):C.GC_630,(0,1):C.GC_632})

V_953 = Vertex(name = 'V_953',
               particles = [ P.W__minus__, P.W__plus__, P.G0, P.G__minus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVSSS10, L.VVSSS27, L.VVSSS31, L.VVSSS35, L.VVSSS52, L.VVSSS71, L.VVSSS91 ],
               couplings = {(0,0):C.GC_607,(0,5):C.GC_602,(0,4):C.GC_619,(0,3):C.GC_610,(0,2):C.GC_846,(0,1):C.GC_857,(0,6):C.GC_850})

V_954 = Vertex(name = 'V_954',
               particles = [ P.W__minus__, P.W__plus__, P.G0, P.G0, P.G0, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS123, L.VVSSSS138, L.VVSSSS47, L.VVSSSS72, L.VVSSSS90 ],
               couplings = {(0,2):C.GC_1392,(0,4):C.GC_755,(0,3):C.GC_766,(0,0):C.GC_750,(0,1):C.GC_759})

V_955 = Vertex(name = 'V_955',
               particles = [ P.W__minus__, P.W__plus__, P.G0, P.G__minus__, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS129, L.VVSSSS149, L.VVSSSS44, L.VVSSSS49, L.VVSSSS51, L.VVSSSS79, L.VVSSSS81 ],
               couplings = {(0,2):C.GC_935,(0,3):C.GC_947,(0,1):C.GC_945,(0,5):C.GC_755,(0,0):C.GC_750,(0,6):C.GC_767,(0,4):C.GC_758})

V_956 = Vertex(name = 'V_956',
               particles = [ P.W__minus__, P.W__plus__, P.G0, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSS34, L.VVSSS46, L.VVSSS55, L.VVSSS82, L.VVSSS83 ],
               couplings = {(0,2):C.GC_608,(0,1):C.GC_620,(0,3):C.GC_603,(0,4):C.GC_609,(0,0):C.GC_1382})

V_957 = Vertex(name = 'V_957',
               particles = [ P.W__minus__, P.W__plus__, P.G0, P.H, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVSSSS131, L.VVSSSS132, L.VVSSSS42, L.VVSSSS69, L.VVSSSS77 ],
               couplings = {(0,2):C.GC_1392,(0,4):C.GC_756,(0,3):C.GC_768,(0,0):C.GC_751,(0,1):C.GC_757})

V_958 = Vertex(name = 'V_958',
               particles = [ P.A, P.A, P.W__minus__, P.W__plus__, P.G0, P.G0 ],
               color = [ '1' ],
               lorentz = [ L.VVVVSS333, L.VVVVSS337, L.VVVVSS338, L.VVVVSS350, L.VVVVSS357, L.VVVVSS422, L.VVVVSS423, L.VVVVSS464, L.VVVVSS470, L.VVVVSS506, L.VVVVSS511, L.VVVVSS603, L.VVVVSS614, L.VVVVSS617, L.VVVVSS649, L.VVVVSS701, L.VVVVSS705, L.VVVVSS780 ],
               couplings = {(0,11):C.GC_1622,(0,2):C.GC_1708,(0,10):C.GC_1711,(0,9):C.GC_1683,(0,3):C.GC_2188,(0,15):C.GC_1693,(0,5):C.GC_1691,(0,17):C.GC_1686,(0,13):C.GC_2189,(0,7):C.GC_1584,(0,14):C.GC_6358,(0,1):C.GC_4254,(0,0):C.GC_4260,(0,6):C.GC_4240,(0,16):C.GC_4251,(0,12):C.GC_4235,(0,4):C.GC_4245,(0,8):C.GC_4137})

V_959 = Vertex(name = 'V_959',
               particles = [ P.A, P.A, P.W__minus__, P.W__plus__, P.G0, P.G0 ],
               color = [ '1' ],
               lorentz = [ L.VVVVSS603 ],
               couplings = {(0,0):C.GC_6558})

V_960 = Vertex(name = 'V_960',
               particles = [ P.A, P.A, P.W__minus__, P.W__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVVS104, L.VVVVS107, L.VVVVS124, L.VVVVS170, L.VVVVS178, L.VVVVS181, L.VVVVS205, L.VVVVS227, L.VVVVS232, L.VVVVS39, L.VVVVS41, L.VVVVS42, L.VVVVS55, L.VVVVS61, L.VVVVS69, L.VVVVS70 ],
               couplings = {(0,0):C.GC_1553,(0,6):C.GC_6262,(0,3):C.GC_1620,(0,11):C.GC_1646,(0,2):C.GC_1648,(0,12):C.GC_1639,(0,7):C.GC_1644,(0,14):C.GC_1643,(0,5):C.GC_1640,(0,1):C.GC_4132,(0,10):C.GC_4176,(0,9):C.GC_4181,(0,15):C.GC_4165,(0,8):C.GC_4173,(0,4):C.GC_4161,(0,13):C.GC_4168})

V_961 = Vertex(name = 'V_961',
               particles = [ P.A, P.A, P.W__minus__, P.W__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVVS170 ],
               couplings = {(0,0):C.GC_6594})

V_962 = Vertex(name = 'V_962',
               particles = [ P.A, P.A, P.W__minus__, P.W__plus__, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVVSS333, L.VVVVSS337, L.VVVVSS338, L.VVVVSS350, L.VVVVSS357, L.VVVVSS422, L.VVVVSS423, L.VVVVSS464, L.VVVVSS470, L.VVVVSS506, L.VVVVSS511, L.VVVVSS603, L.VVVVSS614, L.VVVVSS617, L.VVVVSS649, L.VVVVSS701, L.VVVVSS705, L.VVVVSS780 ],
               couplings = {(0,11):C.GC_1622,(0,2):C.GC_1708,(0,10):C.GC_1711,(0,9):C.GC_1683,(0,3):C.GC_2188,(0,15):C.GC_1693,(0,5):C.GC_1691,(0,17):C.GC_1686,(0,13):C.GC_2189,(0,7):C.GC_1584,(0,14):C.GC_6358,(0,1):C.GC_4254,(0,0):C.GC_4260,(0,6):C.GC_4240,(0,16):C.GC_4251,(0,12):C.GC_4235,(0,4):C.GC_4245,(0,8):C.GC_4137})

V_963 = Vertex(name = 'V_963',
               particles = [ P.A, P.A, P.W__minus__, P.W__plus__, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVVSS603 ],
               couplings = {(0,0):C.GC_6559})

V_964 = Vertex(name = 'V_964',
               particles = [ P.A, P.A, P.A, P.W__minus__, P.W__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVVV1, L.VVVVV134, L.VVVVV19, L.VVVVV2, L.VVVVV34, L.VVVVV35, L.VVVVV44, L.VVVVV49, L.VVVVV52, L.VVVVV76, L.VVVVV77 ],
               couplings = {(0,5):C.GC_2010,(0,4):C.GC_7170,(0,7):C.GC_7169,(0,0):C.GC_7087,(0,3):C.GC_7089,(0,2):C.GC_4077,(0,6):C.GC_7091,(0,9):C.GC_7090,(0,8):C.GC_7088,(0,10):C.GC_4076,(0,1):C.GC_7086})

V_965 = Vertex(name = 'V_965',
               particles = [ P.A, P.A, P.A, P.W__minus__, P.W__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVVV34, L.VVVVV49 ],
               couplings = {(0,0):C.GC_7163,(0,1):C.GC_7162})

V_966 = Vertex(name = 'V_966',
               particles = [ P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVVV101, L.VVVVV131, L.VVVVV132, L.VVVVV139, L.VVVVV14, L.VVVVV33, L.VVVVV38, L.VVVVV46, L.VVVVV47, L.VVVVV5, L.VVVVV50, L.VVVVV54, L.VVVVV68, L.VVVVV71, L.VVVVV72 ],
               couplings = {(0,12):C.GC_7822,(0,1):C.GC_7799,(0,5):C.GC_5147,(0,8):C.GC_5148,(0,13):C.GC_7864,(0,14):C.GC_7865,(0,0):C.GC_7745,(0,4):C.GC_7743,(0,9):C.GC_7741,(0,7):C.GC_7744,(0,11):C.GC_7740,(0,3):C.GC_7742,(0,2):C.GC_7859,(0,6):C.GC_7861,(0,10):C.GC_7860})

V_967 = Vertex(name = 'V_967',
               particles = [ P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVVV131, L.VVVVV68 ],
               couplings = {(0,1):C.GC_7795,(0,0):C.GC_7794})

V_968 = Vertex(name = 'V_968',
               particles = [ P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVVV131 ],
               couplings = {(0,0):C.GC_7862})

V_969 = Vertex(name = 'V_969',
               particles = [ P.A, P.W__minus__, P.Z, P.G0, P.G0, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVSSS101, L.VVVSSS126, L.VVVSSS16, L.VVVSSS186, L.VVVSSS23, L.VVVSSS33, L.VVVSSS4, L.VVVSSS44, L.VVVSSS5, L.VVVSSS58, L.VVVSSS61 ],
               couplings = {(0,8):C.GC_6278,(0,6):C.GC_596,(0,10):C.GC_6273,(0,9):C.GC_587,(0,5):C.GC_3982,(0,7):C.GC_3974,(0,0):C.GC_3978,(0,4):C.GC_3896,(0,2):C.GC_3907,(0,1):C.GC_3891,(0,3):C.GC_3902})

V_970 = Vertex(name = 'V_970',
               particles = [ P.A, P.W__minus__, P.Z, P.G0, P.G0, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVSSS4, L.VVVSSS5, L.VVVSSS58, L.VVVSSS61 ],
               couplings = {(0,1):C.GC_6637,(0,0):C.GC_842,(0,3):C.GC_6631,(0,2):C.GC_833})

V_971 = Vertex(name = 'V_971',
               particles = [ P.A, P.W__minus__, P.Z, P.G0, P.G0, P.G0, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVSSSS141, L.VVVSSSS150, L.VVVSSSS163, L.VVVSSSS19, L.VVVSSSS237, L.VVVSSSS31, L.VVVSSSS316, L.VVVSSSS4, L.VVVSSSS5, L.VVVSSSS83, L.VVVSSSS86 ],
               couplings = {(0,8):C.GC_6512,(0,7):C.GC_740,(0,10):C.GC_6495,(0,9):C.GC_739,(0,5):C.GC_3950,(0,3):C.GC_3971,(0,4):C.GC_3941,(0,6):C.GC_3954,(0,1):C.GC_4269,(0,2):C.GC_4277,(0,0):C.GC_6129})

V_972 = Vertex(name = 'V_972',
               particles = [ P.A, P.W__minus__, P.Z, P.G0, P.G0, P.G0, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVSSSS4, L.VVVSSSS5, L.VVVSSSS83, L.VVVSSSS86 ],
               couplings = {(0,1):C.GC_6769,(0,0):C.GC_930,(0,3):C.GC_2195,(0,2):C.GC_921})

V_973 = Vertex(name = 'V_973',
               particles = [ P.A, P.W__minus__, P.Z, P.G__minus__, P.G__plus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVSSS11, L.VVVSSS130, L.VVVSSS135, L.VVVSSS154, L.VVVSSS155, L.VVVSSS159, L.VVVSSS160, L.VVVSSS188, L.VVVSSS20, L.VVVSSS4, L.VVVSSS5, L.VVVSSS58, L.VVVSSS61, L.VVVSSS72 ],
               couplings = {(0,10):C.GC_6281,(0,9):C.GC_598,(0,12):C.GC_6274,(0,11):C.GC_589,(0,6):C.GC_3975,(0,1):C.GC_3979,(0,2):C.GC_3983,(0,5):C.GC_6781,(0,7):C.GC_4279,(0,8):C.GC_3895,(0,0):C.GC_3908,(0,3):C.GC_3892,(0,13):C.GC_3903,(0,4):C.GC_4189})

V_974 = Vertex(name = 'V_974',
               particles = [ P.A, P.W__minus__, P.Z, P.G__minus__, P.G__plus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVSSS4, L.VVVSSS5, L.VVVSSS58, L.VVVSSS61 ],
               couplings = {(0,1):C.GC_6640,(0,0):C.GC_843,(0,3):C.GC_6630,(0,2):C.GC_832})

V_975 = Vertex(name = 'V_975',
               particles = [ P.A, P.W__minus__, P.Z, P.G0, P.G__minus__, P.G__plus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVSSSS11, L.VVVSSSS115, L.VVVSSSS219, L.VVVSSSS220, L.VVVSSSS233, L.VVVSSSS25, L.VVVSSSS255, L.VVVSSSS260, L.VVVSSSS266, L.VVVSSSS267, L.VVVSSSS268, L.VVVSSSS4, L.VVVSSSS5, L.VVVSSSS83, L.VVVSSSS86, L.VVVSSSS94 ],
               couplings = {(0,12):C.GC_6504,(0,11):C.GC_741,(0,14):C.GC_6503,(0,13):C.GC_738,(0,5):C.GC_3949,(0,0):C.GC_3964,(0,6):C.GC_3940,(0,1):C.GC_3961,(0,15):C.GC_4268,(0,7):C.GC_4273,(0,10):C.GC_4013,(0,3):C.GC_4018,(0,9):C.GC_4306,(0,2):C.GC_4309,(0,4):C.GC_4023,(0,8):C.GC_4312})

V_976 = Vertex(name = 'V_976',
               particles = [ P.A, P.W__minus__, P.Z, P.G0, P.G__minus__, P.G__plus__, P.G__plus__ ],
               color = [ '1' ],
               lorentz = [ L.VVVSSSS4, L.VVVSSSS5, L.VVVSSSS83, L.VVVSSSS86 ],
               couplings = {(0,1):C.GC_6775,(0,0):C.GC_929,(0,3):C.GC_2194,(0,2):C.GC_920})

V_977 = Vertex(name = 'V_977',
               particles = [ P.A, P.W__minus__, P.Z, P.G0, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVSSS127, L.VVVSSS14, L.VVVSSS142, L.VVVSSS24, L.VVVSSS34, L.VVVSSS4, L.VVVSSS5, L.VVVSSS58, L.VVVSSS61, L.VVVSSS68, L.VVVSSS76, L.VVVSSS79, L.VVVSSS88 ],
               couplings = {(0,6):C.GC_6284,(0,5):C.GC_594,(0,8):C.GC_6271,(0,7):C.GC_593,(0,4):C.GC_3984,(0,11):C.GC_3976,(0,0):C.GC_3980,(0,1):C.GC_3897,(0,3):C.GC_3910,(0,12):C.GC_3890,(0,2):C.GC_3901,(0,9):C.GC_4185,(0,10):C.GC_4190})

V_978 = Vertex(name = 'V_978',
               particles = [ P.A, P.W__minus__, P.Z, P.G0, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVSSS4, L.VVVSSS5, L.VVVSSS58, L.VVVSSS61 ],
               couplings = {(0,1):C.GC_6636,(0,0):C.GC_841,(0,3):C.GC_2159,(0,2):C.GC_834})

V_979 = Vertex(name = 'V_979',
               particles = [ P.A, P.W__minus__, P.Z, P.G0, P.G0, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVSSSS18, L.VVVSSSS183, L.VVVSSSS205, L.VVVSSSS217, L.VVVSSSS300, L.VVVSSSS303, L.VVVSSSS321, L.VVVSSSS33, L.VVVSSSS4, L.VVVSSSS48, L.VVVSSSS5, L.VVVSSSS83, L.VVVSSSS86 ],
               couplings = {(0,10):C.GC_6505,(0,8):C.GC_744,(0,12):C.GC_6498,(0,11):C.GC_731,(0,7):C.GC_3947,(0,0):C.GC_3966,(0,3):C.GC_3942,(0,6):C.GC_3957,(0,1):C.GC_4266,(0,4):C.GC_4275,(0,9):C.GC_4021,(0,2):C.GC_4010,(0,5):C.GC_4014})

V_980 = Vertex(name = 'V_980',
               particles = [ P.A, P.W__minus__, P.Z, P.G0, P.G0, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVSSSS4, L.VVVSSSS5, L.VVVSSSS83, L.VVVSSSS86 ],
               couplings = {(0,1):C.GC_6770,(0,0):C.GC_931,(0,3):C.GC_2192,(0,2):C.GC_918})

V_981 = Vertex(name = 'V_981',
               particles = [ P.A, P.W__minus__, P.Z, P.G__minus__, P.G__plus__, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVSSSS146, L.VVVSSSS156, L.VVVSSSS16, L.VVVSSSS183, L.VVVSSSS235, L.VVVSSSS245, L.VVVSSSS302, L.VVVSSSS306, L.VVVSSSS312, L.VVVSSSS313, L.VVVSSSS314, L.VVVSSSS32, L.VVVSSSS4, L.VVVSSSS5, L.VVVSSSS83, L.VVVSSSS86 ],
               couplings = {(0,13):C.GC_6508,(0,12):C.GC_746,(0,15):C.GC_6499,(0,14):C.GC_733,(0,11):C.GC_3946,(0,2):C.GC_3967,(0,4):C.GC_3943,(0,6):C.GC_3958,(0,3):C.GC_4265,(0,8):C.GC_4276,(0,10):C.GC_4011,(0,7):C.GC_4016,(0,0):C.GC_4022,(0,9):C.GC_4308,(0,1):C.GC_4314,(0,5):C.GC_4310})

V_982 = Vertex(name = 'V_982',
               particles = [ P.A, P.W__minus__, P.Z, P.G__minus__, P.G__plus__, P.G__plus__, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVSSSS4, L.VVVSSSS5, L.VVVSSSS83, L.VVVSSSS86 ],
               couplings = {(0,1):C.GC_6774,(0,0):C.GC_932,(0,3):C.GC_2191,(0,2):C.GC_917})

V_983 = Vertex(name = 'V_983',
               particles = [ P.A, P.W__minus__, P.Z, P.G__plus__, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVSSS131, L.VVVSSS147, L.VVVSSS163, L.VVVSSS167, L.VVVSSS18, L.VVVSSS189, L.VVVSSS19, L.VVVSSS4, L.VVVSSS5, L.VVVSSS58, L.VVVSSS61 ],
               couplings = {(0,8):C.GC_6282,(0,7):C.GC_600,(0,10):C.GC_6277,(0,9):C.GC_591,(0,0):C.GC_6125,(0,6):C.GC_3894,(0,4):C.GC_3909,(0,2):C.GC_3893,(0,3):C.GC_3904,(0,1):C.GC_4184,(0,5):C.GC_4188})

V_984 = Vertex(name = 'V_984',
               particles = [ P.A, P.W__minus__, P.Z, P.G__plus__, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVSSS4, L.VVVSSS5, L.VVVSSS58, L.VVVSSS61 ],
               couplings = {(0,1):C.GC_6638,(0,0):C.GC_844,(0,3):C.GC_2158,(0,2):C.GC_831})

V_985 = Vertex(name = 'V_985',
               particles = [ P.A, P.W__minus__, P.Z, P.G0, P.G__plus__, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVSSSS100, L.VVVSSSS101, L.VVVSSSS109, L.VVVSSSS12, L.VVVSSSS218, L.VVVSSSS230, L.VVVSSSS34, L.VVVSSSS4, L.VVVSSSS5, L.VVVSSSS51, L.VVVSSSS83, L.VVVSSSS86, L.VVVSSSS94 ],
               couplings = {(0,8):C.GC_6511,(0,7):C.GC_742,(0,11):C.GC_6496,(0,10):C.GC_737,(0,3):C.GC_3948,(0,6):C.GC_3969,(0,2):C.GC_3939,(0,5):C.GC_3956,(0,12):C.GC_4267,(0,0):C.GC_4277,(0,9):C.GC_4023,(0,1):C.GC_4012,(0,4):C.GC_4017})

V_986 = Vertex(name = 'V_986',
               particles = [ P.A, P.W__minus__, P.Z, P.G0, P.G__plus__, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVSSSS4, L.VVVSSSS5, L.VVVSSSS83, L.VVVSSSS86 ],
               couplings = {(0,1):C.GC_6768,(0,0):C.GC_928,(0,3):C.GC_2193,(0,2):C.GC_919})

V_987 = Vertex(name = 'V_987',
               particles = [ P.A, P.W__minus__, P.Z, P.G__plus__, P.H, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVSSSS223, L.VVVSSSS23, L.VVVSSSS24, L.VVVSSSS250, L.VVVSSSS271, L.VVVSSSS275, L.VVVSSSS323, L.VVVSSSS4, L.VVVSSSS5, L.VVVSSSS83, L.VVVSSSS86 ],
               couplings = {(0,8):C.GC_6509,(0,7):C.GC_748,(0,10):C.GC_6502,(0,9):C.GC_735,(0,2):C.GC_3945,(0,1):C.GC_3968,(0,4):C.GC_3944,(0,5):C.GC_3959,(0,3):C.GC_4264,(0,6):C.GC_4275,(0,0):C.GC_6127})

V_988 = Vertex(name = 'V_988',
               particles = [ P.A, P.W__minus__, P.Z, P.G__plus__, P.H, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVSSSS4, L.VVVSSSS5, L.VVVSSSS83, L.VVVSSSS86 ],
               couplings = {(0,1):C.GC_6771,(0,0):C.GC_933,(0,3):C.GC_2190,(0,2):C.GC_916})

V_989 = Vertex(name = 'V_989',
               particles = [ P.A, P.W__minus__, P.W__plus__, P.Z, P.G0, P.G0 ],
               color = [ '1' ],
               lorentz = [ L.VVVVSS1, L.VVVVSS221, L.VVVVSS262, L.VVVVSS265, L.VVVVSS418, L.VVVVSS437, L.VVVVSS441, L.VVVVSS472, L.VVVVSS475, L.VVVVSS476, L.VVVVSS477, L.VVVVSS497, L.VVVVSS536, L.VVVVSS540, L.VVVVSS541, L.VVVVSS545, L.VVVVSS546, L.VVVVSS547, L.VVVVSS550, L.VVVVSS551, L.VVVVSS559, L.VVVVSS578, L.VVVVSS580, L.VVVVSS604, L.VVVVSS605, L.VVVVSS627, L.VVVVSS631, L.VVVVSS637, L.VVVVSS638, L.VVVVSS643, L.VVVVSS644, L.VVVVSS645, L.VVVVSS704, L.VVVVSS728, L.VVVVSS739, L.VVVVSS740, L.VVVVSS741, L.VVVVSS753, L.VVVVSS760, L.VVVVSS764, L.VVVVSS774, L.VVVVSS785 ],
               couplings = {(0,24):C.GC_7528,(0,14):C.GC_3196,(0,13):C.GC_3198,(0,17):C.GC_3254,(0,15):C.GC_3255,(0,16):C.GC_3219,(0,21):C.GC_3220,(0,5):C.GC_3190,(0,2):C.GC_3212,(0,4):C.GC_3248,(0,33):C.GC_3193,(0,40):C.GC_3194,(0,36):C.GC_3250,(0,38):C.GC_3252,(0,37):C.GC_3217,(0,26):C.GC_3188,(0,11):C.GC_3210,(0,35):C.GC_3214,(0,25):C.GC_3246,(0,10):C.GC_3181,(0,8):C.GC_3202,(0,7):C.GC_3239,(0,29):C.GC_3179,(0,31):C.GC_7442,(0,30):C.GC_3236,(0,19):C.GC_4908,(0,20):C.GC_4910,(0,6):C.GC_4952,(0,12):C.GC_4953,(0,18):C.GC_4924,(0,22):C.GC_4925,(0,39):C.GC_4906,(0,32):C.GC_4951,(0,27):C.GC_7539,(0,28):C.GC_7547,(0,34):C.GC_4921,(0,1):C.GC_7549,(0,3):C.GC_7540,(0,41):C.GC_7548,(0,0):C.GC_7913,(0,9):C.GC_7444,(0,23):C.GC_7910})

V_990 = Vertex(name = 'V_990',
               particles = [ P.A, P.W__minus__, P.W__plus__, P.Z, P.G0, P.G0 ],
               color = [ '1' ],
               lorentz = [ L.VVVVSS605 ],
               couplings = {(0,0):C.GC_7517})

V_991 = Vertex(name = 'V_991',
               particles = [ P.A, P.W__minus__, P.W__plus__, P.Z, P.G0, P.G0 ],
               color = [ '1' ],
               lorentz = [ L.VVVVSS605 ],
               couplings = {(0,0):C.GC_7908})

V_992 = Vertex(name = 'V_992',
               particles = [ P.A, P.W__minus__, P.W__plus__, P.Z, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVVS1, L.VVVVS109, L.VVVVS112, L.VVVVS113, L.VVVVS114, L.VVVVS123, L.VVVVS136, L.VVVVS138, L.VVVVS139, L.VVVVS142, L.VVVVS143, L.VVVVS144, L.VVVVS146, L.VVVVS147, L.VVVVS152, L.VVVVS162, L.VVVVS163, L.VVVVS171, L.VVVVS172, L.VVVVS187, L.VVVVS189, L.VVVVS19, L.VVVVS194, L.VVVVS199, L.VVVVS200, L.VVVVS201, L.VVVVS23, L.VVVVS231, L.VVVVS239, L.VVVVS244, L.VVVVS245, L.VVVVS247, L.VVVVS25, L.VVVVS252, L.VVVVS254, L.VVVVS256, L.VVVVS260, L.VVVVS68, L.VVVVS77, L.VVVVS81 ],
               couplings = {(0,4):C.GC_3177,(0,2):C.GC_3201,(0,1):C.GC_3235,(0,23):C.GC_3176,(0,25):C.GC_7413,(0,24):C.GC_3234,(0,18):C.GC_7535,(0,8):C.GC_3186,(0,7):C.GC_3187,(0,11):C.GC_3244,(0,9):C.GC_3245,(0,10):C.GC_3208,(0,15):C.GC_3209,(0,38):C.GC_3183,(0,26):C.GC_3205,(0,37):C.GC_3241,(0,28):C.GC_3184,(0,36):C.GC_3185,(0,31):C.GC_3242,(0,34):C.GC_3243,(0,33):C.GC_3207,(0,20):C.GC_3182,(0,5):C.GC_3204,(0,30):C.GC_3206,(0,19):C.GC_3240,(0,0):C.GC_7907,(0,3):C.GC_7414,(0,17):C.GC_7906,(0,13):C.GC_4901,(0,14):C.GC_4902,(0,39):C.GC_4945,(0,6):C.GC_4946,(0,12):C.GC_4916,(0,16):C.GC_4917,(0,35):C.GC_4900,(0,27):C.GC_4944,(0,22):C.GC_7536,(0,29):C.GC_4915,(0,21):C.GC_7538,(0,32):C.GC_7537})

V_993 = Vertex(name = 'V_993',
               particles = [ P.A, P.W__minus__, P.W__plus__, P.Z, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVVS172 ],
               couplings = {(0,0):C.GC_7516})

V_994 = Vertex(name = 'V_994',
               particles = [ P.A, P.W__minus__, P.W__plus__, P.Z, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVVS172 ],
               couplings = {(0,0):C.GC_7905})

V_995 = Vertex(name = 'V_995',
               particles = [ P.A, P.W__minus__, P.W__plus__, P.Z, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVVSS1, L.VVVVSS221, L.VVVVSS262, L.VVVVSS265, L.VVVVSS418, L.VVVVSS437, L.VVVVSS441, L.VVVVSS472, L.VVVVSS475, L.VVVVSS476, L.VVVVSS477, L.VVVVSS497, L.VVVVSS536, L.VVVVSS540, L.VVVVSS541, L.VVVVSS545, L.VVVVSS546, L.VVVVSS547, L.VVVVSS550, L.VVVVSS551, L.VVVVSS559, L.VVVVSS578, L.VVVVSS580, L.VVVVSS604, L.VVVVSS605, L.VVVVSS627, L.VVVVSS631, L.VVVVSS637, L.VVVVSS638, L.VVVVSS643, L.VVVVSS644, L.VVVVSS645, L.VVVVSS704, L.VVVVSS728, L.VVVVSS739, L.VVVVSS740, L.VVVVSS741, L.VVVVSS753, L.VVVVSS760, L.VVVVSS764, L.VVVVSS774, L.VVVVSS785 ],
               couplings = {(0,24):C.GC_7529,(0,14):C.GC_3196,(0,13):C.GC_3198,(0,17):C.GC_3254,(0,15):C.GC_3255,(0,16):C.GC_3219,(0,21):C.GC_3220,(0,5):C.GC_3190,(0,2):C.GC_3212,(0,4):C.GC_3248,(0,33):C.GC_3193,(0,40):C.GC_3194,(0,36):C.GC_3250,(0,38):C.GC_3252,(0,37):C.GC_3217,(0,26):C.GC_3188,(0,11):C.GC_3210,(0,35):C.GC_3214,(0,25):C.GC_3246,(0,10):C.GC_3181,(0,8):C.GC_3202,(0,7):C.GC_3239,(0,29):C.GC_3179,(0,31):C.GC_7442,(0,30):C.GC_3236,(0,19):C.GC_4908,(0,20):C.GC_4910,(0,6):C.GC_4952,(0,12):C.GC_4953,(0,18):C.GC_4924,(0,22):C.GC_4925,(0,39):C.GC_4906,(0,32):C.GC_4951,(0,27):C.GC_7539,(0,28):C.GC_7547,(0,34):C.GC_4921,(0,1):C.GC_7549,(0,3):C.GC_7540,(0,41):C.GC_7548,(0,0):C.GC_7914,(0,9):C.GC_7444,(0,23):C.GC_7912})

V_996 = Vertex(name = 'V_996',
               particles = [ P.A, P.W__minus__, P.W__plus__, P.Z, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVVSS605 ],
               couplings = {(0,0):C.GC_7517})

V_997 = Vertex(name = 'V_997',
               particles = [ P.A, P.W__minus__, P.W__plus__, P.Z, P.H, P.H ],
               color = [ '1' ],
               lorentz = [ L.VVVVSS605 ],
               couplings = {(0,0):C.GC_7909})

V_998 = Vertex(name = 'V_998',
               particles = [ P.A, P.A, P.W__minus__, P.W__plus__, P.Z ],
               color = [ '1' ],
               lorentz = [ L.VVVVV102, L.VVVVV11, L.VVVVV114, L.VVVVV115, L.VVVVV116, L.VVVVV117, L.VVVVV12, L.VVVVV124, L.VVVVV127, L.VVVVV135, L.VVVVV136, L.VVVVV21, L.VVVVV24, L.VVVVV28, L.VVVVV29, L.VVVVV3, L.VVVVV30, L.VVVVV31, L.VVVVV32, L.VVVVV4, L.VVVVV57, L.VVVVV60, L.VVVVV62, L.VVVVV63, L.VVVVV64, L.VVVVV74, L.VVVVV75, L.VVVVV92, L.VVVVV93 ],
               couplings = {(0,21):C.GC_2009,(0,8):C.GC_2008,(0,20):C.GC_3685,(0,23):C.GC_3686,(0,16):C.GC_2072,(0,26):C.GC_1982,(0,1):C.GC_1981,(0,15):C.GC_1979,(0,28):C.GC_1983,(0,27):C.GC_2460,(0,6):C.GC_2457,(0,19):C.GC_2455,(0,14):C.GC_2459,(0,9):C.GC_1980,(0,10):C.GC_2456,(0,25):C.GC_2071,(0,17):C.GC_2458,(0,0):C.GC_1978,(0,18):C.GC_2454,(0,3):C.GC_3683,(0,24):C.GC_4082,(0,13):C.GC_4497,(0,7):C.GC_4496,(0,11):C.GC_4717,(0,12):C.GC_4718,(0,2):C.GC_4715,(0,5):C.GC_4716,(0,22):C.GC_4713,(0,4):C.GC_4712})

V_999 = Vertex(name = 'V_999',
               particles = [ P.A, P.A, P.W__minus__, P.W__plus__, P.Z ],
               color = [ '1' ],
               lorentz = [ L.VVVVV127, L.VVVVV60 ],
               couplings = {(0,1):C.GC_7172,(0,0):C.GC_7168})

V_1000 = Vertex(name = 'V_1000',
                particles = [ P.A, P.W__minus__, P.W__plus__, P.Z, P.Z ],
                color = [ '1' ],
                lorentz = [ L.VVVVV103, L.VVVVV104, L.VVVVV105, L.VVVVV106, L.VVVVV107, L.VVVVV108, L.VVVVV109, L.VVVVV110, L.VVVVV111, L.VVVVV112, L.VVVVV113, L.VVVVV119, L.VVVVV125, L.VVVVV13, L.VVVVV140, L.VVVVV141, L.VVVVV142, L.VVVVV15, L.VVVVV16, L.VVVVV20, L.VVVVV36, L.VVVVV37, L.VVVVV39, L.VVVVV40, L.VVVVV41, L.VVVVV42, L.VVVVV43, L.VVVVV45, L.VVVVV48, L.VVVVV51, L.VVVVV53, L.VVVVV55, L.VVVVV56, L.VVVVV6, L.VVVVV69, L.VVVVV78, L.VVVVV79, L.VVVVV8, L.VVVVV80, L.VVVVV82, L.VVVVV83, L.VVVVV84, L.VVVVV85, L.VVVVV88, L.VVVVV89, L.VVVVV9, L.VVVVV90, L.VVVVV94, L.VVVVV95, L.VVVVV96, L.VVVVV97 ],
                couplings = {(0,40):C.GC_3200,(0,42):C.GC_7571,(0,36):C.GC_3223,(0,38):C.GC_3229,(0,6):C.GC_7570,(0,7):C.GC_3222,(0,2):C.GC_3228,(0,39):C.GC_3227,(0,35):C.GC_3233,(0,43):C.GC_3259,(0,24):C.GC_5176,(0,12):C.GC_5175,(0,21):C.GC_3225,(0,31):C.GC_3231,(0,32):C.GC_3257,(0,29):C.GC_3224,(0,1):C.GC_3230,(0,8):C.GC_3232,(0,5):C.GC_3258,(0,3):C.GC_3226,(0,0):C.GC_3256,(0,41):C.GC_7866,(0,26):C.GC_4943,(0,20):C.GC_4955,(0,44):C.GC_7567,(0,46):C.GC_4934,(0,17):C.GC_7563,(0,18):C.GC_4929,(0,37):C.GC_7565,(0,45):C.GC_4931,(0,49):C.GC_4914,(0,50):C.GC_7566,(0,47):C.GC_4933,(0,25):C.GC_4935,(0,33):C.GC_4939,(0,27):C.GC_4942,(0,13):C.GC_4937,(0,48):C.GC_4941,(0,10):C.GC_7564,(0,9):C.GC_4930,(0,23):C.GC_4913,(0,22):C.GC_4932,(0,19):C.GC_4940,(0,16):C.GC_7562,(0,15):C.GC_4928,(0,14):C.GC_4936,(0,30):C.GC_4938,(0,28):C.GC_7918,(0,4):C.GC_7863,(0,34):C.GC_7920,(0,11):C.GC_7919})

V_1001 = Vertex(name = 'V_1001',
                particles = [ P.A, P.W__minus__, P.W__plus__, P.Z, P.Z ],
                color = [ '1' ],
                lorentz = [ L.VVVVV109, L.VVVVV85 ],
                couplings = {(0,1):C.GC_7569,(0,0):C.GC_7568})

V_1002 = Vertex(name = 'V_1002',
                particles = [ P.A, P.A, P.W__minus__, P.W__minus__, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSS349, L.VVVVSS391, L.VVVVSS603 ],
                couplings = {(0,2):C.GC_1624,(0,0):C.GC_1873,(0,1):C.GC_1870})

V_1003 = Vertex(name = 'V_1003',
                particles = [ P.A, P.A, P.W__minus__, P.W__minus__, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSS603 ],
                couplings = {(0,0):C.GC_1776})

V_1004 = Vertex(name = 'V_1004',
                particles = [ P.A, P.A, P.W__minus__, P.W__minus__, P.G0, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS3, L.VVVVSSS4, L.VVVVSSS5 ],
                couplings = {(0,2):C.GC_1656,(0,0):C.GC_1886,(0,1):C.GC_1881})

V_1005 = Vertex(name = 'V_1005',
                particles = [ P.A, P.A, P.W__minus__, P.W__minus__, P.G0, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS5 ],
                couplings = {(0,0):C.GC_1806})

V_1006 = Vertex(name = 'V_1006',
                particles = [ P.A, P.A, P.W__minus__, P.W__minus__, P.G0, P.G0, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS3, L.VVVVSSSS4, L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_1901,(0,1):C.GC_1895,(0,2):C.GC_1732})

V_1007 = Vertex(name = 'V_1007',
                particles = [ P.A, P.A, P.W__minus__, P.W__minus__, P.G0, P.G0, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_1867})

V_1008 = Vertex(name = 'V_1008',
                particles = [ P.A, P.A, P.W__minus__, P.W__minus__, P.G__plus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS3, L.VVVVSSS4, L.VVVVSSS5 ],
                couplings = {(0,2):C.GC_1655,(0,0):C.GC_1885,(0,1):C.GC_1880})

V_1009 = Vertex(name = 'V_1009',
                particles = [ P.A, P.A, P.W__minus__, P.W__minus__, P.G__plus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS5 ],
                couplings = {(0,0):C.GC_1808})

V_1010 = Vertex(name = 'V_1010',
                particles = [ P.A, P.A, P.W__minus__, P.W__minus__, P.G0, P.G__plus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS3, L.VVVVSSSS4, L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_1904,(0,1):C.GC_1896,(0,2):C.GC_1733})

V_1011 = Vertex(name = 'V_1011',
                particles = [ P.A, P.A, P.W__minus__, P.W__minus__, P.G0, P.G__plus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_1866})

V_1012 = Vertex(name = 'V_1012',
                particles = [ P.A, P.A, P.W__minus__, P.W__minus__, P.G__plus__, P.G__plus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS3, L.VVVVSSSS4, L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_1900,(0,1):C.GC_1893,(0,2):C.GC_1731})

V_1013 = Vertex(name = 'V_1013',
                particles = [ P.A, P.A, P.W__minus__, P.W__minus__, P.G__plus__, P.G__plus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_1868})

V_1014 = Vertex(name = 'V_1014',
                particles = [ P.A, P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVV1, L.VVVVVV13, L.VVVVVV21, L.VVVVVV22, L.VVVVVV35, L.VVVVVV57, L.VVVVVV61, L.VVVVVV62, L.VVVVVV74, L.VVVVVV75, L.VVVVVV81, L.VVVVVV82, L.VVVVVV9, L.VVVVVV94 ],
                couplings = {(0,1):C.GC_1737,(0,12):C.GC_1742,(0,0):C.GC_2204,(0,5):C.GC_1747,(0,6):C.GC_1746,(0,2):C.GC_2207,(0,11):C.GC_1734,(0,13):C.GC_1739,(0,3):C.GC_2202,(0,8):C.GC_1874,(0,9):C.GC_1772,(0,4):C.GC_1875,(0,7):C.GC_2205,(0,10):C.GC_2199})

V_1015 = Vertex(name = 'V_1015',
                particles = [ P.A, P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVV75 ],
                couplings = {(0,0):C.GC_6777})

V_1016 = Vertex(name = 'V_1016',
                particles = [ P.A, P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVV75 ],
                couplings = {(0,0):C.GC_1876})

V_1017 = Vertex(name = 'V_1017',
                particles = [ P.A, P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVS13, L.VVVVVS135, L.VVVVVS139, L.VVVVVS170, L.VVVVVS196, L.VVVVVS198, L.VVVVVS21, L.VVVVVS24, L.VVVVVS4, L.VVVVVS6, L.VVVVVS74, L.VVVVVS75 ],
                couplings = {(0,10):C.GC_1789,(0,0):C.GC_1791,(0,9):C.GC_1786,(0,5):C.GC_1783,(0,3):C.GC_1784,(0,4):C.GC_1787,(0,8):C.GC_6802,(0,6):C.GC_4295,(0,7):C.GC_4293,(0,2):C.GC_4148,(0,1):C.GC_4301,(0,11):C.GC_4151})

V_1018 = Vertex(name = 'V_1018',
                particles = [ P.A, P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVS139 ],
                couplings = {(0,0):C.GC_4300})

V_1019 = Vertex(name = 'V_1019',
                particles = [ P.A, P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.G0, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVSS100, L.VVVVVSS14, L.VVVVVSS188, L.VVVVVSS192, L.VVVVVSS228, L.VVVVVSS27, L.VVVVVSS270, L.VVVVVSS275, L.VVVVVSS30, L.VVVVVSS5, L.VVVVVSS7, L.VVVVVSS98 ],
                couplings = {(0,11):C.GC_1836,(0,1):C.GC_1838,(0,10):C.GC_1828,(0,6):C.GC_1824,(0,4):C.GC_1827,(0,7):C.GC_1832,(0,0):C.GC_4217,(0,3):C.GC_4216,(0,9):C.GC_6836,(0,5):C.GC_4351,(0,8):C.GC_4340,(0,2):C.GC_4363})

V_1020 = Vertex(name = 'V_1020',
                particles = [ P.A, P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.G0, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVSS192 ],
                couplings = {(0,0):C.GC_4354})

V_1021 = Vertex(name = 'V_1021',
                particles = [ P.A, P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVVSS100, L.VVVVVSS14, L.VVVVVSS188, L.VVVVVSS192, L.VVVVVSS229, L.VVVVVSS27, L.VVVVVSS284, L.VVVVVSS297, L.VVVVVSS30, L.VVVVVSS5, L.VVVVVSS7, L.VVVVVSS99 ],
                couplings = {(0,11):C.GC_1837,(0,1):C.GC_1840,(0,10):C.GC_1830,(0,6):C.GC_1823,(0,4):C.GC_1826,(0,7):C.GC_1833,(0,0):C.GC_4219,(0,3):C.GC_4214,(0,9):C.GC_6842,(0,5):C.GC_4347,(0,8):C.GC_4342,(0,2):C.GC_4359})

V_1022 = Vertex(name = 'V_1022',
                particles = [ P.A, P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVVSS192 ],
                couplings = {(0,0):C.GC_4355})

V_1023 = Vertex(name = 'V_1023',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.Z, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVS11, L.VVVVS122, L.VVVVS130, L.VVVVS132, L.VVVVS170, L.VVVVS176, L.VVVVS192, L.VVVVS203, L.VVVVS214, L.VVVVS233, L.VVVVS237, L.VVVVS241, L.VVVVS242, L.VVVVS261, L.VVVVS30, L.VVVVS31, L.VVVVS44, L.VVVVS49, L.VVVVS54, L.VVVVS56, L.VVVVS64, L.VVVVS84, L.VVVVS86, L.VVVVS96 ],
                couplings = {(0,4):C.GC_2541,(0,21):C.GC_2564,(0,22):C.GC_2567,(0,3):C.GC_2912,(0,2):C.GC_2911,(0,15):C.GC_2560,(0,13):C.GC_2555,(0,10):C.GC_2561,(0,6):C.GC_2903,(0,9):C.GC_2909,(0,1):C.GC_2557,(0,14):C.GC_2907,(0,19):C.GC_2905,(0,18):C.GC_3782,(0,5):C.GC_3780,(0,20):C.GC_2778,(0,23):C.GC_4398,(0,7):C.GC_4395,(0,17):C.GC_4562,(0,16):C.GC_4559,(0,0):C.GC_4551,(0,8):C.GC_4550,(0,12):C.GC_4553,(0,11):C.GC_4558})

V_1024 = Vertex(name = 'V_1024',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.Z, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVS170 ],
                couplings = {(0,0):C.GC_3666})

V_1025 = Vertex(name = 'V_1025',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.Z, P.G0, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSS132, L.VVVVSS319, L.VVVVSS324, L.VVVVSS343, L.VVVVSS344, L.VVVVSS349, L.VVVVSS351, L.VVVVSS391, L.VVVVSS453, L.VVVVSS479, L.VVVVSS484, L.VVVVSS498, L.VVVVSS518, L.VVVVSS526, L.VVVVSS603, L.VVVVSS610, L.VVVVSS635, L.VVVVSS647, L.VVVVSS669, L.VVVVSS706, L.VVVVSS717, L.VVVVSS738, L.VVVVSS759, L.VVVVSS777 ],
                couplings = {(0,14):C.GC_2529,(0,10):C.GC_2636,(0,9):C.GC_2641,(0,12):C.GC_2977,(0,13):C.GC_2971,(0,1):C.GC_2629,(0,23):C.GC_2617,(0,20):C.GC_2633,(0,16):C.GC_2956,(0,19):C.GC_2966,(0,11):C.GC_2622,(0,2):C.GC_2965,(0,6):C.GC_2959,(0,5):C.GC_3789,(0,15):C.GC_3786,(0,7):C.GC_2779,(0,3):C.GC_4683,(0,4):C.GC_4675,(0,0):C.GC_4658,(0,18):C.GC_4653,(0,22):C.GC_4664,(0,21):C.GC_4666,(0,8):C.GC_4450,(0,17):C.GC_4449})

V_1026 = Vertex(name = 'V_1026',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.Z, P.G0, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSS603 ],
                couplings = {(0,0):C.GC_3689})

V_1027 = Vertex(name = 'V_1027',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.Z, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSS132, L.VVVVSS324, L.VVVVSS325, L.VVVVSS343, L.VVVVSS344, L.VVVVSS349, L.VVVVSS351, L.VVVVSS391, L.VVVVSS453, L.VVVVSS499, L.VVVVSS510, L.VVVVSS518, L.VVVVSS526, L.VVVVSS529, L.VVVVSS603, L.VVVVSS610, L.VVVVSS635, L.VVVVSS647, L.VVVVSS669, L.VVVVSS706, L.VVVVSS722, L.VVVVSS733, L.VVVVSS738, L.VVVVSS759 ],
                couplings = {(0,14):C.GC_2530,(0,13):C.GC_2635,(0,10):C.GC_2643,(0,11):C.GC_2975,(0,12):C.GC_2973,(0,2):C.GC_2628,(0,21):C.GC_2619,(0,20):C.GC_2631,(0,16):C.GC_2954,(0,19):C.GC_2968,(0,9):C.GC_2623,(0,1):C.GC_2963,(0,6):C.GC_2958,(0,5):C.GC_3788,(0,15):C.GC_3784,(0,7):C.GC_2780,(0,3):C.GC_4680,(0,4):C.GC_4673,(0,0):C.GC_4656,(0,18):C.GC_4651,(0,23):C.GC_4660,(0,22):C.GC_4670,(0,8):C.GC_4452,(0,17):C.GC_4447})

V_1028 = Vertex(name = 'V_1028',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.Z, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSS603 ],
                couplings = {(0,0):C.GC_3692})

V_1029 = Vertex(name = 'V_1029',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.G0, P.G0, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVSSS110, L.VVVSSS149, L.VVVSSS183, L.VVVSSS3, L.VVVSSS32, L.VVVSSS57 ],
                couplings = {(0,3):C.GC_576,(0,5):C.GC_570,(0,4):C.GC_1073,(0,2):C.GC_1410,(0,0):C.GC_905,(0,1):C.GC_895})

V_1030 = Vertex(name = 'V_1030',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.G0, P.G0, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVSSS3 ],
                couplings = {(0,0):C.GC_912})

V_1031 = Vertex(name = 'V_1031',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.G0, P.G0, P.G0, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS158, L.VVVSSSS160, L.VVVSSSS177, L.VVVSSSS203, L.VVVSSSS3, L.VVVSSSS327, L.VVVSSSS82 ],
                couplings = {(0,4):C.GC_713,(0,1):C.GC_1020,(0,5):C.GC_1014,(0,6):C.GC_712,(0,3):C.GC_1105,(0,0):C.GC_1128,(0,2):C.GC_1131})

V_1032 = Vertex(name = 'V_1032',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.G0, P.G0, P.G0, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS3 ],
                couplings = {(0,0):C.GC_1040})

V_1033 = Vertex(name = 'V_1033',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.G__minus__, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVSSS152, L.VVVSSS190, L.VVVSSS3, L.VVVSSS36, L.VVVSSS57, L.VVVSSS82 ],
                couplings = {(0,2):C.GC_577,(0,4):C.GC_571,(0,3):C.GC_1065,(0,1):C.GC_1411,(0,5):C.GC_907,(0,0):C.GC_895})

V_1034 = Vertex(name = 'V_1034',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.G__minus__, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVSSS3 ],
                couplings = {(0,0):C.GC_913})

V_1035 = Vertex(name = 'V_1035',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.G0, P.G__minus__, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS124, L.VVVSSSS257, L.VVVSSSS276, L.VVVSSSS280, L.VVVSSSS3, L.VVVSSSS82, L.VVVSSSS96 ],
                couplings = {(0,4):C.GC_721,(0,0):C.GC_1021,(0,3):C.GC_1016,(0,5):C.GC_705,(0,2):C.GC_1117,(0,6):C.GC_1114,(0,1):C.GC_1130})

V_1036 = Vertex(name = 'V_1036',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.G0, P.G__minus__, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS3 ],
                couplings = {(0,0):C.GC_1039})

V_1037 = Vertex(name = 'V_1037',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.G0, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSS198, L.VVVSSS3, L.VVVSSS57, L.VVVSSS74, L.VVVSSS90, L.VVVSSS95, L.VVVSSS99 ],
                couplings = {(0,1):C.GC_574,(0,2):C.GC_573,(0,5):C.GC_1064,(0,3):C.GC_1078,(0,4):C.GC_1079,(0,0):C.GC_903,(0,6):C.GC_899})

V_1038 = Vertex(name = 'V_1038',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.G0, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSS3 ],
                couplings = {(0,0):C.GC_915})

V_1039 = Vertex(name = 'V_1039',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.G0, P.G0, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS151, L.VVVSSSS189, L.VVVSSSS242, L.VVVSSSS251, L.VVVSSSS283, L.VVVSSSS3, L.VVVSSSS82 ],
                couplings = {(0,5):C.GC_716,(0,1):C.GC_1024,(0,4):C.GC_1009,(0,6):C.GC_707,(0,3):C.GC_1121,(0,0):C.GC_1109,(0,2):C.GC_1132})

V_1040 = Vertex(name = 'V_1040',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.G0, P.G0, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS3 ],
                couplings = {(0,0):C.GC_1035})

V_1041 = Vertex(name = 'V_1041',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.G__minus__, P.G__plus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS103, L.VVVSSSS157, L.VVVSSSS198, L.VVVSSSS204, L.VVVSSSS3, L.VVVSSSS311, L.VVVSSSS82 ],
                couplings = {(0,4):C.GC_717,(0,0):C.GC_1026,(0,5):C.GC_1009,(0,6):C.GC_708,(0,3):C.GC_1108,(0,1):C.GC_1123,(0,2):C.GC_1132})

V_1042 = Vertex(name = 'V_1042',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.G__minus__, P.G__plus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS3 ],
                couplings = {(0,0):C.GC_1036})

V_1043 = Vertex(name = 'V_1043',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.G__plus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSS165, L.VVVSSS168, L.VVVSSS169, L.VVVSSS178, L.VVVSSS3, L.VVVSSS57, L.VVVSSS69 ],
                couplings = {(0,4):C.GC_580,(0,5):C.GC_572,(0,1):C.GC_1076,(0,6):C.GC_1066,(0,0):C.GC_1080,(0,3):C.GC_909,(0,2):C.GC_893})

V_1044 = Vertex(name = 'V_1044',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.G__plus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSS3 ],
                couplings = {(0,0):C.GC_914})

V_1045 = Vertex(name = 'V_1045',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.G0, P.G__plus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS111, L.VVVSSSS117, L.VVVSSSS121, L.VVVSSSS3, L.VVVSSSS343, L.VVVSSSS82, L.VVVSSSS99 ],
                couplings = {(0,3):C.GC_714,(0,4):C.GC_1022,(0,2):C.GC_1014,(0,5):C.GC_710,(0,1):C.GC_1105,(0,6):C.GC_1126,(0,0):C.GC_1131})

V_1046 = Vertex(name = 'V_1046',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.G0, P.G__plus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS3 ],
                couplings = {(0,0):C.GC_1038})

V_1047 = Vertex(name = 'V_1047',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.G__plus__, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS273, L.VVVSSSS278, L.VVVSSSS279, L.VVVSSSS296, L.VVVSSSS3, L.VVVSSSS82, L.VVVSSSS95 ],
                couplings = {(0,4):C.GC_720,(0,3):C.GC_1028,(0,2):C.GC_1007,(0,5):C.GC_709,(0,1):C.GC_1124,(0,6):C.GC_1109,(0,0):C.GC_1134})

V_1048 = Vertex(name = 'V_1048',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.G__plus__, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS3 ],
                couplings = {(0,0):C.GC_1037})

V_1049 = Vertex(name = 'V_1049',
                particles = [ P.W__minus__, P.W__minus__, P.Z, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVSS175, L.VVVSS250, L.VVVSS278, L.VVVSS279, L.VVVSS285, L.VVVSS3 ],
                couplings = {(0,5):C.GC_2447,(0,3):C.GC_2537,(0,1):C.GC_2444,(0,0):C.GC_2705,(0,2):C.GC_3675,(0,4):C.GC_3681})

V_1050 = Vertex(name = 'V_1050',
                particles = [ P.W__minus__, P.W__minus__, P.Z, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVSS250, L.VVVSS3 ],
                couplings = {(0,1):C.GC_3524,(0,0):C.GC_2887})

V_1051 = Vertex(name = 'V_1051',
                particles = [ P.W__minus__, P.W__minus__, P.Z, P.G0, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVSSS133, L.VVVSSS151, L.VVVSSS158, L.VVVSSS175, L.VVVSSS3, L.VVVSSS57, L.VVVSSS75 ],
                couplings = {(0,4):C.GC_2416,(0,5):C.GC_2415,(0,1):C.GC_2714,(0,2):C.GC_3701,(0,6):C.GC_2721,(0,0):C.GC_3706,(0,3):C.GC_2596})

V_1052 = Vertex(name = 'V_1052',
                particles = [ P.W__minus__, P.W__minus__, P.Z, P.G0, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVSSS3, L.VVVSSS57 ],
                couplings = {(0,0):C.GC_3575,(0,1):C.GC_2932})

V_1053 = Vertex(name = 'V_1053',
                particles = [ P.W__minus__, P.W__minus__, P.Z, P.G0, P.G0, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS118, L.VVVSSSS228, L.VVVSSSS254, L.VVVSSSS264, L.VVVSSSS292, L.VVVSSSS3, L.VVVSSSS82 ],
                couplings = {(0,5):C.GC_2493,(0,4):C.GC_2695,(0,6):C.GC_2489,(0,2):C.GC_2740,(0,3):C.GC_3736,(0,0):C.GC_2744,(0,1):C.GC_3743})

V_1054 = Vertex(name = 'V_1054',
                particles = [ P.W__minus__, P.W__minus__, P.Z, P.G0, P.G0, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS3, L.VVVSSSS82 ],
                couplings = {(0,0):C.GC_3658,(0,1):C.GC_3009})

V_1055 = Vertex(name = 'V_1055',
                particles = [ P.W__minus__, P.W__minus__, P.Z, P.G__plus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSS141, L.VVVSSS148, L.VVVSSS161, L.VVVSSS162, L.VVVSSS3, L.VVVSSS57, L.VVVSSS96 ],
                couplings = {(0,4):C.GC_2419,(0,5):C.GC_2413,(0,1):C.GC_2719,(0,2):C.GC_3698,(0,6):C.GC_2717,(0,0):C.GC_3704,(0,3):C.GC_2599})

V_1056 = Vertex(name = 'V_1056',
                particles = [ P.W__minus__, P.W__minus__, P.Z, P.G__plus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSS3, L.VVVSSS57 ],
                couplings = {(0,0):C.GC_3578,(0,1):C.GC_2930})

V_1057 = Vertex(name = 'V_1057',
                particles = [ P.W__minus__, P.W__minus__, P.Z, P.G0, P.G__plus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS152, L.VVVSSSS253, L.VVVSSSS270, L.VVVSSSS285, L.VVVSSSS3, L.VVVSSSS308, L.VVVSSSS82 ],
                couplings = {(0,4):C.GC_2491,(0,2):C.GC_2693,(0,6):C.GC_2490,(0,0):C.GC_2738,(0,3):C.GC_3739,(0,1):C.GC_2745,(0,5):C.GC_3747})

V_1058 = Vertex(name = 'V_1058',
                particles = [ P.W__minus__, P.W__minus__, P.Z, P.G0, P.G__plus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS3, L.VVVSSSS82 ],
                couplings = {(0,0):C.GC_3656,(0,1):C.GC_3011})

V_1059 = Vertex(name = 'V_1059',
                particles = [ P.W__minus__, P.W__minus__, P.Z, P.G__plus__, P.G__plus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS118, L.VVVSSSS228, L.VVVSSSS254, L.VVVSSSS264, L.VVVSSSS265, L.VVVSSSS3, L.VVVSSSS82 ],
                couplings = {(0,5):C.GC_2494,(0,4):C.GC_2696,(0,6):C.GC_2488,(0,2):C.GC_2743,(0,3):C.GC_3736,(0,0):C.GC_2741,(0,1):C.GC_3743})

V_1060 = Vertex(name = 'V_1060',
                particles = [ P.W__minus__, P.W__minus__, P.Z, P.G__plus__, P.G__plus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS3, L.VVVSSSS82 ],
                couplings = {(0,0):C.GC_3659,(0,1):C.GC_3008})

V_1061 = Vertex(name = 'V_1061',
                particles = [ P.A, P.W__plus__, P.G0, P.G0, P.G__minus__, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSS1 ],
                couplings = {(0,0):C.GC_4521})

V_1062 = Vertex(name = 'V_1062',
                particles = [ P.A, P.W__plus__, P.G0, P.G0, P.G0, P.G__minus__, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSSS1 ],
                couplings = {(0,0):C.GC_4605})

V_1063 = Vertex(name = 'V_1063',
                particles = [ P.A, P.W__plus__, P.G__minus__, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSS1 ],
                couplings = {(0,0):C.GC_4523})

V_1064 = Vertex(name = 'V_1064',
                particles = [ P.A, P.W__plus__, P.G0, P.G__minus__, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSSS1 ],
                couplings = {(0,0):C.GC_4606})

V_1065 = Vertex(name = 'V_1065',
                particles = [ P.A, P.W__plus__, P.G0, P.G__minus__, P.G__minus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSS1 ],
                couplings = {(0,0):C.GC_4524})

V_1066 = Vertex(name = 'V_1066',
                particles = [ P.A, P.W__plus__, P.G0, P.G0, P.G__minus__, P.G__minus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSSS1 ],
                couplings = {(0,0):C.GC_4601})

V_1067 = Vertex(name = 'V_1067',
                particles = [ P.A, P.W__plus__, P.G__minus__, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSSS1 ],
                couplings = {(0,0):C.GC_4603})

V_1068 = Vertex(name = 'V_1068',
                particles = [ P.A, P.W__plus__, P.G__minus__, P.G__minus__, P.G__plus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSS1 ],
                couplings = {(0,0):C.GC_4522})

V_1069 = Vertex(name = 'V_1069',
                particles = [ P.A, P.W__plus__, P.G0, P.G__minus__, P.G__minus__, P.G__plus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSSS1 ],
                couplings = {(0,0):C.GC_4604})

V_1070 = Vertex(name = 'V_1070',
                particles = [ P.A, P.W__plus__, P.G__minus__, P.G__minus__, P.G__plus__, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSSS1 ],
                couplings = {(0,0):C.GC_4602})

V_1071 = Vertex(name = 'V_1071',
                particles = [ P.A, P.A, P.A, P.W__plus__, P.G__minus__, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS13 ],
                couplings = {(0,0):C.GC_7301})

V_1072 = Vertex(name = 'V_1072',
                particles = [ P.A, P.A, P.A, P.W__plus__, P.G0, P.G__minus__, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS13 ],
                couplings = {(0,0):C.GC_7319})

V_1073 = Vertex(name = 'V_1073',
                particles = [ P.A, P.A, P.A, P.W__plus__, P.G__minus__, P.G__minus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS13 ],
                couplings = {(0,0):C.GC_7315})

V_1074 = Vertex(name = 'V_1074',
                particles = [ P.W__plus__, P.G0, P.G0, P.G0, P.G0, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VSSSSS8 ],
                couplings = {(0,0):C.GC_556})

V_1075 = Vertex(name = 'V_1075',
                particles = [ P.W__plus__, P.G0, P.G0, P.G__minus__, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VSSSSS12 ],
                couplings = {(0,0):C.GC_554})

V_1076 = Vertex(name = 'V_1076',
                particles = [ P.W__plus__, P.G0, P.G0, P.G0, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VSSSSS9 ],
                couplings = {(0,0):C.GC_552})

V_1077 = Vertex(name = 'V_1077',
                particles = [ P.W__plus__, P.G0, P.G0, P.G0, P.G0, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VSSSSSS9 ],
                couplings = {(0,0):C.GC_680})

V_1078 = Vertex(name = 'V_1078',
                particles = [ P.W__plus__, P.G0, P.G__minus__, P.G__minus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VSSSSS16 ],
                couplings = {(0,0):C.GC_551})

V_1079 = Vertex(name = 'V_1079',
                particles = [ P.W__plus__, P.G0, P.G0, P.G__minus__, P.G__minus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VSSSSSS11 ],
                couplings = {(0,0):C.GC_678})

V_1080 = Vertex(name = 'V_1080',
                particles = [ P.W__plus__, P.G0, P.G0, P.G__minus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VSSSSS13 ],
                couplings = {(0,0):C.GC_556})

V_1081 = Vertex(name = 'V_1081',
                particles = [ P.W__plus__, P.G0, P.G0, P.G0, P.G__minus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VSSSSSS14 ],
                couplings = {(0,0):C.GC_676})

V_1082 = Vertex(name = 'V_1082',
                particles = [ P.W__plus__, P.G0, P.G__minus__, P.G__minus__, P.G__plus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VSSSSSS23 ],
                couplings = {(0,0):C.GC_675})

V_1083 = Vertex(name = 'V_1083',
                particles = [ P.W__plus__, P.G0, P.G__minus__, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VSSSSS18 ],
                couplings = {(0,0):C.GC_550})

V_1084 = Vertex(name = 'V_1084',
                particles = [ P.W__plus__, P.G0, P.G0, P.G__minus__, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VSSSSSS20 ],
                couplings = {(0,0):C.GC_680})

V_1085 = Vertex(name = 'V_1085',
                particles = [ P.W__plus__, P.G0, P.G__minus__, P.H, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VSSSSSS26 ],
                couplings = {(0,0):C.GC_673})

V_1086 = Vertex(name = 'V_1086',
                particles = [ P.ghA, P.ghWp__tilde__, P.W__plus__ ],
                color = [ '1' ],
                lorentz = [ L.UUV1 ],
                couplings = {(0,0):C.GC_5288})

V_1087 = Vertex(name = 'V_1087',
                particles = [ P.ghA, P.ghWp__tilde__, P.W__plus__ ],
                color = [ '1' ],
                lorentz = [ L.UUV1 ],
                couplings = {(0,0):C.GC_5181})

V_1088 = Vertex(name = 'V_1088',
                particles = [ P.ghA, P.ghWp__tilde__, P.W__plus__ ],
                color = [ '1' ],
                lorentz = [ L.UUV1 ],
                couplings = {(0,0):C.GC_5296})

V_1089 = Vertex(name = 'V_1089',
                particles = [ P.ghWm, P.ghZ__tilde__, P.W__plus__ ],
                color = [ '1' ],
                lorentz = [ L.UUV1 ],
                couplings = {(0,0):C.GC_2386})

V_1090 = Vertex(name = 'V_1090',
                particles = [ P.ghWm, P.ghZ__tilde__, P.W__plus__ ],
                color = [ '1' ],
                lorentz = [ L.UUV1 ],
                couplings = {(0,0):C.GC_5703})

V_1091 = Vertex(name = 'V_1091',
                particles = [ P.ghWm, P.ghZ__tilde__, P.W__plus__ ],
                color = [ '1' ],
                lorentz = [ L.UUV1 ],
                couplings = {(0,0):C.GC_5734})

V_1092 = Vertex(name = 'V_1092',
                particles = [ P.ghWm, P.ghA__tilde__, P.W__plus__ ],
                color = [ '1' ],
                lorentz = [ L.UUV1 ],
                couplings = {(0,0):C.GC_5180})

V_1093 = Vertex(name = 'V_1093',
                particles = [ P.ghWm, P.ghA__tilde__, P.W__plus__ ],
                color = [ '1' ],
                lorentz = [ L.UUV1 ],
                couplings = {(0,0):C.GC_5297})

V_1094 = Vertex(name = 'V_1094',
                particles = [ P.ghWm, P.ghA__tilde__, P.W__plus__ ],
                color = [ '1' ],
                lorentz = [ L.UUV1 ],
                couplings = {(0,0):C.GC_5289})

V_1095 = Vertex(name = 'V_1095',
                particles = [ P.ghZ, P.ghWp__tilde__, P.W__plus__ ],
                color = [ '1' ],
                lorentz = [ L.UUV1 ],
                couplings = {(0,0):C.GC_2385})

V_1096 = Vertex(name = 'V_1096',
                particles = [ P.ghZ, P.ghWp__tilde__, P.W__plus__ ],
                color = [ '1' ],
                lorentz = [ L.UUV1 ],
                couplings = {(0,0):C.GC_2390})

V_1097 = Vertex(name = 'V_1097',
                particles = [ P.ghZ, P.ghWp__tilde__, P.W__plus__ ],
                color = [ '1' ],
                lorentz = [ L.UUV1 ],
                couplings = {(0,0):C.GC_1944})

V_1098 = Vertex(name = 'V_1098',
                particles = [ P.W__plus__, P.G0, P.G0, P.G0, P.G__minus__, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VSSSSSS13 ],
                couplings = {(0,0):C.GC_683})

V_1099 = Vertex(name = 'V_1099',
                particles = [ P.W__plus__, P.G__minus__, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VSSSSS10 ],
                couplings = {(0,0):C.GC_557})

V_1100 = Vertex(name = 'V_1100',
                particles = [ P.W__plus__, P.G0, P.G__minus__, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VSSSSSS15 ],
                couplings = {(0,0):C.GC_684})

V_1101 = Vertex(name = 'V_1101',
                particles = [ P.W__plus__, P.G__minus__, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VSSSSSS6 ],
                couplings = {(0,0):C.GC_681})

V_1102 = Vertex(name = 'V_1102',
                particles = [ P.W__plus__, P.G__minus__, P.G__minus__, P.G__plus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VSSSSS3 ],
                couplings = {(0,0):C.GC_556})

V_1103 = Vertex(name = 'V_1103',
                particles = [ P.W__plus__, P.G__minus__, P.G__minus__, P.G__plus__, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VSSSSSS2 ],
                couplings = {(0,0):C.GC_680})

V_1104 = Vertex(name = 'V_1104',
                particles = [ P.A, P.A, P.A, P.W__plus__, P.G0, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSS424, L.VVVVSS428, L.VVVVSS442, L.VVVVSS443, L.VVVVSS445, L.VVVVSS480, L.VVVVSS481, L.VVVVSS619, L.VVVVSS624, L.VVVVSS636, L.VVVVSS684, L.VVVVSS685 ],
                couplings = {(0,3):C.GC_2040,(0,4):C.GC_2042,(0,1):C.GC_2033,(0,11):C.GC_2036,(0,8):C.GC_2032,(0,10):C.GC_7215,(0,2):C.GC_1964,(0,6):C.GC_7217,(0,5):C.GC_7219,(0,9):C.GC_7203,(0,0):C.GC_7209,(0,7):C.GC_7208})

V_1105 = Vertex(name = 'V_1105',
                particles = [ P.A, P.A, P.A, P.W__plus__, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSS424, L.VVVVSS429, L.VVVVSS442, L.VVVVSS444, L.VVVVSS446, L.VVVVSS515, L.VVVVSS516, L.VVVVSS619, L.VVVVSS626, L.VVVVSS636, L.VVVVSS723, L.VVVVSS724 ],
                couplings = {(0,3):C.GC_2039,(0,4):C.GC_2043,(0,1):C.GC_2034,(0,11):C.GC_2037,(0,8):C.GC_2031,(0,10):C.GC_7214,(0,2):C.GC_1965,(0,6):C.GC_7218,(0,5):C.GC_7220,(0,9):C.GC_7204,(0,0):C.GC_7210,(0,7):C.GC_7207})

V_1106 = Vertex(name = 'V_1106',
                particles = [ P.A, P.A, P.A, P.W__plus__, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVS183, L.VVVVS193, L.VVVVS71, L.VVVVS82, L.VVVVS83, L.VVVVS85 ],
                couplings = {(0,4):C.GC_1927,(0,3):C.GC_2015,(0,5):C.GC_2017,(0,1):C.GC_7180,(0,2):C.GC_7182,(0,0):C.GC_7181})

V_1107 = Vertex(name = 'V_1107',
                particles = [ P.A, P.W__minus__, P.W__plus__, P.W__plus__, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVS15, L.VVVVS151, L.VVVVS159, L.VVVVS17, L.VVVVS170, L.VVVVS177, L.VVVVS18, L.VVVVS196, L.VVVVS219, L.VVVVS222, L.VVVVS226, L.VVVVS230, L.VVVVS54, L.VVVVS58, L.VVVVS64, L.VVVVS65, L.VVVVS88 ],
                couplings = {(0,16):C.GC_2403,(0,7):C.GC_2401,(0,6):C.GC_2588,(0,3):C.GC_2587,(0,15):C.GC_2580,(0,9):C.GC_2584,(0,5):C.GC_2578,(0,8):C.GC_2582,(0,4):C.GC_4509,(0,2):C.GC_4535,(0,1):C.GC_4538,(0,0):C.GC_4531,(0,11):C.GC_4528,(0,10):C.GC_4533,(0,13):C.GC_4530,(0,12):C.GC_7292,(0,14):C.GC_4804})

V_1108 = Vertex(name = 'V_1108',
                particles = [ P.A, P.W__minus__, P.W__plus__, P.W__plus__, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVS170 ],
                couplings = {(0,0):C.GC_7230})

V_1109 = Vertex(name = 'V_1109',
                particles = [ P.A, P.W__minus__, P.W__plus__, P.W__plus__, P.G0, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSS207, L.VVVVSS208, L.VVVVSS209, L.VVVVSS349, L.VVVVSS356, L.VVVVSS391, L.VVVVSS410, L.VVVVSS448, L.VVVVSS558, L.VVVVSS570, L.VVVVSS603, L.VVVVSS613, L.VVVVSS640, L.VVVVSS693, L.VVVVSS697, L.VVVVSS700, L.VVVVSS703 ],
                couplings = {(0,1):C.GC_2681,(0,2):C.GC_2679,(0,6):C.GC_2665,(0,13):C.GC_2673,(0,11):C.GC_2662,(0,14):C.GC_2670,(0,7):C.GC_2469,(0,12):C.GC_2464,(0,10):C.GC_4500,(0,9):C.GC_4629,(0,8):C.GC_4634,(0,0):C.GC_4622,(0,16):C.GC_4614,(0,15):C.GC_4623,(0,4):C.GC_4615,(0,3):C.GC_7295,(0,5):C.GC_4807})

V_1110 = Vertex(name = 'V_1110',
                particles = [ P.A, P.W__minus__, P.W__plus__, P.W__plus__, P.G0, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSS603 ],
                couplings = {(0,0):C.GC_7242})

V_1111 = Vertex(name = 'V_1111',
                particles = [ P.A, P.W__minus__, P.W__plus__, P.W__plus__, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSS203, L.VVVVSS208, L.VVVVSS209, L.VVVVSS349, L.VVVVSS353, L.VVVVSS391, L.VVVVSS410, L.VVVVSS448, L.VVVVSS571, L.VVVVSS594, L.VVVVSS603, L.VVVVSS613, L.VVVVSS640, L.VVVVSS693, L.VVVVSS697, L.VVVVSS715, L.VVVVSS731 ],
                couplings = {(0,1):C.GC_2682,(0,2):C.GC_2680,(0,6):C.GC_2666,(0,13):C.GC_2674,(0,11):C.GC_2660,(0,14):C.GC_2669,(0,7):C.GC_2467,(0,12):C.GC_2463,(0,10):C.GC_4498,(0,8):C.GC_4627,(0,9):C.GC_4633,(0,0):C.GC_4620,(0,15):C.GC_4613,(0,16):C.GC_4624,(0,4):C.GC_4617,(0,3):C.GC_7294,(0,5):C.GC_4806})

V_1112 = Vertex(name = 'V_1112',
                particles = [ P.A, P.W__minus__, P.W__plus__, P.W__plus__, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSS603 ],
                couplings = {(0,0):C.GC_7238})

V_1113 = Vertex(name = 'V_1113',
                particles = [ P.W__minus__, P.W__plus__, P.W__plus__, P.G0, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVSS100, L.VVVSS13, L.VVVSS211, L.VVVSS215, L.VVVSS251, L.VVVSS255, L.VVVSS256, L.VVVSS264, L.VVVSS288, L.VVVSS300, L.VVVSS315, L.VVVSS327, L.VVVSS336 ],
                couplings = {(0,1):C.GC_645,(0,5):C.GC_814,(0,8):C.GC_812,(0,4):C.GC_642,(0,11):C.GC_698,(0,10):C.GC_700,(0,9):C.GC_685,(0,12):C.GC_696,(0,0):C.GC_691,(0,3):C.GC_688,(0,7):C.GC_1053,(0,2):C.GC_1057,(0,6):C.GC_1052})

V_1114 = Vertex(name = 'V_1114',
                particles = [ P.W__minus__, P.W__plus__, P.W__plus__, P.G0, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVSS13 ],
                couplings = {(0,0):C.GC_817})

V_1115 = Vertex(name = 'V_1115',
                particles = [ P.W__minus__, P.W__plus__, P.W__plus__, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVS105, L.VVVS116, L.VVVS128, L.VVVS129, L.VVVS13, L.VVVS146, L.VVVS147, L.VVVS44, L.VVVS95, L.VVVS96 ],
                couplings = {(0,6):C.GC_567,(0,5):C.GC_568,(0,2):C.GC_560,(0,3):C.GC_565,(0,7):C.GC_564,(0,9):C.GC_562,(0,8):C.GC_824,(0,0):C.GC_827,(0,4):C.GC_628,(0,1):C.GC_627})

V_1116 = Vertex(name = 'V_1116',
                particles = [ P.W__minus__, P.W__plus__, P.W__plus__, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVS105, L.VVVS116, L.VVVS13, L.VVVS95 ],
                couplings = {(0,3):C.GC_1406,(0,0):C.GC_1042,(0,2):C.GC_830,(0,1):C.GC_828})

V_1117 = Vertex(name = 'V_1117',
                particles = [ P.W__minus__, P.W__plus__, P.W__plus__, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSS100, L.VVVSS13, L.VVVSS212, L.VVVSS215, L.VVVSS251, L.VVVSS254, L.VVVSS268, L.VVVSS281, L.VVVSS287, L.VVVSS300, L.VVVSS315, L.VVVSS327, L.VVVSS336 ],
                couplings = {(0,1):C.GC_646,(0,8):C.GC_815,(0,7):C.GC_811,(0,4):C.GC_643,(0,11):C.GC_699,(0,10):C.GC_702,(0,9):C.GC_687,(0,12):C.GC_695,(0,0):C.GC_693,(0,3):C.GC_690,(0,6):C.GC_1051,(0,2):C.GC_1059,(0,5):C.GC_1054})

V_1118 = Vertex(name = 'V_1118',
                particles = [ P.W__minus__, P.W__plus__, P.W__plus__, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSS13 ],
                couplings = {(0,0):C.GC_818})

V_1119 = Vertex(name = 'V_1119',
                particles = [ P.A, P.A, P.W__plus__, P.Z, P.G0, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSS323, L.VVVVSS350, L.VVVVSS422, L.VVVVSS430, L.VVVVSS431, L.VVVVSS438, L.VVVVSS453, L.VVVVSS455, L.VVVVSS456, L.VVVVSS457, L.VVVVSS458, L.VVVVSS459, L.VVVVSS478, L.VVVVSS482, L.VVVVSS483, L.VVVVSS517, L.VVVVSS518, L.VVVVSS525, L.VVVVSS527, L.VVVVSS603, L.VVVVSS615, L.VVVVSS617, L.VVVVSS621, L.VVVVSS625, L.VVVVSS647, L.VVVVSS652, L.VVVVSS658, L.VVVVSS690, L.VVVVSS691, L.VVVVSS706, L.VVVVSS707, L.VVVVSS708, L.VVVVSS709 ],
                couplings = {(0,17):C.GC_2636,(0,15):C.GC_2641,(0,18):C.GC_2972,(0,16):C.GC_2977,(0,13):C.GC_2087,(0,14):C.GC_2089,(0,26):C.GC_2020,(0,25):C.GC_2616,(0,1):C.GC_2956,(0,31):C.GC_2633,(0,29):C.GC_2966,(0,27):C.GC_6179,(0,3):C.GC_2024,(0,5):C.GC_2629,(0,22):C.GC_2021,(0,20):C.GC_2625,(0,2):C.GC_2964,(0,21):C.GC_2957,(0,19):C.GC_3689,(0,9):C.GC_4111,(0,8):C.GC_4114,(0,11):C.GC_4675,(0,10):C.GC_4682,(0,4):C.GC_4106,(0,0):C.GC_4659,(0,28):C.GC_4107,(0,32):C.GC_4663,(0,30):C.GC_4667,(0,23):C.GC_4103,(0,12):C.GC_4648,(0,7):C.GC_4081,(0,6):C.GC_4450,(0,24):C.GC_4449})

V_1120 = Vertex(name = 'V_1120',
                particles = [ P.A, P.A, P.W__plus__, P.Z, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSS328, L.VVVVSS350, L.VVVVSS422, L.VVVVSS430, L.VVVVSS432, L.VVVVSS438, L.VVVVSS453, L.VVVVSS455, L.VVVVSS460, L.VVVVSS461, L.VVVVSS462, L.VVVVSS463, L.VVVVSS503, L.VVVVSS508, L.VVVVSS509, L.VVVVSS518, L.VVVVSS519, L.VVVVSS523, L.VVVVSS524, L.VVVVSS603, L.VVVVSS615, L.VVVVSS617, L.VVVVSS621, L.VVVVSS628, L.VVVVSS647, L.VVVVSS652, L.VVVVSS658, L.VVVVSS706, L.VVVVSS725, L.VVVVSS775, L.VVVVSS776, L.VVVVSS778, L.VVVVSS779 ],
                couplings = {(0,14):C.GC_2639,(0,13):C.GC_2642,(0,16):C.GC_2970,(0,15):C.GC_2976,(0,17):C.GC_2088,(0,18):C.GC_2090,(0,26):C.GC_2019,(0,25):C.GC_2620,(0,1):C.GC_2955,(0,31):C.GC_2632,(0,27):C.GC_2967,(0,29):C.GC_6181,(0,3):C.GC_2025,(0,5):C.GC_2628,(0,22):C.GC_2022,(0,20):C.GC_2624,(0,2):C.GC_2962,(0,21):C.GC_2958,(0,19):C.GC_3690,(0,11):C.GC_4113,(0,8):C.GC_4115,(0,10):C.GC_4673,(0,9):C.GC_4679,(0,0):C.GC_4656,(0,4):C.GC_4105,(0,30):C.GC_4108,(0,32):C.GC_4661,(0,28):C.GC_4668,(0,12):C.GC_4650,(0,23):C.GC_4102,(0,7):C.GC_4080,(0,6):C.GC_4451,(0,24):C.GC_4448})

V_1121 = Vertex(name = 'V_1121',
                particles = [ P.A, P.A, P.W__plus__, P.Z, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVS100, L.VVVVS101, L.VVVVS102, L.VVVVS103, L.VVVVS132, L.VVVVS134, L.VVVVS170, L.VVVVS179, L.VVVVS181, L.VVVVS185, L.VVVVS203, L.VVVVS206, L.VVVVS209, L.VVVVS233, L.VVVVS234, L.VVVVS235, L.VVVVS34, L.VVVVS55, L.VVVVS60, L.VVVVS69, L.VVVVS73, L.VVVVS78, L.VVVVS96, L.VVVVS99 ],
                couplings = {(0,6):C.GC_3664,(0,5):C.GC_3569,(0,4):C.GC_3571,(0,12):C.GC_6166,(0,11):C.GC_2556,(0,17):C.GC_2904,(0,13):C.GC_3568,(0,20):C.GC_6165,(0,21):C.GC_2560,(0,9):C.GC_6163,(0,7):C.GC_2558,(0,19):C.GC_2906,(0,8):C.GC_2905,(0,1):C.GC_4075,(0,22):C.GC_4397,(0,10):C.GC_4396,(0,0):C.GC_4088,(0,23):C.GC_4089,(0,3):C.GC_4559,(0,2):C.GC_4561,(0,16):C.GC_4551,(0,15):C.GC_4554,(0,14):C.GC_4556,(0,18):C.GC_4549})

V_1122 = Vertex(name = 'V_1122',
                particles = [ P.A, P.W__plus__, P.Z, P.Z, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVS110, L.VVVVS111, L.VVVVS156, L.VVVVS157, L.VVVVS165, L.VVVVS166, L.VVVVS167, L.VVVVS168, L.VVVVS170, L.VVVVS186, L.VVVVS195, L.VVVVS196, L.VVVVS197, L.VVVVS207, L.VVVVS208, L.VVVVS212, L.VVVVS218, L.VVVVS220, L.VVVVS223, L.VVVVS225, L.VVVVS28, L.VVVVS29, L.VVVVS32, L.VVVVS54, L.VVVVS57, L.VVVVS64, L.VVVVS66, L.VVVVS74, L.VVVVS90, L.VVVVS93 ],
                couplings = {(0,1):C.GC_2070,(0,0):C.GC_2404,(0,11):C.GC_2400,(0,2):C.GC_2589,(0,4):C.GC_2921,(0,29):C.GC_2082,(0,28):C.GC_2083,(0,6):C.GC_2586,(0,5):C.GC_2920,(0,26):C.GC_2581,(0,27):C.GC_2915,(0,18):C.GC_2585,(0,13):C.GC_2918,(0,12):C.GC_7174,(0,19):C.GC_2582,(0,14):C.GC_2917,(0,21):C.GC_7176,(0,15):C.GC_7175,(0,16):C.GC_2579,(0,9):C.GC_2914,(0,8):C.GC_7231,(0,3):C.GC_4535,(0,20):C.GC_4843,(0,7):C.GC_4537,(0,10):C.GC_4527,(0,17):C.GC_4534,(0,22):C.GC_4531,(0,24):C.GC_4529,(0,23):C.GC_7345,(0,25):C.GC_4882})

V_1123 = Vertex(name = 'V_1123',
                particles = [ P.A, P.W__plus__, P.Z, P.Z, P.G0, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSS317, L.VVVVSS318, L.VVVVSS320, L.VVVVSS326, L.VVVVSS349, L.VVVVSS352, L.VVVVSS391, L.VVVVSS416, L.VVVVSS421, L.VVVVSS473, L.VVVVSS474, L.VVVVSS485, L.VVVVSS487, L.VVVVSS488, L.VVVVSS491, L.VVVVSS566, L.VVVVSS568, L.VVVVSS585, L.VVVVSS586, L.VVVVSS588, L.VVVVSS591, L.VVVVSS603, L.VVVVSS623, L.VVVVSS639, L.VVVVSS640, L.VVVVSS641, L.VVVVSS655, L.VVVVSS657, L.VVVVSS663, L.VVVVSS665, L.VVVVSS677, L.VVVVSS686, L.VVVVSS687, L.VVVVSS692, L.VVVVSS694, L.VVVVSS698 ],
                couplings = {(0,15):C.GC_2684,(0,17):C.GC_2993,(0,14):C.GC_2103,(0,11):C.GC_2105,(0,19):C.GC_2679,(0,18):C.GC_2991,(0,2):C.GC_2096,(0,8):C.GC_2668,(0,7):C.GC_2981,(0,34):C.GC_2676,(0,26):C.GC_2987,(0,32):C.GC_2101,(0,35):C.GC_2671,(0,27):C.GC_2985,(0,29):C.GC_2095,(0,30):C.GC_2658,(0,31):C.GC_6172,(0,22):C.GC_2980,(0,10):C.GC_2075,(0,9):C.GC_2465,(0,24):C.GC_2461,(0,16):C.GC_4629,(0,0):C.GC_4849,(0,20):C.GC_4631,(0,13):C.GC_4094,(0,12):C.GC_4098,(0,25):C.GC_7189,(0,23):C.GC_4611,(0,33):C.GC_4626,(0,1):C.GC_7193,(0,28):C.GC_7192,(0,3):C.GC_4619,(0,5):C.GC_4615,(0,4):C.GC_7348,(0,6):C.GC_4885,(0,21):C.GC_7241})

V_1124 = Vertex(name = 'V_1124',
                particles = [ P.A, P.W__plus__, P.Z, P.Z, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSS317, L.VVVVSS318, L.VVVVSS321, L.VVVVSS326, L.VVVVSS349, L.VVVVSS352, L.VVVVSS391, L.VVVVSS414, L.VVVVSS433, L.VVVVSS473, L.VVVVSS474, L.VVVVSS542, L.VVVVSS544, L.VVVVSS557, L.VVVVSS564, L.VVVVSS586, L.VVVVSS589, L.VVVVSS590, L.VVVVSS591, L.VVVVSS600, L.VVVVSS602, L.VVVVSS603, L.VVVVSS622, L.VVVVSS639, L.VVVVSS640, L.VVVVSS641, L.VVVVSS656, L.VVVVSS657, L.VVVVSS663, L.VVVVSS667, L.VVVVSS679, L.VVVVSS692, L.VVVVSS729, L.VVVVSS747, L.VVVVSS769, L.VVVVSS770 ],
                couplings = {(0,12):C.GC_2683,(0,13):C.GC_2994,(0,19):C.GC_2104,(0,11):C.GC_2106,(0,20):C.GC_2677,(0,15):C.GC_2992,(0,7):C.GC_2667,(0,8):C.GC_2982,(0,2):C.GC_2097,(0,33):C.GC_2675,(0,26):C.GC_2988,(0,35):C.GC_2100,(0,32):C.GC_2669,(0,27):C.GC_2986,(0,29):C.GC_2094,(0,30):C.GC_2661,(0,34):C.GC_6173,(0,22):C.GC_2979,(0,10):C.GC_2074,(0,9):C.GC_2468,(0,24):C.GC_2462,(0,14):C.GC_4627,(0,0):C.GC_4850,(0,18):C.GC_4632,(0,17):C.GC_4093,(0,16):C.GC_4097,(0,25):C.GC_7188,(0,23):C.GC_4612,(0,31):C.GC_4625,(0,1):C.GC_7194,(0,28):C.GC_7191,(0,3):C.GC_4620,(0,5):C.GC_4616,(0,4):C.GC_7347,(0,6):C.GC_4884,(0,21):C.GC_7239})

V_1125 = Vertex(name = 'V_1125',
                particles = [ P.W__minus__, P.W__plus__, P.G0, P.G0, P.G0, P.G0, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSSS1 ],
                couplings = {(0,0):C.GC_956})

V_1126 = Vertex(name = 'V_1126',
                particles = [ P.W__minus__, P.W__plus__, P.G0, P.G0, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSSS1 ],
                couplings = {(0,0):C.GC_954})

V_1127 = Vertex(name = 'V_1127',
                particles = [ P.W__minus__, P.W__plus__, P.G0, P.G0, P.G__minus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSS1 ],
                couplings = {(0,0):C.GC_863})

V_1128 = Vertex(name = 'V_1128',
                particles = [ P.W__minus__, P.W__plus__, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSS1 ],
                couplings = {(0,0):C.GC_864})

V_1129 = Vertex(name = 'V_1129',
                particles = [ P.W__minus__, P.W__plus__, P.G0, P.G0, P.G__minus__, P.G__plus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSSS1 ],
                couplings = {(0,0):C.GC_953})

V_1130 = Vertex(name = 'V_1130',
                particles = [ P.W__minus__, P.W__plus__, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSSS1 ],
                couplings = {(0,0):C.GC_954})

V_1131 = Vertex(name = 'V_1131',
                particles = [ P.W__minus__, P.W__plus__, P.G__minus__, P.G__plus__, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSS1 ],
                couplings = {(0,0):C.GC_865})

V_1132 = Vertex(name = 'V_1132',
                particles = [ P.W__minus__, P.W__plus__, P.G__minus__, P.G__plus__, P.H, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSSS1 ],
                couplings = {(0,0):C.GC_956})

V_1133 = Vertex(name = 'V_1133',
                particles = [ P.A, P.A, P.W__minus__, P.W__plus__, P.G0, P.G0, P.G0, P.G0 ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_1727})

V_1134 = Vertex(name = 'V_1134',
                particles = [ P.A, P.A, P.W__minus__, P.W__plus__, P.G0, P.G0, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS16, L.VVVVSSSS3, L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_1898,(0,1):C.GC_1892,(0,2):C.GC_1730})

V_1135 = Vertex(name = 'V_1135',
                particles = [ P.A, P.A, P.W__minus__, P.W__plus__, P.G0, P.G0, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_1864})

V_1136 = Vertex(name = 'V_1136',
                particles = [ P.A, P.A, P.W__minus__, P.W__plus__, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS3, L.VVVVSSSS4, L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_1894,(0,1):C.GC_1902,(0,2):C.GC_1726})

V_1137 = Vertex(name = 'V_1137',
                particles = [ P.A, P.A, P.W__minus__, P.W__plus__, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_1863})

V_1138 = Vertex(name = 'V_1138',
                particles = [ P.A, P.A, P.W__minus__, P.W__plus__, P.G0, P.G0, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS5 ],
                couplings = {(0,0):C.GC_1650})

V_1139 = Vertex(name = 'V_1139',
                particles = [ P.A, P.A, P.W__minus__, P.W__plus__, P.G__minus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS16, L.VVVVSSS3, L.VVVVSSS5 ],
                couplings = {(0,2):C.GC_1654,(0,0):C.GC_1883,(0,1):C.GC_1879})

V_1140 = Vertex(name = 'V_1140',
                particles = [ P.A, P.A, P.W__minus__, P.W__plus__, P.G__minus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS5 ],
                couplings = {(0,0):C.GC_1805})

V_1141 = Vertex(name = 'V_1141',
                particles = [ P.A, P.A, P.W__minus__, P.W__plus__, P.G0, P.G0, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_1725})

V_1142 = Vertex(name = 'V_1142',
                particles = [ P.A, P.A, P.W__minus__, P.W__plus__, P.G__minus__, P.G__plus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS16, L.VVVVSSSS3, L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_1898,(0,1):C.GC_1892,(0,2):C.GC_1730})

V_1143 = Vertex(name = 'V_1143',
                particles = [ P.A, P.A, P.W__minus__, P.W__plus__, P.G__minus__, P.G__plus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_1864})

V_1144 = Vertex(name = 'V_1144',
                particles = [ P.A, P.A, P.W__minus__, P.W__plus__, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS5 ],
                couplings = {(0,0):C.GC_1651})

V_1145 = Vertex(name = 'V_1145',
                particles = [ P.A, P.A, P.W__minus__, P.W__plus__, P.H, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_1727})

V_1146 = Vertex(name = 'V_1146',
                particles = [ P.A, P.A, P.A, P.A, P.W__minus__, P.W__plus__, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVSS24 ],
                couplings = {(0,0):C.GC_1909})

V_1147 = Vertex(name = 'V_1147',
                particles = [ P.A, P.W__minus__, P.W__plus__, P.G0, P.G0, P.G0 ],
                color = [ '1' ],
                lorentz = [ L.VVVSSS119, L.VVVSSS25, L.VVVSSS46 ],
                couplings = {(0,1):C.GC_4582,(0,0):C.GC_4566,(0,2):C.GC_4576})

V_1148 = Vertex(name = 'V_1148',
                particles = [ P.A, P.W__minus__, P.W__plus__, P.G0, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVSSS10, L.VVVSSS40, L.VVVSSS42, L.VVVSSS55, L.VVVSSS65 ],
                couplings = {(0,2):C.GC_7243,(0,3):C.GC_4722,(0,0):C.GC_4583,(0,4):C.GC_4566,(0,1):C.GC_4570})

V_1149 = Vertex(name = 'V_1149',
                particles = [ P.A, P.W__minus__, P.W__plus__, P.G0, P.G0, P.G0, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS14, L.VVVSSSS350, L.VVVSSSS76 ],
                couplings = {(0,0):C.GC_4707,(0,1):C.GC_4687,(0,2):C.GC_4700})

V_1150 = Vertex(name = 'V_1150',
                particles = [ P.A, P.W__minus__, P.W__plus__, P.G0, P.G__minus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS15, L.VVVSSSS206, L.VVVSSSS330, L.VVVSSSS66, L.VVVSSSS74 ],
                couplings = {(0,0):C.GC_4708,(0,2):C.GC_4687,(0,4):C.GC_4692,(0,3):C.GC_7259,(0,1):C.GC_4754})

V_1151 = Vertex(name = 'V_1151',
                particles = [ P.A, P.W__minus__, P.W__plus__, P.G0, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSS17, L.VVVSSS179, L.VVVSSS51 ],
                couplings = {(0,0):C.GC_4584,(0,1):C.GC_4567,(0,2):C.GC_4577})

V_1152 = Vertex(name = 'V_1152',
                particles = [ P.A, P.W__minus__, P.W__plus__, P.G0, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS22, L.VVVSSSS297, L.VVVSSSS72 ],
                couplings = {(0,0):C.GC_4709,(0,1):C.GC_4688,(0,2):C.GC_4701})

V_1153 = Vertex(name = 'V_1153',
                particles = [ P.A, P.A, P.A, P.A, P.W__minus__, P.W__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVV2, L.VVVVVV30, L.VVVVVV33, L.VVVVVV64, L.VVVVVV85 ],
                couplings = {(0,0):C.GC_1743,(0,1):C.GC_1749,(0,2):C.GC_1740,(0,3):C.GC_1745,(0,4):C.GC_1736})

V_1154 = Vertex(name = 'V_1154',
                particles = [ P.W__minus__, P.W__plus__, P.W__plus__, P.G0, P.G0, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVSSS112, L.VVVSSS115, L.VVVSSS53, L.VVVSSS56, L.VVVSSS59, L.VVVSSS7 ],
                couplings = {(0,5):C.GC_575,(0,4):C.GC_570,(0,2):C.GC_1412,(0,3):C.GC_1074,(0,0):C.GC_904,(0,1):C.GC_896})

V_1155 = Vertex(name = 'V_1155',
                particles = [ P.W__minus__, P.W__plus__, P.W__plus__, P.G0, P.G0, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVSSS7 ],
                couplings = {(0,0):C.GC_912})

V_1156 = Vertex(name = 'V_1156',
                particles = [ P.W__minus__, P.W__plus__, P.W__plus__, P.G0, P.G0, P.G0, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS149, L.VVVSSSS166, L.VVVSSSS170, L.VVVSSSS350, L.VVVSSSS64, L.VVVSSSS7, L.VVVSSSS84 ],
                couplings = {(0,5):C.GC_713,(0,1):C.GC_1020,(0,3):C.GC_1011,(0,6):C.GC_704,(0,2):C.GC_1118,(0,4):C.GC_1131,(0,0):C.GC_1115})

V_1157 = Vertex(name = 'V_1157',
                particles = [ P.W__minus__, P.W__plus__, P.W__plus__, P.G0, P.G0, P.G0, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS7 ],
                couplings = {(0,0):C.GC_1032})

V_1158 = Vertex(name = 'V_1158',
                particles = [ P.W__minus__, P.W__plus__, P.W__plus__, P.G__minus__, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVSSS101, L.VVVSSS202, L.VVVSSS45, L.VVVSSS59, L.VVVSSS7, L.VVVSSS86 ],
                couplings = {(0,4):C.GC_578,(0,3):C.GC_571,(0,2):C.GC_1413,(0,0):C.GC_1066,(0,1):C.GC_906,(0,5):C.GC_896})

V_1159 = Vertex(name = 'V_1159',
                particles = [ P.W__minus__, P.W__plus__, P.W__plus__, P.G__minus__, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVSSS7 ],
                couplings = {(0,0):C.GC_913})

V_1160 = Vertex(name = 'V_1160',
                particles = [ P.W__minus__, P.W__plus__, P.W__plus__, P.G0, P.G__minus__, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS139, L.VVVSSSS161, L.VVVSSSS347, L.VVVSSSS63, L.VVVSSSS7, L.VVVSSSS84, L.VVVSSSS90 ],
                couplings = {(0,4):C.GC_721,(0,2):C.GC_1021,(0,1):C.GC_1013,(0,5):C.GC_711,(0,0):C.GC_1105,(0,3):C.GC_1130,(0,6):C.GC_1125})

V_1161 = Vertex(name = 'V_1161',
                particles = [ P.W__minus__, P.W__plus__, P.W__plus__, P.G0, P.G__minus__, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS7 ],
                couplings = {(0,0):C.GC_1033})

V_1162 = Vertex(name = 'V_1162',
                particles = [ P.W__minus__, P.W__plus__, P.W__plus__, P.G0, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSS107, L.VVVSSS203, L.VVVSSS43, L.VVVSSS59, L.VVVSSS66, L.VVVSSS7, L.VVVSSS85 ],
                couplings = {(0,5):C.GC_574,(0,3):C.GC_569,(0,6):C.GC_1071,(0,2):C.GC_1079,(0,4):C.GC_1070,(0,1):C.GC_903,(0,0):C.GC_897})

V_1163 = Vertex(name = 'V_1163',
                particles = [ P.W__minus__, P.W__plus__, P.W__plus__, P.G0, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSS7 ],
                couplings = {(0,0):C.GC_911})

V_1164 = Vertex(name = 'V_1164',
                particles = [ P.W__minus__, P.W__plus__, P.W__plus__, P.G0, P.G0, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS131, L.VVVSSSS174, L.VVVSSSS180, L.VVVSSSS334, L.VVVSSSS69, L.VVVSSSS7, L.VVVSSSS84 ],
                couplings = {(0,5):C.GC_715,(0,1):C.GC_1023,(0,3):C.GC_1010,(0,6):C.GC_707,(0,2):C.GC_1107,(0,4):C.GC_1133,(0,0):C.GC_1119})

V_1165 = Vertex(name = 'V_1165',
                particles = [ P.W__minus__, P.W__plus__, P.W__plus__, P.G0, P.G0, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS7 ],
                couplings = {(0,0):C.GC_1035})

V_1166 = Vertex(name = 'V_1166',
                particles = [ P.W__minus__, P.W__plus__, P.W__plus__, P.G__minus__, P.G__minus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS107, L.VVVSSSS169, L.VVVSSSS171, L.VVVSSSS348, L.VVVSSSS65, L.VVVSSSS7, L.VVVSSSS84 ],
                couplings = {(0,5):C.GC_718,(0,1):C.GC_1025,(0,3):C.GC_1010,(0,6):C.GC_708,(0,2):C.GC_1120,(0,4):C.GC_1133,(0,0):C.GC_1108})

V_1167 = Vertex(name = 'V_1167',
                particles = [ P.W__minus__, P.W__plus__, P.W__plus__, P.G__minus__, P.G__minus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS7 ],
                couplings = {(0,0):C.GC_1036})

V_1168 = Vertex(name = 'V_1168',
                particles = [ P.W__minus__, P.W__plus__, P.W__plus__, P.G__minus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSS145, L.VVVSSS179, L.VVVSSS196, L.VVVSSS50, L.VVVSSS59, L.VVVSSS64, L.VVVSSS7 ],
                couplings = {(0,6):C.GC_579,(0,4):C.GC_572,(0,0):C.GC_1068,(0,3):C.GC_1081,(0,5):C.GC_1072,(0,2):C.GC_908,(0,1):C.GC_894})

V_1169 = Vertex(name = 'V_1169',
                particles = [ P.W__minus__, P.W__plus__, P.W__plus__, P.G__minus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSS7 ],
                couplings = {(0,0):C.GC_914})

V_1170 = Vertex(name = 'V_1170',
                particles = [ P.W__minus__, P.W__plus__, P.W__plus__, P.G0, P.G__minus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS105, L.VVVSSSS125, L.VVVSSSS349, L.VVVSSSS61, L.VVVSSSS7, L.VVVSSSS84, L.VVVSSSS92 ],
                couplings = {(0,4):C.GC_714,(0,2):C.GC_1022,(0,1):C.GC_1011,(0,5):C.GC_706,(0,0):C.GC_1118,(0,3):C.GC_1131,(0,6):C.GC_1113})

V_1171 = Vertex(name = 'V_1171',
                particles = [ P.W__minus__, P.W__plus__, P.W__plus__, P.G0, P.G__minus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS7 ],
                couplings = {(0,0):C.GC_1034})

V_1172 = Vertex(name = 'V_1172',
                particles = [ P.W__minus__, P.W__plus__, P.W__plus__, P.G__minus__, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS249, L.VVVSSSS297, L.VVVSSSS326, L.VVVSSSS7, L.VVVSSSS71, L.VVVSSSS84, L.VVVSSSS89 ],
                couplings = {(0,3):C.GC_719,(0,2):C.GC_1027,(0,1):C.GC_1008,(0,5):C.GC_709,(0,0):C.GC_1111,(0,4):C.GC_1135,(0,6):C.GC_1119})

V_1173 = Vertex(name = 'V_1173',
                particles = [ P.W__minus__, P.W__plus__, P.W__plus__, P.G__minus__, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS7 ],
                couplings = {(0,0):C.GC_1037})

V_1174 = Vertex(name = 'V_1174',
                particles = [ P.W__minus__, P.W__plus__, P.Z, P.G0, P.G0, P.G0, P.G0 ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS224, L.VVVSSSS262, L.VVVSSSS263, L.VVVSSSS28, L.VVVSSSS293, L.VVVSSSS3, L.VVVSSSS37, L.VVVSSSS4, L.VVVSSSS82, L.VVVSSSS83, L.VVVSSSS85, L.VVVSSSS9 ],
                couplings = {(0,3):C.GC_3005,(0,5):C.GC_3014,(0,6):C.GC_2691,(0,2):C.GC_2996,(0,8):C.GC_3010,(0,1):C.GC_2697,(0,4):C.GC_2686,(0,11):C.GC_2486,(0,7):C.GC_7130,(0,10):C.GC_2483,(0,9):C.GC_7127,(0,0):C.GC_3733})

V_1175 = Vertex(name = 'V_1175',
                particles = [ P.W__minus__, P.W__plus__, P.Z, P.G0, P.G0, P.G0, P.G0 ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS4, L.VVVSSSS83 ],
                couplings = {(0,0):C.GC_4588,(0,1):C.GC_4587})

V_1176 = Vertex(name = 'V_1176',
                particles = [ P.W__minus__, P.W__plus__, P.Z, P.G0, P.G0, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS138, L.VVVSSSS148, L.VVVSSSS167, L.VVVSSSS17, L.VVVSSSS188, L.VVVSSSS20, L.VVVSSSS210, L.VVVSSSS212, L.VVVSSSS243, L.VVVSSSS291, L.VVVSSSS304, L.VVVSSSS320, L.VVVSSSS39, L.VVVSSSS8, L.VVVSSSS85, L.VVVSSSS88, L.VVVSSSS9 ],
                couplings = {(0,12):C.GC_2690,(0,3):C.GC_3003,(0,5):C.GC_3012,(0,1):C.GC_2687,(0,9):C.GC_2696,(0,11):C.GC_2998,(0,10):C.GC_3007,(0,16):C.GC_2484,(0,13):C.GC_2492,(0,14):C.GC_2481,(0,15):C.GC_2487,(0,6):C.GC_2739,(0,7):C.GC_2746,(0,8):C.GC_3039,(0,2):C.GC_3040,(0,4):C.GC_3041,(0,0):C.GC_2743})

V_1177 = Vertex(name = 'V_1177',
                particles = [ P.W__minus__, P.W__plus__, P.Z, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS108, L.VVVSSSS119, L.VVVSSSS215, L.VVVSSSS26, L.VVVSSSS263, L.VVVSSSS28, L.VVVSSSS287, L.VVVSSSS3, L.VVVSSSS36, L.VVVSSSS4, L.VVVSSSS50, L.VVVSSSS82, L.VVVSSSS83, L.VVVSSSS85, L.VVVSSSS9 ],
                couplings = {(0,8):C.GC_2692,(0,3):C.GC_2702,(0,5):C.GC_3001,(0,7):C.GC_3013,(0,1):C.GC_2685,(0,6):C.GC_2698,(0,4):C.GC_3000,(0,11):C.GC_3009,(0,14):C.GC_2485,(0,9):C.GC_7129,(0,13):C.GC_2482,(0,12):C.GC_7126,(0,10):C.GC_3742,(0,2):C.GC_3734,(0,0):C.GC_3731})

V_1178 = Vertex(name = 'V_1178',
                particles = [ P.W__minus__, P.W__plus__, P.Z, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS4, L.VVVSSSS83 ],
                couplings = {(0,0):C.GC_4590,(0,1):C.GC_4585})

V_1179 = Vertex(name = 'V_1179',
                particles = [ P.W__minus__, P.W__plus__, P.Z, P.G0, P.G0, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSS132, L.VVVSSS156, L.VVVSSS157, L.VVVSSS176, L.VVVSSS21, L.VVVSSS27, L.VVVSSS3, L.VVVSSS4, L.VVVSSS57, L.VVVSSS58, L.VVVSSS60, L.VVVSSS9 ],
                couplings = {(0,11):C.GC_2410,(0,7):C.GC_6995,(0,10):C.GC_2408,(0,9):C.GC_6993,(0,0):C.GC_3695,(0,4):C.GC_2926,(0,6):C.GC_2933,(0,5):C.GC_2594,(0,2):C.GC_2923,(0,8):C.GC_2929,(0,1):C.GC_2597,(0,3):C.GC_2591})

V_1180 = Vertex(name = 'V_1180',
                particles = [ P.W__minus__, P.W__plus__, P.Z, P.G0, P.G0, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSS4, L.VVVSSS58 ],
                couplings = {(0,0):C.GC_4518,(0,1):C.GC_4515})

V_1181 = Vertex(name = 'V_1181',
                particles = [ P.W__minus__, P.W__plus__, P.Z, P.G__minus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSS100, L.VVVSSS12, L.VVVSSS128, L.VVVSSS15, L.VVVSSS150, L.VVVSSS171, L.VVVSSS172, L.VVVSSS173, L.VVVSSS184, L.VVVSSS185, L.VVVSSS28, L.VVVSSS60, L.VVVSSS63, L.VVVSSS71, L.VVVSSS8, L.VVVSSS9, L.VVVSSS91 ],
                couplings = {(0,15):C.GC_2410,(0,14):C.GC_2417,(0,11):C.GC_2408,(0,12):C.GC_2412,(0,4):C.GC_2715,(0,6):C.GC_2722,(0,16):C.GC_3022,(0,2):C.GC_3023,(0,8):C.GC_3024,(0,13):C.GC_2719,(0,10):C.GC_2594,(0,3):C.GC_2925,(0,1):C.GC_2933,(0,5):C.GC_2591,(0,7):C.GC_2598,(0,9):C.GC_2924,(0,0):C.GC_2929})

V_1182 = Vertex(name = 'V_1182',
                particles = [ P.W__minus__, P.W__plus__, P.Z, P.G0, P.G0, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS224, L.VVVSSSS262, L.VVVSSSS263, L.VVVSSSS28, L.VVVSSSS293, L.VVVSSSS3, L.VVVSSSS37, L.VVVSSSS4, L.VVVSSSS82, L.VVVSSSS83, L.VVVSSSS85, L.VVVSSSS9 ],
                couplings = {(0,3):C.GC_3004,(0,5):C.GC_3012,(0,6):C.GC_2690,(0,2):C.GC_2997,(0,8):C.GC_3007,(0,1):C.GC_2694,(0,4):C.GC_2687,(0,11):C.GC_2484,(0,7):C.GC_7128,(0,10):C.GC_2481,(0,9):C.GC_7125,(0,0):C.GC_3732})

V_1183 = Vertex(name = 'V_1183',
                particles = [ P.W__minus__, P.W__plus__, P.Z, P.G0, P.G0, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS4, L.VVVSSSS83 ],
                couplings = {(0,0):C.GC_4589,(0,1):C.GC_4586})

V_1184 = Vertex(name = 'V_1184',
                particles = [ P.W__minus__, P.W__plus__, P.Z, P.G__minus__, P.G__plus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS10, L.VVVSSSS112, L.VVVSSSS122, L.VVVSSSS17, L.VVVSSSS222, L.VVVSSSS259, L.VVVSSSS288, L.VVVSSSS289, L.VVVSSSS291, L.VVVSSSS319, L.VVVSSSS320, L.VVVSSSS38, L.VVVSSSS8, L.VVVSSSS85, L.VVVSSSS88, L.VVVSSSS9, L.VVVSSSS97 ],
                couplings = {(0,11):C.GC_2690,(0,3):C.GC_3002,(0,0):C.GC_3012,(0,6):C.GC_2687,(0,8):C.GC_2695,(0,10):C.GC_2999,(0,2):C.GC_3007,(0,15):C.GC_2484,(0,12):C.GC_2492,(0,13):C.GC_2481,(0,14):C.GC_2487,(0,5):C.GC_2739,(0,7):C.GC_2746,(0,1):C.GC_3039,(0,4):C.GC_3040,(0,9):C.GC_3041,(0,16):C.GC_2743})

V_1185 = Vertex(name = 'V_1185',
                particles = [ P.W__minus__, P.W__plus__, P.Z, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSS132, L.VVVSSS156, L.VVVSSS157, L.VVVSSS176, L.VVVSSS21, L.VVVSSS27, L.VVVSSS3, L.VVVSSS4, L.VVVSSS57, L.VVVSSS58, L.VVVSSS60, L.VVVSSS9 ],
                couplings = {(0,11):C.GC_2411,(0,7):C.GC_6996,(0,10):C.GC_2409,(0,9):C.GC_6994,(0,0):C.GC_3696,(0,4):C.GC_2927,(0,6):C.GC_2934,(0,5):C.GC_2595,(0,2):C.GC_2922,(0,8):C.GC_2931,(0,1):C.GC_2600,(0,3):C.GC_2590})

V_1186 = Vertex(name = 'V_1186',
                particles = [ P.W__minus__, P.W__plus__, P.Z, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSS4, L.VVVSSS58 ],
                couplings = {(0,0):C.GC_4517,(0,1):C.GC_4516})

V_1187 = Vertex(name = 'V_1187',
                particles = [ P.W__minus__, P.W__plus__, P.Z, P.H, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS224, L.VVVSSSS262, L.VVVSSSS263, L.VVVSSSS28, L.VVVSSSS293, L.VVVSSSS3, L.VVVSSSS37, L.VVVSSSS4, L.VVVSSSS82, L.VVVSSSS83, L.VVVSSSS85, L.VVVSSSS9 ],
                couplings = {(0,3):C.GC_3005,(0,5):C.GC_3014,(0,6):C.GC_2691,(0,2):C.GC_2996,(0,8):C.GC_3010,(0,1):C.GC_2697,(0,4):C.GC_2686,(0,11):C.GC_2486,(0,7):C.GC_7130,(0,10):C.GC_2483,(0,9):C.GC_7127,(0,0):C.GC_3733})

V_1188 = Vertex(name = 'V_1188',
                particles = [ P.W__minus__, P.W__plus__, P.Z, P.H, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS4, L.VVVSSSS83 ],
                couplings = {(0,0):C.GC_4588,(0,1):C.GC_4587})

V_1189 = Vertex(name = 'V_1189',
                particles = [ P.A, P.A, P.A, P.W__minus__, P.W__plus__, P.Z ],
                color = [ '1' ],
                lorentz = [ L.VVVVVV27, L.VVVVVV29, L.VVVVVV40, L.VVVVVV42, L.VVVVVV5, L.VVVVVV6, L.VVVVVV60, L.VVVVVV65, L.VVVVVV66, L.VVVVVV80 ],
                couplings = {(0,5):C.GC_6682,(0,4):C.GC_4207,(0,2):C.GC_6684,(0,3):C.GC_4210,(0,7):C.GC_6681,(0,8):C.GC_4205,(0,6):C.GC_6683,(0,0):C.GC_4209,(0,9):C.GC_6680,(0,1):C.GC_4203})

V_1190 = Vertex(name = 'V_1190',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.Z ],
                color = [ '1' ],
                lorentz = [ L.VVVVV10, L.VVVVV121, L.VVVVV122, L.VVVVV123, L.VVVVV126, L.VVVVV133, L.VVVVV137, L.VVVVV22, L.VVVVV23, L.VVVVV58, L.VVVVV61, L.VVVVV65, L.VVVVV66, L.VVVVV7, L.VVVVV73, L.VVVVV91 ],
                couplings = {(0,10):C.GC_2527,(0,1):C.GC_2526,(0,12):C.GC_2712,(0,11):C.GC_3687,(0,9):C.GC_3021,(0,15):C.GC_2500,(0,13):C.GC_2496,(0,0):C.GC_2498,(0,14):C.GC_2499,(0,6):C.GC_2497,(0,8):C.GC_2709,(0,5):C.GC_2495,(0,2):C.GC_2707,(0,4):C.GC_2708,(0,7):C.GC_4714,(0,3):C.GC_7235})

V_1191 = Vertex(name = 'V_1191',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.Z ],
                color = [ '1' ],
                lorentz = [ L.VVVVV121, L.VVVVV61 ],
                couplings = {(0,1):C.GC_7171,(0,0):C.GC_7167})

V_1192 = Vertex(name = 'V_1192',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.Z ],
                color = [ '1' ],
                lorentz = [ L.VVVVV121 ],
                couplings = {(0,0):C.GC_3684})

V_1193 = Vertex(name = 'V_1193',
                particles = [ P.A, P.A, P.W__minus__, P.W__plus__, P.Z, P.Z ],
                color = [ '1' ],
                lorentz = [ L.VVVVVV11, L.VVVVVV12, L.VVVVVV20, L.VVVVVV23, L.VVVVVV31, L.VVVVVV32, L.VVVVVV34, L.VVVVVV36, L.VVVVVV45, L.VVVVVV46, L.VVVVVV54, L.VVVVVV55, L.VVVVVV63, L.VVVVVV73, L.VVVVVV8, L.VVVVVV89, L.VVVVVV90, L.VVVVVV92 ],
                couplings = {(0,1):C.GC_1741,(0,14):C.GC_2203,(0,0):C.GC_962,(0,9):C.GC_1748,(0,8):C.GC_2207,(0,2):C.GC_5044,(0,4):C.GC_964,(0,10):C.GC_1738,(0,3):C.GC_963,(0,12):C.GC_1744,(0,5):C.GC_2206,(0,15):C.GC_960,(0,17):C.GC_1735,(0,16):C.GC_2200,(0,11):C.GC_2201,(0,6):C.GC_961,(0,7):C.GC_5042,(0,13):C.GC_5043})

V_1194 = Vertex(name = 'V_1194',
                particles = [ P.W__minus__, P.W__plus__, P.Z, P.Z, P.Z ],
                color = [ '1' ],
                lorentz = [ L.VVVVV100, L.VVVVV118, L.VVVVV120, L.VVVVV128, L.VVVVV129, L.VVVVV130, L.VVVVV138, L.VVVVV143, L.VVVVV17, L.VVVVV18, L.VVVVV25, L.VVVVV26, L.VVVVV27, L.VVVVV59, L.VVVVV67, L.VVVVV70, L.VVVVV81, L.VVVVV86, L.VVVVV87, L.VVVVV98, L.VVVVV99 ],
                couplings = {(0,18):C.GC_2078,(0,5):C.GC_2077,(0,17):C.GC_2713,(0,9):C.GC_1958,(0,0):C.GC_1963,(0,8):C.GC_1960,(0,19):C.GC_1962,(0,20):C.GC_2076,(0,12):C.GC_1961,(0,7):C.GC_1957,(0,10):C.GC_2711,(0,6):C.GC_1959,(0,4):C.GC_3017,(0,15):C.GC_3019,(0,13):C.GC_3020,(0,2):C.GC_3018,(0,16):C.GC_7330,(0,11):C.GC_4714,(0,3):C.GC_7329,(0,14):C.GC_4865,(0,1):C.GC_7328})

V_1195 = Vertex(name = 'V_1195',
                particles = [ P.W__minus__, P.W__plus__, P.Z, P.Z, P.Z ],
                color = [ '1' ],
                lorentz = [ L.VVVVV130, L.VVVVV86, L.VVVVV87 ],
                couplings = {(0,2):C.GC_6158,(0,0):C.GC_6157,(0,1):C.GC_4083})

V_1196 = Vertex(name = 'V_1196',
                particles = [ P.W__minus__, P.W__plus__, P.Z, P.Z, P.Z ],
                color = [ '1' ],
                lorentz = [ L.VVVVV130 ],
                couplings = {(0,0):C.GC_2710})

V_1197 = Vertex(name = 'V_1197',
                particles = [ P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.G0, P.G0, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS12, L.VVVVSSS2, L.VVVVSSS7 ],
                couplings = {(0,2):C.GC_4540,(0,1):C.GC_4810,(0,0):C.GC_7298})

V_1198 = Vertex(name = 'V_1198',
                particles = [ P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.G0, P.G0, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS7 ],
                couplings = {(0,0):C.GC_7251})

V_1199 = Vertex(name = 'V_1199',
                particles = [ P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.G0, P.G0, P.G0, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS12, L.VVVVSSSS2, L.VVVVSSSS7 ],
                couplings = {(0,1):C.GC_4822,(0,0):C.GC_7309,(0,2):C.GC_4645})

V_1200 = Vertex(name = 'V_1200',
                particles = [ P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.G0, P.G0, P.G0, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS7 ],
                couplings = {(0,0):C.GC_7273})

V_1201 = Vertex(name = 'V_1201',
                particles = [ P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.G__minus__, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS12, L.VVVVSSS2, L.VVVVSSS7 ],
                couplings = {(0,2):C.GC_4542,(0,1):C.GC_4808,(0,0):C.GC_7299})

V_1202 = Vertex(name = 'V_1202',
                particles = [ P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.G__minus__, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS7 ],
                couplings = {(0,0):C.GC_7255})

V_1203 = Vertex(name = 'V_1203',
                particles = [ P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.G0, P.G__minus__, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS12, L.VVVVSSSS2, L.VVVVSSSS7 ],
                couplings = {(0,1):C.GC_4819,(0,0):C.GC_7310,(0,2):C.GC_4635})

V_1204 = Vertex(name = 'V_1204',
                particles = [ P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.G0, P.G__minus__, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS7 ],
                couplings = {(0,0):C.GC_7291})

V_1205 = Vertex(name = 'V_1205',
                particles = [ P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.G0, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS12, L.VVVVSSS2, L.VVVVSSS7 ],
                couplings = {(0,2):C.GC_4545,(0,1):C.GC_4809,(0,0):C.GC_7297})

V_1206 = Vertex(name = 'V_1206',
                particles = [ P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.G0, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS7 ],
                couplings = {(0,0):C.GC_7245})

V_1207 = Vertex(name = 'V_1207',
                particles = [ P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.G0, P.G0, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS12, L.VVVVSSSS2, L.VVVVSSSS7 ],
                couplings = {(0,1):C.GC_4824,(0,0):C.GC_7312,(0,2):C.GC_4638})

V_1208 = Vertex(name = 'V_1208',
                particles = [ P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.G0, P.G0, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS7 ],
                couplings = {(0,0):C.GC_7281})

V_1209 = Vertex(name = 'V_1209',
                particles = [ P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.G__minus__, P.G__plus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS12, L.VVVVSSSS2, L.VVVVSSSS7 ],
                couplings = {(0,1):C.GC_4820,(0,0):C.GC_7313,(0,2):C.GC_4640})

V_1210 = Vertex(name = 'V_1210',
                particles = [ P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.G__minus__, P.G__plus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS7 ],
                couplings = {(0,0):C.GC_7285})

V_1211 = Vertex(name = 'V_1211',
                particles = [ P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.G__plus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS12, L.VVVVSSS2, L.VVVVSSS7 ],
                couplings = {(0,2):C.GC_4543,(0,1):C.GC_4811,(0,0):C.GC_7300})

V_1212 = Vertex(name = 'V_1212',
                particles = [ P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.G__plus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS7 ],
                couplings = {(0,0):C.GC_7256})

V_1213 = Vertex(name = 'V_1213',
                particles = [ P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.G0, P.G__plus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS12, L.VVVVSSSS2, L.VVVVSSSS7 ],
                couplings = {(0,1):C.GC_4823,(0,0):C.GC_7311,(0,2):C.GC_4643})

V_1214 = Vertex(name = 'V_1214',
                particles = [ P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.G0, P.G__plus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS7 ],
                couplings = {(0,0):C.GC_7275})

V_1215 = Vertex(name = 'V_1215',
                particles = [ P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.G__plus__, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS12, L.VVVVSSSS2, L.VVVVSSSS7 ],
                couplings = {(0,1):C.GC_4825,(0,0):C.GC_7314,(0,2):C.GC_4641})

V_1216 = Vertex(name = 'V_1216',
                particles = [ P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.G__plus__, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS7 ],
                couplings = {(0,0):C.GC_7286})

V_1217 = Vertex(name = 'V_1217',
                particles = [ P.A, P.A, P.A, P.W__minus__, P.W__plus__, P.G0, P.G0 ],
                color = [ '1' ],
                lorentz = [ L.VVVVVSS43, L.VVVVVSS44, L.VVVVVSS66 ],
                couplings = {(0,1):C.GC_2027,(0,2):C.GC_7223,(0,0):C.GC_7224})

V_1218 = Vertex(name = 'V_1218',
                particles = [ P.A, P.A, P.A, P.W__minus__, P.W__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVVS32, L.VVVVVS33, L.VVVVVS53 ],
                couplings = {(0,1):C.GC_2013,(0,2):C.GC_7183,(0,0):C.GC_7184})

V_1219 = Vertex(name = 'V_1219',
                particles = [ P.A, P.A, P.A, P.W__minus__, P.W__plus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVVSS43, L.VVVVVSS44, L.VVVVVSS66 ],
                couplings = {(0,1):C.GC_2027,(0,2):C.GC_7223,(0,0):C.GC_7224})

V_1220 = Vertex(name = 'V_1220',
                particles = [ P.A, P.A, P.W__minus__, P.W__plus__, P.G0 ],
                color = [ '1' ],
                lorentz = [ L.VVVVS125, L.VVVVS227, L.VVVVS35, L.VVVVS38, L.VVVVS40, L.VVVVS43, L.VVVVS5, L.VVVVS61, L.VVVVS62 ],
                couplings = {(0,0):C.GC_1647,(0,5):C.GC_1649,(0,7):C.GC_1645,(0,3):C.GC_4178,(0,4):C.GC_4180,(0,6):C.GC_4164,(0,2):C.GC_4163,(0,1):C.GC_4169,(0,8):C.GC_4172})

V_1221 = Vertex(name = 'V_1221',
                particles = [ P.A, P.A, P.W__minus__, P.W__plus__, P.G0, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSS330, L.VVVVSS334, L.VVVVSS335, L.VVVVSS336, L.VVVVSS358, L.VVVVSS359, L.VVVVSS530, L.VVVVSS716, L.VVVVSS77 ],
                couplings = {(0,6):C.GC_1709,(0,2):C.GC_1724,(0,5):C.GC_1706,(0,3):C.GC_4256,(0,1):C.GC_4259,(0,8):C.GC_4239,(0,0):C.GC_4238,(0,7):C.GC_4246,(0,4):C.GC_4250})

V_1222 = Vertex(name = 'V_1222',
                particles = [ P.A, P.A, P.W__minus__, P.W__plus__, P.W__plus__, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVS136, L.VVVVVS137, L.VVVVVS138, L.VVVVVS14, L.VVVVVS19, L.VVVVVS193, L.VVVVVS195, L.VVVVVS31, L.VVVVVS57, L.VVVVVS62, L.VVVVVS8, L.VVVVVS80 ],
                couplings = {(0,7):C.GC_1788,(0,4):C.GC_1790,(0,3):C.GC_1786,(0,6):C.GC_1783,(0,8):C.GC_1784,(0,5):C.GC_1787,(0,10):C.GC_6801,(0,9):C.GC_4295,(0,0):C.GC_4293,(0,1):C.GC_4148,(0,2):C.GC_4301,(0,11):C.GC_4151})

V_1223 = Vertex(name = 'V_1223',
                particles = [ P.A, P.A, P.W__minus__, P.W__plus__, P.W__plus__, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVS137 ],
                couplings = {(0,0):C.GC_4299})

V_1224 = Vertex(name = 'V_1224',
                particles = [ P.A, P.A, P.W__minus__, P.W__plus__, P.W__plus__, P.G0, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVSS107, L.VVVVVSS17, L.VVVVVSS189, L.VVVVVSS190, L.VVVVVSS191, L.VVVVVSS25, L.VVVVVSS262, L.VVVVVSS264, L.VVVVVSS38, L.VVVVVSS71, L.VVVVVSS80, L.VVVVVSS9 ],
                couplings = {(0,8):C.GC_1836,(0,5):C.GC_1838,(0,1):C.GC_1831,(0,6):C.GC_1822,(0,9):C.GC_1825,(0,7):C.GC_1834,(0,0):C.GC_4220,(0,3):C.GC_4213,(0,11):C.GC_6846,(0,10):C.GC_4346,(0,2):C.GC_4344,(0,4):C.GC_4358})

V_1225 = Vertex(name = 'V_1225',
                particles = [ P.A, P.A, P.W__minus__, P.W__plus__, P.W__plus__, P.G0, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVSS190 ],
                couplings = {(0,0):C.GC_4354})

V_1226 = Vertex(name = 'V_1226',
                particles = [ P.A, P.A, P.W__minus__, P.W__plus__, P.W__plus__, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVVSS107, L.VVVVVSS17, L.VVVVVSS189, L.VVVVVSS190, L.VVVVVSS191, L.VVVVVSS25, L.VVVVVSS292, L.VVVVVSS302, L.VVVVVSS40, L.VVVVVSS70, L.VVVVVSS80, L.VVVVVSS9 ],
                couplings = {(0,8):C.GC_1835,(0,5):C.GC_1839,(0,1):C.GC_1830,(0,6):C.GC_1823,(0,9):C.GC_1826,(0,7):C.GC_1833,(0,0):C.GC_4219,(0,3):C.GC_4214,(0,11):C.GC_6841,(0,10):C.GC_4347,(0,2):C.GC_4342,(0,4):C.GC_4359})

V_1227 = Vertex(name = 'V_1227',
                particles = [ P.A, P.A, P.W__minus__, P.W__plus__, P.W__plus__, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVVSS190 ],
                couplings = {(0,0):C.GC_4353})

V_1228 = Vertex(name = 'V_1228',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.G0, P.G0 ],
                color = [ '1' ],
                lorentz = [ L.VVVVSS327, L.VVVVSS349, L.VVVVSS391, L.VVVVSS464, L.VVVVSS514, L.VVVVSS533, L.VVVVSS603, L.VVVVSS649, L.VVVVSS651, L.VVVVSS730, L.VVVVSS786 ],
                couplings = {(0,6):C.GC_795,(0,5):C.GC_983,(0,4):C.GC_990,(0,8):C.GC_972,(0,9):C.GC_980,(0,0):C.GC_979,(0,10):C.GC_976,(0,1):C.GC_1424,(0,2):C.GC_1183,(0,3):C.GC_723,(0,7):C.GC_722})

V_1229 = Vertex(name = 'V_1229',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.G0, P.G0 ],
                color = [ '1' ],
                lorentz = [ L.VVVVSS603 ],
                couplings = {(0,0):C.GC_1362})

V_1230 = Vertex(name = 'V_1230',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.G0, P.G0 ],
                color = [ '1' ],
                lorentz = [ L.VVVVSS603 ],
                couplings = {(0,0):C.GC_1061})

V_1231 = Vertex(name = 'V_1231',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSS327, L.VVVVSS349, L.VVVVSS391, L.VVVVSS464, L.VVVVSS507, L.VVVVSS534, L.VVVVSS603, L.VVVVSS649, L.VVVVSS651, L.VVVVSS699, L.VVVVSS786 ],
                couplings = {(0,6):C.GC_795,(0,5):C.GC_986,(0,4):C.GC_990,(0,8):C.GC_972,(0,9):C.GC_980,(0,0):C.GC_979,(0,10):C.GC_976,(0,1):C.GC_1425,(0,2):C.GC_1182,(0,3):C.GC_723,(0,7):C.GC_722})

V_1232 = Vertex(name = 'V_1232',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSS603 ],
                couplings = {(0,0):C.GC_1361})

V_1233 = Vertex(name = 'V_1233',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSS603 ],
                couplings = {(0,0):C.GC_1061})

V_1234 = Vertex(name = 'V_1234',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVS104, L.VVVVS129, L.VVVVS135, L.VVVVS170, L.VVVVS204, L.VVVVS205, L.VVVVS240, L.VVVVS33, L.VVVVS54, L.VVVVS59, L.VVVVS64 ],
                couplings = {(0,0):C.GC_582,(0,5):C.GC_581,(0,3):C.GC_789,(0,2):C.GC_880,(0,1):C.GC_885,(0,4):C.GC_871,(0,6):C.GC_877,(0,7):C.GC_876,(0,9):C.GC_873,(0,8):C.GC_1423,(0,10):C.GC_1181})

V_1235 = Vertex(name = 'V_1235',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVS170 ],
                couplings = {(0,0):C.GC_1377})

V_1236 = Vertex(name = 'V_1236',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVS170 ],
                couplings = {(0,0):C.GC_1043})

V_1237 = Vertex(name = 'V_1237',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSS327, L.VVVVSS349, L.VVVVSS391, L.VVVVSS464, L.VVVVSS514, L.VVVVSS533, L.VVVVSS603, L.VVVVSS649, L.VVVVSS651, L.VVVVSS730, L.VVVVSS786 ],
                couplings = {(0,6):C.GC_795,(0,5):C.GC_983,(0,4):C.GC_990,(0,8):C.GC_972,(0,9):C.GC_980,(0,0):C.GC_979,(0,10):C.GC_976,(0,1):C.GC_1426,(0,2):C.GC_1184,(0,3):C.GC_723,(0,7):C.GC_722})

V_1238 = Vertex(name = 'V_1238',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSS603 ],
                couplings = {(0,0):C.GC_1363})

V_1239 = Vertex(name = 'V_1239',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSS603 ],
                couplings = {(0,0):C.GC_1060})

V_1240 = Vertex(name = 'V_1240',
                particles = [ P.A, P.A, P.W__minus__, P.W__plus__, P.Z, P.G0, P.G0 ],
                color = [ '1' ],
                lorentz = [ L.VVVVVSS10, L.VVVVVSS192, L.VVVVVSS194, L.VVVVVSS195, L.VVVVVSS213, L.VVVVVSS238, L.VVVVVSS24, L.VVVVVSS287, L.VVVVVSS5, L.VVVVVSS83, L.VVVVVSS92, L.VVVVVSS94, L.VVVVVSS95, L.VVVVVSS96 ],
                couplings = {(0,10):C.GC_2029,(0,5):C.GC_6171,(0,9):C.GC_3754,(0,13):C.GC_3756,(0,7):C.GC_3752,(0,12):C.GC_4091,(0,6):C.GC_4609,(0,4):C.GC_4608,(0,8):C.GC_4801,(0,0):C.GC_4802,(0,1):C.GC_4796,(0,3):C.GC_4797,(0,11):C.GC_4792,(0,2):C.GC_4790})

V_1241 = Vertex(name = 'V_1241',
                particles = [ P.A, P.A, P.W__minus__, P.W__plus__, P.Z, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVSS105, L.VVVVVSS15, L.VVVVVSS16, L.VVVVVSS18, L.VVVVVSS19, L.VVVVVSS192, L.VVVVVSS21, L.VVVVVSS213, L.VVVVVSS238, L.VVVVVSS239, L.VVVVVSS24, L.VVVVVSS252, L.VVVVVSS266, L.VVVVVSS272, L.VVVVVSS276, L.VVVVVSS277, L.VVVVVSS279, L.VVVVVSS280, L.VVVVVSS287, L.VVVVVSS31, L.VVVVVSS5, L.VVVVVSS79, L.VVVVVSS85, L.VVVVVSS88, L.VVVVVSS89, L.VVVVVSS91, L.VVVVVSS92, L.VVVVVSS95, L.VVVVVSS96, L.VVVVVSS97 ],
                couplings = {(0,26):C.GC_2029,(0,8):C.GC_6169,(0,29):C.GC_2115,(0,0):C.GC_2765,(0,21):C.GC_2761,(0,22):C.GC_3054,(0,28):C.GC_3057,(0,2):C.GC_2112,(0,23):C.GC_2113,(0,3):C.GC_2753,(0,1):C.GC_3051,(0,13):C.GC_2109,(0,14):C.GC_2749,(0,17):C.GC_2756,(0,16):C.GC_3045,(0,18):C.GC_3052,(0,12):C.GC_2111,(0,15):C.GC_2751,(0,19):C.GC_3048,(0,27):C.GC_4092,(0,10):C.GC_4610,(0,7):C.GC_4607,(0,6):C.GC_4129,(0,4):C.GC_4803,(0,20):C.GC_4800,(0,24):C.GC_4128,(0,25):C.GC_4794,(0,5):C.GC_4795,(0,11):C.GC_4798,(0,9):C.GC_4791})

V_1242 = Vertex(name = 'V_1242',
                particles = [ P.A, P.A, P.W__minus__, P.W__plus__, P.Z, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVSS238 ],
                couplings = {(0,0):C.GC_6183})

V_1243 = Vertex(name = 'V_1243',
                particles = [ P.A, P.A, P.W__minus__, P.W__plus__, P.Z, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVVS139, L.VVVVVS141, L.VVVVVS142, L.VVVVVS156, L.VVVVVS179, L.VVVVVS18, L.VVVVVS203, L.VVVVVS4, L.VVVVVS65, L.VVVVVS69, L.VVVVVS71, L.VVVVVS72, L.VVVVVS73, L.VVVVVS9 ],
                couplings = {(0,8):C.GC_3712,(0,12):C.GC_3714,(0,6):C.GC_3710,(0,9):C.GC_2014,(0,4):C.GC_6160,(0,7):C.GC_4747,(0,13):C.GC_4748,(0,0):C.GC_4745,(0,2):C.GC_4746,(0,10):C.GC_4743,(0,1):C.GC_4742,(0,11):C.GC_4084,(0,5):C.GC_4526,(0,3):C.GC_4525})

V_1244 = Vertex(name = 'V_1244',
                particles = [ P.A, P.A, P.W__minus__, P.W__plus__, P.Z, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVVSS10, L.VVVVVSS192, L.VVVVVSS194, L.VVVVVSS195, L.VVVVVSS213, L.VVVVVSS238, L.VVVVVSS24, L.VVVVVSS287, L.VVVVVSS5, L.VVVVVSS83, L.VVVVVSS92, L.VVVVVSS94, L.VVVVVSS95, L.VVVVVSS96 ],
                couplings = {(0,10):C.GC_2029,(0,5):C.GC_6171,(0,9):C.GC_3754,(0,13):C.GC_3756,(0,7):C.GC_3752,(0,12):C.GC_4091,(0,6):C.GC_4609,(0,4):C.GC_4608,(0,8):C.GC_4801,(0,0):C.GC_4802,(0,1):C.GC_4796,(0,3):C.GC_4797,(0,11):C.GC_4792,(0,2):C.GC_4790})

V_1245 = Vertex(name = 'V_1245',
                particles = [ P.A, P.W__minus__, P.W__plus__, P.Z, P.G0 ],
                color = [ '1' ],
                lorentz = [ L.VVVVS116, L.VVVVS117, L.VVVVS137, L.VVVVS140, L.VVVVS141, L.VVVVS145, L.VVVVS160, L.VVVVS161, L.VVVVS164, L.VVVVS236, L.VVVVS24, L.VVVVS243, L.VVVVS244, L.VVVVS245, L.VVVVS246, L.VVVVS255, L.VVVVS3, L.VVVVS4, L.VVVVS7 ],
                couplings = {(0,7):C.GC_2179,(0,4):C.GC_2180,(0,6):C.GC_892,(0,3):C.GC_890,(0,16):C.GC_2176,(0,17):C.GC_887,(0,14):C.GC_889,(0,1):C.GC_2175,(0,12):C.GC_2177,(0,15):C.GC_2178,(0,0):C.GC_886,(0,11):C.GC_888,(0,8):C.GC_4153,(0,5):C.GC_4154,(0,2):C.GC_3875,(0,18):C.GC_3874,(0,9):C.GC_3872,(0,13):C.GC_4152,(0,10):C.GC_3873})

V_1246 = Vertex(name = 'V_1246',
                particles = [ P.A, P.W__minus__, P.W__plus__, P.Z, P.G0, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSS263, L.VVVVSS495, L.VVVVSS496, L.VVVVSS537, L.VVVVSS548, L.VVVVSS549, L.VVVVSS552, L.VVVVSS576, L.VVVVSS577, L.VVVVSS579, L.VVVVSS713, L.VVVVSS73, L.VVVVSS742, L.VVVVSS758, L.VVVVSS76, L.VVVVSS761, L.VVVVSS762, L.VVVVSS763, L.VVVVSS79 ],
                couplings = {(0,4):C.GC_2243,(0,7):C.GC_2245,(0,5):C.GC_1006,(0,8):C.GC_1003,(0,11):C.GC_2240,(0,14):C.GC_999,(0,15):C.GC_1001,(0,2):C.GC_2239,(0,17):C.GC_2241,(0,12):C.GC_2242,(0,1):C.GC_996,(0,13):C.GC_1000,(0,6):C.GC_4225,(0,9):C.GC_4226,(0,3):C.GC_3921,(0,18):C.GC_3920,(0,10):C.GC_3918,(0,16):C.GC_4224,(0,0):C.GC_3919})

V_1247 = Vertex(name = 'V_1247',
                particles = [ P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVS109, L.VVVVS115, L.VVVVS131, L.VVVVS133, L.VVVVS136, L.VVVVS137, L.VVVVS140, L.VVVVS153, L.VVVVS172, L.VVVVS173, L.VVVVS174, L.VVVVS182, L.VVVVS188, L.VVVVS191, L.VVVVS20, L.VVVVS200, L.VVVVS21, L.VVVVS231, L.VVVVS238, L.VVVVS243, L.VVVVS251, L.VVVVS257, L.VVVVS67, L.VVVVS75 ],
                couplings = {(0,8):C.GC_2542,(0,3):C.GC_2564,(0,2):C.GC_2566,(0,4):C.GC_2913,(0,5):C.GC_2910,(0,22):C.GC_2559,(0,21):C.GC_2554,(0,18):C.GC_2562,(0,13):C.GC_2904,(0,17):C.GC_2908,(0,12):C.GC_2558,(0,14):C.GC_2778,(0,9):C.GC_3781,(0,23):C.GC_2907,(0,11):C.GC_2905,(0,10):C.GC_3782,(0,0):C.GC_4397,(0,15):C.GC_4396,(0,7):C.GC_4563,(0,6):C.GC_4559,(0,16):C.GC_4552,(0,20):C.GC_4557,(0,19):C.GC_4554,(0,1):C.GC_4548})

V_1248 = Vertex(name = 'V_1248',
                particles = [ P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVS172 ],
                couplings = {(0,0):C.GC_3667})

V_1249 = Vertex(name = 'V_1249',
                particles = [ P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.G0, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSS242, L.VVVVSS258, L.VVVVSS434, L.VVVVSS435, L.VVVVSS472, L.VVVVSS493, L.VVVVSS520, L.VVVVSS521, L.VVVVSS536, L.VVVVSS537, L.VVVVSS560, L.VVVVSS577, L.VVVVSS605, L.VVVVSS606, L.VVVVSS608, L.VVVVSS618, L.VVVVSS630, L.VVVVSS634, L.VVVVSS644, L.VVVVSS704, L.VVVVSS721, L.VVVVSS752, L.VVVVSS758, L.VVVVSS766 ],
                couplings = {(0,12):C.GC_2528,(0,7):C.GC_2637,(0,6):C.GC_2641,(0,8):C.GC_2977,(0,9):C.GC_2971,(0,3):C.GC_2629,(0,23):C.GC_2617,(0,20):C.GC_2633,(0,17):C.GC_2956,(0,19):C.GC_2966,(0,16):C.GC_2622,(0,0):C.GC_2781,(0,13):C.GC_3783,(0,2):C.GC_2960,(0,15):C.GC_2957,(0,14):C.GC_3787,(0,10):C.GC_4683,(0,11):C.GC_4674,(0,1):C.GC_4658,(0,21):C.GC_4666,(0,22):C.GC_4662,(0,5):C.GC_4648,(0,4):C.GC_4450,(0,18):C.GC_4449})

V_1250 = Vertex(name = 'V_1250',
                particles = [ P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.G0, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSS605 ],
                couplings = {(0,0):C.GC_3694})

V_1251 = Vertex(name = 'V_1251',
                particles = [ P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSS242, L.VVVVSS258, L.VVVVSS417, L.VVVVSS434, L.VVVVSS472, L.VVVVSS493, L.VVVVSS535, L.VVVVSS536, L.VVVVSS537, L.VVVVSS539, L.VVVVSS560, L.VVVVSS577, L.VVVVSS605, L.VVVVSS606, L.VVVVSS608, L.VVVVSS618, L.VVVVSS629, L.VVVVSS634, L.VVVVSS644, L.VVVVSS704, L.VVVVSS719, L.VVVVSS750, L.VVVVSS752, L.VVVVSS758 ],
                couplings = {(0,12):C.GC_2531,(0,9):C.GC_2635,(0,6):C.GC_2642,(0,7):C.GC_2976,(0,8):C.GC_2970,(0,2):C.GC_2627,(0,21):C.GC_2618,(0,20):C.GC_2632,(0,17):C.GC_2955,(0,19):C.GC_2967,(0,16):C.GC_2624,(0,0):C.GC_2780,(0,13):C.GC_3785,(0,3):C.GC_2963,(0,15):C.GC_2958,(0,14):C.GC_3788,(0,10):C.GC_4681,(0,11):C.GC_4673,(0,1):C.GC_4657,(0,22):C.GC_4669,(0,23):C.GC_4661,(0,5):C.GC_4649,(0,4):C.GC_4451,(0,18):C.GC_4448})

V_1252 = Vertex(name = 'V_1252',
                particles = [ P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSS605 ],
                couplings = {(0,0):C.GC_3693})

V_1253 = Vertex(name = 'V_1253',
                particles = [ P.W__minus__, P.W__plus__, P.Z, P.Z, P.G0, P.G0 ],
                color = [ '1' ],
                lorentz = [ L.VVVVSS130, L.VVVVSS131, L.VVVVSS317, L.VVVVSS327, L.VVVVSS339, L.VVVVSS341, L.VVVVSS346, L.VVVVSS348, L.VVVVSS349, L.VVVVSS350, L.VVVVSS354, L.VVVVSS362, L.VVVVSS391, L.VVVVSS447, L.VVVVSS452, L.VVVVSS454, L.VVVVSS464, L.VVVVSS467, L.VVVVSS494, L.VVVVSS505, L.VVVVSS512, L.VVVVSS586, L.VVVVSS603, L.VVVVSS617, L.VVVVSS648, L.VVVVSS649, L.VVVVSS657, L.VVVVSS662, L.VVVVSS670, L.VVVVSS702, L.VVVVSS743, L.VVVVSS744, L.VVVVSS781 ],
                couplings = {(0,22):C.GC_1062,(0,2):C.GC_3116,(0,17):C.GC_983,(0,20):C.GC_989,(0,5):C.GC_2222,(0,7):C.GC_2224,(0,9):C.GC_3112,(0,29):C.GC_981,(0,0):C.GC_1690,(0,27):C.GC_1665,(0,32):C.GC_2216,(0,31):C.GC_2219,(0,19):C.GC_2215,(0,13):C.GC_1664,(0,8):C.GC_5035,(0,11):C.GC_3114,(0,23):C.GC_3113,(0,12):C.GC_3161,(0,16):C.GC_2143,(0,25):C.GC_6354,(0,21):C.GC_3932,(0,14):C.GC_3935,(0,4):C.GC_4257,(0,6):C.GC_4261,(0,1):C.GC_4241,(0,26):C.GC_3928,(0,24):C.GC_3929,(0,28):C.GC_4236,(0,30):C.GC_4252,(0,3):C.GC_3926,(0,10):C.GC_3922,(0,18):C.GC_4248,(0,15):C.GC_4138})

V_1254 = Vertex(name = 'V_1254',
                particles = [ P.W__minus__, P.W__plus__, P.Z, P.Z, P.G0, P.G0 ],
                color = [ '1' ],
                lorentz = [ L.VVVVSS603 ],
                couplings = {(0,0):C.GC_2154})

V_1255 = Vertex(name = 'V_1255',
                particles = [ P.W__minus__, P.W__plus__, P.Z, P.Z, P.G0, P.G0 ],
                color = [ '1' ],
                lorentz = [ L.VVVVSS603 ],
                couplings = {(0,0):C.GC_6555})

V_1256 = Vertex(name = 'V_1256',
                particles = [ P.W__minus__, P.W__plus__, P.Z, P.Z, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSS130, L.VVVVSS317, L.VVVVSS322, L.VVVVSS329, L.VVVVSS349, L.VVVVSS350, L.VVVVSS355, L.VVVVSS362, L.VVVVSS407, L.VVVVSS411, L.VVVVSS447, L.VVVVSS454, L.VVVVSS464, L.VVVVSS512, L.VVVVSS513, L.VVVVSS522, L.VVVVSS528, L.VVVVSS555, L.VVVVSS556, L.VVVVSS586, L.VVVVSS587, L.VVVVSS603, L.VVVVSS609, L.VVVVSS610, L.VVVVSS612, L.VVVVSS617, L.VVVVSS649, L.VVVVSS650, L.VVVVSS657, L.VVVVSS662, L.VVVVSS673, L.VVVVSS702, L.VVVVSS710, L.VVVVSS711, L.VVVVSS745, L.VVVVSS746, L.VVVVSS748, L.VVVVSS782 ],
                couplings = {(0,21):C.GC_2154,(0,15):C.GC_987,(0,16):C.GC_2220,(0,1):C.GC_3115,(0,13):C.GC_990,(0,14):C.GC_2225,(0,8):C.GC_979,(0,9):C.GC_2217,(0,33):C.GC_973,(0,32):C.GC_2215,(0,5):C.GC_3112,(0,31):C.GC_980,(0,36):C.GC_2219,(0,0):C.GC_1666,(0,29):C.GC_1665,(0,37):C.GC_2216,(0,24):C.GC_975,(0,10):C.GC_1664,(0,22):C.GC_5039,(0,23):C.GC_1872,(0,4):C.GC_2319,(0,7):C.GC_3114,(0,25):C.GC_3113,(0,12):C.GC_2143,(0,26):C.GC_6356,(0,19):C.GC_3931,(0,17):C.GC_3935,(0,20):C.GC_4258,(0,18):C.GC_4262,(0,3):C.GC_4242,(0,2):C.GC_3925,(0,28):C.GC_3927,(0,27):C.GC_3929,(0,35):C.GC_4249,(0,34):C.GC_4251,(0,30):C.GC_4237,(0,6):C.GC_3922,(0,11):C.GC_4139})

V_1257 = Vertex(name = 'V_1257',
                particles = [ P.W__minus__, P.W__plus__, P.Z, P.Z, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSS603 ],
                couplings = {(0,0):C.GC_6557})

V_1258 = Vertex(name = 'V_1258',
                particles = [ P.W__minus__, P.W__plus__, P.Z, P.Z, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSS603 ],
                couplings = {(0,0):C.GC_2262})

V_1259 = Vertex(name = 'V_1259',
                particles = [ P.W__minus__, P.W__plus__, P.Z, P.Z, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVS10, L.VVVVS104, L.VVVVS106, L.VVVVS120, L.VVVVS128, L.VVVVS166, L.VVVVS170, L.VVVVS181, L.VVVVS204, L.VVVVS205, L.VVVVS208, L.VVVVS211, L.VVVVS215, L.VVVVS228, L.VVVVS248, L.VVVVS249, L.VVVVS28, L.VVVVS33, L.VVVVS46, L.VVVVS47, L.VVVVS51, L.VVVVS52, L.VVVVS54, L.VVVVS55, L.VVVVS59, L.VVVVS63, L.VVVVS64, L.VVVVS87, L.VVVVS9, L.VVVVS95, L.VVVVS97 ],
                couplings = {(0,1):C.GC_2140,(0,9):C.GC_6261,(0,6):C.GC_1044,(0,16):C.GC_3105,(0,2):C.GC_880,(0,4):C.GC_884,(0,19):C.GC_2167,(0,21):C.GC_2169,(0,23):C.GC_3102,(0,13):C.GC_878,(0,28):C.GC_1642,(0,11):C.GC_1641,(0,15):C.GC_2165,(0,27):C.GC_1638,(0,22):C.GC_5034,(0,25):C.GC_3104,(0,7):C.GC_3103,(0,26):C.GC_3160,(0,30):C.GC_4133,(0,5):C.GC_3883,(0,29):C.GC_3886,(0,18):C.GC_4179,(0,20):C.GC_4182,(0,0):C.GC_4166,(0,10):C.GC_3880,(0,8):C.GC_3881,(0,12):C.GC_4162,(0,14):C.GC_4174,(0,17):C.GC_3879,(0,24):C.GC_3876,(0,3):C.GC_4171})

V_1260 = Vertex(name = 'V_1260',
                particles = [ P.W__minus__, P.W__plus__, P.Z, P.Z, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVS170 ],
                couplings = {(0,0):C.GC_2153})

V_1261 = Vertex(name = 'V_1261',
                particles = [ P.W__minus__, P.W__plus__, P.Z, P.Z, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVS170 ],
                couplings = {(0,0):C.GC_6593})

V_1262 = Vertex(name = 'V_1262',
                particles = [ P.W__minus__, P.W__plus__, P.Z, P.Z, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSS130, L.VVVVSS131, L.VVVVSS317, L.VVVVSS327, L.VVVVSS339, L.VVVVSS341, L.VVVVSS346, L.VVVVSS348, L.VVVVSS349, L.VVVVSS350, L.VVVVSS354, L.VVVVSS362, L.VVVVSS391, L.VVVVSS447, L.VVVVSS452, L.VVVVSS454, L.VVVVSS464, L.VVVVSS467, L.VVVVSS494, L.VVVVSS505, L.VVVVSS512, L.VVVVSS586, L.VVVVSS603, L.VVVVSS617, L.VVVVSS648, L.VVVVSS649, L.VVVVSS657, L.VVVVSS662, L.VVVVSS670, L.VVVVSS702, L.VVVVSS743, L.VVVVSS744, L.VVVVSS781 ],
                couplings = {(0,22):C.GC_1063,(0,2):C.GC_3116,(0,17):C.GC_983,(0,20):C.GC_989,(0,5):C.GC_2222,(0,7):C.GC_2224,(0,9):C.GC_3112,(0,29):C.GC_981,(0,0):C.GC_1690,(0,27):C.GC_1665,(0,32):C.GC_2216,(0,31):C.GC_2219,(0,19):C.GC_2215,(0,13):C.GC_1664,(0,8):C.GC_5038,(0,11):C.GC_3114,(0,23):C.GC_3113,(0,12):C.GC_3162,(0,16):C.GC_2143,(0,25):C.GC_6354,(0,21):C.GC_3932,(0,14):C.GC_3935,(0,4):C.GC_4257,(0,6):C.GC_4261,(0,1):C.GC_4241,(0,26):C.GC_3928,(0,24):C.GC_3929,(0,28):C.GC_4236,(0,30):C.GC_4252,(0,3):C.GC_3926,(0,10):C.GC_3922,(0,18):C.GC_4248,(0,15):C.GC_4138})

V_1263 = Vertex(name = 'V_1263',
                particles = [ P.W__minus__, P.W__plus__, P.Z, P.Z, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSS603 ],
                couplings = {(0,0):C.GC_2154})

V_1264 = Vertex(name = 'V_1264',
                particles = [ P.W__minus__, P.W__plus__, P.Z, P.Z, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSS603 ],
                couplings = {(0,0):C.GC_6556})

V_1265 = Vertex(name = 'V_1265',
                particles = [ P.A, P.A, P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVS36 ],
                couplings = {(0,0):C.GC_7304})

V_1266 = Vertex(name = 'V_1266',
                particles = [ P.A, P.A, P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.G0, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVSS39 ],
                couplings = {(0,0):C.GC_7325})

V_1267 = Vertex(name = 'V_1267',
                particles = [ P.A, P.A, P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVSS39 ],
                couplings = {(0,0):C.GC_7323})

V_1268 = Vertex(name = 'V_1268',
                particles = [ P.A, P.A, P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVV2, L.VVVVVVV21, L.VVVVVVV3, L.VVVVVVV9 ],
                couplings = {(0,3):C.GC_7270,(0,0):C.GC_7269,(0,2):C.GC_7267,(0,1):C.GC_7268})

V_1269 = Vertex(name = 'V_1269',
                particles = [ P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.Z ],
                color = [ '1' ],
                lorentz = [ L.VVVVVV19, L.VVVVVV24, L.VVVVVV26, L.VVVVVV28, L.VVVVVV3, L.VVVVVV39, L.VVVVVV4, L.VVVVVV48, L.VVVVVV49, L.VVVVVV52, L.VVVVVV58, L.VVVVVV78, L.VVVVVV79, L.VVVVVV83, L.VVVVVV88 ],
                couplings = {(0,11):C.GC_7557,(0,6):C.GC_7553,(0,0):C.GC_7551,(0,4):C.GC_7544,(0,7):C.GC_7554,(0,10):C.GC_7555,(0,5):C.GC_7546,(0,14):C.GC_7552,(0,1):C.GC_7917,(0,13):C.GC_7550,(0,8):C.GC_7543,(0,2):C.GC_7545,(0,3):C.GC_7542,(0,9):C.GC_7560,(0,12):C.GC_7561})

V_1270 = Vertex(name = 'V_1270',
                particles = [ P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.Z ],
                color = [ '1' ],
                lorentz = [ L.VVVVVV78 ],
                couplings = {(0,0):C.GC_7556})

V_1271 = Vertex(name = 'V_1271',
                particles = [ P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.Z ],
                color = [ '1' ],
                lorentz = [ L.VVVVVV78 ],
                couplings = {(0,0):C.GC_7916})

V_1272 = Vertex(name = 'V_1272',
                particles = [ P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.G0, P.G0 ],
                color = [ '1' ],
                lorentz = [ L.VVVVVSS121, L.VVVVVSS128, L.VVVVVSS135, L.VVVVVSS249, L.VVVVVSS250, L.VVVVVSS33, L.VVVVVSS51, L.VVVVVSS63, L.VVVVVSS72 ],
                couplings = {(0,5):C.GC_2771,(0,7):C.GC_2057,(0,0):C.GC_4647,(0,3):C.GC_4646,(0,1):C.GC_4778,(0,2):C.GC_4782,(0,4):C.GC_4764,(0,6):C.GC_4770,(0,8):C.GC_4767})

V_1273 = Vertex(name = 'V_1273',
                particles = [ P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.G0, P.G0 ],
                color = [ '1' ],
                lorentz = [ L.VVVVVSS249 ],
                couplings = {(0,0):C.GC_4772})

V_1274 = Vertex(name = 'V_1274',
                particles = [ P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVSS121, L.VVVVVSS130, L.VVVVVSS131, L.VVVVVSS249, L.VVVVVSS251, L.VVVVVSS296, L.VVVVVSS298, L.VVVVVSS33, L.VVVVVSS51, L.VVVVVSS63 ],
                couplings = {(0,7):C.GC_2772,(0,9):C.GC_2056,(0,0):C.GC_4647,(0,3):C.GC_4646,(0,1):C.GC_4781,(0,2):C.GC_4785,(0,4):C.GC_4764,(0,5):C.GC_4775,(0,8):C.GC_4770,(0,6):C.GC_4767})

V_1275 = Vertex(name = 'V_1275',
                particles = [ P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVVS185, L.VVVVVS186, L.VVVVVS26, L.VVVVVS39, L.VVVVVS50, L.VVVVVS58, L.VVVVVS89, L.VVVVVS95, L.VVVVVS99 ],
                couplings = {(0,2):C.GC_2734,(0,4):C.GC_2047,(0,7):C.GC_4737,(0,8):C.GC_4740,(0,1):C.GC_4729,(0,0):C.GC_4546,(0,3):C.GC_4733,(0,5):C.GC_4731,(0,6):C.GC_4547})

V_1276 = Vertex(name = 'V_1276',
                particles = [ P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVVS185 ],
                couplings = {(0,0):C.GC_4734})

V_1277 = Vertex(name = 'V_1277',
                particles = [ P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVVSS121, L.VVVVVSS128, L.VVVVVSS135, L.VVVVVSS249, L.VVVVVSS250, L.VVVVVSS33, L.VVVVVSS51, L.VVVVVSS63, L.VVVVVSS72 ],
                couplings = {(0,5):C.GC_2771,(0,7):C.GC_2057,(0,0):C.GC_4647,(0,3):C.GC_4646,(0,1):C.GC_4778,(0,2):C.GC_4782,(0,4):C.GC_4764,(0,6):C.GC_4770,(0,8):C.GC_4767})

V_1278 = Vertex(name = 'V_1278',
                particles = [ P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVVSS249 ],
                couplings = {(0,0):C.GC_4772})

V_1279 = Vertex(name = 'V_1279',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.G0 ],
                color = [ '1' ],
                lorentz = [ L.VVVVS126, L.VVVVS127, L.VVVVS262 ],
                couplings = {(0,1):C.GC_882,(0,0):C.GC_883,(0,2):C.GC_879})

V_1280 = Vertex(name = 'V_1280',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.G0, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSS531, L.VVVVSS532, L.VVVVSS732 ],
                couplings = {(0,0):C.GC_985,(0,1):C.GC_988,(0,2):C.GC_982})

V_1281 = Vertex(name = 'V_1281',
                particles = [ P.W__plus__, P.W__plus__, P.G0, P.G0, P.G0, P.G__minus__, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSS1 ],
                couplings = {(0,0):C.GC_867})

V_1282 = Vertex(name = 'V_1282',
                particles = [ P.W__plus__, P.W__plus__, P.G0, P.G0, P.G0, P.G0, P.G__minus__, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSSS1 ],
                couplings = {(0,0):C.GC_957})

V_1283 = Vertex(name = 'V_1283',
                particles = [ P.W__plus__, P.W__plus__, P.G__minus__, P.G__minus__, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVSSSS91 ],
                couplings = {(0,0):C.GC_800})

V_1284 = Vertex(name = 'V_1284',
                particles = [ P.W__plus__, P.W__plus__, P.G0, P.G__minus__, P.G__minus__, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSS1 ],
                couplings = {(0,0):C.GC_867})

V_1285 = Vertex(name = 'V_1285',
                particles = [ P.W__plus__, P.W__plus__, P.G0, P.G0, P.G__minus__, P.G__minus__, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSSS1 ],
                couplings = {(0,0):C.GC_955})

V_1286 = Vertex(name = 'V_1286',
                particles = [ P.W__plus__, P.W__plus__, P.G0, P.G0, P.G0, P.G__minus__, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSSS1 ],
                couplings = {(0,0):C.GC_959})

V_1287 = Vertex(name = 'V_1287',
                particles = [ P.W__plus__, P.W__plus__, P.G__minus__, P.G__minus__, P.G__minus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSS1 ],
                couplings = {(0,0):C.GC_865})

V_1288 = Vertex(name = 'V_1288',
                particles = [ P.W__plus__, P.W__plus__, P.G0, P.G__minus__, P.G__minus__, P.G__minus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSSS1 ],
                couplings = {(0,0):C.GC_959})

V_1289 = Vertex(name = 'V_1289',
                particles = [ P.W__plus__, P.W__plus__, P.G0, P.G__minus__, P.G__minus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSS1 ],
                couplings = {(0,0):C.GC_867})

V_1290 = Vertex(name = 'V_1290',
                particles = [ P.W__plus__, P.W__plus__, P.G__minus__, P.G__minus__, P.G__minus__, P.G__plus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSSS1 ],
                couplings = {(0,0):C.GC_956})

V_1291 = Vertex(name = 'V_1291',
                particles = [ P.W__plus__, P.W__plus__, P.G__minus__, P.G__minus__, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSS1 ],
                couplings = {(0,0):C.GC_866})

V_1292 = Vertex(name = 'V_1292',
                particles = [ P.W__plus__, P.W__plus__, P.G0, P.G__minus__, P.G__minus__, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSSS1 ],
                couplings = {(0,0):C.GC_959})

V_1293 = Vertex(name = 'V_1293',
                particles = [ P.W__plus__, P.W__plus__, P.G__minus__, P.G__minus__, P.H, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSSS1 ],
                couplings = {(0,0):C.GC_958})

V_1294 = Vertex(name = 'V_1294',
                particles = [ P.A, P.A, P.W__plus__, P.G0, P.G0, P.G0, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS154, L.VVVSSSS160, L.VVVSSSS3, L.VVVSSSS82 ],
                couplings = {(0,2):C.GC_6548,(0,1):C.GC_1761,(0,0):C.GC_1764,(0,3):C.GC_6514})

V_1295 = Vertex(name = 'V_1295',
                particles = [ P.A, P.A, P.W__plus__, P.G0, P.G0, P.G0, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS3, L.VVVSSSS82 ],
                couplings = {(0,0):C.GC_6657,(0,1):C.GC_4199})

V_1296 = Vertex(name = 'V_1296',
                particles = [ P.A, P.A, P.W__plus__, P.G0, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSS3, L.VVVSSS57, L.VVVSSS73, L.VVVSSS82 ],
                couplings = {(0,0):C.GC_6312,(0,1):C.GC_6286,(0,3):C.GC_1658,(0,2):C.GC_1660})

V_1297 = Vertex(name = 'V_1297',
                particles = [ P.A, P.A, P.W__plus__, P.G0, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSS3, L.VVVSSS57 ],
                couplings = {(0,0):C.GC_6619,(0,1):C.GC_4146})

V_1298 = Vertex(name = 'V_1298',
                particles = [ P.A, P.A, P.W__plus__, P.G0, P.G__minus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS103, L.VVVSSSS3, L.VVVSSSS82, L.VVVSSSS98 ],
                couplings = {(0,1):C.GC_6546,(0,0):C.GC_1759,(0,3):C.GC_1764,(0,2):C.GC_6518})

V_1299 = Vertex(name = 'V_1299',
                particles = [ P.A, P.A, P.W__plus__, P.G0, P.G__minus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS3, L.VVVSSSS82 ],
                couplings = {(0,0):C.GC_6650,(0,1):C.GC_4197})

V_1300 = Vertex(name = 'V_1300',
                particles = [ P.A, P.A, P.W__plus__, P.G0, P.G0, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS252, L.VVVSSSS3, L.VVVSSSS329, L.VVVSSSS82 ],
                couplings = {(0,1):C.GC_6537,(0,2):C.GC_1762,(0,0):C.GC_1766,(0,3):C.GC_6520})

V_1301 = Vertex(name = 'V_1301',
                particles = [ P.A, P.A, P.W__plus__, P.G0, P.G0, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS3, L.VVVSSSS82 ],
                couplings = {(0,0):C.GC_6660,(0,1):C.GC_4196})

V_1302 = Vertex(name = 'V_1302',
                particles = [ P.A, P.A, P.W__plus__, P.G__minus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSS152, L.VVVSSS178, L.VVVSSS3, L.VVVSSS57 ],
                couplings = {(0,2):C.GC_6311,(0,3):C.GC_6296,(0,1):C.GC_1659,(0,0):C.GC_1661})

V_1303 = Vertex(name = 'V_1303',
                particles = [ P.A, P.A, P.W__plus__, P.G__minus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSS3, L.VVVSSS57 ],
                couplings = {(0,0):C.GC_6626,(0,1):C.GC_4145})

V_1304 = Vertex(name = 'V_1304',
                particles = [ P.A, P.A, P.W__plus__, P.G__minus__, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS261, L.VVVSSSS296, L.VVVSSSS3, L.VVVSSSS82 ],
                couplings = {(0,2):C.GC_6545,(0,1):C.GC_1763,(0,0):C.GC_1766,(0,3):C.GC_6528})

V_1305 = Vertex(name = 'V_1305',
                particles = [ P.A, P.A, P.W__plus__, P.G__minus__, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS3, L.VVVSSSS82 ],
                couplings = {(0,0):C.GC_6664,(0,1):C.GC_4194})

V_1306 = Vertex(name = 'V_1306',
                particles = [ P.A, P.A, P.W__plus__, P.G0, P.G0, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVSSS3, L.VVVSSS57 ],
                couplings = {(0,0):C.GC_6303,(0,1):C.GC_6288})

V_1307 = Vertex(name = 'V_1307',
                particles = [ P.A, P.A, P.W__plus__, P.G0, P.G0, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVSSS3, L.VVVSSS57 ],
                couplings = {(0,0):C.GC_6622,(0,1):C.GC_6608})

V_1308 = Vertex(name = 'V_1308',
                particles = [ P.A, P.W__plus__, P.W__plus__, P.G0, P.G__minus__, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVSSS117, L.VVVSSS192, L.VVVSSS47, L.VVVSSS59, L.VVVSSS67, L.VVVSSS7 ],
                couplings = {(0,5):C.GC_4410,(0,3):C.GC_4406,(0,0):C.GC_4722,(0,2):C.GC_4726,(0,4):C.GC_4721,(0,1):C.GC_4570})

V_1309 = Vertex(name = 'V_1309',
                particles = [ P.A, P.W__plus__, P.W__plus__, P.G0, P.G__minus__, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVSSS7 ],
                couplings = {(0,0):C.GC_4579})

V_1310 = Vertex(name = 'V_1310',
                particles = [ P.A, P.W__plus__, P.W__plus__, P.G__minus__, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVSS13, L.VVVSS214, L.VVVSS251, L.VVVSS284, L.VVVSS286 ],
                couplings = {(0,0):C.GC_4438,(0,4):C.GC_4503,(0,2):C.GC_4436,(0,1):C.GC_7234,(0,3):C.GC_4711})

V_1311 = Vertex(name = 'V_1311',
                particles = [ P.A, P.W__plus__, P.W__plus__, P.G__minus__, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVSS13 ],
                couplings = {(0,0):C.GC_4506})

V_1312 = Vertex(name = 'V_1312',
                particles = [ P.A, P.W__plus__, P.W__plus__, P.G0, P.G0, P.G__minus__, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS106, L.VVVSSSS190, L.VVVSSSS322, L.VVVSSSS68, L.VVVSSSS7, L.VVVSSSS84 ],
                couplings = {(0,4):C.GC_4470,(0,2):C.GC_4698,(0,5):C.GC_4466,(0,1):C.GC_4756,(0,3):C.GC_4762,(0,0):C.GC_4750})

V_1313 = Vertex(name = 'V_1313',
                particles = [ P.A, P.W__plus__, P.W__plus__, P.G0, P.G0, P.G__minus__, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS7 ],
                couplings = {(0,0):C.GC_4705})

V_1314 = Vertex(name = 'V_1314',
                particles = [ P.A, P.W__plus__, P.W__plus__, P.G__minus__, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSS114, L.VVVSSS143, L.VVVSSS48, L.VVVSSS59, L.VVVSSS7, L.VVVSSS87 ],
                couplings = {(0,4):C.GC_4412,(0,3):C.GC_4408,(0,0):C.GC_4720,(0,2):C.GC_4728,(0,5):C.GC_4723,(0,1):C.GC_4574})

V_1315 = Vertex(name = 'V_1315',
                particles = [ P.A, P.W__plus__, P.W__plus__, P.G__minus__, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSS7 ],
                couplings = {(0,0):C.GC_4580})

V_1316 = Vertex(name = 'V_1316',
                particles = [ P.A, P.W__plus__, P.W__plus__, P.G0, P.G__minus__, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS132, L.VVVSSSS184, L.VVVSSSS246, L.VVVSSSS7, L.VVVSSSS75, L.VVVSSSS84 ],
                couplings = {(0,3):C.GC_4467,(0,2):C.GC_4692,(0,5):C.GC_4463,(0,0):C.GC_4754,(0,4):C.GC_4759,(0,1):C.GC_4753})

V_1317 = Vertex(name = 'V_1317',
                particles = [ P.A, P.W__plus__, P.W__plus__, P.G0, P.G__minus__, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS7 ],
                couplings = {(0,0):C.GC_4703})

V_1318 = Vertex(name = 'V_1318',
                particles = [ P.A, P.W__plus__, P.W__plus__, P.G__minus__, P.G__minus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS106, L.VVVSSSS190, L.VVVSSSS232, L.VVVSSSS68, L.VVVSSSS7, L.VVVSSSS84 ],
                couplings = {(0,4):C.GC_4469,(0,2):C.GC_4697,(0,5):C.GC_4465,(0,1):C.GC_4751,(0,3):C.GC_4762,(0,0):C.GC_4755})

V_1319 = Vertex(name = 'V_1319',
                particles = [ P.A, P.W__plus__, P.W__plus__, P.G__minus__, P.G__minus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS7 ],
                couplings = {(0,0):C.GC_4704})

V_1320 = Vertex(name = 'V_1320',
                particles = [ P.A, P.W__plus__, P.Z, P.G0, P.G0, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVSSS101, L.VVVSSS126, L.VVVSSS16, L.VVVSSS186, L.VVVSSS23, L.VVVSSS33, L.VVVSSS4, L.VVVSSS44, L.VVVSSS5, L.VVVSSS58, L.VVVSSS61 ],
                couplings = {(0,8):C.GC_6279,(0,6):C.GC_595,(0,10):C.GC_6272,(0,9):C.GC_588,(0,5):C.GC_3981,(0,7):C.GC_3973,(0,0):C.GC_3977,(0,4):C.GC_3898,(0,2):C.GC_3907,(0,1):C.GC_3889,(0,3):C.GC_3902})

V_1321 = Vertex(name = 'V_1321',
                particles = [ P.A, P.W__plus__, P.Z, P.G0, P.G0, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVSSS4, L.VVVSSS5, L.VVVSSS58, L.VVVSSS61 ],
                couplings = {(0,1):C.GC_6635,(0,0):C.GC_840,(0,3):C.GC_6632,(0,2):C.GC_835})

V_1322 = Vertex(name = 'V_1322',
                particles = [ P.A, P.W__plus__, P.Z, P.G0, P.G0, P.G0, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS141, L.VVVSSSS150, L.VVVSSSS163, L.VVVSSSS19, L.VVVSSSS237, L.VVVSSSS31, L.VVVSSSS316, L.VVVSSSS4, L.VVVSSSS5, L.VVVSSSS83, L.VVVSSSS86 ],
                couplings = {(0,8):C.GC_6512,(0,7):C.GC_740,(0,10):C.GC_6495,(0,9):C.GC_739,(0,5):C.GC_3950,(0,3):C.GC_3963,(0,4):C.GC_3941,(0,6):C.GC_3962,(0,1):C.GC_4269,(0,2):C.GC_4274,(0,0):C.GC_6129})

V_1323 = Vertex(name = 'V_1323',
                particles = [ P.A, P.W__plus__, P.Z, P.G0, P.G0, P.G0, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS4, L.VVVSSSS5, L.VVVSSSS83, L.VVVSSSS86 ],
                couplings = {(0,1):C.GC_6769,(0,0):C.GC_930,(0,3):C.GC_2195,(0,2):C.GC_921})

V_1324 = Vertex(name = 'V_1324',
                particles = [ P.A, P.W__plus__, P.Z, P.G__minus__, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVSSS102, L.VVVSSS103, L.VVVSSS113, L.VVVSSS121, L.VVVSSS125, L.VVVSSS13, L.VVVSSS138, L.VVVSSS140, L.VVVSSS22, L.VVVSSS4, L.VVVSSS5, L.VVVSSS58, L.VVVSSS61, L.VVVSSS97 ],
                couplings = {(0,10):C.GC_6280,(0,9):C.GC_597,(0,12):C.GC_6275,(0,11):C.GC_590,(0,7):C.GC_3975,(0,1):C.GC_3979,(0,2):C.GC_3981,(0,3):C.GC_6780,(0,0):C.GC_4280,(0,5):C.GC_3899,(0,8):C.GC_3908,(0,13):C.GC_3888,(0,4):C.GC_3903,(0,6):C.GC_4189})

V_1325 = Vertex(name = 'V_1325',
                particles = [ P.A, P.W__plus__, P.Z, P.G__minus__, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVSSS4, L.VVVSSS5, L.VVVSSS58, L.VVVSSS61 ],
                couplings = {(0,1):C.GC_6639,(0,0):C.GC_839,(0,3):C.GC_6633,(0,2):C.GC_836})

V_1326 = Vertex(name = 'V_1326',
                particles = [ P.A, P.W__plus__, P.Z, P.G0, P.G__minus__, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS13, L.VVVSSSS143, L.VVVSSSS144, L.VVVSSSS153, L.VVVSSSS175, L.VVVSSSS197, L.VVVSSSS209, L.VVVSSSS236, L.VVVSSSS29, L.VVVSSSS313, L.VVVSSSS315, L.VVVSSSS4, L.VVVSSSS5, L.VVVSSSS83, L.VVVSSSS86, L.VVVSSSS94 ],
                couplings = {(0,12):C.GC_6504,(0,11):C.GC_741,(0,14):C.GC_6503,(0,13):C.GC_738,(0,0):C.GC_3949,(0,8):C.GC_3970,(0,3):C.GC_3940,(0,6):C.GC_3955,(0,15):C.GC_4268,(0,7):C.GC_4278,(0,10):C.GC_4013,(0,2):C.GC_4018,(0,9):C.GC_4306,(0,1):C.GC_4309,(0,4):C.GC_4019,(0,5):C.GC_4315})

V_1327 = Vertex(name = 'V_1327',
                particles = [ P.A, P.W__plus__, P.Z, P.G0, P.G__minus__, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS4, L.VVVSSSS5, L.VVVSSSS83, L.VVVSSSS86 ],
                couplings = {(0,1):C.GC_6772,(0,0):C.GC_929,(0,3):C.GC_2194,(0,2):C.GC_920})

V_1328 = Vertex(name = 'V_1328',
                particles = [ P.A, P.W__plus__, P.Z, P.G0, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSS127, L.VVVSSS14, L.VVVSSS142, L.VVVSSS24, L.VVVSSS34, L.VVVSSS4, L.VVVSSS5, L.VVVSSS58, L.VVVSSS61, L.VVVSSS68, L.VVVSSS76, L.VVVSSS79, L.VVVSSS88 ],
                couplings = {(0,6):C.GC_6284,(0,5):C.GC_594,(0,8):C.GC_6271,(0,7):C.GC_593,(0,4):C.GC_3984,(0,11):C.GC_3976,(0,0):C.GC_3980,(0,1):C.GC_3897,(0,3):C.GC_3906,(0,12):C.GC_3890,(0,2):C.GC_3905,(0,9):C.GC_4185,(0,10):C.GC_4187})

V_1329 = Vertex(name = 'V_1329',
                particles = [ P.A, P.W__plus__, P.Z, P.G0, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSS4, L.VVVSSS5, L.VVVSSS58, L.VVVSSS61 ],
                couplings = {(0,1):C.GC_6636,(0,0):C.GC_841,(0,3):C.GC_2159,(0,2):C.GC_834})

V_1330 = Vertex(name = 'V_1330',
                particles = [ P.A, P.W__plus__, P.Z, P.G0, P.G0, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS18, L.VVVSSSS183, L.VVVSSSS205, L.VVVSSSS217, L.VVVSSSS300, L.VVVSSSS303, L.VVVSSSS321, L.VVVSSSS33, L.VVVSSSS4, L.VVVSSSS48, L.VVVSSSS5, L.VVVSSSS83, L.VVVSSSS86 ],
                couplings = {(0,10):C.GC_6506,(0,8):C.GC_743,(0,12):C.GC_6497,(0,11):C.GC_732,(0,7):C.GC_3951,(0,0):C.GC_3966,(0,3):C.GC_3938,(0,6):C.GC_3957,(0,1):C.GC_4270,(0,4):C.GC_4275,(0,9):C.GC_4020,(0,2):C.GC_4009,(0,5):C.GC_4015})

V_1331 = Vertex(name = 'V_1331',
                particles = [ P.A, P.W__plus__, P.Z, P.G0, P.G0, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS4, L.VVVSSSS5, L.VVVSSSS83, L.VVVSSSS86 ],
                couplings = {(0,1):C.GC_6767,(0,0):C.GC_927,(0,3):C.GC_2196,(0,2):C.GC_922})

V_1332 = Vertex(name = 'V_1332',
                particles = [ P.A, P.W__plus__, P.Z, P.G__minus__, P.G__minus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS129, L.VVVSSSS135, L.VVVSSSS183, L.VVVSSSS194, L.VVVSSSS21, L.VVVSSSS211, L.VVVSSSS213, L.VVVSSSS214, L.VVVSSSS225, L.VVVSSSS30, L.VVVSSSS305, L.VVVSSSS309, L.VVVSSSS4, L.VVVSSSS5, L.VVVSSSS83, L.VVVSSSS86 ],
                couplings = {(0,13):C.GC_6507,(0,12):C.GC_745,(0,15):C.GC_6500,(0,14):C.GC_734,(0,9):C.GC_3952,(0,4):C.GC_3967,(0,5):C.GC_3937,(0,10):C.GC_3958,(0,2):C.GC_4271,(0,11):C.GC_4276,(0,8):C.GC_4011,(0,7):C.GC_4016,(0,0):C.GC_4020,(0,3):C.GC_4307,(0,6):C.GC_4311,(0,1):C.GC_4313})

V_1333 = Vertex(name = 'V_1333',
                particles = [ P.A, P.W__plus__, P.Z, P.G__minus__, P.G__minus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS4, L.VVVSSSS5, L.VVVSSSS83, L.VVVSSSS86 ],
                couplings = {(0,1):C.GC_6773,(0,0):C.GC_926,(0,3):C.GC_2197,(0,2):C.GC_923})

V_1334 = Vertex(name = 'V_1334',
                particles = [ P.A, P.W__plus__, P.Z, P.G__minus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSS131, L.VVVSSS147, L.VVVSSS163, L.VVVSSS167, L.VVVSSS18, L.VVVSSS189, L.VVVSSS19, L.VVVSSS4, L.VVVSSS5, L.VVVSSS58, L.VVVSSS61 ],
                couplings = {(0,8):C.GC_6283,(0,7):C.GC_599,(0,10):C.GC_6276,(0,9):C.GC_592,(0,0):C.GC_6126,(0,6):C.GC_3900,(0,4):C.GC_3909,(0,2):C.GC_3887,(0,3):C.GC_3904,(0,1):C.GC_4186,(0,5):C.GC_4188})

V_1335 = Vertex(name = 'V_1335',
                particles = [ P.A, P.W__plus__, P.Z, P.G__minus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSS4, L.VVVSSS5, L.VVVSSS58, L.VVVSSS61 ],
                couplings = {(0,1):C.GC_6634,(0,0):C.GC_838,(0,3):C.GC_2160,(0,2):C.GC_837})

V_1336 = Vertex(name = 'V_1336',
                particles = [ P.A, P.W__plus__, P.Z, P.G0, P.G__minus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS100, L.VVVSSSS101, L.VVVSSSS109, L.VVVSSSS12, L.VVVSSSS218, L.VVVSSSS230, L.VVVSSSS34, L.VVVSSSS4, L.VVVSSSS5, L.VVVSSSS51, L.VVVSSSS83, L.VVVSSSS86, L.VVVSSSS94 ],
                couplings = {(0,8):C.GC_6511,(0,7):C.GC_742,(0,11):C.GC_6496,(0,10):C.GC_737,(0,3):C.GC_3948,(0,6):C.GC_3965,(0,2):C.GC_3939,(0,5):C.GC_3960,(0,12):C.GC_4267,(0,0):C.GC_4274,(0,9):C.GC_4023,(0,1):C.GC_4012,(0,4):C.GC_4017})

V_1337 = Vertex(name = 'V_1337',
                particles = [ P.A, P.W__plus__, P.Z, P.G0, P.G__minus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS4, L.VVVSSSS5, L.VVVSSSS83, L.VVVSSSS86 ],
                couplings = {(0,1):C.GC_6768,(0,0):C.GC_928,(0,3):C.GC_2193,(0,2):C.GC_919})

V_1338 = Vertex(name = 'V_1338',
                particles = [ P.A, P.W__plus__, P.Z, P.G__minus__, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS223, L.VVVSSSS23, L.VVVSSSS24, L.VVVSSSS250, L.VVVSSSS271, L.VVVSSSS275, L.VVVSSSS323, L.VVVSSSS4, L.VVVSSSS5, L.VVVSSSS83, L.VVVSSSS86 ],
                couplings = {(0,8):C.GC_6510,(0,7):C.GC_747,(0,10):C.GC_6501,(0,9):C.GC_736,(0,2):C.GC_3953,(0,1):C.GC_3968,(0,4):C.GC_3936,(0,5):C.GC_3959,(0,3):C.GC_4272,(0,6):C.GC_4275,(0,0):C.GC_6128})

V_1339 = Vertex(name = 'V_1339',
                particles = [ P.A, P.W__plus__, P.Z, P.G__minus__, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS4, L.VVVSSSS5, L.VVVSSSS83, L.VVVSSSS86 ],
                couplings = {(0,1):C.GC_6766,(0,0):C.GC_925,(0,3):C.GC_2198,(0,2):C.GC_924})

V_1340 = Vertex(name = 'V_1340',
                particles = [ P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.Z, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVS132, L.VVVVVS153, L.VVVVVS158, L.VVVVVS159, L.VVVVVS160, L.VVVVVS175, L.VVVVVS176, L.VVVVVS177, L.VVVVVS199, L.VVVVVS2, L.VVVVVS207, L.VVVVVS208, L.VVVVVS25, L.VVVVVS37, L.VVVVVS38, L.VVVVVS40, L.VVVVVS42, L.VVVVVS45, L.VVVVVS46, L.VVVVVS55, L.VVVVVS85, L.VVVVVS86, L.VVVVVS87, L.VVVVVS98 ],
                couplings = {(0,15):C.GC_1804,(0,17):C.GC_1100,(0,9):C.GC_1095,(0,12):C.GC_2274,(0,7):C.GC_1798,(0,5):C.GC_2273,(0,6):C.GC_2276,(0,2):C.GC_1093,(0,4):C.GC_1096,(0,16):C.GC_2163,(0,18):C.GC_870,(0,3):C.GC_869,(0,22):C.GC_4286,(0,20):C.GC_3991,(0,23):C.GC_3993,(0,21):C.GC_4290,(0,14):C.GC_4284,(0,1):C.GC_3986,(0,8):C.GC_4282,(0,11):C.GC_3989,(0,10):C.GC_4285,(0,0):C.GC_4283,(0,13):C.GC_3988,(0,19):C.GC_3987})

V_1341 = Vertex(name = 'V_1341',
                particles = [ P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.Z, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVS177 ],
                couplings = {(0,0):C.GC_2162})

V_1342 = Vertex(name = 'V_1342',
                particles = [ P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.Z, P.G0, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVSS115, L.VVVVVSS116, L.VVVVVSS118, L.VVVVVSS134, L.VVVVVSS185, L.VVVVVSS2, L.VVVVVSS210, L.VVVVVSS215, L.VVVVVSS216, L.VVVVVSS217, L.VVVVVSS234, L.VVVVVSS235, L.VVVVVSS236, L.VVVVVSS273, L.VVVVVSS288, L.VVVVVSS295, L.VVVVVSS32, L.VVVVVSS49, L.VVVVVSS50, L.VVVVVSS52, L.VVVVVSS54, L.VVVVVSS57, L.VVVVVSS58, L.VVVVVSS68 ],
                couplings = {(0,20):C.GC_2212,(0,22):C.GC_969,(0,12):C.GC_1850,(0,8):C.GC_968,(0,19):C.GC_1855,(0,21):C.GC_1172,(0,5):C.GC_1161,(0,16):C.GC_2312,(0,10):C.GC_2303,(0,11):C.GC_2317,(0,7):C.GC_1155,(0,9):C.GC_1170,(0,2):C.GC_4333,(0,1):C.GC_4038,(0,3):C.GC_4040,(0,0):C.GC_4335,(0,18):C.GC_4325,(0,6):C.GC_4024,(0,13):C.GC_4319,(0,15):C.GC_4036,(0,14):C.GC_4328,(0,4):C.GC_4320,(0,17):C.GC_4031,(0,23):C.GC_4030})

V_1343 = Vertex(name = 'V_1343',
                particles = [ P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.Z, P.G0, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVSS236 ],
                couplings = {(0,0):C.GC_2211})

V_1344 = Vertex(name = 'V_1344',
                particles = [ P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.Z, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVVSS115, L.VVVVVSS117, L.VVVVVSS119, L.VVVVVSS134, L.VVVVVSS184, L.VVVVVSS2, L.VVVVVSS210, L.VVVVVSS215, L.VVVVVSS216, L.VVVVVSS217, L.VVVVVSS234, L.VVVVVSS235, L.VVVVVSS236, L.VVVVVSS253, L.VVVVVSS285, L.VVVVVSS295, L.VVVVVSS32, L.VVVVVSS49, L.VVVVVSS50, L.VVVVVSS52, L.VVVVVSS54, L.VVVVVSS57, L.VVVVVSS58, L.VVVVVSS68 ],
                couplings = {(0,20):C.GC_2213,(0,22):C.GC_970,(0,12):C.GC_1851,(0,8):C.GC_967,(0,19):C.GC_1861,(0,21):C.GC_1173,(0,5):C.GC_1163,(0,16):C.GC_2310,(0,10):C.GC_2307,(0,11):C.GC_2314,(0,7):C.GC_1159,(0,9):C.GC_1166,(0,2):C.GC_4329,(0,1):C.GC_4039,(0,3):C.GC_4042,(0,0):C.GC_4337,(0,18):C.GC_4324,(0,6):C.GC_4026,(0,14):C.GC_4318,(0,15):C.GC_4034,(0,13):C.GC_4327,(0,4):C.GC_4321,(0,17):C.GC_4032,(0,23):C.GC_4029})

V_1345 = Vertex(name = 'V_1345',
                particles = [ P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.Z, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVVSS236 ],
                couplings = {(0,0):C.GC_2210})

V_1346 = Vertex(name = 'V_1346',
                particles = [ P.A, P.A, P.W__plus__, P.W__plus__, P.G__minus__, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSS349, L.VVVVSS391, L.VVVVSS603 ],
                couplings = {(0,2):C.GC_1624,(0,0):C.GC_1873,(0,1):C.GC_1870})

V_1347 = Vertex(name = 'V_1347',
                particles = [ P.A, P.A, P.W__plus__, P.W__plus__, P.G__minus__, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSS603 ],
                couplings = {(0,0):C.GC_1775})

V_1348 = Vertex(name = 'V_1348',
                particles = [ P.A, P.A, P.W__plus__, P.W__plus__, P.G0, P.G__minus__, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS3, L.VVVVSSS4, L.VVVVSSS5 ],
                couplings = {(0,2):C.GC_1652,(0,0):C.GC_1882,(0,1):C.GC_1878})

V_1349 = Vertex(name = 'V_1349',
                particles = [ P.A, P.A, P.W__plus__, P.W__plus__, P.G0, P.G__minus__, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS5 ],
                couplings = {(0,0):C.GC_1806})

V_1350 = Vertex(name = 'V_1350',
                particles = [ P.A, P.A, P.W__plus__, P.W__plus__, P.G0, P.G0, P.G__minus__, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS3, L.VVVVSSSS4, L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_1901,(0,1):C.GC_1895,(0,2):C.GC_1732})

V_1351 = Vertex(name = 'V_1351',
                particles = [ P.A, P.A, P.W__plus__, P.W__plus__, P.G0, P.G0, P.G__minus__, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_1868})

V_1352 = Vertex(name = 'V_1352',
                particles = [ P.A, P.A, P.W__plus__, P.W__plus__, P.G__minus__, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS3, L.VVVVSSS4, L.VVVVSSS5 ],
                couplings = {(0,2):C.GC_1655,(0,0):C.GC_1885,(0,1):C.GC_1880})

V_1353 = Vertex(name = 'V_1353',
                particles = [ P.A, P.A, P.W__plus__, P.W__plus__, P.G__minus__, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS5 ],
                couplings = {(0,0):C.GC_1807})

V_1354 = Vertex(name = 'V_1354',
                particles = [ P.A, P.A, P.W__plus__, P.W__plus__, P.G0, P.G__minus__, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS3, L.VVVVSSSS4, L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_1897,(0,1):C.GC_1891,(0,2):C.GC_1728})

V_1355 = Vertex(name = 'V_1355',
                particles = [ P.A, P.A, P.W__plus__, P.W__plus__, P.G0, P.G__minus__, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_1866})

V_1356 = Vertex(name = 'V_1356',
                particles = [ P.A, P.A, P.W__plus__, P.W__plus__, P.G__minus__, P.G__minus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS3, L.VVVVSSSS4, L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_1900,(0,1):C.GC_1893,(0,2):C.GC_1731})

V_1357 = Vertex(name = 'V_1357',
                particles = [ P.A, P.A, P.W__plus__, P.W__plus__, P.G__minus__, P.G__minus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_1867})

V_1358 = Vertex(name = 'V_1358',
                particles = [ P.A, P.W__minus__, P.W__plus__, P.W__plus__, P.G0, P.G0, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS3, L.VVVVSSS4, L.VVVVSSS5 ],
                couplings = {(0,2):C.GC_4539,(0,0):C.GC_7298,(0,1):C.GC_4810})

V_1359 = Vertex(name = 'V_1359',
                particles = [ P.A, P.W__minus__, P.W__plus__, P.W__plus__, P.G0, P.G0, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS5 ],
                couplings = {(0,0):C.GC_7247})

V_1360 = Vertex(name = 'V_1360',
                particles = [ P.A, P.W__minus__, P.W__plus__, P.W__plus__, P.G0, P.G0, P.G0, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS3, L.VVVVSSSS4, L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_7318,(0,1):C.GC_4827,(0,2):C.GC_4644})

V_1361 = Vertex(name = 'V_1361',
                particles = [ P.A, P.W__minus__, P.W__plus__, P.W__plus__, P.G0, P.G0, P.G0, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_7290})

V_1362 = Vertex(name = 'V_1362',
                particles = [ P.A, P.W__minus__, P.W__plus__, P.W__plus__, P.G__minus__, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS3, L.VVVVSSS4, L.VVVVSSS5 ],
                couplings = {(0,2):C.GC_4540,(0,0):C.GC_7299,(0,1):C.GC_4808})

V_1363 = Vertex(name = 'V_1363',
                particles = [ P.A, P.W__minus__, P.W__plus__, P.W__plus__, P.G__minus__, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS5 ],
                couplings = {(0,0):C.GC_7249})

V_1364 = Vertex(name = 'V_1364',
                particles = [ P.A, P.W__minus__, P.W__plus__, P.W__plus__, P.G0, P.G__minus__, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS3, L.VVVVSSSS4, L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_7317,(0,1):C.GC_4821,(0,2):C.GC_4636})

V_1365 = Vertex(name = 'V_1365',
                particles = [ P.A, P.W__minus__, P.W__plus__, P.W__plus__, P.G0, P.G__minus__, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_7275})

V_1366 = Vertex(name = 'V_1366',
                particles = [ P.A, P.W__minus__, P.W__plus__, P.W__plus__, P.G0, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS3, L.VVVVSSS4, L.VVVVSSS5 ],
                couplings = {(0,2):C.GC_4544,(0,0):C.GC_7302,(0,1):C.GC_4812})

V_1367 = Vertex(name = 'V_1367',
                particles = [ P.A, P.W__minus__, P.W__plus__, P.W__plus__, P.G0, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS5 ],
                couplings = {(0,0):C.GC_7258})

V_1368 = Vertex(name = 'V_1368',
                particles = [ P.A, P.W__minus__, P.W__plus__, P.W__plus__, P.G0, P.G0, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS3, L.VVVVSSSS4, L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_7312,(0,1):C.GC_4824,(0,2):C.GC_4637})

V_1369 = Vertex(name = 'V_1369',
                particles = [ P.A, P.W__minus__, P.W__plus__, P.W__plus__, P.G0, P.G0, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_7277})

V_1370 = Vertex(name = 'V_1370',
                particles = [ P.A, P.W__minus__, P.W__plus__, P.W__plus__, P.G__minus__, P.G__minus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS3, L.VVVVSSSS4, L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_7313,(0,1):C.GC_4820,(0,2):C.GC_4638})

V_1371 = Vertex(name = 'V_1371',
                particles = [ P.A, P.W__minus__, P.W__plus__, P.W__plus__, P.G__minus__, P.G__minus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_7279})

V_1372 = Vertex(name = 'V_1372',
                particles = [ P.A, P.W__minus__, P.W__plus__, P.W__plus__, P.G__minus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS3, L.VVVVSSS4, L.VVVVSSS5 ],
                couplings = {(0,2):C.GC_4541,(0,0):C.GC_7300,(0,1):C.GC_4811})

V_1373 = Vertex(name = 'V_1373',
                particles = [ P.A, P.W__minus__, P.W__plus__, P.W__plus__, P.G__minus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS5 ],
                couplings = {(0,0):C.GC_7253})

V_1374 = Vertex(name = 'V_1374',
                particles = [ P.A, P.W__minus__, P.W__plus__, P.W__plus__, P.G0, P.G__minus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS3, L.VVVVSSSS4, L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_7316,(0,1):C.GC_4826,(0,2):C.GC_4642})

V_1375 = Vertex(name = 'V_1375',
                particles = [ P.A, P.W__minus__, P.W__plus__, P.W__plus__, P.G0, P.G__minus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_7288})

V_1376 = Vertex(name = 'V_1376',
                particles = [ P.A, P.W__minus__, P.W__plus__, P.W__plus__, P.G__minus__, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS3, L.VVVVSSSS4, L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_7314,(0,1):C.GC_4825,(0,2):C.GC_4639})

V_1377 = Vertex(name = 'V_1377',
                particles = [ P.A, P.W__minus__, P.W__plus__, P.W__plus__, P.G__minus__, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_7283})

V_1378 = Vertex(name = 'V_1378',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.G0, P.G0, P.G0, P.G0 ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS3, L.VVVVSSSS4, L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_1437,(0,1):C.GC_1191,(0,2):C.GC_1404})

V_1379 = Vertex(name = 'V_1379',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.G0, P.G0, P.G0, P.G0 ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_1175})

V_1380 = Vertex(name = 'V_1380',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.G0, P.G0, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS3, L.VVVVSSSS4, L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_1435,(0,1):C.GC_1188,(0,2):C.GC_1401})

V_1381 = Vertex(name = 'V_1381',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.G0, P.G0, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_1177})

V_1382 = Vertex(name = 'V_1382',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS3, L.VVVVSSSS4, L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_1436,(0,1):C.GC_1190,(0,2):C.GC_1403})

V_1383 = Vertex(name = 'V_1383',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_1176})

V_1384 = Vertex(name = 'V_1384',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.G0, P.G0, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS3, L.VVVVSSS4, L.VVVVSSS5 ],
                couplings = {(0,2):C.GC_1390,(0,0):C.GC_1429,(0,1):C.GC_1186})

V_1385 = Vertex(name = 'V_1385',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.G0, P.G0, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS5 ],
                couplings = {(0,0):C.GC_1102})

V_1386 = Vertex(name = 'V_1386',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.G__minus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS3, L.VVVVSSS4, L.VVVVSSS5 ],
                couplings = {(0,2):C.GC_1389,(0,0):C.GC_1430,(0,1):C.GC_1185})

V_1387 = Vertex(name = 'V_1387',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.G__minus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS5 ],
                couplings = {(0,0):C.GC_1102})

V_1388 = Vertex(name = 'V_1388',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.G0, P.G0, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS3, L.VVVVSSSS4, L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_1434,(0,1):C.GC_1189,(0,2):C.GC_1402})

V_1389 = Vertex(name = 'V_1389',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.G0, P.G0, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_1177})

V_1390 = Vertex(name = 'V_1390',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.G__minus__, P.G__plus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS3, L.VVVVSSSS4, L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_1435,(0,1):C.GC_1188,(0,2):C.GC_1401})

V_1391 = Vertex(name = 'V_1391',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.G__minus__, P.G__plus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_1177})

V_1392 = Vertex(name = 'V_1392',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS3, L.VVVVSSS4, L.VVVVSSS5 ],
                couplings = {(0,2):C.GC_1391,(0,0):C.GC_1431,(0,1):C.GC_1187})

V_1393 = Vertex(name = 'V_1393',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS5 ],
                couplings = {(0,0):C.GC_1101})

V_1394 = Vertex(name = 'V_1394',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.H, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS3, L.VVVVSSSS4, L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_1437,(0,1):C.GC_1191,(0,2):C.GC_1404})

V_1395 = Vertex(name = 'V_1395',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.H, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_1175})

V_1396 = Vertex(name = 'V_1396',
                particles = [ P.A, P.A, P.A, P.W__minus__, P.W__plus__, P.W__plus__, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVS10 ],
                couplings = {(0,0):C.GC_7304})

V_1397 = Vertex(name = 'V_1397',
                particles = [ P.A, P.A, P.A, P.W__minus__, P.W__plus__, P.W__plus__, P.G0, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVSS12 ],
                couplings = {(0,0):C.GC_7320})

V_1398 = Vertex(name = 'V_1398',
                particles = [ P.A, P.A, P.A, P.W__minus__, P.W__plus__, P.W__plus__, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVSS12 ],
                couplings = {(0,0):C.GC_7323})

V_1399 = Vertex(name = 'V_1399',
                particles = [ P.A, P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVS101, L.VVVVVS102, L.VVVVVS112, L.VVVVVS113, L.VVVVVS116, L.VVVVVS119, L.VVVVVS121, L.VVVVVS122, L.VVVVVS126, L.VVVVVS127, L.VVVVVS146, L.VVVVVS148, L.VVVVVS151, L.VVVVVS157, L.VVVVVS161, L.VVVVVS174, L.VVVVVS178, L.VVVVVS197, L.VVVVVS200, L.VVVVVS204, L.VVVVVS22, L.VVVVVS60, L.VVVVVS91, L.VVVVVS92 ],
                couplings = {(0,0):C.GC_1803,(0,2):C.GC_1100,(0,20):C.GC_1095,(0,21):C.GC_2274,(0,15):C.GC_1797,(0,16):C.GC_2277,(0,13):C.GC_1097,(0,8):C.GC_1091,(0,9):C.GC_2272,(0,1):C.GC_2163,(0,3):C.GC_870,(0,14):C.GC_868,(0,5):C.GC_4288,(0,4):C.GC_3992,(0,6):C.GC_3991,(0,7):C.GC_4289,(0,23):C.GC_4284,(0,12):C.GC_3985,(0,18):C.GC_4281,(0,17):C.GC_3990,(0,11):C.GC_4283,(0,19):C.GC_4285,(0,22):C.GC_3988,(0,10):C.GC_3987})

V_1400 = Vertex(name = 'V_1400',
                particles = [ P.A, P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVS174 ],
                couplings = {(0,0):C.GC_2161})

V_1401 = Vertex(name = 'V_1401',
                particles = [ P.A, P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.G0, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVSS124, L.VVVVVSS125, L.VVVVVSS140, L.VVVVVSS141, L.VVVVVSS152, L.VVVVVSS153, L.VVVVVSS155, L.VVVVVSS161, L.VVVVVSS168, L.VVVVVSS169, L.VVVVVSS174, L.VVVVVSS175, L.VVVVVSS200, L.VVVVVSS202, L.VVVVVSS208, L.VVVVVSS214, L.VVVVVSS218, L.VVVVVSS233, L.VVVVVSS237, L.VVVVVSS265, L.VVVVVSS274, L.VVVVVSS28, L.VVVVVSS283, L.VVVVVSS77 ],
                couplings = {(0,3):C.GC_2214,(0,5):C.GC_971,(0,17):C.GC_1849,(0,16):C.GC_965,(0,2):C.GC_1862,(0,4):C.GC_1174,(0,21):C.GC_1164,(0,23):C.GC_2309,(0,18):C.GC_2313,(0,15):C.GC_1165,(0,10):C.GC_1156,(0,11):C.GC_2308,(0,7):C.GC_4333,(0,6):C.GC_4040,(0,8):C.GC_4037,(0,9):C.GC_4335,(0,1):C.GC_4323,(0,14):C.GC_4027,(0,20):C.GC_4316,(0,19):C.GC_4036,(0,13):C.GC_4322,(0,22):C.GC_4326,(0,0):C.GC_4033,(0,12):C.GC_4028})

V_1402 = Vertex(name = 'V_1402',
                particles = [ P.A, P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.G0, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVSS233 ],
                couplings = {(0,0):C.GC_2208})

V_1403 = Vertex(name = 'V_1403',
                particles = [ P.A, P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVVSS124, L.VVVVVSS125, L.VVVVVSS140, L.VVVVVSS141, L.VVVVVSS152, L.VVVVVSS153, L.VVVVVSS155, L.VVVVVSS159, L.VVVVVSS162, L.VVVVVSS169, L.VVVVVSS174, L.VVVVVSS175, L.VVVVVSS200, L.VVVVVSS203, L.VVVVVSS208, L.VVVVVSS214, L.VVVVVSS218, L.VVVVVSS233, L.VVVVVSS237, L.VVVVVSS256, L.VVVVVSS265, L.VVVVVSS28, L.VVVVVSS286, L.VVVVVSS77 ],
                couplings = {(0,3):C.GC_2213,(0,5):C.GC_970,(0,17):C.GC_1848,(0,16):C.GC_966,(0,2):C.GC_1860,(0,4):C.GC_1173,(0,21):C.GC_1163,(0,23):C.GC_2310,(0,18):C.GC_2315,(0,15):C.GC_1167,(0,10):C.GC_1157,(0,11):C.GC_2306,(0,8):C.GC_4334,(0,6):C.GC_4041,(0,7):C.GC_4039,(0,9):C.GC_4336,(0,1):C.GC_4324,(0,14):C.GC_4025,(0,22):C.GC_4317,(0,20):C.GC_4035,(0,13):C.GC_4321,(0,19):C.GC_4327,(0,0):C.GC_4032,(0,12):C.GC_4029})

V_1404 = Vertex(name = 'V_1404',
                particles = [ P.A, P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVVSS233 ],
                couplings = {(0,0):C.GC_2209})

V_1405 = Vertex(name = 'V_1405',
                particles = [ P.A, P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.G0, P.G0 ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVSS10, L.VVVVVVSS33, L.VVVVVVSS36 ],
                couplings = {(0,1):C.GC_1905,(0,2):C.GC_1841,(0,0):C.GC_1907})

V_1406 = Vertex(name = 'V_1406',
                particles = [ P.A, P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.G0, P.G0 ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVSS36 ],
                couplings = {(0,0):C.GC_1911})

V_1407 = Vertex(name = 'V_1407',
                particles = [ P.A, P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVSS36, L.VVVVVVSS42, L.VVVVVVSS63 ],
                couplings = {(0,1):C.GC_1906,(0,0):C.GC_1841,(0,2):C.GC_1907})

V_1408 = Vertex(name = 'V_1408',
                particles = [ P.A, P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVSS36 ],
                couplings = {(0,0):C.GC_1913})

V_1409 = Vertex(name = 'V_1409',
                particles = [ P.A, P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVS30, L.VVVVVVS33, L.VVVVVVS8 ],
                couplings = {(0,1):C.GC_1792,(0,0):C.GC_1887,(0,2):C.GC_1888})

V_1410 = Vertex(name = 'V_1410',
                particles = [ P.A, P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVS33 ],
                couplings = {(0,0):C.GC_1889})

V_1411 = Vertex(name = 'V_1411',
                particles = [ P.A, P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVSS10, L.VVVVVVSS33, L.VVVVVVSS36 ],
                couplings = {(0,1):C.GC_1905,(0,2):C.GC_1841,(0,0):C.GC_1907})

V_1412 = Vertex(name = 'V_1412',
                particles = [ P.A, P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVSS36 ],
                couplings = {(0,0):C.GC_1911})

V_1413 = Vertex(name = 'V_1413',
                particles = [ P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.G0 ],
                color = [ '1' ],
                lorentz = [ L.VVVVVS191, L.VVVVVS47 ],
                couplings = {(0,0):C.GC_4736,(0,1):C.GC_4739})

V_1414 = Vertex(name = 'V_1414',
                particles = [ P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.G0, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVVSS289, L.VVVVVSS59 ],
                couplings = {(0,0):C.GC_4776,(0,1):C.GC_4780})

V_1415 = Vertex(name = 'V_1415',
                particles = [ P.A, P.W__minus__, P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVS23 ],
                couplings = {(0,0):C.GC_7303})

V_1416 = Vertex(name = 'V_1416',
                particles = [ P.A, P.W__minus__, P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.G0, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVSS26 ],
                couplings = {(0,0):C.GC_7321})

V_1417 = Vertex(name = 'V_1417',
                particles = [ P.A, P.W__minus__, P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVSS26 ],
                couplings = {(0,0):C.GC_7322})

V_1418 = Vertex(name = 'V_1418',
                particles = [ P.W__minus__, P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.G0, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVSS291, L.VVVVVSS3 ],
                couplings = {(0,1):C.GC_1152,(0,0):C.GC_1419})

V_1419 = Vertex(name = 'V_1419',
                particles = [ P.W__minus__, P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVS190, L.VVVVVS3 ],
                couplings = {(0,1):C.GC_1088,(0,0):C.GC_1414})

V_1420 = Vertex(name = 'V_1420',
                particles = [ P.W__minus__, P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVVSS291, L.VVVVVSS3 ],
                couplings = {(0,1):C.GC_1148,(0,0):C.GC_1420})

V_1421 = Vertex(name = 'V_1421',
                particles = [ P.A, P.A, P.A, P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVVV16, L.VVVVVVVV2 ],
                couplings = {(0,1):C.GC_1916,(0,0):C.GC_1919})

V_1422 = Vertex(name = 'V_1422',
                particles = [ P.A, P.W__minus__, P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.W__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVV15, L.VVVVVVV18, L.VVVVVVV6, L.VVVVVVV8 ],
                couplings = {(0,2):C.GC_4789,(0,0):C.GC_4787,(0,3):C.GC_4788,(0,1):C.GC_4786})

V_1423 = Vertex(name = 'V_1423',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.G0, P.G0 ],
                color = [ '1' ],
                lorentz = [ L.VVVVVSS101, L.VVVVVSS102, L.VVVVVSS104, L.VVVVVSS209, L.VVVVVSS211, L.VVVVVSS212, L.VVVVVSS226, L.VVVVVSS6, L.VVVVVSS7, L.VVVVVSS84, L.VVVVVSS93 ],
                couplings = {(0,10):C.GC_2657,(0,3):C.GC_2656,(0,2):C.GC_2761,(0,1):C.GC_2762,(0,9):C.GC_3055,(0,0):C.GC_3058,(0,8):C.GC_2752,(0,4):C.GC_2747,(0,6):C.GC_2750,(0,7):C.GC_4793,(0,5):C.GC_7271})

V_1424 = Vertex(name = 'V_1424',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.G0, P.G0 ],
                color = [ '1' ],
                lorentz = [ L.VVVVVSS209 ],
                couplings = {(0,0):C.GC_3753})

V_1425 = Vertex(name = 'V_1425',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVSS101, L.VVVVVSS103, L.VVVVVSS209, L.VVVVVSS212, L.VVVVVSS227, L.VVVVVSS259, L.VVVVVSS267, L.VVVVVSS282, L.VVVVVSS29, L.VVVVVSS6, L.VVVVVSS7, L.VVVVVSS84, L.VVVVVSS90, L.VVVVVSS93 ],
                couplings = {(0,13):C.GC_2657,(0,2):C.GC_2656,(0,12):C.GC_2758,(0,1):C.GC_2764,(0,11):C.GC_3055,(0,0):C.GC_3057,(0,10):C.GC_2752,(0,5):C.GC_2747,(0,4):C.GC_2750,(0,7):C.GC_2755,(0,8):C.GC_3047,(0,6):C.GC_3044,(0,9):C.GC_4792,(0,3):C.GC_7272})

V_1426 = Vertex(name = 'V_1426',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVSS209 ],
                couplings = {(0,0):C.GC_3052})

V_1427 = Vertex(name = 'V_1427',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVVS152, L.VVVVVS154, L.VVVVVS155, L.VVVVVS169, L.VVVVVS5, L.VVVVVS6, L.VVVVVS66, L.VVVVVS70, L.VVVVVS76, L.VVVVVS77, L.VVVVVS78 ],
                couplings = {(0,10):C.GC_2730,(0,9):C.GC_2731,(0,6):C.GC_3033,(0,8):C.GC_3034,(0,5):C.GC_2725,(0,1):C.GC_2723,(0,3):C.GC_2724,(0,0):C.GC_2575,(0,7):C.GC_2576,(0,4):C.GC_4744,(0,2):C.GC_7244})

V_1428 = Vertex(name = 'V_1428',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVVS152 ],
                couplings = {(0,0):C.GC_3711})

V_1429 = Vertex(name = 'V_1429',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVVSS101, L.VVVVVSS102, L.VVVVVSS104, L.VVVVVSS209, L.VVVVVSS211, L.VVVVVSS212, L.VVVVVSS226, L.VVVVVSS6, L.VVVVVSS7, L.VVVVVSS84, L.VVVVVSS93 ],
                couplings = {(0,10):C.GC_2657,(0,3):C.GC_2656,(0,2):C.GC_2761,(0,1):C.GC_2762,(0,9):C.GC_3055,(0,0):C.GC_3058,(0,8):C.GC_2752,(0,4):C.GC_2747,(0,6):C.GC_2750,(0,7):C.GC_4793,(0,5):C.GC_7271})

V_1430 = Vertex(name = 'V_1430',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVVSS209 ],
                couplings = {(0,0):C.GC_3753})

V_1431 = Vertex(name = 'V_1431',
                particles = [ P.W__minus__, P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.W__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVV41, L.VVVVVV51, L.VVVVVV67, L.VVVVVV7, L.VVVVVV76, L.VVVVVV84 ],
                couplings = {(0,3):C.GC_993,(0,0):C.GC_995,(0,2):C.GC_992,(0,1):C.GC_994,(0,5):C.GC_991,(0,4):C.GC_1428})

V_1432 = Vertex(name = 'V_1432',
                particles = [ P.A, P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.Z ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVV13, L.VVVVVVV17, L.VVVVVVV22, L.VVVVVVV5 ],
                couplings = {(0,0):C.GC_2054,(0,3):C.GC_2053,(0,2):C.GC_2052,(0,1):C.GC_2051})

V_1433 = Vertex(name = 'V_1433',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.Z ],
                color = [ '1' ],
                lorentz = [ L.VVVVVV14, L.VVVVVV15, L.VVVVVV16, L.VVVVVV23, L.VVVVVV31, L.VVVVVV34, L.VVVVVV36, L.VVVVVV53, L.VVVVVV56, L.VVVVVV59, L.VVVVVV72, L.VVVVVV73, L.VVVVVV75, L.VVVVVV89, L.VVVVVV91, L.VVVVVV95 ],
                couplings = {(0,1):C.GC_2234,(0,2):C.GC_2236,(0,0):C.GC_1677,(0,9):C.GC_2238,(0,7):C.GC_2237,(0,4):C.GC_1682,(0,14):C.GC_2233,(0,15):C.GC_2235,(0,3):C.GC_1679,(0,13):C.GC_1673,(0,5):C.GC_1675,(0,12):C.GC_1877,(0,10):C.GC_2321,(0,6):C.GC_3163,(0,8):C.GC_2322,(0,11):C.GC_3164})

V_1434 = Vertex(name = 'V_1434',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.Z ],
                color = [ '1' ],
                lorentz = [ L.VVVVVV75 ],
                couplings = {(0,0):C.GC_2261})

V_1435 = Vertex(name = 'V_1435',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.Z ],
                color = [ '1' ],
                lorentz = [ L.VVVVVV75 ],
                couplings = {(0,0):C.GC_6776})

V_1436 = Vertex(name = 'V_1436',
                particles = [ P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.W__plus__, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVS15 ],
                couplings = {(0,0):C.GC_7303})

V_1437 = Vertex(name = 'V_1437',
                particles = [ P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.W__plus__, P.G0, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVSS17 ],
                couplings = {(0,0):C.GC_7324})

V_1438 = Vertex(name = 'V_1438',
                particles = [ P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.W__plus__, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVSS17 ],
                couplings = {(0,0):C.GC_7322})

V_1439 = Vertex(name = 'V_1439',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.W__plus__, P.G0, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVSS171, L.VVVVVSS86 ],
                couplings = {(0,0):C.GC_1419,(0,1):C.GC_1153})

V_1440 = Vertex(name = 'V_1440',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.W__plus__, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVS124, L.VVVVVS67 ],
                couplings = {(0,0):C.GC_1415,(0,1):C.GC_1088})

V_1441 = Vertex(name = 'V_1441',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.W__plus__, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVVSS171, L.VVVVVSS86 ],
                couplings = {(0,0):C.GC_1421,(0,1):C.GC_1148})

V_1442 = Vertex(name = 'V_1442',
                particles = [ P.W__minus__, P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.W__plus__, P.G0, P.G0 ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVSS40 ],
                couplings = {(0,0):C.GC_1439})

V_1443 = Vertex(name = 'V_1443',
                particles = [ P.W__minus__, P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.W__plus__, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVSS40 ],
                couplings = {(0,0):C.GC_1439})

V_1444 = Vertex(name = 'V_1444',
                particles = [ P.W__minus__, P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.W__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVS37 ],
                couplings = {(0,0):C.GC_1433})

V_1445 = Vertex(name = 'V_1445',
                particles = [ P.W__minus__, P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.W__plus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVSS40 ],
                couplings = {(0,0):C.GC_1439})

V_1446 = Vertex(name = 'V_1446',
                particles = [ P.A, P.A, P.W__minus__, P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.W__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVVV14, L.VVVVVVVV4 ],
                couplings = {(0,1):C.GC_1918,(0,0):C.GC_1915})

V_1447 = Vertex(name = 'V_1447',
                particles = [ P.W__plus__, P.W__plus__, P.Z, P.G__minus__, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVSS175, L.VVVSS250, L.VVVSS278, L.VVVSS279, L.VVVSS285, L.VVVSS3 ],
                couplings = {(0,5):C.GC_2446,(0,3):C.GC_2537,(0,1):C.GC_2445,(0,0):C.GC_2706,(0,2):C.GC_3673,(0,4):C.GC_3679})

V_1448 = Vertex(name = 'V_1448',
                particles = [ P.W__plus__, P.W__plus__, P.Z, P.G__minus__, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVSS250, L.VVVSS3 ],
                couplings = {(0,1):C.GC_3524,(0,0):C.GC_2887})

V_1449 = Vertex(name = 'V_1449',
                particles = [ P.W__plus__, P.W__plus__, P.Z, P.G0, P.G__minus__, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVSSS133, L.VVVSSS151, L.VVVSSS158, L.VVVSSS175, L.VVVSSS3, L.VVVSSS57, L.VVVSSS75 ],
                couplings = {(0,4):C.GC_2416,(0,5):C.GC_2415,(0,1):C.GC_2714,(0,2):C.GC_3701,(0,6):C.GC_2721,(0,0):C.GC_3706,(0,3):C.GC_2603})

V_1450 = Vertex(name = 'V_1450',
                particles = [ P.W__plus__, P.W__plus__, P.Z, P.G0, P.G__minus__, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVSSS3, L.VVVSSS57 ],
                couplings = {(0,0):C.GC_3579,(0,1):C.GC_2928})

V_1451 = Vertex(name = 'V_1451',
                particles = [ P.W__plus__, P.W__plus__, P.Z, P.G0, P.G0, P.G__minus__, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS118, L.VVVSSSS228, L.VVVSSSS254, L.VVVSSSS264, L.VVVSSSS292, L.VVVSSSS3, L.VVVSSSS82 ],
                couplings = {(0,5):C.GC_2494,(0,4):C.GC_2695,(0,6):C.GC_2488,(0,2):C.GC_2741,(0,3):C.GC_3735,(0,0):C.GC_2743,(0,1):C.GC_3741})

V_1452 = Vertex(name = 'V_1452',
                particles = [ P.W__plus__, P.W__plus__, P.Z, P.G0, P.G0, P.G__minus__, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS3, L.VVVSSSS82 ],
                couplings = {(0,0):C.GC_3658,(0,1):C.GC_3009})

V_1453 = Vertex(name = 'V_1453',
                particles = [ P.W__plus__, P.W__plus__, P.Z, P.G__minus__, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSS141, L.VVVSSS148, L.VVVSSS161, L.VVVSSS162, L.VVVSSS3, L.VVVSSS57, L.VVVSSS96 ],
                couplings = {(0,4):C.GC_2418,(0,5):C.GC_2414,(0,1):C.GC_2720,(0,2):C.GC_3697,(0,6):C.GC_2716,(0,0):C.GC_3703,(0,3):C.GC_2599})

V_1454 = Vertex(name = 'V_1454',
                particles = [ P.W__plus__, P.W__plus__, P.Z, P.G__minus__, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSS3, L.VVVSSS57 ],
                couplings = {(0,0):C.GC_3578,(0,1):C.GC_2930})

V_1455 = Vertex(name = 'V_1455',
                particles = [ P.W__plus__, P.W__plus__, P.Z, P.G0, P.G__minus__, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS152, L.VVVSSSS253, L.VVVSSSS270, L.VVVSSSS285, L.VVVSSSS3, L.VVVSSSS308, L.VVVSSSS82 ],
                couplings = {(0,4):C.GC_2491,(0,2):C.GC_2701,(0,6):C.GC_2490,(0,0):C.GC_2738,(0,3):C.GC_3739,(0,1):C.GC_2745,(0,5):C.GC_3747})

V_1456 = Vertex(name = 'V_1456',
                particles = [ P.W__plus__, P.W__plus__, P.Z, P.G0, P.G__minus__, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS3, L.VVVSSSS82 ],
                couplings = {(0,0):C.GC_3660,(0,1):C.GC_3006})

V_1457 = Vertex(name = 'V_1457',
                particles = [ P.W__plus__, P.W__plus__, P.Z, P.G__minus__, P.G__minus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS118, L.VVVSSSS228, L.VVVSSSS254, L.VVVSSSS264, L.VVVSSSS265, L.VVVSSSS3, L.VVVSSSS82 ],
                couplings = {(0,5):C.GC_2493,(0,4):C.GC_2696,(0,6):C.GC_2489,(0,2):C.GC_2744,(0,3):C.GC_3735,(0,0):C.GC_2740,(0,1):C.GC_3741})

V_1458 = Vertex(name = 'V_1458',
                particles = [ P.W__plus__, P.W__plus__, P.Z, P.G__minus__, P.G__minus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS3, L.VVVSSSS82 ],
                couplings = {(0,0):C.GC_3659,(0,1):C.GC_3008})

V_1459 = Vertex(name = 'V_1459',
                particles = [ P.W__minus__, P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.W__plus__, P.Z ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVV1, L.VVVVVVV10, L.VVVVVVV20, L.VVVVVVV24 ],
                couplings = {(0,0):C.GC_2768,(0,1):C.GC_2769,(0,3):C.GC_2766,(0,2):C.GC_2767})

V_1460 = Vertex(name = 'V_1460',
                particles = [ P.W__minus__, P.W__minus__, P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.W__plus__, P.W__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVVV13 ],
                couplings = {(0,0):C.GC_1440})

V_1461 = Vertex(name = 'V_1461',
                particles = [ P.A, P.Z, P.G0, P.G0, P.G0, P.G0, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSSS1 ],
                couplings = {(0,0):C.GC_3917})

V_1462 = Vertex(name = 'V_1462',
                particles = [ P.A, P.Z, P.G0, P.G0, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSSS1 ],
                couplings = {(0,0):C.GC_6666})

V_1463 = Vertex(name = 'V_1463',
                particles = [ P.A, P.Z, P.G__minus__, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSSS1 ],
                couplings = {(0,0):C.GC_6667})

V_1464 = Vertex(name = 'V_1464',
                particles = [ P.A, P.Z, P.G0, P.G0, P.G__minus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSS1 ],
                couplings = {(0,0):C.GC_3870})

V_1465 = Vertex(name = 'V_1465',
                particles = [ P.A, P.Z, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSS1 ],
                couplings = {(0,0):C.GC_6628})

V_1466 = Vertex(name = 'V_1466',
                particles = [ P.A, P.Z, P.G0, P.G0, P.G__minus__, P.G__plus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSSS1 ],
                couplings = {(0,0):C.GC_3916})

V_1467 = Vertex(name = 'V_1467',
                particles = [ P.A, P.Z, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSSS1 ],
                couplings = {(0,0):C.GC_6666})

V_1468 = Vertex(name = 'V_1468',
                particles = [ P.A, P.Z, P.G__minus__, P.G__plus__, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSS1 ],
                couplings = {(0,0):C.GC_3871})

V_1469 = Vertex(name = 'V_1469',
                particles = [ P.A, P.Z, P.G__minus__, P.G__plus__, P.H, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSSS1 ],
                couplings = {(0,0):C.GC_3917})

V_1470 = Vertex(name = 'V_1470',
                particles = [ P.A, P.A, P.A, P.Z, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS13 ],
                couplings = {(0,0):C.GC_6863})

V_1471 = Vertex(name = 'V_1471',
                particles = [ P.Z, P.G0, P.G0, P.G0, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VSSSSS5 ],
                couplings = {(0,0):C.GC_3275})

V_1472 = Vertex(name = 'V_1472',
                particles = [ P.Z, P.G0, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VSSSSS1 ],
                couplings = {(0,0):C.GC_3276})

V_1473 = Vertex(name = 'V_1473',
                particles = [ P.Z, P.G0, P.G0, P.G0, P.G__minus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VSSSSSS10 ],
                couplings = {(0,0):C.GC_3385})

V_1474 = Vertex(name = 'V_1474',
                particles = [ P.Z, P.G0, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VSSSSSS16 ],
                couplings = {(0,0):C.GC_3386})

V_1475 = Vertex(name = 'V_1475',
                particles = [ P.Z, P.G0, P.G__minus__, P.G__plus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VSSSSS17 ],
                couplings = {(0,0):C.GC_3277})

V_1476 = Vertex(name = 'V_1476',
                particles = [ P.Z, P.G0, P.G__minus__, P.G__plus__, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VSSSSSS25 ],
                couplings = {(0,0):C.GC_3387})

V_1477 = Vertex(name = 'V_1477',
                particles = [ P.Z, P.G0, P.G0, P.G0 ],
                color = [ '1' ],
                lorentz = [ L.VSSS16, L.VSSS29 ],
                couplings = {(0,0):C.GC_2817,(0,1):C.GC_3272})

V_1478 = Vertex(name = 'V_1478',
                particles = [ P.Z, P.G0, P.G0, P.G0 ],
                color = [ '1' ],
                lorentz = [ L.VSSS16 ],
                couplings = {(0,0):C.GC_3323})

V_1479 = Vertex(name = 'V_1479',
                particles = [ P.Z, P.G0, P.G0, P.G0, P.G0, P.G0 ],
                color = [ '1' ],
                lorentz = [ L.VSSSSS21 ],
                couplings = {(0,0):C.GC_2831})

V_1480 = Vertex(name = 'V_1480',
                particles = [ P.Z, P.G0, P.G0, P.G0, P.G0, P.G0, P.H ],
                color = [ '1' ],
                lorentz = [ L.VSSSSSS8 ],
                couplings = {(0,0):C.GC_2856})

V_1481 = Vertex(name = 'V_1481',
                particles = [ P.Z, P.G0, P.G0, P.G0, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VSSSSS11 ],
                couplings = {(0,0):C.GC_2831})

V_1482 = Vertex(name = 'V_1482',
                particles = [ P.Z, P.G0, P.G0, P.G0, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VSSSSSS17 ],
                couplings = {(0,0):C.GC_2856})

V_1483 = Vertex(name = 'V_1483',
                particles = [ P.Z, P.G0, P.H, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VSSSSS19 ],
                couplings = {(0,0):C.GC_2832})

V_1484 = Vertex(name = 'V_1484',
                particles = [ P.Z, P.G0, P.H, P.H, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VSSSSSS27 ],
                couplings = {(0,0):C.GC_2857})

V_1485 = Vertex(name = 'V_1485',
                particles = [ P.A, P.A, P.Z, P.G0, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVSSS31, L.VVVSSS77 ],
                couplings = {(0,0):C.GC_3707,(0,1):C.GC_3702})

V_1486 = Vertex(name = 'V_1486',
                particles = [ P.A, P.A, P.Z, P.G0, P.G__minus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS207, L.VVVSSSS49 ],
                couplings = {(0,1):C.GC_3748,(0,0):C.GC_3740})

V_1487 = Vertex(name = 'V_1487',
                particles = [ P.ghWm, P.ghWm__tilde__, P.Z ],
                color = [ '1' ],
                lorentz = [ L.UUV1 ],
                couplings = {(0,0):C.GC_2385})

V_1488 = Vertex(name = 'V_1488',
                particles = [ P.ghWm, P.ghWm__tilde__, P.Z ],
                color = [ '1' ],
                lorentz = [ L.UUV1 ],
                couplings = {(0,0):C.GC_5701})

V_1489 = Vertex(name = 'V_1489',
                particles = [ P.ghWm, P.ghWm__tilde__, P.Z ],
                color = [ '1' ],
                lorentz = [ L.UUV1 ],
                couplings = {(0,0):C.GC_5732})

V_1490 = Vertex(name = 'V_1490',
                particles = [ P.ghWp, P.ghWp__tilde__, P.Z ],
                color = [ '1' ],
                lorentz = [ L.UUV1 ],
                couplings = {(0,0):C.GC_2386})

V_1491 = Vertex(name = 'V_1491',
                particles = [ P.ghWp, P.ghWp__tilde__, P.Z ],
                color = [ '1' ],
                lorentz = [ L.UUV1 ],
                couplings = {(0,0):C.GC_5703})

V_1492 = Vertex(name = 'V_1492',
                particles = [ P.ghWp, P.ghWp__tilde__, P.Z ],
                color = [ '1' ],
                lorentz = [ L.UUV1 ],
                couplings = {(0,0):C.GC_5734})

V_1493 = Vertex(name = 'V_1493',
                particles = [ P.Z, P.G0, P.G0, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VSSSSSS18 ],
                couplings = {(0,0):C.GC_3383})

V_1494 = Vertex(name = 'V_1494',
                particles = [ P.Z, P.G__minus__, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VSSSSSS17 ],
                couplings = {(0,0):C.GC_3384})

V_1495 = Vertex(name = 'V_1495',
                particles = [ P.Z, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VSSSSS6 ],
                couplings = {(0,0):C.GC_3274})

V_1496 = Vertex(name = 'V_1496',
                particles = [ P.Z, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VSSSSSS4 ],
                couplings = {(0,0):C.GC_3383})

V_1497 = Vertex(name = 'V_1497',
                particles = [ P.Z, P.G0, P.G0, P.G0, P.G0, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VSSSSSS19 ],
                couplings = {(0,0):C.GC_2855})

V_1498 = Vertex(name = 'V_1498',
                particles = [ P.Z, P.G0, P.G0, P.G__minus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VSSSSS7 ],
                couplings = {(0,0):C.GC_2829})

V_1499 = Vertex(name = 'V_1499',
                particles = [ P.Z, P.G0, P.G0, P.G__minus__, P.G__plus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VSSSSSS5 ],
                couplings = {(0,0):C.GC_2854})

V_1500 = Vertex(name = 'V_1500',
                particles = [ P.Z, P.G__minus__, P.G__plus__, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VSSSSS2 ],
                couplings = {(0,0):C.GC_2830})

V_1501 = Vertex(name = 'V_1501',
                particles = [ P.Z, P.G__minus__, P.G__plus__, P.H, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VSSSSSS1 ],
                couplings = {(0,0):C.GC_2855})

V_1502 = Vertex(name = 'V_1502',
                particles = [ P.A, P.A, P.Z, P.G0 ],
                color = [ '1' ],
                lorentz = [ L.VVVS123, L.VVVS124, L.VVVS42, L.VVVS76 ],
                couplings = {(0,0):C.GC_6991,(0,2):C.GC_6990,(0,3):C.GC_6987,(0,1):C.GC_4421})

V_1503 = Vertex(name = 'V_1503',
                particles = [ P.A, P.A, P.Z, P.G0, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSS101, L.VVVSS176, L.VVVSS292, L.VVVSS297 ],
                couplings = {(0,2):C.GC_7106,(0,0):C.GC_7105,(0,1):C.GC_7092,(0,3):C.GC_4478})

V_1504 = Vertex(name = 'V_1504',
                particles = [ P.A, P.Z, P.Z, P.G0 ],
                color = [ '1' ],
                lorentz = [ L.VVVS128, L.VVVS136, L.VVVS145, L.VVVS44, L.VVVS96 ],
                couplings = {(0,1):C.GC_2426,(0,2):C.GC_2842,(0,0):C.GC_6980,(0,3):C.GC_6982,(0,4):C.GC_6981})

V_1505 = Vertex(name = 'V_1505',
                particles = [ P.A, P.Z, P.Z, P.G0, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSS100, L.VVVSS215, L.VVVSS300, L.VVVSS313, L.VVVSS323 ],
                couplings = {(0,4):C.GC_2507,(0,3):C.GC_2867,(0,2):C.GC_7071,(0,0):C.GC_7079,(0,1):C.GC_7075})

V_1506 = Vertex(name = 'V_1506',
                particles = [ P.A, P.Z, P.Z, P.Z, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSS408, L.VVVVSS409, L.VVVVSS413, L.VVVVSS415, L.VVVVSS419, L.VVVVSS436, L.VVVVSS450, L.VVVVSS466, L.VVVVSS468, L.VVVVSS469, L.VVVVSS609, L.VVVVSS620, L.VVVVSS642, L.VVVVSS653, L.VVVVSS654, L.VVVVSS659, L.VVVVSS660, L.VVVVSS661, L.VVVVSS674, L.VVVVSS675, L.VVVVSS676, L.VVVVSS681, L.VVVVSS682 ],
                couplings = {(0,9):C.GC_1004,(0,7):C.GC_2067,(0,8):C.GC_2244,(0,6):C.GC_3117,(0,14):C.GC_1002,(0,15):C.GC_6143,(0,12):C.GC_6110,(0,1):C.GC_998,(0,2):C.GC_6145,(0,19):C.GC_997,(0,20):C.GC_6144,(0,5):C.GC_6114,(0,11):C.GC_6112,(0,17):C.GC_3911,(0,16):C.GC_4191,(0,13):C.GC_4221,(0,4):C.GC_3913,(0,3):C.GC_4193,(0,0):C.GC_4223,(0,22):C.GC_3912,(0,21):C.GC_4192,(0,18):C.GC_4222,(0,10):C.GC_7367})

V_1507 = Vertex(name = 'V_1507',
                particles = [ P.Z, P.Z, P.Z, P.G0 ],
                color = [ '1' ],
                lorentz = [ L.VVVS120, L.VVVS122, L.VVVS131, L.VVVS137, L.VVVS43 ],
                couplings = {(0,2):C.GC_6992,(0,4):C.GC_6989,(0,1):C.GC_6988,(0,0):C.GC_5083,(0,3):C.GC_4422})

V_1508 = Vertex(name = 'V_1508',
                particles = [ P.Z, P.Z, P.Z, P.G0, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSS102, L.VVVSS273, L.VVVSS291, L.VVVSS305, L.VVVSS324 ],
                couplings = {(0,3):C.GC_7114,(0,0):C.GC_7099,(0,2):C.GC_7098,(0,1):C.GC_5085,(0,4):C.GC_4479})

V_1509 = Vertex(name = 'V_1509',
                particles = [ P.Z, P.Z, P.Z, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVSS102, L.VVVSS267, L.VVVSS291, L.VVVSS305, L.VVVSS312, L.VVVSS324 ],
                couplings = {(0,3):C.GC_7110,(0,0):C.GC_7100,(0,2):C.GC_7096,(0,1):C.GC_5084,(0,4):C.GC_7115,(0,5):C.GC_7118})

V_1510 = Vertex(name = 'V_1510',
                particles = [ P.W__minus__, P.Z, P.G0, P.G0, P.G__minus__, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSS1 ],
                couplings = {(0,0):C.GC_3564})

V_1511 = Vertex(name = 'V_1511',
                particles = [ P.W__minus__, P.Z, P.G0, P.G0, P.G0, P.G__minus__, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSSS1 ],
                couplings = {(0,0):C.GC_3652})

V_1512 = Vertex(name = 'V_1512',
                particles = [ P.W__minus__, P.Z, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSS1 ],
                couplings = {(0,0):C.GC_3566})

V_1513 = Vertex(name = 'V_1513',
                particles = [ P.W__minus__, P.Z, P.G0, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSSS1 ],
                couplings = {(0,0):C.GC_3651})

V_1514 = Vertex(name = 'V_1514',
                particles = [ P.W__minus__, P.Z, P.G0, P.G__minus__, P.G__plus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSS1 ],
                couplings = {(0,0):C.GC_3567})

V_1515 = Vertex(name = 'V_1515',
                particles = [ P.W__minus__, P.Z, P.G0, P.G0, P.G__minus__, P.G__plus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSSS1 ],
                couplings = {(0,0):C.GC_3647})

V_1516 = Vertex(name = 'V_1516',
                particles = [ P.W__minus__, P.Z, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSSS1 ],
                couplings = {(0,0):C.GC_3649})

V_1517 = Vertex(name = 'V_1517',
                particles = [ P.W__minus__, P.Z, P.G__minus__, P.G__plus__, P.G__plus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSS1 ],
                couplings = {(0,0):C.GC_3565})

V_1518 = Vertex(name = 'V_1518',
                particles = [ P.W__minus__, P.Z, P.G0, P.G__minus__, P.G__plus__, P.G__plus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSSS1 ],
                couplings = {(0,0):C.GC_3650})

V_1519 = Vertex(name = 'V_1519',
                particles = [ P.W__minus__, P.Z, P.G__minus__, P.G__plus__, P.G__plus__, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSSS1 ],
                couplings = {(0,0):C.GC_3648})

V_1520 = Vertex(name = 'V_1520',
                particles = [ P.W__minus__, P.Z, P.G0, P.G0, P.G0, P.G0, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSS1 ],
                couplings = {(0,0):C.GC_2900})

V_1521 = Vertex(name = 'V_1521',
                particles = [ P.W__minus__, P.Z, P.G0, P.G0, P.G0, P.G0, P.G0, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSSS1 ],
                couplings = {(0,0):C.GC_2952})

V_1522 = Vertex(name = 'V_1522',
                particles = [ P.W__minus__, P.Z, P.G0, P.G0, P.G0, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSS1 ],
                couplings = {(0,0):C.GC_2902})

V_1523 = Vertex(name = 'V_1523',
                particles = [ P.W__minus__, P.Z, P.G0, P.G0, P.G0, P.G0, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSSS1 ],
                couplings = {(0,0):C.GC_2949})

V_1524 = Vertex(name = 'V_1524',
                particles = [ P.W__minus__, P.Z, P.G0, P.G0, P.G__plus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSS1 ],
                couplings = {(0,0):C.GC_2900})

V_1525 = Vertex(name = 'V_1525',
                particles = [ P.W__minus__, P.Z, P.G0, P.G0, P.G0, P.G__plus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSSS1 ],
                couplings = {(0,0):C.GC_2951})

V_1526 = Vertex(name = 'V_1526',
                particles = [ P.W__minus__, P.Z, P.G0, P.G__plus__, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSS1 ],
                couplings = {(0,0):C.GC_2902})

V_1527 = Vertex(name = 'V_1527',
                particles = [ P.W__minus__, P.Z, P.G0, P.G0, P.G__plus__, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSSS1 ],
                couplings = {(0,0):C.GC_2949})

V_1528 = Vertex(name = 'V_1528',
                particles = [ P.W__minus__, P.Z, P.G__plus__, P.H, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSS1 ],
                couplings = {(0,0):C.GC_2901})

V_1529 = Vertex(name = 'V_1529',
                particles = [ P.W__minus__, P.Z, P.G0, P.G__plus__, P.H, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSSS1 ],
                couplings = {(0,0):C.GC_2951})

V_1530 = Vertex(name = 'V_1530',
                particles = [ P.W__minus__, P.Z, P.G__plus__, P.H, P.H, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSSS1 ],
                couplings = {(0,0):C.GC_2950})

V_1531 = Vertex(name = 'V_1531',
                particles = [ P.A, P.A, P.W__minus__, P.Z, P.G__minus__, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS10, L.VVVVSSS11, L.VVVVSSS13, L.VVVVSSS15, L.VVVVSSS16, L.VVVVSSS5 ],
                couplings = {(0,5):C.GC_3722,(0,2):C.GC_1451,(0,1):C.GC_2059,(0,3):C.GC_2787,(0,0):C.GC_3796,(0,4):C.GC_3067})

V_1532 = Vertex(name = 'V_1532',
                particles = [ P.A, P.A, P.W__minus__, P.Z, P.G0, P.G__minus__, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS10, L.VVVVSSSS11, L.VVVVSSSS13, L.VVVVSSSS15, L.VVVVSSSS16, L.VVVVSSSS5 ],
                couplings = {(0,2):C.GC_1455,(0,1):C.GC_2061,(0,3):C.GC_2800,(0,0):C.GC_3820,(0,4):C.GC_3073,(0,5):C.GC_3777})

V_1533 = Vertex(name = 'V_1533',
                particles = [ P.A, P.A, P.W__minus__, P.Z, P.G__minus__, P.G__plus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS10, L.VVVVSSSS11, L.VVVVSSSS13, L.VVVVSSSS15, L.VVVVSSSS16, L.VVVVSSSS5 ],
                couplings = {(0,2):C.GC_1454,(0,1):C.GC_2062,(0,3):C.GC_2801,(0,0):C.GC_3816,(0,4):C.GC_3072,(0,5):C.GC_3769})

V_1534 = Vertex(name = 'V_1534',
                particles = [ P.W__minus__, P.Z, P.Z, P.G0, P.G0, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVSSS101, L.VVVSSS109, L.VVVSSS123, L.VVVSSS182, L.VVVSSS197, L.VVVSSS45, L.VVVSSS59, L.VVVSSS7 ],
                couplings = {(0,7):C.GC_6623,(0,6):C.GC_6289,(0,5):C.GC_1413,(0,1):C.GC_5014,(0,3):C.GC_3125,(0,0):C.GC_1066,(0,4):C.GC_900,(0,2):C.GC_905})

V_1535 = Vertex(name = 'V_1535',
                particles = [ P.W__minus__, P.Z, P.Z, P.G0, P.G0, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVSSS59, L.VVVSSS7 ],
                couplings = {(0,1):C.GC_6302,(0,0):C.GC_6609})

V_1536 = Vertex(name = 'V_1536',
                particles = [ P.W__minus__, P.Z, P.Z, P.G0, P.G0, P.G0, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS133, L.VVVSSSS166, L.VVVSSSS176, L.VVVSSSS196, L.VVVSSSS339, L.VVVSSSS64, L.VVVSSSS7, L.VVVSSSS84 ],
                couplings = {(0,6):C.GC_6658,(0,4):C.GC_1015,(0,3):C.GC_1020,(0,1):C.GC_2251,(0,0):C.GC_1416,(0,7):C.GC_6513,(0,5):C.GC_5023,(0,2):C.GC_3139})

V_1537 = Vertex(name = 'V_1537',
                particles = [ P.W__minus__, P.Z, P.Z, P.G0, P.G0, P.G0, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS133, L.VVVSSSS7, L.VVVSSSS84 ],
                couplings = {(0,1):C.GC_6531,(0,0):C.GC_2259,(0,2):C.GC_4199})

V_1538 = Vertex(name = 'V_1538',
                particles = [ P.W__minus__, P.Z, P.Z, P.G__minus__, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVSSS129, L.VVVSSS134, L.VVVSSS136, L.VVVSSS137, L.VVVSSS146, L.VVVSSS153, L.VVVSSS191, L.VVVSSS195, L.VVVSSS59, L.VVVSSS67, L.VVVSSS7, L.VVVSSS83 ],
                couplings = {(0,10):C.GC_6625,(0,8):C.GC_6293,(0,1):C.GC_1069,(0,3):C.GC_1073,(0,4):C.GC_1082,(0,0):C.GC_1781,(0,2):C.GC_5016,(0,5):C.GC_3127,(0,9):C.GC_2263,(0,6):C.GC_901,(0,11):C.GC_906,(0,7):C.GC_2186})

V_1539 = Vertex(name = 'V_1539',
                particles = [ P.W__minus__, P.Z, P.Z, P.G__minus__, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVSSS59, L.VVVSSS7 ],
                couplings = {(0,1):C.GC_6306,(0,0):C.GC_6611})

V_1540 = Vertex(name = 'V_1540',
                particles = [ P.W__minus__, P.Z, P.Z, P.G0, P.G__minus__, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS104, L.VVVSSSS123, L.VVVSSSS126, L.VVVSSSS216, L.VVVSSSS221, L.VVVSSSS226, L.VVVSSSS234, L.VVVSSSS247, L.VVVSSSS258, L.VVVSSSS269, L.VVVSSSS318, L.VVVSSSS324, L.VVVSSSS7, L.VVVSSSS84 ],
                couplings = {(0,12):C.GC_6655,(0,10):C.GC_1014,(0,2):C.GC_1030,(0,0):C.GC_2250,(0,11):C.GC_2255,(0,13):C.GC_6515,(0,5):C.GC_1116,(0,9):C.GC_1127,(0,3):C.GC_2280,(0,1):C.GC_2283,(0,6):C.GC_5022,(0,7):C.GC_1138,(0,4):C.GC_2286,(0,8):C.GC_3138})

V_1541 = Vertex(name = 'V_1541',
                particles = [ P.W__minus__, P.Z, P.Z, P.G0, P.G__minus__, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS7, L.VVVSSSS84 ],
                couplings = {(0,0):C.GC_6532,(0,1):C.GC_4198})

V_1542 = Vertex(name = 'V_1542',
                particles = [ P.W__minus__, P.Z, P.Z, P.G0, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSS111, L.VVVSSS116, L.VVVSSS144, L.VVVSSS200, L.VVVSSS49, L.VVVSSS59, L.VVVSSS65, L.VVVSSS7, L.VVVSSS81, L.VVVSSS84, L.VVVSSS98 ],
                couplings = {(0,7):C.GC_6620,(0,5):C.GC_6285,(0,1):C.GC_1070,(0,8):C.GC_1077,(0,4):C.GC_1083,(0,2):C.GC_5013,(0,10):C.GC_3124,(0,0):C.GC_898,(0,3):C.GC_903,(0,9):C.GC_2182,(0,6):C.GC_2187})

V_1543 = Vertex(name = 'V_1543',
                particles = [ P.W__minus__, P.Z, P.Z, P.G0, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSS59, L.VVVSSS7 ],
                couplings = {(0,1):C.GC_6299,(0,0):C.GC_4146})

V_1544 = Vertex(name = 'V_1544',
                particles = [ P.W__minus__, P.Z, P.Z, P.G0, P.G0, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS173, L.VVVSSSS181, L.VVVSSSS182, L.VVVSSSS195, L.VVVSSSS241, L.VVVSSSS332, L.VVVSSSS342, L.VVVSSSS347, L.VVVSSSS65, L.VVVSSSS7, L.VVVSSSS84 ],
                couplings = {(0,9):C.GC_6661,(0,6):C.GC_1017,(0,3):C.GC_1024,(0,7):C.GC_2248,(0,2):C.GC_2257,(0,10):C.GC_6521,(0,1):C.GC_1120,(0,8):C.GC_1133,(0,0):C.GC_5024,(0,4):C.GC_3140,(0,5):C.GC_1106})

V_1545 = Vertex(name = 'V_1545',
                particles = [ P.W__minus__, P.Z, P.Z, P.G0, P.G0, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS7, L.VVVSSSS84 ],
                couplings = {(0,0):C.GC_6536,(0,1):C.GC_4200})

V_1546 = Vertex(name = 'V_1546',
                particles = [ P.W__minus__, P.Z, P.Z, P.G__minus__, P.G__plus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS140, L.VVVSSSS142, L.VVVSSSS145, L.VVVSSSS147, L.VVVSSSS186, L.VVVSSSS199, L.VVVSSSS310, L.VVVSSSS325, L.VVVSSSS336, L.VVVSSSS340, L.VVVSSSS347, L.VVVSSSS7, L.VVVSSSS84, L.VVVSSSS93 ],
                couplings = {(0,11):C.GC_6663,(0,9):C.GC_1018,(0,4):C.GC_1025,(0,10):C.GC_2247,(0,5):C.GC_2258,(0,12):C.GC_6525,(0,1):C.GC_1112,(0,3):C.GC_1121,(0,7):C.GC_1136,(0,0):C.GC_2282,(0,8):C.GC_2288,(0,2):C.GC_5026,(0,6):C.GC_3142,(0,13):C.GC_2284})

V_1547 = Vertex(name = 'V_1547',
                particles = [ P.W__minus__, P.Z, P.Z, P.G__minus__, P.G__plus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS7, L.VVVSSSS84 ],
                couplings = {(0,0):C.GC_6540,(0,1):C.GC_4201})

V_1548 = Vertex(name = 'V_1548',
                particles = [ P.W__minus__, P.Z, P.Z, P.G__plus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSS118, L.VVVSSS164, L.VVVSSS180, L.VVVSSS181, L.VVVSSS196, L.VVVSSS50, L.VVVSSS59, L.VVVSSS7 ],
                couplings = {(0,7):C.GC_6627,(0,6):C.GC_6297,(0,5):C.GC_5017,(0,0):C.GC_1409,(0,1):C.GC_3128,(0,3):C.GC_902,(0,2):C.GC_909,(0,4):C.GC_2181})

V_1549 = Vertex(name = 'V_1549',
                particles = [ P.W__minus__, P.Z, P.Z, P.G__plus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSS118, L.VVVSSS59, L.VVVSSS7 ],
                couplings = {(0,2):C.GC_6310,(0,1):C.GC_4147,(0,0):C.GC_2185})

V_1550 = Vertex(name = 'V_1550',
                particles = [ P.W__minus__, P.Z, P.Z, P.G0, P.G__plus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS102, L.VVVSSSS104, L.VVVSSSS120, L.VVVSSSS128, L.VVVSSSS191, L.VVVSSSS248, L.VVVSSSS345, L.VVVSSSS7, L.VVVSSSS70, L.VVVSSSS84, L.VVVSSSS91 ],
                couplings = {(0,7):C.GC_6651,(0,3):C.GC_1012,(0,6):C.GC_1022,(0,1):C.GC_2249,(0,10):C.GC_2259,(0,9):C.GC_6517,(0,4):C.GC_1113,(0,0):C.GC_1125,(0,8):C.GC_1137,(0,5):C.GC_5021,(0,2):C.GC_3138})

V_1551 = Vertex(name = 'V_1551',
                particles = [ P.W__minus__, P.Z, P.Z, P.G0, P.G__plus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS7, L.VVVSSSS84 ],
                couplings = {(0,0):C.GC_6533,(0,1):C.GC_4197})

V_1552 = Vertex(name = 'V_1552',
                particles = [ P.W__minus__, P.Z, P.Z, P.G__plus__, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS192, L.VVVSSSS272, L.VVVSSSS298, L.VVVSSSS299, L.VVVSSSS326, L.VVVSSSS7, L.VVVSSSS71, L.VVVSSSS84 ],
                couplings = {(0,5):C.GC_6665,(0,3):C.GC_1019,(0,2):C.GC_1028,(0,4):C.GC_2246,(0,0):C.GC_1418,(0,7):C.GC_6529,(0,6):C.GC_5027,(0,1):C.GC_3143})

V_1553 = Vertex(name = 'V_1553',
                particles = [ P.W__minus__, P.Z, P.Z, P.G__plus__, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS192, L.VVVSSSS7, L.VVVSSSS84 ],
                couplings = {(0,1):C.GC_6544,(0,0):C.GC_2257,(0,2):C.GC_4202})

V_1554 = Vertex(name = 'V_1554',
                particles = [ P.A, P.W__minus__, P.W__minus__, P.Z, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSS242, L.VVVVSS605, L.VVVVSS606, L.VVVVSS608 ],
                couplings = {(0,1):C.GC_6779,(0,2):C.GC_6130,(0,0):C.GC_4366,(0,3):C.GC_6851})

V_1555 = Vertex(name = 'V_1555',
                particles = [ P.A, P.W__minus__, P.W__minus__, P.Z, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSS605 ],
                couplings = {(0,0):C.GC_4144})

V_1556 = Vertex(name = 'V_1556',
                particles = [ P.A, P.W__minus__, P.W__minus__, P.Z, P.G0, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS12, L.VVVVSSS2, L.VVVVSSS7, L.VVVVSSS8 ],
                couplings = {(0,2):C.GC_6803,(0,3):C.GC_6134,(0,1):C.GC_4367,(0,0):C.GC_6852})

V_1557 = Vertex(name = 'V_1557',
                particles = [ P.A, P.W__minus__, P.W__minus__, P.Z, P.G0, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS7 ],
                couplings = {(0,0):C.GC_4159})

V_1558 = Vertex(name = 'V_1558',
                particles = [ P.A, P.W__minus__, P.W__minus__, P.Z, P.G0, P.G0, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS12, L.VVVVSSSS2, L.VVVVSSSS7, L.VVVVSSSS8 ],
                couplings = {(0,3):C.GC_6139,(0,1):C.GC_4375,(0,0):C.GC_6859,(0,2):C.GC_6849})

V_1559 = Vertex(name = 'V_1559',
                particles = [ P.A, P.W__minus__, P.W__minus__, P.Z, P.G0, P.G0, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS7 ],
                couplings = {(0,0):C.GC_4232})

V_1560 = Vertex(name = 'V_1560',
                particles = [ P.A, P.W__minus__, P.W__minus__, P.Z, P.G__plus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS12, L.VVVVSSS2, L.VVVVSSS7, L.VVVVSSS8 ],
                couplings = {(0,2):C.GC_6805,(0,3):C.GC_6133,(0,1):C.GC_4369,(0,0):C.GC_6854})

V_1561 = Vertex(name = 'V_1561',
                particles = [ P.A, P.W__minus__, P.W__minus__, P.Z, P.G__plus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS7 ],
                couplings = {(0,0):C.GC_4158})

V_1562 = Vertex(name = 'V_1562',
                particles = [ P.A, P.W__minus__, P.W__minus__, P.Z, P.G0, P.G__plus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS12, L.VVVVSSSS2, L.VVVVSSSS7, L.VVVVSSSS8 ],
                couplings = {(0,3):C.GC_6140,(0,1):C.GC_4373,(0,0):C.GC_6858,(0,2):C.GC_6848})

V_1563 = Vertex(name = 'V_1563',
                particles = [ P.A, P.W__minus__, P.W__minus__, P.Z, P.G0, P.G__plus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS7 ],
                couplings = {(0,0):C.GC_4233})

V_1564 = Vertex(name = 'V_1564',
                particles = [ P.A, P.W__minus__, P.W__minus__, P.Z, P.G__plus__, P.G__plus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS12, L.VVVVSSSS2, L.VVVVSSSS7, L.VVVVSSSS8 ],
                couplings = {(0,3):C.GC_6138,(0,1):C.GC_4376,(0,0):C.GC_6861,(0,2):C.GC_6850})

V_1565 = Vertex(name = 'V_1565',
                particles = [ P.A, P.W__minus__, P.W__minus__, P.Z, P.G__plus__, P.G__plus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS7 ],
                couplings = {(0,0):C.GC_4231})

V_1566 = Vertex(name = 'V_1566',
                particles = [ P.A, P.A, P.A, P.W__minus__, P.Z, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVS1, L.VVVVVS27, L.VVVVVS29, L.VVVVVS33, L.VVVVVS51, L.VVVVVS53, L.VVVVVS54 ],
                couplings = {(0,0):C.GC_1802,(0,1):C.GC_1795,(0,5):C.GC_6785,(0,6):C.GC_1799,(0,4):C.GC_1794,(0,2):C.GC_6786,(0,3):C.GC_6788})

V_1567 = Vertex(name = 'V_1567',
                particles = [ P.A, P.A, P.A, P.W__minus__, P.Z, P.G0, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVSS1, L.VVVVVSS34, L.VVVVVSS36, L.VVVVVSS44, L.VVVVVSS64, L.VVVVVSS66, L.VVVVVSS67 ],
                couplings = {(0,0):C.GC_1856,(0,1):C.GC_1847,(0,5):C.GC_6806,(0,6):C.GC_1854,(0,4):C.GC_1842,(0,2):C.GC_6815,(0,3):C.GC_6817})

V_1568 = Vertex(name = 'V_1568',
                particles = [ P.A, P.A, P.A, P.W__minus__, P.Z, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVVSS1, L.VVVVVSS34, L.VVVVVSS36, L.VVVVVSS44, L.VVVVVSS64, L.VVVVVSS66, L.VVVVVSS67 ],
                couplings = {(0,0):C.GC_1859,(0,1):C.GC_1845,(0,5):C.GC_6811,(0,6):C.GC_1852,(0,4):C.GC_1844,(0,2):C.GC_6816,(0,3):C.GC_6819})

V_1569 = Vertex(name = 'V_1569',
                particles = [ P.A, P.A, P.W__minus__, P.Z, P.Z, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVS140, L.VVVVVS143, L.VVVVVS15, L.VVVVVS16, L.VVVVVS164, L.VVVVVS171, L.VVVVVS181, L.VVVVVS183, L.VVVVVS28, L.VVVVVS63, L.VVVVVS64, L.VVVVVS68, L.VVVVVS79, L.VVVVVS81 ],
                couplings = {(0,11):C.GC_1089,(0,13):C.GC_1791,(0,9):C.GC_2269,(0,8):C.GC_3131,(0,7):C.GC_6793,(0,3):C.GC_6797,(0,2):C.GC_4001,(0,12):C.GC_4295,(0,10):C.GC_3996,(0,6):C.GC_3999,(0,1):C.GC_4293,(0,5):C.GC_4304,(0,4):C.GC_3998,(0,0):C.GC_3995})

V_1570 = Vertex(name = 'V_1570',
                particles = [ P.A, P.A, P.W__minus__, P.Z, P.Z, P.G0, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVSS106, L.VVVVVSS108, L.VVVVVSS193, L.VVVVVSS196, L.VVVVVSS20, L.VVVVVSS22, L.VVVVVSS221, L.VVVVVSS230, L.VVVVVSS241, L.VVVVVSS245, L.VVVVVSS35, L.VVVVVSS81, L.VVVVVSS82, L.VVVVVSS87 ],
                couplings = {(0,13):C.GC_1150,(0,1):C.GC_1838,(0,11):C.GC_2300,(0,10):C.GC_3148,(0,9):C.GC_6826,(0,5):C.GC_6844,(0,4):C.GC_4056,(0,0):C.GC_4351,(0,12):C.GC_4048,(0,8):C.GC_4054,(0,3):C.GC_4340,(0,7):C.GC_4356,(0,6):C.GC_4050,(0,2):C.GC_4043})

V_1571 = Vertex(name = 'V_1571',
                particles = [ P.A, P.A, P.W__minus__, P.Z, P.Z, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVVSS106, L.VVVVVSS108, L.VVVVVSS193, L.VVVVVSS196, L.VVVVVSS20, L.VVVVVSS22, L.VVVVVSS221, L.VVVVVSS230, L.VVVVVSS241, L.VVVVVSS245, L.VVVVVSS35, L.VVVVVSS81, L.VVVVVSS82, L.VVVVVSS87 ],
                couplings = {(0,13):C.GC_1149,(0,1):C.GC_1840,(0,11):C.GC_2301,(0,10):C.GC_3149,(0,9):C.GC_6830,(0,5):C.GC_6837,(0,4):C.GC_4055,(0,0):C.GC_4347,(0,12):C.GC_4046,(0,8):C.GC_4052,(0,3):C.GC_4342,(0,7):C.GC_4362,(0,6):C.GC_4051,(0,2):C.GC_4045})

V_1572 = Vertex(name = 'V_1572',
                particles = [ P.W__minus__, P.Z, P.Z, P.Z, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVS108, L.VVVVS150, L.VVVVS155, L.VVVVS158, L.VVVVS16, L.VVVVS169, L.VVVVS175, L.VVVVS180, L.VVVVS184, L.VVVVS198, L.VVVVS202, L.VVVVS213, L.VVVVS253, L.VVVVS259, L.VVVVS76, L.VVVVS79, L.VVVVS91, L.VVVVS92, L.VVVVS94, L.VVVVS98 ],
                couplings = {(0,3):C.GC_2563,(0,17):C.GC_2911,(0,5):C.GC_2567,(0,10):C.GC_6167,(0,4):C.GC_6164,(0,11):C.GC_6162,(0,13):C.GC_7186,(0,6):C.GC_5095,(0,0):C.GC_4074,(0,2):C.GC_4563,(0,16):C.GC_4847,(0,18):C.GC_4088,(0,19):C.GC_4090,(0,1):C.GC_4559,(0,15):C.GC_4552,(0,12):C.GC_4557,(0,9):C.GC_4846,(0,7):C.GC_4549,(0,14):C.GC_4845,(0,8):C.GC_4844})

V_1573 = Vertex(name = 'V_1573',
                particles = [ P.W__minus__, P.Z, P.Z, P.Z, P.G0, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSS204, L.VVVVSS205, L.VVVVSS412, L.VVVVSS436, L.VVVVSS450, L.VVVVSS451, L.VVVVSS471, L.VVVVSS486, L.VVVVSS489, L.VVVVSS490, L.VVVVSS492, L.VVVVSS554, L.VVVVSS567, L.VVVVSS569, L.VVVVSS595, L.VVVVSS609, L.VVVVSS620, L.VVVVSS632, L.VVVVSS642, L.VVVVSS646, L.VVVVSS664, L.VVVVSS666, L.VVVVSS688, L.VVVVSS689, L.VVVVSS757, L.VVVVSS773 ],
                couplings = {(0,13):C.GC_2638,(0,5):C.GC_2972,(0,9):C.GC_2087,(0,8):C.GC_2091,(0,14):C.GC_2641,(0,19):C.GC_3582,(0,0):C.GC_3586,(0,20):C.GC_3585,(0,22):C.GC_6180,(0,25):C.GC_7226,(0,15):C.GC_5098,(0,12):C.GC_4677,(0,4):C.GC_4862,(0,7):C.GC_4112,(0,10):C.GC_4114,(0,11):C.GC_4674,(0,1):C.GC_4104,(0,2):C.GC_4658,(0,24):C.GC_4672,(0,18):C.GC_4857,(0,23):C.GC_4109,(0,21):C.GC_4103,(0,17):C.GC_4652,(0,3):C.GC_4856,(0,16):C.GC_4853,(0,6):C.GC_4081})

V_1574 = Vertex(name = 'V_1574',
                particles = [ P.W__minus__, P.Z, P.Z, P.Z, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSS204, L.VVVVSS206, L.VVVVSS436, L.VVVVSS439, L.VVVVSS450, L.VVVVSS451, L.VVVVSS471, L.VVVVSS543, L.VVVVSS554, L.VVVVSS563, L.VVVVSS565, L.VVVVSS592, L.VVVVSS593, L.VVVVSS595, L.VVVVSS601, L.VVVVSS609, L.VVVVSS616, L.VVVVSS620, L.VVVVSS642, L.VVVVSS646, L.VVVVSS664, L.VVVVSS672, L.VVVVSS754, L.VVVVSS771, L.VVVVSS772, L.VVVVSS773 ],
                couplings = {(0,10):C.GC_2634,(0,5):C.GC_2973,(0,13):C.GC_2643,(0,12):C.GC_2086,(0,11):C.GC_2090,(0,19):C.GC_3581,(0,0):C.GC_3587,(0,20):C.GC_3584,(0,25):C.GC_7228,(0,23):C.GC_6178,(0,15):C.GC_5097,(0,9):C.GC_4681,(0,4):C.GC_4861,(0,7):C.GC_4113,(0,14):C.GC_4116,(0,8):C.GC_4673,(0,3):C.GC_4657,(0,1):C.GC_4105,(0,22):C.GC_4669,(0,18):C.GC_4858,(0,24):C.GC_4108,(0,21):C.GC_4101,(0,16):C.GC_4650,(0,2):C.GC_4855,(0,17):C.GC_4852,(0,6):C.GC_4079})

V_1575 = Vertex(name = 'V_1575',
                particles = [ P.W__plus__, P.Z, P.G0, P.G0, P.G__minus__, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSS1 ],
                couplings = {(0,0):C.GC_3564})

V_1576 = Vertex(name = 'V_1576',
                particles = [ P.W__plus__, P.Z, P.G0, P.G0, P.G0, P.G__minus__, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSSS1 ],
                couplings = {(0,0):C.GC_3644})

V_1577 = Vertex(name = 'V_1577',
                particles = [ P.W__plus__, P.Z, P.G__minus__, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSS1 ],
                couplings = {(0,0):C.GC_3566})

V_1578 = Vertex(name = 'V_1578',
                particles = [ P.W__plus__, P.Z, P.G0, P.G__minus__, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSSS1 ],
                couplings = {(0,0):C.GC_3645})

V_1579 = Vertex(name = 'V_1579',
                particles = [ P.W__plus__, P.Z, P.G0, P.G__minus__, P.G__minus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSS1 ],
                couplings = {(0,0):C.GC_3563})

V_1580 = Vertex(name = 'V_1580',
                particles = [ P.W__plus__, P.Z, P.G0, P.G0, P.G__minus__, P.G__minus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSSS1 ],
                couplings = {(0,0):C.GC_3647})

V_1581 = Vertex(name = 'V_1581',
                particles = [ P.W__plus__, P.Z, P.G__minus__, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSSS1 ],
                couplings = {(0,0):C.GC_3649})

V_1582 = Vertex(name = 'V_1582',
                particles = [ P.W__plus__, P.Z, P.G__minus__, P.G__minus__, P.G__plus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSS1 ],
                couplings = {(0,0):C.GC_3565})

V_1583 = Vertex(name = 'V_1583',
                particles = [ P.W__plus__, P.Z, P.G0, P.G__minus__, P.G__minus__, P.G__plus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSSS1 ],
                couplings = {(0,0):C.GC_3646})

V_1584 = Vertex(name = 'V_1584',
                particles = [ P.W__plus__, P.Z, P.G__minus__, P.G__minus__, P.G__plus__, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSSS1 ],
                couplings = {(0,0):C.GC_3648})

V_1585 = Vertex(name = 'V_1585',
                particles = [ P.W__plus__, P.Z, P.G0, P.G0, P.G0, P.G0, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSS1 ],
                couplings = {(0,0):C.GC_2900})

V_1586 = Vertex(name = 'V_1586',
                particles = [ P.W__plus__, P.Z, P.G0, P.G0, P.G0, P.G0, P.G0, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSSS1 ],
                couplings = {(0,0):C.GC_2947})

V_1587 = Vertex(name = 'V_1587',
                particles = [ P.W__plus__, P.Z, P.G0, P.G0, P.G0, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSS1 ],
                couplings = {(0,0):C.GC_2899})

V_1588 = Vertex(name = 'V_1588',
                particles = [ P.W__plus__, P.Z, P.G0, P.G0, P.G0, P.G0, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSSS1 ],
                couplings = {(0,0):C.GC_2949})

V_1589 = Vertex(name = 'V_1589',
                particles = [ P.W__plus__, P.Z, P.G0, P.G0, P.G__minus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSS1 ],
                couplings = {(0,0):C.GC_2900})

V_1590 = Vertex(name = 'V_1590',
                particles = [ P.W__plus__, P.Z, P.G0, P.G0, P.G0, P.G__minus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSSS1 ],
                couplings = {(0,0):C.GC_2948})

V_1591 = Vertex(name = 'V_1591',
                particles = [ P.W__plus__, P.Z, P.G0, P.G__minus__, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSS1 ],
                couplings = {(0,0):C.GC_2899})

V_1592 = Vertex(name = 'V_1592',
                particles = [ P.W__plus__, P.Z, P.G0, P.G0, P.G__minus__, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSSS1 ],
                couplings = {(0,0):C.GC_2949})

V_1593 = Vertex(name = 'V_1593',
                particles = [ P.W__plus__, P.Z, P.G__minus__, P.H, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSS1 ],
                couplings = {(0,0):C.GC_2901})

V_1594 = Vertex(name = 'V_1594',
                particles = [ P.W__plus__, P.Z, P.G0, P.G__minus__, P.H, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSSS1 ],
                couplings = {(0,0):C.GC_2948})

V_1595 = Vertex(name = 'V_1595',
                particles = [ P.W__plus__, P.Z, P.G__minus__, P.H, P.H, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSSS1 ],
                couplings = {(0,0):C.GC_2950})

V_1596 = Vertex(name = 'V_1596',
                particles = [ P.A, P.A, P.W__plus__, P.Z, P.G__minus__, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS10, L.VVVVSSS11, L.VVVVSSS13, L.VVVVSSS15, L.VVVVSSS16, L.VVVVSSS5 ],
                couplings = {(0,5):C.GC_3724,(0,2):C.GC_1451,(0,1):C.GC_2059,(0,3):C.GC_2787,(0,0):C.GC_3796,(0,4):C.GC_3067})

V_1597 = Vertex(name = 'V_1597',
                particles = [ P.A, P.A, P.W__plus__, P.Z, P.G0, P.G__minus__, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS10, L.VVVVSSSS11, L.VVVVSSSS13, L.VVVVSSSS15, L.VVVVSSSS16, L.VVVVSSSS5 ],
                couplings = {(0,2):C.GC_1453,(0,1):C.GC_2063,(0,3):C.GC_2802,(0,0):C.GC_3807,(0,4):C.GC_3071,(0,5):C.GC_3778})

V_1598 = Vertex(name = 'V_1598',
                particles = [ P.A, P.A, P.W__plus__, P.Z, P.G__minus__, P.G__minus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS10, L.VVVVSSSS11, L.VVVVSSSS13, L.VVVVSSSS15, L.VVVVSSSS16, L.VVVVSSSS5 ],
                couplings = {(0,2):C.GC_1454,(0,1):C.GC_2062,(0,3):C.GC_2801,(0,0):C.GC_3816,(0,4):C.GC_3072,(0,5):C.GC_3771})

V_1599 = Vertex(name = 'V_1599',
                particles = [ P.A, P.A, P.W__plus__, P.Z, P.G0, P.G0, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS5 ],
                couplings = {(0,0):C.GC_3719})

V_1600 = Vertex(name = 'V_1600',
                particles = [ P.A, P.A, P.W__plus__, P.Z, P.G0, P.G0, P.G0, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_3763})

V_1601 = Vertex(name = 'V_1601',
                particles = [ P.A, P.A, P.W__plus__, P.Z, P.G0, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS5 ],
                couplings = {(0,0):C.GC_3718})

V_1602 = Vertex(name = 'V_1602',
                particles = [ P.A, P.A, P.W__plus__, P.Z, P.G0, P.G0, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_3766})

V_1603 = Vertex(name = 'V_1603',
                particles = [ P.A, P.A, P.W__plus__, P.Z, P.G__minus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS5 ],
                couplings = {(0,0):C.GC_3725})

V_1604 = Vertex(name = 'V_1604',
                particles = [ P.A, P.A, P.W__plus__, P.Z, P.G0, P.G__minus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_3765})

V_1605 = Vertex(name = 'V_1605',
                particles = [ P.A, P.A, P.W__plus__, P.Z, P.G__minus__, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_3772})

V_1606 = Vertex(name = 'V_1606',
                particles = [ P.W__plus__, P.Z, P.Z, P.G0, P.G0, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVSSS101, L.VVVSSS109, L.VVVSSS123, L.VVVSSS182, L.VVVSSS197, L.VVVSSS45, L.VVVSSS59, L.VVVSSS7 ],
                couplings = {(0,7):C.GC_6618,(0,6):C.GC_6287,(0,5):C.GC_1411,(0,1):C.GC_5015,(0,3):C.GC_3126,(0,0):C.GC_1065,(0,4):C.GC_896,(0,2):C.GC_905})

V_1607 = Vertex(name = 'V_1607',
                particles = [ P.W__plus__, P.Z, P.Z, P.G0, P.G0, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVSSS59, L.VVVSSS7 ],
                couplings = {(0,1):C.GC_6300,(0,0):C.GC_6607})

V_1608 = Vertex(name = 'V_1608',
                particles = [ P.W__plus__, P.Z, P.Z, P.G0, P.G0, P.G0, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS133, L.VVVSSSS166, L.VVVSSSS176, L.VVVSSSS196, L.VVVSSSS339, L.VVVSSSS64, L.VVVSSSS7, L.VVVSSSS84 ],
                couplings = {(0,6):C.GC_6659,(0,4):C.GC_1015,(0,3):C.GC_1031,(0,1):C.GC_2251,(0,0):C.GC_1416,(0,7):C.GC_6513,(0,5):C.GC_5023,(0,2):C.GC_3139})

V_1609 = Vertex(name = 'V_1609',
                particles = [ P.W__plus__, P.Z, P.Z, P.G0, P.G0, P.G0, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS133, L.VVVSSSS7, L.VVVSSSS84 ],
                couplings = {(0,1):C.GC_6531,(0,0):C.GC_2256,(0,2):C.GC_4199})

V_1610 = Vertex(name = 'V_1610',
                particles = [ P.W__plus__, P.Z, P.Z, P.G__minus__, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVSSS104, L.VVVSSS105, L.VVVSSS106, L.VVVSSS108, L.VVVSSS114, L.VVVSSS120, L.VVVSSS122, L.VVVSSS124, L.VVVSSS197, L.VVVSSS201, L.VVVSSS59, L.VVVSSS7 ],
                couplings = {(0,11):C.GC_6616,(0,10):C.GC_6291,(0,7):C.GC_1067,(0,5):C.GC_1075,(0,2):C.GC_1080,(0,3):C.GC_1779,(0,4):C.GC_2264,(0,6):C.GC_5016,(0,0):C.GC_3126,(0,1):C.GC_895,(0,8):C.GC_906,(0,9):C.GC_2186})

V_1611 = Vertex(name = 'V_1611',
                particles = [ P.W__plus__, P.Z, P.Z, P.G__minus__, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVSSS59, L.VVVSSS7 ],
                couplings = {(0,1):C.GC_6304,(0,0):C.GC_6605})

V_1612 = Vertex(name = 'V_1612',
                particles = [ P.W__plus__, P.Z, P.Z, P.G0, P.G__minus__, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS104, L.VVVSSSS140, L.VVVSSSS162, L.VVVSSSS164, L.VVVSSSS165, L.VVVSSSS168, L.VVVSSSS307, L.VVVSSSS328, L.VVVSSSS331, L.VVVSSSS337, L.VVVSSSS338, L.VVVSSSS341, L.VVVSSSS7, L.VVVSSSS84 ],
                couplings = {(0,12):C.GC_6656,(0,3):C.GC_1014,(0,8):C.GC_1021,(0,0):C.GC_2250,(0,11):C.GC_2260,(0,13):C.GC_6515,(0,6):C.GC_1116,(0,10):C.GC_1127,(0,1):C.GC_2280,(0,7):C.GC_2283,(0,9):C.GC_5022,(0,4):C.GC_1129,(0,5):C.GC_2289,(0,2):C.GC_3145})

V_1613 = Vertex(name = 'V_1613',
                particles = [ P.W__plus__, P.Z, P.Z, P.G0, P.G__minus__, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS7, L.VVVSSSS84 ],
                couplings = {(0,0):C.GC_6532,(0,1):C.GC_4198})

V_1614 = Vertex(name = 'V_1614',
                particles = [ P.W__plus__, P.Z, P.Z, P.G0, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSS111, L.VVVSSS116, L.VVVSSS144, L.VVVSSS200, L.VVVSSS49, L.VVVSSS59, L.VVVSSS65, L.VVVSSS7, L.VVVSSS81, L.VVVSSS84, L.VVVSSS98 ],
                couplings = {(0,7):C.GC_6621,(0,5):C.GC_6285,(0,1):C.GC_1070,(0,8):C.GC_1077,(0,4):C.GC_1083,(0,2):C.GC_5013,(0,10):C.GC_3124,(0,0):C.GC_898,(0,3):C.GC_910,(0,9):C.GC_2182,(0,6):C.GC_2184})

V_1615 = Vertex(name = 'V_1615',
                particles = [ P.W__plus__, P.Z, P.Z, P.G0, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSS59, L.VVVSSS7 ],
                couplings = {(0,1):C.GC_6299,(0,0):C.GC_4146})

V_1616 = Vertex(name = 'V_1616',
                particles = [ P.W__plus__, P.Z, P.Z, P.G0, P.G0, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS173, L.VVVSSSS181, L.VVVSSSS182, L.VVVSSSS195, L.VVVSSSS241, L.VVVSSSS332, L.VVVSSSS342, L.VVVSSSS347, L.VVVSSSS65, L.VVVSSSS7, L.VVVSSSS84 ],
                couplings = {(0,9):C.GC_6649,(0,6):C.GC_1010,(0,3):C.GC_1024,(0,7):C.GC_2252,(0,2):C.GC_2257,(0,10):C.GC_6519,(0,1):C.GC_1119,(0,8):C.GC_1132,(0,0):C.GC_5025,(0,4):C.GC_3141,(0,5):C.GC_1107})

V_1617 = Vertex(name = 'V_1617',
                particles = [ P.W__plus__, P.Z, P.Z, P.G0, P.G0, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS7, L.VVVSSSS84 ],
                couplings = {(0,0):C.GC_6534,(0,1):C.GC_4196})

V_1618 = Vertex(name = 'V_1618',
                particles = [ P.W__plus__, P.Z, P.Z, P.G__minus__, P.G__minus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS127, L.VVVSSSS130, L.VVVSSSS134, L.VVVSSSS136, L.VVVSSSS137, L.VVVSSSS172, L.VVVSSSS179, L.VVVSSSS187, L.VVVSSSS201, L.VVVSSSS202, L.VVVSSSS333, L.VVVSSSS347, L.VVVSSSS7, L.VVVSSSS84 ],
                couplings = {(0,12):C.GC_6646,(0,10):C.GC_1009,(0,8):C.GC_1025,(0,11):C.GC_2253,(0,9):C.GC_2258,(0,13):C.GC_6523,(0,4):C.GC_1110,(0,2):C.GC_1122,(0,6):C.GC_1134,(0,0):C.GC_2281,(0,1):C.GC_2285,(0,5):C.GC_2287,(0,3):C.GC_5026,(0,7):C.GC_3141})

V_1619 = Vertex(name = 'V_1619',
                particles = [ P.W__plus__, P.Z, P.Z, P.G__minus__, P.G__minus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS7, L.VVVSSSS84 ],
                couplings = {(0,0):C.GC_6538,(0,1):C.GC_4195})

V_1620 = Vertex(name = 'V_1620',
                particles = [ P.W__plus__, P.Z, P.Z, P.G__minus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSS118, L.VVVSSS164, L.VVVSSS180, L.VVVSSS181, L.VVVSSS196, L.VVVSSS50, L.VVVSSS59, L.VVVSSS7 ],
                couplings = {(0,7):C.GC_6614,(0,6):C.GC_6295,(0,5):C.GC_5018,(0,0):C.GC_1408,(0,1):C.GC_3129,(0,3):C.GC_894,(0,2):C.GC_909,(0,4):C.GC_2183})

V_1621 = Vertex(name = 'V_1621',
                particles = [ P.W__plus__, P.Z, P.Z, P.G__minus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSS118, L.VVVSSS59, L.VVVSSS7 ],
                couplings = {(0,2):C.GC_6308,(0,1):C.GC_4145,(0,0):C.GC_2185})

V_1622 = Vertex(name = 'V_1622',
                particles = [ P.W__plus__, P.Z, P.Z, P.G0, P.G__minus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS102, L.VVVSSSS104, L.VVVSSSS120, L.VVVSSSS128, L.VVVSSSS191, L.VVVSSSS248, L.VVVSSSS345, L.VVVSSSS7, L.VVVSSSS70, L.VVVSSSS84, L.VVVSSSS91 ],
                couplings = {(0,7):C.GC_6652,(0,3):C.GC_1012,(0,6):C.GC_1029,(0,1):C.GC_2249,(0,10):C.GC_2256,(0,9):C.GC_6517,(0,4):C.GC_1113,(0,0):C.GC_1125,(0,8):C.GC_1137,(0,5):C.GC_5021,(0,2):C.GC_3138})

V_1623 = Vertex(name = 'V_1623',
                particles = [ P.W__plus__, P.Z, P.Z, P.G0, P.G__minus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS7, L.VVVSSSS84 ],
                couplings = {(0,0):C.GC_6533,(0,1):C.GC_4197})

V_1624 = Vertex(name = 'V_1624',
                particles = [ P.W__plus__, P.Z, P.Z, P.G__minus__, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS192, L.VVVSSSS272, L.VVVSSSS298, L.VVVSSSS299, L.VVVSSSS326, L.VVVSSSS7, L.VVVSSSS71, L.VVVSSSS84 ],
                couplings = {(0,5):C.GC_6644,(0,3):C.GC_1008,(0,2):C.GC_1028,(0,4):C.GC_2254,(0,0):C.GC_1417,(0,7):C.GC_6527,(0,6):C.GC_5028,(0,1):C.GC_3144})

V_1625 = Vertex(name = 'V_1625',
                particles = [ P.W__plus__, P.Z, P.Z, P.G__minus__, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS192, L.VVVSSSS7, L.VVVSSSS84 ],
                couplings = {(0,1):C.GC_6542,(0,0):C.GC_2257,(0,2):C.GC_4194})

V_1626 = Vertex(name = 'V_1626',
                particles = [ P.A, P.W__minus__, P.W__plus__, P.Z, P.G0, P.G0, P.G0, P.G0 ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS1, L.VVVVSSSS6, L.VVVVSSSS7 ],
                couplings = {(0,2):C.GC_4058,(0,0):C.GC_4066,(0,1):C.GC_4063})

V_1627 = Vertex(name = 'V_1627',
                particles = [ P.A, P.W__minus__, P.W__plus__, P.Z, P.G0, P.G0, P.G0, P.G0 ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS7 ],
                couplings = {(0,0):C.GC_4229})

V_1628 = Vertex(name = 'V_1628',
                particles = [ P.A, P.W__minus__, P.W__plus__, P.Z, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS1, L.VVVVSSSS12, L.VVVVSSSS2, L.VVVVSSSS6, L.VVVVSSSS7 ],
                couplings = {(0,2):C.GC_6862,(0,1):C.GC_6857,(0,4):C.GC_6847,(0,0):C.GC_4065,(0,3):C.GC_4061})

V_1629 = Vertex(name = 'V_1629',
                particles = [ P.A, P.W__minus__, P.W__plus__, P.Z, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS7 ],
                couplings = {(0,0):C.GC_4228})

V_1630 = Vertex(name = 'V_1630',
                particles = [ P.A, P.W__minus__, P.W__plus__, P.Z, P.G0, P.G0, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS1, L.VVVVSSS6, L.VVVVSSS7 ],
                couplings = {(0,0):C.GC_4007,(0,2):C.GC_4003,(0,1):C.GC_4004})

V_1631 = Vertex(name = 'V_1631',
                particles = [ P.A, P.W__minus__, P.W__plus__, P.Z, P.G0, P.G0, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS7 ],
                couplings = {(0,0):C.GC_4155})

V_1632 = Vertex(name = 'V_1632',
                particles = [ P.A, P.W__minus__, P.W__plus__, P.Z, P.G0, P.G0, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS1, L.VVVVSSSS6, L.VVVVSSSS7 ],
                couplings = {(0,2):C.GC_4059,(0,0):C.GC_4064,(0,1):C.GC_4060})

V_1633 = Vertex(name = 'V_1633',
                particles = [ P.A, P.W__minus__, P.W__plus__, P.Z, P.G0, P.G0, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS7 ],
                couplings = {(0,0):C.GC_4227})

V_1634 = Vertex(name = 'V_1634',
                particles = [ P.A, P.W__minus__, P.W__plus__, P.Z, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS1, L.VVVVSSS6, L.VVVVSSS7 ],
                couplings = {(0,0):C.GC_4008,(0,2):C.GC_4002,(0,1):C.GC_4006})

V_1635 = Vertex(name = 'V_1635',
                particles = [ P.A, P.W__minus__, P.W__plus__, P.Z, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS7 ],
                couplings = {(0,0):C.GC_4156})

V_1636 = Vertex(name = 'V_1636',
                particles = [ P.A, P.W__minus__, P.W__plus__, P.Z, P.H, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS1, L.VVVVSSSS6, L.VVVVSSSS7 ],
                couplings = {(0,2):C.GC_4058,(0,0):C.GC_4066,(0,1):C.GC_4063})

V_1637 = Vertex(name = 'V_1637',
                particles = [ P.A, P.W__minus__, P.W__plus__, P.Z, P.H, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS7 ],
                couplings = {(0,0):C.GC_4229})

V_1638 = Vertex(name = 'V_1638',
                particles = [ P.A, P.W__minus__, P.W__plus__, P.Z, P.G0, P.G0, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS1, L.VVVVSSSS12, L.VVVVSSSS13, L.VVVVSSSS6, L.VVVVSSSS7, L.VVVVSSSS8 ],
                couplings = {(0,2):C.GC_6141,(0,5):C.GC_6860,(0,1):C.GC_4374,(0,4):C.GC_6679,(0,0):C.GC_4064,(0,3):C.GC_4062})

V_1639 = Vertex(name = 'V_1639',
                particles = [ P.A, P.W__minus__, P.W__plus__, P.Z, P.G0, P.G0, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS7 ],
                couplings = {(0,0):C.GC_4365})

V_1640 = Vertex(name = 'V_1640',
                particles = [ P.A, P.W__minus__, P.W__plus__, P.Z, P.G__minus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS1, L.VVVVSSS12, L.VVVVSSS13, L.VVVVSSS6, L.VVVVSSS7, L.VVVVSSS8 ],
                couplings = {(0,0):C.GC_4007,(0,4):C.GC_6629,(0,3):C.GC_4005,(0,2):C.GC_6135,(0,5):C.GC_6853,(0,1):C.GC_4368})

V_1641 = Vertex(name = 'V_1641',
                particles = [ P.A, P.W__minus__, P.W__plus__, P.Z, P.G__minus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS7 ],
                couplings = {(0,0):C.GC_4305})

V_1642 = Vertex(name = 'V_1642',
                particles = [ P.A, P.W__minus__, P.W__plus__, P.Z, P.G__minus__, P.G__plus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS1, L.VVVVSSSS12, L.VVVVSSSS13, L.VVVVSSSS6, L.VVVVSSSS7, L.VVVVSSSS8 ],
                couplings = {(0,2):C.GC_6141,(0,5):C.GC_6860,(0,1):C.GC_4374,(0,4):C.GC_6679,(0,0):C.GC_4064,(0,3):C.GC_4062})

V_1643 = Vertex(name = 'V_1643',
                particles = [ P.A, P.W__minus__, P.W__plus__, P.Z, P.G__minus__, P.G__plus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS7 ],
                couplings = {(0,0):C.GC_4365})

V_1644 = Vertex(name = 'V_1644',
                particles = [ P.W__minus__, P.W__plus__, P.Z, P.G0, P.G0, P.G0 ],
                color = [ '1' ],
                lorentz = [ L.VVVSSS132, L.VVVSSS156, L.VVVSSS193, L.VVVSSS25, L.VVVSSS37 ],
                couplings = {(0,4):C.GC_3025,(0,2):C.GC_3699,(0,3):C.GC_2604,(0,1):C.GC_2592,(0,0):C.GC_2601})

V_1645 = Vertex(name = 'V_1645',
                particles = [ P.W__minus__, P.W__plus__, P.Z, P.G0, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVSSS10, L.VVVSSS31, L.VVVSSS70, L.VVVSSS73, L.VVVSSS77, L.VVVSSS78 ],
                couplings = {(0,1):C.GC_2718,(0,5):C.GC_3705,(0,4):C.GC_2045,(0,0):C.GC_3576,(0,3):C.GC_2592,(0,2):C.GC_3574})

V_1646 = Vertex(name = 'V_1646',
                particles = [ P.W__minus__, P.W__plus__, P.Z, P.G0, P.G0, P.G0, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS14, L.VVVSSSS177, L.VVVSSSS327, L.VVVSSSS346, L.VVVSSSS47 ],
                couplings = {(0,0):C.GC_2703,(0,2):C.GC_2688,(0,3):C.GC_2699,(0,4):C.GC_3042,(0,1):C.GC_3737})

V_1647 = Vertex(name = 'V_1647',
                particles = [ P.W__minus__, P.W__plus__, P.Z, P.G0, P.G__minus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS15, L.VVVSSSS207, L.VVVSSSS208, L.VVVSSSS282, L.VVVSSSS301, L.VVVSSSS49 ],
                couplings = {(0,0):C.GC_3657,(0,3):C.GC_2688,(0,4):C.GC_3655,(0,5):C.GC_2742,(0,2):C.GC_3746,(0,1):C.GC_2048})

V_1648 = Vertex(name = 'V_1648',
                particles = [ P.W__minus__, P.W__plus__, P.Z, P.G0, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSS165, L.VVVSSS169, L.VVVSSS17, L.VVVSSS170, L.VVVSSS35 ],
                couplings = {(0,4):C.GC_3026,(0,0):C.GC_3700,(0,2):C.GC_2605,(0,1):C.GC_2593,(0,3):C.GC_2602})

V_1649 = Vertex(name = 'V_1649',
                particles = [ P.W__minus__, P.W__plus__, P.Z, P.G0, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS22, L.VVVSSSS273, L.VVVSSSS279, L.VVVSSSS281, L.VVVSSSS52 ],
                couplings = {(0,0):C.GC_2704,(0,2):C.GC_2689,(0,3):C.GC_2700,(0,4):C.GC_3043,(0,1):C.GC_3738})

V_1650 = Vertex(name = 'V_1650',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.Z, P.G0, P.G0, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS16, L.VVVVSSS3, L.VVVVSSS4, L.VVVVSSS5 ],
                couplings = {(0,3):C.GC_2570,(0,1):C.GC_3799,(0,0):C.GC_3791,(0,2):C.GC_2784})

V_1651 = Vertex(name = 'V_1651',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.Z, P.G0, P.G0, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS5 ],
                couplings = {(0,0):C.GC_3721})

V_1652 = Vertex(name = 'V_1652',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.Z, P.G0, P.G0, P.G0, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS16, L.VVVVSSSS3, L.VVVVSSSS4, L.VVVVSSSS5 ],
                couplings = {(0,1):C.GC_3829,(0,0):C.GC_3819,(0,2):C.GC_2794,(0,3):C.GC_2646})

V_1653 = Vertex(name = 'V_1653',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.Z, P.G0, P.G0, P.G0, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_3763})

V_1654 = Vertex(name = 'V_1654',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.Z, P.G__minus__, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS16, L.VVVVSSS3, L.VVVVSSS4, L.VVVVSSS5 ],
                couplings = {(0,3):C.GC_2571,(0,1):C.GC_3800,(0,0):C.GC_3792,(0,2):C.GC_2782})

V_1655 = Vertex(name = 'V_1655',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.Z, P.G__minus__, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS5 ],
                couplings = {(0,0):C.GC_3723})

V_1656 = Vertex(name = 'V_1656',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.Z, P.G0, P.G__minus__, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS16, L.VVVVSSSS3, L.VVVVSSSS4, L.VVVVSSSS5 ],
                couplings = {(0,1):C.GC_3828,(0,0):C.GC_3818,(0,2):C.GC_2791,(0,3):C.GC_2654})

V_1657 = Vertex(name = 'V_1657',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.Z, P.G0, P.G__minus__, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_3778})

V_1658 = Vertex(name = 'V_1658',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.Z, P.G0, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS16, L.VVVVSSS3, L.VVVVSSS4, L.VVVVSSS5 ],
                couplings = {(0,3):C.GC_2569,(0,1):C.GC_3802,(0,0):C.GC_3797,(0,2):C.GC_2783})

V_1659 = Vertex(name = 'V_1659',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.Z, P.G0, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS5 ],
                couplings = {(0,0):C.GC_3718})

V_1660 = Vertex(name = 'V_1660',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.Z, P.G0, P.G0, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS16, L.VVVVSSSS3, L.VVVVSSSS4, L.VVVVSSSS5 ],
                couplings = {(0,1):C.GC_3824,(0,0):C.GC_3811,(0,2):C.GC_2796,(0,3):C.GC_2649})

V_1661 = Vertex(name = 'V_1661',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.Z, P.G0, P.G0, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_3768})

V_1662 = Vertex(name = 'V_1662',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.Z, P.G__minus__, P.G__plus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS16, L.VVVVSSSS3, L.VVVVSSSS4, L.VVVVSSSS5 ],
                couplings = {(0,1):C.GC_3825,(0,0):C.GC_3812,(0,2):C.GC_2792,(0,3):C.GC_2650})

V_1663 = Vertex(name = 'V_1663',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.Z, P.G__minus__, P.G__plus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_3770})

V_1664 = Vertex(name = 'V_1664',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.Z, P.G__plus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS16, L.VVVVSSS3, L.VVVVSSS4, L.VVVVSSS5 ],
                couplings = {(0,3):C.GC_2572,(0,1):C.GC_3801,(0,0):C.GC_3793,(0,2):C.GC_2785})

V_1665 = Vertex(name = 'V_1665',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.Z, P.G__plus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS5 ],
                couplings = {(0,0):C.GC_3727})

V_1666 = Vertex(name = 'V_1666',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.Z, P.G0, P.G__plus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS16, L.VVVVSSSS3, L.VVVVSSSS4, L.VVVVSSSS5 ],
                couplings = {(0,1):C.GC_3827,(0,0):C.GC_3817,(0,2):C.GC_2795,(0,3):C.GC_2648})

V_1667 = Vertex(name = 'V_1667',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.Z, P.G0, P.G__plus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_3765})

V_1668 = Vertex(name = 'V_1668',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.Z, P.G__plus__, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS16, L.VVVVSSSS3, L.VVVVSSSS4, L.VVVVSSSS5 ],
                couplings = {(0,1):C.GC_3826,(0,0):C.GC_3813,(0,2):C.GC_2797,(0,3):C.GC_2651})

V_1669 = Vertex(name = 'V_1669',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.Z, P.G__plus__, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_3774})

V_1670 = Vertex(name = 'V_1670',
                particles = [ P.A, P.A, P.A, P.W__minus__, P.W__plus__, P.Z, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVSS1, L.VVVVVVSS48, L.VVVVVVSS57, L.VVVVVVSS8 ],
                couplings = {(0,0):C.GC_6870,(0,3):C.GC_6142,(0,2):C.GC_6152,(0,1):C.GC_6866})

V_1671 = Vertex(name = 'V_1671',
                particles = [ P.A, P.A, P.W__minus__, P.W__plus__, P.Z, P.G0 ],
                color = [ '1' ],
                lorentz = [ L.VVVVVS20, L.VVVVVS202, L.VVVVVS23 ],
                couplings = {(0,0):C.GC_3713,(0,2):C.GC_3709,(0,1):C.GC_3708})

V_1672 = Vertex(name = 'V_1672',
                particles = [ P.A, P.A, P.W__minus__, P.W__plus__, P.Z, P.G0, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVVSS26, L.VVVVVSS267, L.VVVVVSS29 ],
                couplings = {(0,0):C.GC_3755,(0,2):C.GC_3750,(0,1):C.GC_3749})

V_1673 = Vertex(name = 'V_1673',
                particles = [ P.A, P.W__minus__, P.W__plus__, P.Z, P.Z, P.G0, P.G0 ],
                color = [ '1' ],
                lorentz = [ L.VVVVVSS122, L.VVVVVSS143, L.VVVVVSS145, L.VVVVVSS146, L.VVVVVSS148, L.VVVVVSS154, L.VVVVVSS157, L.VVVVVSS172, L.VVVVVSS176, L.VVVVVSS177, L.VVVVVSS178, L.VVVVVSS180, L.VVVVVSS186, L.VVVVVSS199, L.VVVVVSS222, L.VVVVVSS46, L.VVVVVSS48, L.VVVVVSS53, L.VVVVVSS56, L.VVVVVSS65, L.VVVVVSS73, L.VVVVVSS78 ],
                couplings = {(0,3):C.GC_2084,(0,1):C.GC_2615,(0,11):C.GC_6177,(0,8):C.GC_2613,(0,2):C.GC_2776,(0,5):C.GC_3065,(0,17):C.GC_3759,(0,14):C.GC_3758,(0,16):C.GC_2772,(0,21):C.GC_3061,(0,20):C.GC_2770,(0,10):C.GC_3064,(0,9):C.GC_2774,(0,7):C.GC_3059,(0,4):C.GC_4099,(0,6):C.GC_4784,(0,15):C.GC_4876,(0,18):C.GC_4778,(0,19):C.GC_4873,(0,12):C.GC_4774,(0,0):C.GC_4875,(0,13):C.GC_4874})

V_1674 = Vertex(name = 'V_1674',
                particles = [ P.A, P.W__minus__, P.W__plus__, P.Z, P.Z, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVSS122, L.VVVVVSS123, L.VVVVVSS136, L.VVVVVSS138, L.VVVVVSS139, L.VVVVVSS142, L.VVVVVSS143, L.VVVVVSS146, L.VVVVVSS148, L.VVVVVSS156, L.VVVVVSS157, L.VVVVVSS166, L.VVVVVSS167, L.VVVVVSS173, L.VVVVVSS176, L.VVVVVSS179, L.VVVVVSS180, L.VVVVVSS181, L.VVVVVSS182, L.VVVVVSS186, L.VVVVVSS197, L.VVVVVSS199, L.VVVVVSS222, L.VVVVVSS268, L.VVVVVSS269, L.VVVVVSS278, L.VVVVVSS46, L.VVVVVSS53, L.VVVVVSS65, L.VVVVVSS74, L.VVVVVSS75, L.VVVVVSS76 ],
                couplings = {(0,7):C.GC_2085,(0,6):C.GC_2614,(0,16):C.GC_6176,(0,14):C.GC_2612,(0,5):C.GC_2121,(0,4):C.GC_2777,(0,3):C.GC_3066,(0,27):C.GC_3760,(0,30):C.GC_2120,(0,29):C.GC_2773,(0,31):C.GC_3062,(0,22):C.GC_3757,(0,18):C.GC_2770,(0,17):C.GC_2775,(0,15):C.GC_3063,(0,13):C.GC_3060,(0,8):C.GC_4099,(0,9):C.GC_4122,(0,10):C.GC_4783,(0,12):C.GC_4777,(0,26):C.GC_4877,(0,11):C.GC_4121,(0,1):C.GC_4120,(0,2):C.GC_4771,(0,24):C.GC_4118,(0,23):C.GC_4119,(0,25):C.GC_4765,(0,20):C.GC_4768,(0,28):C.GC_4873,(0,19):C.GC_4773,(0,0):C.GC_4875,(0,21):C.GC_4874})

V_1675 = Vertex(name = 'V_1675',
                particles = [ P.A, P.W__minus__, P.W__plus__, P.Z, P.Z, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVSS180 ],
                couplings = {(0,0):C.GC_6182})

V_1676 = Vertex(name = 'V_1676',
                particles = [ P.A, P.W__minus__, P.W__plus__, P.Z, P.Z, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVVS103, L.VVVVVS105, L.VVVVVS106, L.VVVVVS108, L.VVVVVS114, L.VVVVVS117, L.VVVVVS125, L.VVVVVS128, L.VVVVVS129, L.VVVVVS130, L.VVVVVS131, L.VVVVVS133, L.VVVVVS145, L.VVVVVS165, L.VVVVVS34, L.VVVVVS36, L.VVVVVS41, L.VVVVVS44, L.VVVVVS52, L.VVVVVS59, L.VVVVVS61, L.VVVVVS90 ],
                couplings = {(0,1):C.GC_2737,(0,4):C.GC_3038,(0,16):C.GC_3716,(0,13):C.GC_3715,(0,15):C.GC_2735,(0,20):C.GC_3036,(0,19):C.GC_2733,(0,9):C.GC_3037,(0,8):C.GC_2736,(0,6):C.GC_3035,(0,2):C.GC_2079,(0,0):C.GC_2553,(0,10):C.GC_6161,(0,7):C.GC_2552,(0,5):C.GC_4741,(0,14):C.GC_4870,(0,17):C.GC_4737,(0,18):C.GC_4867,(0,11):C.GC_4735,(0,21):C.GC_4869,(0,12):C.GC_4868,(0,3):C.GC_4086})

V_1677 = Vertex(name = 'V_1677',
                particles = [ P.A, P.W__minus__, P.W__plus__, P.Z, P.Z, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVVSS122, L.VVVVVSS143, L.VVVVVSS145, L.VVVVVSS146, L.VVVVVSS148, L.VVVVVSS154, L.VVVVVSS157, L.VVVVVSS172, L.VVVVVSS176, L.VVVVVSS177, L.VVVVVSS178, L.VVVVVSS180, L.VVVVVSS186, L.VVVVVSS199, L.VVVVVSS222, L.VVVVVSS46, L.VVVVVSS48, L.VVVVVSS53, L.VVVVVSS56, L.VVVVVSS65, L.VVVVVSS73, L.VVVVVSS78 ],
                couplings = {(0,3):C.GC_2084,(0,1):C.GC_2615,(0,11):C.GC_6177,(0,8):C.GC_2613,(0,2):C.GC_2776,(0,5):C.GC_3065,(0,17):C.GC_3759,(0,14):C.GC_3758,(0,16):C.GC_2772,(0,21):C.GC_3061,(0,20):C.GC_2770,(0,10):C.GC_3064,(0,9):C.GC_2774,(0,7):C.GC_3059,(0,4):C.GC_4099,(0,6):C.GC_4784,(0,15):C.GC_4876,(0,18):C.GC_4778,(0,19):C.GC_4873,(0,12):C.GC_4774,(0,0):C.GC_4875,(0,13):C.GC_4874})

V_1678 = Vertex(name = 'V_1678',
                particles = [ P.W__minus__, P.W__plus__, P.Z, P.Z, P.G0 ],
                color = [ '1' ],
                lorentz = [ L.VVVVS118, L.VVVVS119, L.VVVVS120, L.VVVVS121, L.VVVVS125, L.VVVVS149, L.VVVVS2, L.VVVVS229, L.VVVVS249, L.VVVVS36, L.VVVVS37, L.VVVVS45, L.VVVVS48, L.VVVVS50, L.VVVVS53, L.VVVVS6, L.VVVVS8 ],
                couplings = {(0,4):C.GC_881,(0,14):C.GC_2166,(0,12):C.GC_2168,(0,16):C.GC_875,(0,7):C.GC_872,(0,10):C.GC_874,(0,2):C.GC_2164,(0,13):C.GC_4177,(0,11):C.GC_4183,(0,5):C.GC_3884,(0,6):C.GC_4167,(0,15):C.GC_3878,(0,8):C.GC_4170,(0,1):C.GC_3882,(0,0):C.GC_4160,(0,3):C.GC_4175,(0,9):C.GC_3877})

V_1679 = Vertex(name = 'V_1679',
                particles = [ P.W__minus__, P.W__plus__, P.Z, P.Z, P.G0, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSS331, L.VVVVSS332, L.VVVVSS340, L.VVVVSS342, L.VVVVSS345, L.VVVVSS347, L.VVVVSS500, L.VVVVSS501, L.VVVVSS502, L.VVVVSS504, L.VVVVSS530, L.VVVVSS584, L.VVVVSS70, L.VVVVSS714, L.VVVVSS768, L.VVVVSS78, L.VVVVSS80 ],
                couplings = {(0,10):C.GC_984,(0,3):C.GC_2221,(0,5):C.GC_2223,(0,16):C.GC_978,(0,13):C.GC_974,(0,1):C.GC_977,(0,9):C.GC_2218,(0,2):C.GC_4255,(0,4):C.GC_4263,(0,11):C.GC_3933,(0,12):C.GC_4244,(0,15):C.GC_3924,(0,14):C.GC_4247,(0,8):C.GC_3930,(0,6):C.GC_4234,(0,7):C.GC_4253,(0,0):C.GC_3923})

V_1680 = Vertex(name = 'V_1680',
                particles = [ P.A, P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.Z, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVS1, L.VVVVVVS19, L.VVVVVVS20, L.VVVVVVS32, L.VVVVVVS33, L.VVVVVVS34, L.VVVVVVS9 ],
                couplings = {(0,0):C.GC_3806,(0,5):C.GC_2788,(0,4):C.GC_3805,(0,3):C.GC_3069,(0,1):C.GC_1452,(0,2):C.GC_2790,(0,6):C.GC_3070})

V_1681 = Vertex(name = 'V_1681',
                particles = [ P.A, P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.Z, P.G0, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVSS11, L.VVVVVVSS2, L.VVVVVVSS21, L.VVVVVVSS22, L.VVVVVVSS35, L.VVVVVVSS36, L.VVVVVVSS37 ],
                couplings = {(0,1):C.GC_3838,(0,6):C.GC_2805,(0,5):C.GC_3836,(0,4):C.GC_3074,(0,2):C.GC_1458,(0,3):C.GC_2807,(0,0):C.GC_3078})

V_1682 = Vertex(name = 'V_1682',
                particles = [ P.A, P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.Z, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVSS11, L.VVVVVVSS2, L.VVVVVVSS21, L.VVVVVVSS22, L.VVVVVVSS35, L.VVVVVVSS36, L.VVVVVVSS37 ],
                couplings = {(0,1):C.GC_3837,(0,6):C.GC_2803,(0,5):C.GC_3834,(0,4):C.GC_3077,(0,2):C.GC_1457,(0,3):C.GC_2808,(0,0):C.GC_3079})

V_1683 = Vertex(name = 'V_1683',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.Z, P.Z, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVS11, L.VVVVVS123, L.VVVVVS14, L.VVVVVS15, L.VVVVVS163, L.VVVVVS164, L.VVVVVS167, L.VVVVVS17, L.VVVVVS189, L.VVVVVS192, L.VVVVVS194, L.VVVVVS206, L.VVVVVS28, L.VVVVVS30, L.VVVVVS56, L.VVVVVS82, L.VVVVVS83 ],
                couplings = {(0,13):C.GC_1090,(0,15):C.GC_1791,(0,16):C.GC_2269,(0,12):C.GC_3130,(0,2):C.GC_1785,(0,6):C.GC_1084,(0,14):C.GC_1086,(0,11):C.GC_1087,(0,10):C.GC_2266,(0,8):C.GC_2267,(0,9):C.GC_2268,(0,3):C.GC_6799,(0,0):C.GC_4297,(0,5):C.GC_6794,(0,4):C.GC_4303,(0,1):C.GC_4292,(0,7):C.GC_4150})

V_1684 = Vertex(name = 'V_1684',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.Z, P.Z, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVS164 ],
                couplings = {(0,0):C.GC_4148})

V_1685 = Vertex(name = 'V_1685',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.Z, P.Z, P.G0, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVSS109, L.VVVVVSS111, L.VVVVVSS12, L.VVVVVSS17, L.VVVVVSS170, L.VVVVVSS20, L.VVVVVSS220, L.VVVVVSS221, L.VVVVVSS224, L.VVVVVSS23, L.VVVVVSS257, L.VVVVVSS261, L.VVVVVSS263, L.VVVVVSS294, L.VVVVVSS35, L.VVVVVSS37, L.VVVVVSS69 ],
                couplings = {(0,15):C.GC_1151,(0,0):C.GC_1838,(0,1):C.GC_2300,(0,14):C.GC_3147,(0,3):C.GC_1831,(0,8):C.GC_1141,(0,16):C.GC_1144,(0,13):C.GC_1147,(0,11):C.GC_2290,(0,10):C.GC_2293,(0,12):C.GC_2296,(0,9):C.GC_4220,(0,7):C.GC_6827,(0,5):C.GC_6845,(0,2):C.GC_4352,(0,6):C.GC_4364,(0,4):C.GC_4344})

V_1686 = Vertex(name = 'V_1686',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.Z, P.Z, P.G0, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVSS221 ],
                couplings = {(0,0):C.GC_4216})

V_1687 = Vertex(name = 'V_1687',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.Z, P.Z, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVVSS109, L.VVVVVSS110, L.VVVVVSS12, L.VVVVVSS17, L.VVVVVSS170, L.VVVVVSS20, L.VVVVVSS220, L.VVVVVSS221, L.VVVVVSS224, L.VVVVVSS23, L.VVVVVSS290, L.VVVVVSS293, L.VVVVVSS294, L.VVVVVSS301, L.VVVVVSS35, L.VVVVVSS39, L.VVVVVSS69 ],
                couplings = {(0,15):C.GC_1154,(0,0):C.GC_1840,(0,1):C.GC_2301,(0,14):C.GC_3146,(0,3):C.GC_1829,(0,8):C.GC_1139,(0,16):C.GC_1143,(0,12):C.GC_1146,(0,11):C.GC_2292,(0,10):C.GC_2294,(0,13):C.GC_2297,(0,9):C.GC_4218,(0,7):C.GC_6831,(0,5):C.GC_6839,(0,2):C.GC_4349,(0,6):C.GC_4361,(0,4):C.GC_4341})

V_1688 = Vertex(name = 'V_1688',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.Z, P.Z, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVVSS221 ],
                couplings = {(0,0):C.GC_4214})

V_1689 = Vertex(name = 'V_1689',
                particles = [ P.A, P.W__plus__, P.W__plus__, P.Z, P.G__minus__, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSS242, L.VVVVSS605, L.VVVVSS606, L.VVVVSS608 ],
                couplings = {(0,1):C.GC_6778,(0,2):C.GC_6130,(0,0):C.GC_4366,(0,3):C.GC_6851})

V_1690 = Vertex(name = 'V_1690',
                particles = [ P.A, P.W__plus__, P.W__plus__, P.Z, P.G__minus__, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSS605 ],
                couplings = {(0,0):C.GC_4144})

V_1691 = Vertex(name = 'V_1691',
                particles = [ P.A, P.W__plus__, P.W__plus__, P.Z, P.G0, P.G__minus__, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS12, L.VVVVSSS2, L.VVVVSSS7, L.VVVVSSS8 ],
                couplings = {(0,2):C.GC_6803,(0,3):C.GC_6132,(0,1):C.GC_4370,(0,0):C.GC_6855})

V_1692 = Vertex(name = 'V_1692',
                particles = [ P.A, P.W__plus__, P.W__plus__, P.Z, P.G0, P.G__minus__, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS7 ],
                couplings = {(0,0):C.GC_4157})

V_1693 = Vertex(name = 'V_1693',
                particles = [ P.A, P.W__plus__, P.W__plus__, P.Z, P.G0, P.G0, P.G__minus__, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS12, L.VVVVSSSS2, L.VVVVSSSS7, L.VVVVSSSS8 ],
                couplings = {(0,3):C.GC_6139,(0,1):C.GC_4375,(0,0):C.GC_6859,(0,2):C.GC_6850})

V_1694 = Vertex(name = 'V_1694',
                particles = [ P.A, P.W__plus__, P.W__plus__, P.Z, P.G0, P.G0, P.G__minus__, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS7 ],
                couplings = {(0,0):C.GC_4232})

V_1695 = Vertex(name = 'V_1695',
                particles = [ P.A, P.W__plus__, P.W__plus__, P.Z, P.G__minus__, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS12, L.VVVVSSS2, L.VVVVSSS7, L.VVVVSSS8 ],
                couplings = {(0,2):C.GC_6804,(0,3):C.GC_6133,(0,1):C.GC_4369,(0,0):C.GC_6854})

V_1696 = Vertex(name = 'V_1696',
                particles = [ P.A, P.W__plus__, P.W__plus__, P.Z, P.G__minus__, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS7 ],
                couplings = {(0,0):C.GC_4158})

V_1697 = Vertex(name = 'V_1697',
                particles = [ P.A, P.W__plus__, P.W__plus__, P.Z, P.G0, P.G__minus__, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS12, L.VVVVSSSS2, L.VVVVSSSS7, L.VVVVSSSS8 ],
                couplings = {(0,3):C.GC_6137,(0,1):C.GC_4377,(0,0):C.GC_6864,(0,2):C.GC_6848})

V_1698 = Vertex(name = 'V_1698',
                particles = [ P.A, P.W__plus__, P.W__plus__, P.Z, P.G0, P.G__minus__, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS7 ],
                couplings = {(0,0):C.GC_4230})

V_1699 = Vertex(name = 'V_1699',
                particles = [ P.A, P.W__plus__, P.W__plus__, P.Z, P.G__minus__, P.G__minus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS12, L.VVVVSSSS2, L.VVVVSSSS7, L.VVVVSSSS8 ],
                couplings = {(0,3):C.GC_6138,(0,1):C.GC_4376,(0,0):C.GC_6861,(0,2):C.GC_6849})

V_1700 = Vertex(name = 'V_1700',
                particles = [ P.A, P.W__plus__, P.W__plus__, P.Z, P.G__minus__, P.G__minus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS7 ],
                couplings = {(0,0):C.GC_4231})

V_1701 = Vertex(name = 'V_1701',
                particles = [ P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.G0, P.G0, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS12, L.VVVVSSS2, L.VVVVSSS7, L.VVVVSSS8 ],
                couplings = {(0,2):C.GC_2571,(0,1):C.GC_2784,(0,3):C.GC_3792,(0,0):C.GC_3799})

V_1702 = Vertex(name = 'V_1702',
                particles = [ P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.G0, P.G0, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS7 ],
                couplings = {(0,0):C.GC_3724})

V_1703 = Vertex(name = 'V_1703',
                particles = [ P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.G0, P.G0, P.G0, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS12, L.VVVVSSSS2, L.VVVVSSSS7, L.VVVVSSSS8 ],
                couplings = {(0,1):C.GC_2799,(0,3):C.GC_3808,(0,0):C.GC_3821,(0,2):C.GC_2645})

V_1704 = Vertex(name = 'V_1704',
                particles = [ P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.G0, P.G0, P.G0, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS7 ],
                couplings = {(0,0):C.GC_3779})

V_1705 = Vertex(name = 'V_1705',
                particles = [ P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.G__minus__, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS12, L.VVVVSSS2, L.VVVVSSS7, L.VVVVSSS8 ],
                couplings = {(0,2):C.GC_2573,(0,1):C.GC_2782,(0,3):C.GC_3794,(0,0):C.GC_3800})

V_1706 = Vertex(name = 'V_1706',
                particles = [ P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.G__minus__, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS7 ],
                couplings = {(0,0):C.GC_3728})

V_1707 = Vertex(name = 'V_1707',
                particles = [ P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.G0, P.G__minus__, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS12, L.VVVVSSSS2, L.VVVVSSSS7, L.VVVVSSSS8 ],
                couplings = {(0,1):C.GC_2793,(0,3):C.GC_3809,(0,0):C.GC_3822,(0,2):C.GC_2655})

V_1708 = Vertex(name = 'V_1708',
                particles = [ P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.G0, P.G__minus__, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS7 ],
                couplings = {(0,0):C.GC_3761})

V_1709 = Vertex(name = 'V_1709',
                particles = [ P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.G0, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS12, L.VVVVSSS2, L.VVVVSSS7, L.VVVVSSS8 ],
                couplings = {(0,2):C.GC_2568,(0,1):C.GC_2786,(0,3):C.GC_3790,(0,0):C.GC_3798})

V_1710 = Vertex(name = 'V_1710',
                particles = [ P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.G0, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS7 ],
                couplings = {(0,0):C.GC_3730})

V_1711 = Vertex(name = 'V_1711',
                particles = [ P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.G0, P.G0, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS12, L.VVVVSSSS2, L.VVVVSSSS7, L.VVVVSSSS8 ],
                couplings = {(0,1):C.GC_2796,(0,3):C.GC_3812,(0,0):C.GC_3824,(0,2):C.GC_2650})

V_1712 = Vertex(name = 'V_1712',
                particles = [ P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.G0, P.G0, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS7 ],
                couplings = {(0,0):C.GC_3771})

V_1713 = Vertex(name = 'V_1713',
                particles = [ P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.G__minus__, P.G__minus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS12, L.VVVVSSSS2, L.VVVVSSSS7, L.VVVVSSSS8 ],
                couplings = {(0,1):C.GC_2792,(0,3):C.GC_3814,(0,0):C.GC_3825,(0,2):C.GC_2652})

V_1714 = Vertex(name = 'V_1714',
                particles = [ P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.G__minus__, P.G__minus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS7 ],
                couplings = {(0,0):C.GC_3775})

V_1715 = Vertex(name = 'V_1715',
                particles = [ P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.G__minus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS12, L.VVVVSSS2, L.VVVVSSS7, L.VVVVSSS8 ],
                couplings = {(0,2):C.GC_2574,(0,1):C.GC_2785,(0,3):C.GC_3795,(0,0):C.GC_3801})

V_1716 = Vertex(name = 'V_1716',
                particles = [ P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.G__minus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS7 ],
                couplings = {(0,0):C.GC_3729})

V_1717 = Vertex(name = 'V_1717',
                particles = [ P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.G0, P.G__minus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS12, L.VVVVSSSS2, L.VVVVSSSS7, L.VVVVSSSS8 ],
                couplings = {(0,1):C.GC_2798,(0,3):C.GC_3810,(0,0):C.GC_3823,(0,2):C.GC_2647})

V_1718 = Vertex(name = 'V_1718',
                particles = [ P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.G0, P.G__minus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS7 ],
                couplings = {(0,0):C.GC_3778})

V_1719 = Vertex(name = 'V_1719',
                particles = [ P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.G__minus__, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS12, L.VVVVSSSS2, L.VVVVSSSS7, L.VVVVSSSS8 ],
                couplings = {(0,1):C.GC_2797,(0,3):C.GC_3815,(0,0):C.GC_3826,(0,2):C.GC_2653})

V_1720 = Vertex(name = 'V_1720',
                particles = [ P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.G__minus__, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS7 ],
                couplings = {(0,0):C.GC_3776})

V_1721 = Vertex(name = 'V_1721',
                particles = [ P.A, P.A, P.A, P.W__plus__, P.Z, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVS1, L.VVVVVS27, L.VVVVVS29, L.VVVVVS33, L.VVVVVS51, L.VVVVVS53, L.VVVVVS54 ],
                couplings = {(0,0):C.GC_1801,(0,1):C.GC_1796,(0,5):C.GC_6784,(0,6):C.GC_1800,(0,4):C.GC_1793,(0,2):C.GC_6786,(0,3):C.GC_6787})

V_1722 = Vertex(name = 'V_1722',
                particles = [ P.A, P.A, P.A, P.W__plus__, P.Z, P.G0, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVSS1, L.VVVVVSS34, L.VVVVVSS36, L.VVVVVSS44, L.VVVVVSS64, L.VVVVVSS66, L.VVVVVSS67 ],
                couplings = {(0,0):C.GC_1857,(0,1):C.GC_1847,(0,5):C.GC_6807,(0,6):C.GC_1854,(0,4):C.GC_1842,(0,2):C.GC_6814,(0,3):C.GC_6817})

V_1723 = Vertex(name = 'V_1723',
                particles = [ P.A, P.A, P.A, P.W__plus__, P.Z, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVVSS1, L.VVVVVSS34, L.VVVVVSS36, L.VVVVVSS44, L.VVVVVSS64, L.VVVVVSS66, L.VVVVVSS67 ],
                couplings = {(0,0):C.GC_1858,(0,1):C.GC_1846,(0,5):C.GC_6810,(0,6):C.GC_1853,(0,4):C.GC_1843,(0,2):C.GC_6816,(0,3):C.GC_6818})

V_1724 = Vertex(name = 'V_1724',
                particles = [ P.A, P.A, P.W__plus__, P.Z, P.Z, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVS140, L.VVVVVS143, L.VVVVVS15, L.VVVVVS16, L.VVVVVS164, L.VVVVVS171, L.VVVVVS181, L.VVVVVS183, L.VVVVVS28, L.VVVVVS63, L.VVVVVS64, L.VVVVVS68, L.VVVVVS79, L.VVVVVS81 ],
                couplings = {(0,11):C.GC_1089,(0,13):C.GC_1790,(0,9):C.GC_2269,(0,8):C.GC_3131,(0,7):C.GC_6792,(0,3):C.GC_6798,(0,2):C.GC_4001,(0,12):C.GC_4296,(0,10):C.GC_3997,(0,6):C.GC_4000,(0,1):C.GC_4292,(0,5):C.GC_4303,(0,4):C.GC_3998,(0,0):C.GC_3994})

V_1725 = Vertex(name = 'V_1725',
                particles = [ P.A, P.A, P.W__plus__, P.Z, P.Z, P.G0, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVSS106, L.VVVVVSS108, L.VVVVVSS193, L.VVVVVSS196, L.VVVVVSS20, L.VVVVVSS22, L.VVVVVSS221, L.VVVVVSS230, L.VVVVVSS241, L.VVVVVSS245, L.VVVVVSS35, L.VVVVVSS81, L.VVVVVSS82, L.VVVVVSS87 ],
                couplings = {(0,13):C.GC_1151,(0,1):C.GC_1838,(0,11):C.GC_2299,(0,10):C.GC_3147,(0,9):C.GC_6825,(0,5):C.GC_6843,(0,4):C.GC_4057,(0,0):C.GC_4351,(0,12):C.GC_4048,(0,8):C.GC_4054,(0,3):C.GC_4340,(0,7):C.GC_4356,(0,6):C.GC_4049,(0,2):C.GC_4043})

V_1726 = Vertex(name = 'V_1726',
                particles = [ P.A, P.A, P.W__plus__, P.Z, P.Z, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVVSS106, L.VVVVVSS108, L.VVVVVSS193, L.VVVVVSS196, L.VVVVVSS20, L.VVVVVSS22, L.VVVVVSS221, L.VVVVVSS230, L.VVVVVSS241, L.VVVVVSS245, L.VVVVVSS35, L.VVVVVSS81, L.VVVVVSS82, L.VVVVVSS87 ],
                couplings = {(0,13):C.GC_1149,(0,1):C.GC_1839,(0,11):C.GC_2301,(0,10):C.GC_3149,(0,9):C.GC_6829,(0,5):C.GC_6838,(0,4):C.GC_4055,(0,0):C.GC_4348,(0,12):C.GC_4047,(0,8):C.GC_4053,(0,3):C.GC_4341,(0,7):C.GC_4361,(0,6):C.GC_4051,(0,2):C.GC_4044})

V_1727 = Vertex(name = 'V_1727',
                particles = [ P.W__plus__, P.Z, P.Z, P.Z, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVS108, L.VVVVS150, L.VVVVS155, L.VVVVS158, L.VVVVS16, L.VVVVS169, L.VVVVS175, L.VVVVS180, L.VVVVS184, L.VVVVS198, L.VVVVS202, L.VVVVS213, L.VVVVS253, L.VVVVS259, L.VVVVS76, L.VVVVS79, L.VVVVS91, L.VVVVS92, L.VVVVS94, L.VVVVS98 ],
                couplings = {(0,3):C.GC_2565,(0,17):C.GC_2910,(0,5):C.GC_2567,(0,10):C.GC_6167,(0,4):C.GC_6164,(0,11):C.GC_6162,(0,13):C.GC_7185,(0,6):C.GC_5095,(0,0):C.GC_4074,(0,2):C.GC_4563,(0,16):C.GC_4847,(0,18):C.GC_4087,(0,19):C.GC_4090,(0,1):C.GC_4560,(0,15):C.GC_4552,(0,12):C.GC_4557,(0,9):C.GC_4846,(0,7):C.GC_4549,(0,14):C.GC_4845,(0,8):C.GC_4844})

V_1728 = Vertex(name = 'V_1728',
                particles = [ P.W__plus__, P.Z, P.Z, P.Z, P.G0, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSS204, L.VVVVSS205, L.VVVVSS412, L.VVVVSS436, L.VVVVSS450, L.VVVVSS451, L.VVVVSS471, L.VVVVSS486, L.VVVVSS489, L.VVVVSS490, L.VVVVSS492, L.VVVVSS554, L.VVVVSS567, L.VVVVSS569, L.VVVVSS595, L.VVVVSS609, L.VVVVSS620, L.VVVVSS632, L.VVVVSS642, L.VVVVSS646, L.VVVVSS664, L.VVVVSS666, L.VVVVSS688, L.VVVVSS689, L.VVVVSS757, L.VVVVSS773 ],
                couplings = {(0,13):C.GC_2638,(0,5):C.GC_2972,(0,9):C.GC_2087,(0,8):C.GC_2089,(0,14):C.GC_2644,(0,19):C.GC_3580,(0,0):C.GC_3588,(0,20):C.GC_3583,(0,22):C.GC_6179,(0,25):C.GC_7227,(0,15):C.GC_5096,(0,12):C.GC_4683,(0,4):C.GC_4860,(0,7):C.GC_4112,(0,10):C.GC_4117,(0,11):C.GC_4674,(0,1):C.GC_4106,(0,2):C.GC_4655,(0,24):C.GC_4666,(0,18):C.GC_4859,(0,23):C.GC_4107,(0,21):C.GC_4100,(0,17):C.GC_4648,(0,3):C.GC_4854,(0,16):C.GC_4851,(0,6):C.GC_4078})

V_1729 = Vertex(name = 'V_1729',
                particles = [ P.W__plus__, P.Z, P.Z, P.Z, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSS204, L.VVVVSS206, L.VVVVSS436, L.VVVVSS439, L.VVVVSS450, L.VVVVSS451, L.VVVVSS471, L.VVVVSS543, L.VVVVSS554, L.VVVVSS563, L.VVVVSS565, L.VVVVSS592, L.VVVVSS593, L.VVVVSS595, L.VVVVSS601, L.VVVVSS609, L.VVVVSS616, L.VVVVSS620, L.VVVVSS642, L.VVVVSS646, L.VVVVSS664, L.VVVVSS672, L.VVVVSS754, L.VVVVSS771, L.VVVVSS772, L.VVVVSS773 ],
                couplings = {(0,10):C.GC_2640,(0,5):C.GC_2970,(0,13):C.GC_2643,(0,12):C.GC_2088,(0,11):C.GC_2090,(0,19):C.GC_3581,(0,0):C.GC_3587,(0,20):C.GC_3584,(0,25):C.GC_7225,(0,23):C.GC_6181,(0,15):C.GC_5097,(0,9):C.GC_4681,(0,4):C.GC_4861,(0,7):C.GC_4110,(0,14):C.GC_4116,(0,8):C.GC_4676,(0,3):C.GC_4657,(0,1):C.GC_4105,(0,22):C.GC_4669,(0,18):C.GC_4858,(0,24):C.GC_4108,(0,21):C.GC_4101,(0,16):C.GC_4650,(0,2):C.GC_4855,(0,17):C.GC_4852,(0,6):C.GC_4079})

V_1730 = Vertex(name = 'V_1730',
                particles = [ P.A, P.A, P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVS2, L.VVVVVVS27, L.VVVVVVS29, L.VVVVVVS42, L.VVVVVVS44, L.VVVVVVS45, L.VVVVVVS46 ],
                couplings = {(0,0):C.GC_3806,(0,3):C.GC_1452,(0,4):C.GC_2789,(0,5):C.GC_2790,(0,2):C.GC_3804,(0,6):C.GC_3068,(0,1):C.GC_3070})

V_1731 = Vertex(name = 'V_1731',
                particles = [ P.A, P.A, P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.G0, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVSS3, L.VVVVVVSS30, L.VVVVVVSS32, L.VVVVVVSS50, L.VVVVVVSS58, L.VVVVVVSS60, L.VVVVVVSS61 ],
                couplings = {(0,0):C.GC_3839,(0,3):C.GC_1456,(0,4):C.GC_2806,(0,5):C.GC_2809,(0,2):C.GC_3835,(0,6):C.GC_3075,(0,1):C.GC_3080})

V_1732 = Vertex(name = 'V_1732',
                particles = [ P.A, P.A, P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVSS3, L.VVVVVVSS30, L.VVVVVVSS32, L.VVVVVVSS50, L.VVVVVVSS58, L.VVVVVVSS60, L.VVVVVVSS61 ],
                couplings = {(0,0):C.GC_3837,(0,3):C.GC_1457,(0,4):C.GC_2804,(0,5):C.GC_2808,(0,2):C.GC_3833,(0,6):C.GC_3076,(0,1):C.GC_3079})

V_1733 = Vertex(name = 'V_1733',
                particles = [ P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.Z, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVS134, L.VVVVVS162, L.VVVVVS165, L.VVVVVS166, L.VVVVVS186, L.VVVVVS187, L.VVVVVS188, L.VVVVVS209, L.VVVVVS34, L.VVVVVS35, L.VVVVVS39, L.VVVVVS41, L.VVVVVS43, L.VVVVVS48, L.VVVVVS58, L.VVVVVS96, L.VVVVVS97 ],
                couplings = {(0,13):C.GC_1090,(0,16):C.GC_1790,(0,15):C.GC_2269,(0,8):C.GC_3130,(0,4):C.GC_1085,(0,7):C.GC_1087,(0,6):C.GC_2265,(0,5):C.GC_2268,(0,10):C.GC_1785,(0,14):C.GC_1086,(0,0):C.GC_2267,(0,11):C.GC_6800,(0,9):C.GC_4298,(0,2):C.GC_6791,(0,1):C.GC_4294,(0,3):C.GC_4302,(0,12):C.GC_4150})

V_1734 = Vertex(name = 'V_1734',
                particles = [ P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.Z, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVS165 ],
                couplings = {(0,0):C.GC_4149})

V_1735 = Vertex(name = 'V_1735',
                particles = [ P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.Z, P.G0, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVSS129, L.VVVVVSS133, L.VVVVVSS187, L.VVVVVSS219, L.VVVVVSS222, L.VVVVVSS223, L.VVVVVSS250, L.VVVVVSS254, L.VVVVVSS255, L.VVVVVSS300, L.VVVVVSS46, L.VVVVVSS47, L.VVVVVSS51, L.VVVVVSS53, L.VVVVVSS55, L.VVVVVSS61, L.VVVVVSS72 ],
                couplings = {(0,15):C.GC_1150,(0,1):C.GC_1838,(0,0):C.GC_2299,(0,10):C.GC_3148,(0,6):C.GC_1141,(0,9):C.GC_1145,(0,7):C.GC_2290,(0,8):C.GC_2298,(0,12):C.GC_1828,(0,16):C.GC_1142,(0,2):C.GC_2295,(0,14):C.GC_4217,(0,4):C.GC_6828,(0,13):C.GC_6835,(0,11):C.GC_4352,(0,3):C.GC_4345,(0,5):C.GC_4357})

V_1736 = Vertex(name = 'V_1736',
                particles = [ P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.Z, P.G0, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVSS222 ],
                couplings = {(0,0):C.GC_4212})

V_1737 = Vertex(name = 'V_1737',
                particles = [ P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.Z, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVVSS132, L.VVVVVSS133, L.VVVVVSS183, L.VVVVVSS219, L.VVVVVSS222, L.VVVVVSS223, L.VVVVVSS250, L.VVVVVSS299, L.VVVVVSS300, L.VVVVVSS303, L.VVVVVSS46, L.VVVVVSS47, L.VVVVVSS51, L.VVVVVSS53, L.VVVVVSS55, L.VVVVVSS60, L.VVVVVSS72 ],
                couplings = {(0,15):C.GC_1154,(0,1):C.GC_1839,(0,0):C.GC_2301,(0,10):C.GC_3146,(0,6):C.GC_1140,(0,8):C.GC_1146,(0,7):C.GC_2291,(0,9):C.GC_2297,(0,12):C.GC_1829,(0,16):C.GC_1143,(0,2):C.GC_2294,(0,14):C.GC_4218,(0,4):C.GC_6824,(0,13):C.GC_6840,(0,11):C.GC_4350,(0,3):C.GC_4343,(0,5):C.GC_4360})

V_1738 = Vertex(name = 'V_1738',
                particles = [ P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.Z, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVVSS222 ],
                couplings = {(0,0):C.GC_4215})

V_1739 = Vertex(name = 'V_1739',
                particles = [ P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.G0, P.G0 ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVSS18, L.VVVVVVSS44, L.VVVVVVSS45, L.VVVVVVSS5 ],
                couplings = {(0,3):C.GC_4071,(0,1):C.GC_6867,(0,0):C.GC_4378,(0,2):C.GC_4379})

V_1740 = Vertex(name = 'V_1740',
                particles = [ P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.G0, P.G0 ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVSS44 ],
                couplings = {(0,0):C.GC_4339})

V_1741 = Vertex(name = 'V_1741',
                particles = [ P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVSS44, L.VVVVVVSS46, L.VVVVVVSS5, L.VVVVVVSS55, L.VVVVVVSS56, L.VVVVVVSS7 ],
                couplings = {(0,2):C.GC_4071,(0,5):C.GC_4070,(0,0):C.GC_6868,(0,3):C.GC_4378,(0,1):C.GC_4380,(0,4):C.GC_4069})

V_1742 = Vertex(name = 'V_1742',
                particles = [ P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVSS44 ],
                couplings = {(0,0):C.GC_4339})

V_1743 = Vertex(name = 'V_1743',
                particles = [ P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVS16, L.VVVVVVS39, L.VVVVVVS4, L.VVVVVVS40 ],
                couplings = {(0,1):C.GC_6856,(0,2):C.GC_4068,(0,0):C.GC_4371,(0,3):C.GC_4372})

V_1744 = Vertex(name = 'V_1744',
                particles = [ P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVS39 ],
                couplings = {(0,0):C.GC_4291})

V_1745 = Vertex(name = 'V_1745',
                particles = [ P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVSS18, L.VVVVVVSS44, L.VVVVVVSS45, L.VVVVVVSS5 ],
                couplings = {(0,3):C.GC_4071,(0,1):C.GC_6867,(0,0):C.GC_4378,(0,2):C.GC_4379})

V_1746 = Vertex(name = 'V_1746',
                particles = [ P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVSS44 ],
                couplings = {(0,0):C.GC_4339})

V_1747 = Vertex(name = 'V_1747',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.G0 ],
                color = [ '1' ],
                lorentz = [ L.VVVVVS201, L.VVVVVS202, L.VVVVVS23, L.VVVVVS7 ],
                couplings = {(0,3):C.GC_2729,(0,0):C.GC_2727,(0,2):C.GC_3030,(0,1):C.GC_3028})

V_1748 = Vertex(name = 'V_1748',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.G0, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVVSS267, L.VVVVVSS281, L.VVVVVSS29, L.VVVVVSS8 ],
                couplings = {(0,3):C.GC_2760,(0,1):C.GC_2757,(0,2):C.GC_3049,(0,0):C.GC_3046})

V_1749 = Vertex(name = 'V_1749',
                particles = [ P.W__minus__, P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVS6 ],
                couplings = {(0,0):C.GC_3803})

V_1750 = Vertex(name = 'V_1750',
                particles = [ P.W__minus__, P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.G0, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVSS8 ],
                couplings = {(0,0):C.GC_3832})

V_1751 = Vertex(name = 'V_1751',
                particles = [ P.W__minus__, P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVSS8 ],
                couplings = {(0,0):C.GC_3831})

V_1752 = Vertex(name = 'V_1752',
                particles = [ P.A, P.A, P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.Z ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVVV10, L.VVVVVVVV7 ],
                couplings = {(0,1):C.GC_6872,(0,0):C.GC_6871})

V_1753 = Vertex(name = 'V_1753',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.W__plus__, P.Z, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVS28 ],
                couplings = {(0,0):C.GC_3803})

V_1754 = Vertex(name = 'V_1754',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.W__plus__, P.Z, P.G0, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVSS31 ],
                couplings = {(0,0):C.GC_3830})

V_1755 = Vertex(name = 'V_1755',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.W__plus__, P.Z, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVSS31 ],
                couplings = {(0,0):C.GC_3831})

V_1756 = Vertex(name = 'V_1756',
                particles = [ P.A, P.W__minus__, P.W__plus__, P.Z, P.Z, P.Z ],
                color = [ '1' ],
                lorentz = [ L.VVVVVV17, L.VVVVVV18, L.VVVVVV25, L.VVVVVV37, L.VVVVVV43, L.VVVVVV44, L.VVVVVV50, L.VVVVVV68, L.VVVVVV69, L.VVVVVV77, L.VVVVVV86, L.VVVVVV87 ],
                couplings = {(0,1):C.GC_6148,(0,0):C.GC_4206,(0,4):C.GC_6150,(0,5):C.GC_4211,(0,6):C.GC_6149,(0,2):C.GC_4208,(0,11):C.GC_6146,(0,10):C.GC_4204,(0,7):C.GC_6147,(0,8):C.GC_4205,(0,3):C.GC_4067,(0,9):C.GC_6131})

V_1757 = Vertex(name = 'V_1757',
                particles = [ P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.Z ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVV11, L.VVVVVVV12, L.VVVVVVV14, L.VVVVVVV16 ],
                couplings = {(0,2):C.GC_4126,(0,0):C.GC_4125,(0,1):C.GC_4123,(0,3):C.GC_4124})

V_1758 = Vertex(name = 'V_1758',
                particles = [ P.A, P.W__minus__, P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.W__plus__, P.Z ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVVV12, L.VVVVVVVV6 ],
                couplings = {(0,1):C.GC_4381,(0,0):C.GC_4382})

V_1759 = Vertex(name = 'V_1759',
                particles = [ P.Z, P.Z, P.G0, P.G0, P.G0, P.G0, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSSS1 ],
                couplings = {(0,0):C.GC_5002})

V_1760 = Vertex(name = 'V_1760',
                particles = [ P.Z, P.Z, P.G0, P.G0, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSSS1 ],
                couplings = {(0,0):C.GC_5001})

V_1761 = Vertex(name = 'V_1761',
                particles = [ P.Z, P.Z, P.G__minus__, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSSS1 ],
                couplings = {(0,0):C.GC_5003})

V_1762 = Vertex(name = 'V_1762',
                particles = [ P.Z, P.Z, P.G0, P.G0, P.G__minus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSS1 ],
                couplings = {(0,0):C.GC_4983})

V_1763 = Vertex(name = 'V_1763',
                particles = [ P.Z, P.Z, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSS1 ],
                couplings = {(0,0):C.GC_4984})

V_1764 = Vertex(name = 'V_1764',
                particles = [ P.Z, P.Z, P.G0, P.G0, P.G__minus__, P.G__plus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSSS1 ],
                couplings = {(0,0):C.GC_5000})

V_1765 = Vertex(name = 'V_1765',
                particles = [ P.Z, P.Z, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSSS1 ],
                couplings = {(0,0):C.GC_5001})

V_1766 = Vertex(name = 'V_1766',
                particles = [ P.Z, P.Z, P.G__minus__, P.G__plus__, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSS1 ],
                couplings = {(0,0):C.GC_4985})

V_1767 = Vertex(name = 'V_1767',
                particles = [ P.Z, P.Z, P.G__minus__, P.G__plus__, P.H, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSSS1 ],
                couplings = {(0,0):C.GC_5002})

V_1768 = Vertex(name = 'V_1768',
                particles = [ P.Z, P.Z, P.G0, P.G0, P.G0, P.G0, P.G0, P.G0 ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSSS1 ],
                couplings = {(0,0):C.GC_3111})

V_1769 = Vertex(name = 'V_1769',
                particles = [ P.Z, P.Z, P.G0, P.G0, P.G0, P.G0, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSS1 ],
                couplings = {(0,0):C.GC_3100})

V_1770 = Vertex(name = 'V_1770',
                particles = [ P.Z, P.Z, P.G0, P.G0, P.G0, P.G0, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSSS1 ],
                couplings = {(0,0):C.GC_3110})

V_1771 = Vertex(name = 'V_1771',
                particles = [ P.Z, P.Z, P.G0, P.G0, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSS1 ],
                couplings = {(0,0):C.GC_3100})

V_1772 = Vertex(name = 'V_1772',
                particles = [ P.Z, P.Z, P.G0, P.G0, P.H, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSSS1 ],
                couplings = {(0,0):C.GC_3110})

V_1773 = Vertex(name = 'V_1773',
                particles = [ P.Z, P.Z, P.H, P.H, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSS1 ],
                couplings = {(0,0):C.GC_3101})

V_1774 = Vertex(name = 'V_1774',
                particles = [ P.Z, P.Z, P.H, P.H, P.H, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVSSSSSS1 ],
                couplings = {(0,0):C.GC_3111})

V_1775 = Vertex(name = 'V_1775',
                particles = [ P.A, P.A, P.Z, P.G0, P.G0 ],
                color = [ '1' ],
                lorentz = [ L.VVVSS293 ],
                couplings = {(0,0):C.GC_4475})

V_1776 = Vertex(name = 'V_1776',
                particles = [ P.A, P.A, P.Z, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVS125 ],
                couplings = {(0,0):C.GC_4418})

V_1777 = Vertex(name = 'V_1777',
                particles = [ P.A, P.A, P.Z, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSS293 ],
                couplings = {(0,0):C.GC_4475})

V_1778 = Vertex(name = 'V_1778',
                particles = [ P.A, P.Z, P.Z, P.G0, P.G0, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS240, L.VVVSSSS69, L.VVVSSSS7, L.VVVSSSS84 ],
                couplings = {(0,2):C.GC_4705,(0,3):C.GC_4698,(0,1):C.GC_7338,(0,0):C.GC_4872})

V_1779 = Vertex(name = 'V_1779',
                particles = [ P.A, P.Z, P.Z, P.G__minus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSS43, L.VVVSSS59, L.VVVSSS7, L.VVVSSS89 ],
                couplings = {(0,0):C.GC_7332,(0,3):C.GC_4866,(0,2):C.GC_4581,(0,1):C.GC_4575})

V_1780 = Vertex(name = 'V_1780',
                particles = [ P.A, P.Z, P.Z, P.G__minus__, P.G__plus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS110, L.VVVSSSS61, L.VVVSSSS7, L.VVVSSSS84 ],
                couplings = {(0,2):C.GC_4705,(0,3):C.GC_4698,(0,1):C.GC_7338,(0,0):C.GC_4872})

V_1781 = Vertex(name = 'V_1781',
                particles = [ P.Z, P.Z, P.G0, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVSSS32, L.VVSSS70, L.VVSSS89, L.VVSSS9 ],
                couplings = {(0,3):C.GC_1565,(0,1):C.GC_1562,(0,2):C.GC_4975,(0,0):C.GC_4979})

V_1782 = Vertex(name = 'V_1782',
                particles = [ P.Z, P.Z, P.G0, P.G__minus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVSSSS135, L.VVSSSS152, L.VVSSSS52, L.VVSSSS70 ],
                couplings = {(0,1):C.GC_4986,(0,2):C.GC_4992,(0,3):C.GC_1616,(0,0):C.GC_1613})

V_1783 = Vertex(name = 'V_1783',
                particles = [ P.A, P.Z, P.Z, P.G0, P.G0 ],
                color = [ '1' ],
                lorentz = [ L.VVVSS302, L.VVVSS311, L.VVVSS325 ],
                couplings = {(0,1):C.GC_2505,(0,2):C.GC_2866,(0,0):C.GC_2865})

V_1784 = Vertex(name = 'V_1784',
                particles = [ P.A, P.Z, P.Z, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVS129, L.VVVS135, L.VVVS144 ],
                couplings = {(0,1):C.GC_2424,(0,2):C.GC_2841,(0,0):C.GC_2840})

V_1785 = Vertex(name = 'V_1785',
                particles = [ P.A, P.Z, P.Z, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSS302, L.VVVSS311, L.VVVSS325 ],
                couplings = {(0,1):C.GC_2505,(0,2):C.GC_2866,(0,0):C.GC_2865})

V_1786 = Vertex(name = 'V_1786',
                particles = [ P.Z, P.Z, P.Z, P.G0, P.G0 ],
                color = [ '1' ],
                lorentz = [ L.VVVSS312 ],
                couplings = {(0,0):C.GC_4477})

V_1787 = Vertex(name = 'V_1787',
                particles = [ P.Z, P.Z, P.Z, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVS138 ],
                couplings = {(0,0):C.GC_4420})

V_1788 = Vertex(name = 'V_1788',
                particles = [ P.Z, P.Z, P.Z, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSS312 ],
                couplings = {(0,0):C.GC_4477})

V_1789 = Vertex(name = 'V_1789',
                particles = [ P.A, P.A, P.W__minus__, P.Z, P.G0, P.G0, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS5 ],
                couplings = {(0,0):C.GC_3720})

V_1790 = Vertex(name = 'V_1790',
                particles = [ P.A, P.A, P.W__minus__, P.Z, P.G0, P.G0, P.G0, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_3762})

V_1791 = Vertex(name = 'V_1791',
                particles = [ P.A, P.A, P.W__minus__, P.Z, P.G0, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS5 ],
                couplings = {(0,0):C.GC_3717})

V_1792 = Vertex(name = 'V_1792',
                particles = [ P.A, P.A, P.W__minus__, P.Z, P.G0, P.G0, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_3767})

V_1793 = Vertex(name = 'V_1793',
                particles = [ P.A, P.A, P.W__minus__, P.Z, P.G__plus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS5 ],
                couplings = {(0,0):C.GC_3726})

V_1794 = Vertex(name = 'V_1794',
                particles = [ P.A, P.A, P.W__minus__, P.Z, P.G0, P.G__plus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_3764})

V_1795 = Vertex(name = 'V_1795',
                particles = [ P.A, P.A, P.W__minus__, P.Z, P.G__plus__, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_3773})

V_1796 = Vertex(name = 'V_1796',
                particles = [ P.A, P.A, P.Z, P.Z, P.G0, P.G0, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS3, L.VVVVSSSS4 ],
                couplings = {(0,0):C.GC_5062,(0,1):C.GC_5070})

V_1797 = Vertex(name = 'V_1797',
                particles = [ P.A, P.A, P.Z, P.Z, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS13 ],
                couplings = {(0,0):C.GC_5073})

V_1798 = Vertex(name = 'V_1798',
                particles = [ P.A, P.A, P.Z, P.Z, P.G__minus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS3, L.VVVVSSS4 ],
                couplings = {(0,0):C.GC_5047,(0,1):C.GC_5053})

V_1799 = Vertex(name = 'V_1799',
                particles = [ P.A, P.A, P.Z, P.Z, P.G__minus__, P.G__plus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS3, L.VVVVSSSS4 ],
                couplings = {(0,0):C.GC_5062,(0,1):C.GC_5070})

V_1800 = Vertex(name = 'V_1800',
                particles = [ P.A, P.Z, P.Z, P.G0, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVSSS42, L.VVVSSS80 ],
                couplings = {(0,1):C.GC_7331,(0,0):C.GC_7333})

V_1801 = Vertex(name = 'V_1801',
                particles = [ P.A, P.Z, P.Z, P.G0, P.G__minus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS185, L.VVVSSSS66 ],
                couplings = {(0,0):C.GC_7337,(0,1):C.GC_7339})

V_1802 = Vertex(name = 'V_1802',
                particles = [ P.A, P.Z, P.Z, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS229 ],
                couplings = {(0,0):C.GC_7340})

V_1803 = Vertex(name = 'V_1803',
                particles = [ P.A, P.W__minus__, P.Z, P.Z, P.G__minus__, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS10, L.VVVVSSS13, L.VVVVSSS14, L.VVVVSSS15, L.VVVVSSS5, L.VVVVSSS9 ],
                couplings = {(0,4):C.GC_7251,(0,1):C.GC_6185,(0,2):C.GC_7296,(0,0):C.GC_4813,(0,3):C.GC_7352,(0,5):C.GC_4889})

V_1804 = Vertex(name = 'V_1804',
                particles = [ P.A, P.W__minus__, P.Z, P.Z, P.G0, P.G__minus__, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS10, L.VVVVSSSS13, L.VVVVSSSS14, L.VVVVSSSS15, L.VVVVSSSS5, L.VVVVSSSS9 ],
                couplings = {(0,1):C.GC_6187,(0,2):C.GC_7307,(0,0):C.GC_4830,(0,3):C.GC_7355,(0,5):C.GC_4891,(0,4):C.GC_7275})

V_1805 = Vertex(name = 'V_1805',
                particles = [ P.A, P.W__minus__, P.Z, P.Z, P.G__minus__, P.G__plus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS10, L.VVVVSSSS13, L.VVVVSSSS14, L.VVVVSSSS15, L.VVVVSSSS5, L.VVVVSSSS9 ],
                couplings = {(0,1):C.GC_6188,(0,2):C.GC_7306,(0,0):C.GC_4829,(0,3):C.GC_7360,(0,5):C.GC_4896,(0,4):C.GC_7281})

V_1806 = Vertex(name = 'V_1806',
                particles = [ P.A, P.W__minus__, P.Z, P.Z, P.G0, P.G0, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS3, L.VVVVSSS4, L.VVVVSSS5 ],
                couplings = {(0,2):C.GC_7246,(0,0):C.GC_7350,(0,1):C.GC_4887})

V_1807 = Vertex(name = 'V_1807',
                particles = [ P.A, P.W__minus__, P.Z, P.Z, P.G0, P.G0, P.G0, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS3, L.VVVVSSSS4, L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_7356,(0,1):C.GC_4892,(0,2):C.GC_7290})

V_1808 = Vertex(name = 'V_1808',
                particles = [ P.A, P.W__minus__, P.Z, P.Z, P.G0, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS3, L.VVVVSSS4, L.VVVVSSS5 ],
                couplings = {(0,2):C.GC_7258,(0,0):C.GC_7349,(0,1):C.GC_4886})

V_1809 = Vertex(name = 'V_1809',
                particles = [ P.A, P.W__minus__, P.Z, P.Z, P.G0, P.G0, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS3, L.VVVVSSSS4, L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_7358,(0,1):C.GC_4894,(0,2):C.GC_7276})

V_1810 = Vertex(name = 'V_1810',
                particles = [ P.A, P.W__minus__, P.Z, P.Z, P.G__plus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS3, L.VVVVSSS4, L.VVVVSSS5 ],
                couplings = {(0,2):C.GC_7252,(0,0):C.GC_7351,(0,1):C.GC_4888})

V_1811 = Vertex(name = 'V_1811',
                particles = [ P.A, P.W__minus__, P.Z, P.Z, P.G0, P.G__plus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS3, L.VVVVSSSS4, L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_7357,(0,1):C.GC_4893,(0,2):C.GC_7288})

V_1812 = Vertex(name = 'V_1812',
                particles = [ P.A, P.W__minus__, P.Z, P.Z, P.G__plus__, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS3, L.VVVVSSSS4, L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_7359,(0,1):C.GC_4895,(0,2):C.GC_7282})

V_1813 = Vertex(name = 'V_1813',
                particles = [ P.W__minus__, P.W__minus__, P.Z, P.Z, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSS349, L.VVVVSS391, L.VVVVSS603, L.VVVVSS610 ],
                couplings = {(0,2):C.GC_1775,(0,3):C.GC_5037,(0,0):C.GC_5041,(0,1):C.GC_2320})

V_1814 = Vertex(name = 'V_1814',
                particles = [ P.W__minus__, P.W__minus__, P.Z, P.Z, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSS603 ],
                couplings = {(0,0):C.GC_2155})

V_1815 = Vertex(name = 'V_1815',
                particles = [ P.W__minus__, P.W__minus__, P.Z, P.Z, P.G0, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS16, L.VVVVSSS3, L.VVVVSSS4, L.VVVVSSS5 ],
                couplings = {(0,3):C.GC_1809,(0,0):C.GC_5045,(0,1):C.GC_5051,(0,2):C.GC_2323})

V_1816 = Vertex(name = 'V_1816',
                particles = [ P.W__minus__, P.W__minus__, P.Z, P.Z, P.G0, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS5 ],
                couplings = {(0,0):C.GC_2172})

V_1817 = Vertex(name = 'V_1817',
                particles = [ P.W__minus__, P.W__minus__, P.Z, P.Z, P.G0, P.G0, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS16, L.VVVVSSSS3, L.VVVVSSSS4, L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_5061,(0,1):C.GC_5069,(0,2):C.GC_2331,(0,3):C.GC_1868})

V_1818 = Vertex(name = 'V_1818',
                particles = [ P.W__minus__, P.W__minus__, P.Z, P.Z, P.G0, P.G0, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_2230})

V_1819 = Vertex(name = 'V_1819',
                particles = [ P.W__minus__, P.W__minus__, P.Z, P.Z, P.G__plus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS16, L.VVVVSSS3, L.VVVVSSS4, L.VVVVSSS5 ],
                couplings = {(0,3):C.GC_1807,(0,0):C.GC_5048,(0,1):C.GC_5054,(0,2):C.GC_2325})

V_1820 = Vertex(name = 'V_1820',
                particles = [ P.W__minus__, P.W__minus__, P.Z, P.Z, P.G__plus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS5 ],
                couplings = {(0,0):C.GC_2173})

V_1821 = Vertex(name = 'V_1821',
                particles = [ P.W__minus__, P.W__minus__, P.Z, P.Z, P.G0, P.G__plus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS16, L.VVVVSSSS3, L.VVVVSSSS4, L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_5059,(0,1):C.GC_5067,(0,2):C.GC_2329,(0,3):C.GC_1869})

V_1822 = Vertex(name = 'V_1822',
                particles = [ P.W__minus__, P.W__minus__, P.Z, P.Z, P.G0, P.G__plus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_2229})

V_1823 = Vertex(name = 'V_1823',
                particles = [ P.W__minus__, P.W__minus__, P.Z, P.Z, P.G__plus__, P.G__plus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS16, L.VVVVSSSS3, L.VVVVSSSS4, L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_5063,(0,1):C.GC_5071,(0,2):C.GC_2332,(0,3):C.GC_1867})

V_1824 = Vertex(name = 'V_1824',
                particles = [ P.W__minus__, P.W__minus__, P.Z, P.Z, P.G__plus__, P.G__plus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_2231})

V_1825 = Vertex(name = 'V_1825',
                particles = [ P.A, P.W__minus__, P.Z, P.Z, P.Z, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVS100, L.VVVVVS104, L.VVVVVS107, L.VVVVVS109, L.VVVVVS111, L.VVVVVS144, L.VVVVVS149, L.VVVVVS150, L.VVVVVS172, L.VVVVVS173, L.VVVVVS180, L.VVVVVS184, L.VVVVVS88, L.VVVVVS94 ],
                couplings = {(0,1):C.GC_5019,(0,0):C.GC_1094,(0,13):C.GC_2275,(0,7):C.GC_1091,(0,11):C.GC_6782,(0,9):C.GC_1098,(0,6):C.GC_2272,(0,8):C.GC_2278,(0,10):C.GC_3137,(0,12):C.GC_3135,(0,5):C.GC_3132,(0,2):C.GC_3991,(0,4):C.GC_4287,(0,3):C.GC_4289})

V_1826 = Vertex(name = 'V_1826',
                particles = [ P.A, P.W__minus__, P.Z, P.Z, P.Z, P.G0, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVSS120, L.VVVVVSS127, L.VVVVVSS137, L.VVVVVSS144, L.VVVVVSS147, L.VVVVVSS149, L.VVVVVSS151, L.VVVVVSS198, L.VVVVVSS204, L.VVVVVSS206, L.VVVVVSS231, L.VVVVVSS232, L.VVVVVSS240, L.VVVVVSS247 ],
                couplings = {(0,3):C.GC_5032,(0,2):C.GC_1164,(0,1):C.GC_2309,(0,9):C.GC_1160,(0,13):C.GC_6813,(0,11):C.GC_1171,(0,8):C.GC_2304,(0,10):C.GC_2313,(0,12):C.GC_3156,(0,0):C.GC_3153,(0,7):C.GC_3152,(0,4):C.GC_4038,(0,6):C.GC_4331,(0,5):C.GC_4338})

V_1827 = Vertex(name = 'V_1827',
                particles = [ P.A, P.W__minus__, P.Z, P.Z, P.Z, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVVSS120, L.VVVVVSS127, L.VVVVVSS137, L.VVVVVSS144, L.VVVVVSS147, L.VVVVVSS149, L.VVVVVSS151, L.VVVVVSS198, L.VVVVVSS204, L.VVVVVSS206, L.VVVVVSS231, L.VVVVVSS232, L.VVVVVSS240, L.VVVVVSS247 ],
                couplings = {(0,3):C.GC_5029,(0,2):C.GC_1162,(0,1):C.GC_2311,(0,9):C.GC_1157,(0,13):C.GC_6808,(0,11):C.GC_1168,(0,8):C.GC_2306,(0,10):C.GC_2316,(0,12):C.GC_3158,(0,0):C.GC_3155,(0,7):C.GC_3150,(0,4):C.GC_4039,(0,6):C.GC_4330,(0,5):C.GC_4336})

V_1828 = Vertex(name = 'V_1828',
                particles = [ P.A, P.W__plus__, P.Z, P.Z, P.G__minus__, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS10, L.VVVVSSS13, L.VVVVSSS14, L.VVVVSSS15, L.VVVVSSS5, L.VVVVSSS9 ],
                couplings = {(0,4):C.GC_7250,(0,1):C.GC_6185,(0,2):C.GC_7296,(0,0):C.GC_4813,(0,3):C.GC_7352,(0,5):C.GC_4889})

V_1829 = Vertex(name = 'V_1829',
                particles = [ P.A, P.W__plus__, P.Z, P.Z, P.G0, P.G__minus__, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS10, L.VVVVSSSS13, L.VVVVSSSS14, L.VVVVSSSS15, L.VVVVSSSS5, L.VVVVSSSS9 ],
                couplings = {(0,1):C.GC_6189,(0,2):C.GC_7305,(0,0):C.GC_4828,(0,3):C.GC_7363,(0,5):C.GC_4899,(0,4):C.GC_7274})

V_1830 = Vertex(name = 'V_1830',
                particles = [ P.A, P.W__plus__, P.Z, P.Z, P.G__minus__, P.G__minus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS10, L.VVVVSSSS13, L.VVVVSSSS14, L.VVVVSSSS15, L.VVVVSSSS5, L.VVVVSSSS9 ],
                couplings = {(0,1):C.GC_6188,(0,2):C.GC_7306,(0,0):C.GC_4829,(0,3):C.GC_7360,(0,5):C.GC_4896,(0,4):C.GC_7280})

V_1831 = Vertex(name = 'V_1831',
                particles = [ P.A, P.W__plus__, P.Z, P.Z, P.G0, P.G0, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS3, L.VVVVSSS4, L.VVVVSSS5 ],
                couplings = {(0,2):C.GC_7248,(0,0):C.GC_7350,(0,1):C.GC_4887})

V_1832 = Vertex(name = 'V_1832',
                particles = [ P.A, P.W__plus__, P.Z, P.Z, P.G0, P.G0, P.G0, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS3, L.VVVVSSSS4, L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_7362,(0,1):C.GC_4898,(0,2):C.GC_7289})

V_1833 = Vertex(name = 'V_1833',
                particles = [ P.A, P.W__plus__, P.Z, P.Z, P.G0, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS3, L.VVVVSSS4, L.VVVVSSS5 ],
                couplings = {(0,2):C.GC_7257,(0,0):C.GC_7353,(0,1):C.GC_4890})

V_1834 = Vertex(name = 'V_1834',
                particles = [ P.A, P.W__plus__, P.Z, P.Z, P.G0, P.G0, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS3, L.VVVVSSSS4, L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_7358,(0,1):C.GC_4894,(0,2):C.GC_7278})

V_1835 = Vertex(name = 'V_1835',
                particles = [ P.A, P.W__plus__, P.Z, P.Z, P.G__minus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS3, L.VVVVSSS4, L.VVVVSSS5 ],
                couplings = {(0,2):C.GC_7254,(0,0):C.GC_7351,(0,1):C.GC_4888})

V_1836 = Vertex(name = 'V_1836',
                particles = [ P.A, P.W__plus__, P.Z, P.Z, P.G0, P.G__minus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS3, L.VVVVSSSS4, L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_7361,(0,1):C.GC_4897,(0,2):C.GC_7287})

V_1837 = Vertex(name = 'V_1837',
                particles = [ P.A, P.W__plus__, P.Z, P.Z, P.G__minus__, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS3, L.VVVVSSSS4, L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_7359,(0,1):C.GC_4895,(0,2):C.GC_7284})

V_1838 = Vertex(name = 'V_1838',
                particles = [ P.W__minus__, P.W__plus__, P.Z, P.Z, P.G0, P.G0, P.G0, P.G0 ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS3, L.VVVVSSSS4, L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_5065,(0,1):C.GC_3170,(0,2):C.GC_1179})

V_1839 = Vertex(name = 'V_1839',
                particles = [ P.W__minus__, P.W__plus__, P.Z, P.Z, P.G0, P.G0, P.G0, P.G0 ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_2228})

V_1840 = Vertex(name = 'V_1840',
                particles = [ P.W__minus__, P.W__plus__, P.Z, P.Z, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS3, L.VVVVSSSS4, L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_5064,(0,1):C.GC_5072,(0,2):C.GC_1865})

V_1841 = Vertex(name = 'V_1841',
                particles = [ P.W__minus__, P.W__plus__, P.Z, P.Z, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_2227})

V_1842 = Vertex(name = 'V_1842',
                particles = [ P.W__minus__, P.W__plus__, P.Z, P.Z, P.G0, P.G0, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS3, L.VVVVSSS4, L.VVVVSSS5 ],
                couplings = {(0,2):C.GC_1103,(0,0):C.GC_5046,(0,1):C.GC_3165})

V_1843 = Vertex(name = 'V_1843',
                particles = [ P.W__minus__, P.W__plus__, P.Z, P.Z, P.G0, P.G0, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS5 ],
                couplings = {(0,0):C.GC_2170})

V_1844 = Vertex(name = 'V_1844',
                particles = [ P.W__minus__, P.W__plus__, P.Z, P.Z, P.G0, P.G0, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS3, L.VVVVSSSS4, L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_5060,(0,1):C.GC_3169,(0,2):C.GC_1178})

V_1845 = Vertex(name = 'V_1845',
                particles = [ P.W__minus__, P.W__plus__, P.Z, P.Z, P.G0, P.G0, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_2226})

V_1846 = Vertex(name = 'V_1846',
                particles = [ P.W__minus__, P.W__plus__, P.Z, P.Z, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS3, L.VVVVSSS4, L.VVVVSSS5 ],
                couplings = {(0,2):C.GC_1104,(0,0):C.GC_5049,(0,1):C.GC_3166})

V_1847 = Vertex(name = 'V_1847',
                particles = [ P.W__minus__, P.W__plus__, P.Z, P.Z, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS5 ],
                couplings = {(0,0):C.GC_2171})

V_1848 = Vertex(name = 'V_1848',
                particles = [ P.W__minus__, P.W__plus__, P.Z, P.Z, P.H, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS3, L.VVVVSSSS4, L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_5065,(0,1):C.GC_3170,(0,2):C.GC_1179})

V_1849 = Vertex(name = 'V_1849',
                particles = [ P.W__minus__, P.W__plus__, P.Z, P.Z, P.H, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_2228})

V_1850 = Vertex(name = 'V_1850',
                particles = [ P.W__minus__, P.W__plus__, P.Z, P.Z, P.G0, P.G0, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS13, L.VVVVSSSS16, L.VVVVSSSS3, L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_5068,(0,1):C.GC_1899,(0,2):C.GC_2330,(0,3):C.GC_1729})

V_1851 = Vertex(name = 'V_1851',
                particles = [ P.W__minus__, P.W__plus__, P.Z, P.Z, P.G0, P.G0, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_2318})

V_1852 = Vertex(name = 'V_1852',
                particles = [ P.W__minus__, P.W__plus__, P.Z, P.Z, P.G__minus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS13, L.VVVVSSS16, L.VVVVSSS3, L.VVVVSSS5 ],
                couplings = {(0,3):C.GC_1653,(0,0):C.GC_5052,(0,1):C.GC_1884,(0,2):C.GC_2324})

V_1853 = Vertex(name = 'V_1853',
                particles = [ P.W__minus__, P.W__plus__, P.Z, P.Z, P.G__minus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS5 ],
                couplings = {(0,0):C.GC_2279})

V_1854 = Vertex(name = 'V_1854',
                particles = [ P.W__minus__, P.W__plus__, P.Z, P.Z, P.G__minus__, P.G__plus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS13, L.VVVVSSSS16, L.VVVVSSSS3, L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_5068,(0,1):C.GC_1899,(0,2):C.GC_2330,(0,3):C.GC_1729})

V_1855 = Vertex(name = 'V_1855',
                particles = [ P.W__minus__, P.W__plus__, P.Z, P.Z, P.G__minus__, P.G__plus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_2318})

V_1856 = Vertex(name = 'V_1856',
                particles = [ P.W__plus__, P.W__plus__, P.Z, P.Z, P.G__minus__, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSS349, L.VVVVSS391, L.VVVVSS603, L.VVVVSS610 ],
                couplings = {(0,2):C.GC_1776,(0,3):C.GC_5037,(0,0):C.GC_5041,(0,1):C.GC_2320})

V_1857 = Vertex(name = 'V_1857',
                particles = [ P.W__plus__, P.W__plus__, P.Z, P.Z, P.G__minus__, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSS603 ],
                couplings = {(0,0):C.GC_2155})

V_1858 = Vertex(name = 'V_1858',
                particles = [ P.W__plus__, P.W__plus__, P.Z, P.Z, P.G0, P.G__minus__, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS16, L.VVVVSSS3, L.VVVVSSS4, L.VVVVSSS5 ],
                couplings = {(0,3):C.GC_1809,(0,0):C.GC_5050,(0,1):C.GC_5055,(0,2):C.GC_2326})

V_1859 = Vertex(name = 'V_1859',
                particles = [ P.W__plus__, P.W__plus__, P.Z, P.Z, P.G0, P.G__minus__, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS5 ],
                couplings = {(0,0):C.GC_2174})

V_1860 = Vertex(name = 'V_1860',
                particles = [ P.W__plus__, P.W__plus__, P.Z, P.Z, P.G0, P.G0, P.G__minus__, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS16, L.VVVVSSSS3, L.VVVVSSSS4, L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_5061,(0,1):C.GC_5069,(0,2):C.GC_2331,(0,3):C.GC_1867})

V_1861 = Vertex(name = 'V_1861',
                particles = [ P.W__plus__, P.W__plus__, P.Z, P.Z, P.G0, P.G0, P.G__minus__, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_2230})

V_1862 = Vertex(name = 'V_1862',
                particles = [ P.W__plus__, P.W__plus__, P.Z, P.Z, P.G__minus__, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS16, L.VVVVSSS3, L.VVVVSSS4, L.VVVVSSS5 ],
                couplings = {(0,3):C.GC_1808,(0,0):C.GC_5048,(0,1):C.GC_5054,(0,2):C.GC_2325})

V_1863 = Vertex(name = 'V_1863',
                particles = [ P.W__plus__, P.W__plus__, P.Z, P.Z, P.G__minus__, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS5 ],
                couplings = {(0,0):C.GC_2173})

V_1864 = Vertex(name = 'V_1864',
                particles = [ P.W__plus__, P.W__plus__, P.Z, P.Z, P.G0, P.G__minus__, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS16, L.VVVVSSSS3, L.VVVVSSSS4, L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_5066,(0,1):C.GC_5074,(0,2):C.GC_2333,(0,3):C.GC_1869})

V_1865 = Vertex(name = 'V_1865',
                particles = [ P.W__plus__, P.W__plus__, P.Z, P.Z, P.G0, P.G__minus__, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_2232})

V_1866 = Vertex(name = 'V_1866',
                particles = [ P.W__plus__, P.W__plus__, P.Z, P.Z, P.G__minus__, P.G__minus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS16, L.VVVVSSSS3, L.VVVVSSSS4, L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_5063,(0,1):C.GC_5071,(0,2):C.GC_2332,(0,3):C.GC_1868})

V_1867 = Vertex(name = 'V_1867',
                particles = [ P.W__plus__, P.W__plus__, P.Z, P.Z, P.G__minus__, P.G__minus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS5 ],
                couplings = {(0,0):C.GC_2231})

V_1868 = Vertex(name = 'V_1868',
                particles = [ P.A, P.W__plus__, P.Z, P.Z, P.Z, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVS100, L.VVVVVS104, L.VVVVVS107, L.VVVVVS109, L.VVVVVS111, L.VVVVVS144, L.VVVVVS149, L.VVVVVS150, L.VVVVVS172, L.VVVVVS173, L.VVVVVS180, L.VVVVVS184, L.VVVVVS88, L.VVVVVS94 ],
                couplings = {(0,1):C.GC_5020,(0,0):C.GC_1095,(0,13):C.GC_2274,(0,7):C.GC_1092,(0,11):C.GC_6783,(0,9):C.GC_1099,(0,6):C.GC_2271,(0,8):C.GC_2277,(0,10):C.GC_3136,(0,12):C.GC_3134,(0,5):C.GC_3133,(0,2):C.GC_3991,(0,4):C.GC_4287,(0,3):C.GC_4290})

V_1869 = Vertex(name = 'V_1869',
                particles = [ P.A, P.W__plus__, P.Z, P.Z, P.Z, P.G0, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVSS120, L.VVVVVSS127, L.VVVVVSS137, L.VVVVVSS144, L.VVVVVSS147, L.VVVVVSS149, L.VVVVVSS151, L.VVVVVSS198, L.VVVVVSS204, L.VVVVVSS206, L.VVVVVSS231, L.VVVVVSS232, L.VVVVVSS240, L.VVVVVSS247 ],
                couplings = {(0,3):C.GC_5031,(0,2):C.GC_1164,(0,1):C.GC_2309,(0,9):C.GC_1160,(0,13):C.GC_6812,(0,11):C.GC_1171,(0,8):C.GC_2304,(0,10):C.GC_2313,(0,12):C.GC_3156,(0,0):C.GC_3153,(0,7):C.GC_3152,(0,4):C.GC_4037,(0,6):C.GC_4332,(0,5):C.GC_4338})

V_1870 = Vertex(name = 'V_1870',
                particles = [ P.A, P.W__plus__, P.Z, P.Z, P.Z, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVVSS120, L.VVVVVSS127, L.VVVVVSS137, L.VVVVVSS144, L.VVVVVSS147, L.VVVVVSS149, L.VVVVVSS151, L.VVVVVSS198, L.VVVVVSS204, L.VVVVVSS206, L.VVVVVSS231, L.VVVVVSS232, L.VVVVVSS240, L.VVVVVSS247 ],
                couplings = {(0,3):C.GC_5030,(0,2):C.GC_1163,(0,1):C.GC_2310,(0,9):C.GC_1158,(0,13):C.GC_6809,(0,11):C.GC_1169,(0,8):C.GC_2305,(0,10):C.GC_2315,(0,12):C.GC_3157,(0,0):C.GC_3154,(0,7):C.GC_3151,(0,4):C.GC_4039,(0,6):C.GC_4330,(0,5):C.GC_4337})

V_1871 = Vertex(name = 'V_1871',
                particles = [ P.A, P.A, P.W__minus__, P.W__plus__, P.Z, P.Z, P.G0, P.G0 ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVSS15, L.VVVVVVSS29, L.VVVVVVSS4 ],
                couplings = {(0,2):C.GC_5079,(0,0):C.GC_5076,(0,1):C.GC_5077})

V_1872 = Vertex(name = 'V_1872',
                particles = [ P.A, P.A, P.W__minus__, P.W__plus__, P.Z, P.Z, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVSS15, L.VVVVVVSS29, L.VVVVVVSS4, L.VVVVVVSS49, L.VVVVVVSS51, L.VVVVVVSS52, L.VVVVVVSS59 ],
                couplings = {(0,2):C.GC_5080,(0,3):C.GC_1192,(0,6):C.GC_1193,(0,5):C.GC_1450,(0,4):C.GC_1910,(0,0):C.GC_3172,(0,1):C.GC_3173})

V_1873 = Vertex(name = 'V_1873',
                particles = [ P.A, P.A, P.W__minus__, P.W__plus__, P.Z, P.Z, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVS13, L.VVVVVVS26, L.VVVVVVS3 ],
                couplings = {(0,2):C.GC_5058,(0,0):C.GC_5056,(0,1):C.GC_5057})

V_1874 = Vertex(name = 'V_1874',
                particles = [ P.A, P.A, P.W__minus__, P.W__plus__, P.Z, P.Z, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVSS15, L.VVVVVVSS29, L.VVVVVVSS4 ],
                couplings = {(0,2):C.GC_5079,(0,0):C.GC_5076,(0,1):C.GC_5077})

V_1875 = Vertex(name = 'V_1875',
                particles = [ P.A, P.W__minus__, P.W__plus__, P.Z, P.Z, P.G0 ],
                color = [ '1' ],
                lorentz = [ L.VVVVVS115, L.VVVVVS205, L.VVVVVS49 ],
                couplings = {(0,0):C.GC_4738,(0,1):C.GC_4730,(0,2):C.GC_4732})

V_1876 = Vertex(name = 'V_1876',
                particles = [ P.A, P.W__minus__, P.W__plus__, P.Z, P.Z, P.G0, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVVSS163, L.VVVVVSS258, L.VVVVVSS62 ],
                couplings = {(0,0):C.GC_4779,(0,1):C.GC_4766,(0,2):C.GC_4769})

V_1877 = Vertex(name = 'V_1877',
                particles = [ P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.Z, P.Z, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVS12, L.VVVVVVS24, L.VVVVVVS41, L.VVVVVVS43, L.VVVVVVS5 ],
                couplings = {(0,4):C.GC_7354,(0,3):C.GC_6186,(0,2):C.GC_4815,(0,0):C.GC_4816,(0,1):C.GC_4817})

V_1878 = Vertex(name = 'V_1878',
                particles = [ P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.Z, P.Z, P.G0, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVSS14, L.VVVVVVSS27, L.VVVVVVSS47, L.VVVVVVSS53, L.VVVVVVSS6 ],
                couplings = {(0,4):C.GC_7365,(0,3):C.GC_6190,(0,2):C.GC_4834,(0,0):C.GC_4837,(0,1):C.GC_4840})

V_1879 = Vertex(name = 'V_1879',
                particles = [ P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.Z, P.Z, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVSS14, L.VVVVVVSS27, L.VVVVVVSS47, L.VVVVVVSS53, L.VVVVVVSS6 ],
                couplings = {(0,4):C.GC_7366,(0,3):C.GC_6191,(0,2):C.GC_4833,(0,0):C.GC_4836,(0,1):C.GC_4838})

V_1880 = Vertex(name = 'V_1880',
                particles = [ P.A, P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.Z, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVS11, L.VVVVVVS21, L.VVVVVVS31, L.VVVVVVS33, L.VVVVVVS7 ],
                couplings = {(0,2):C.GC_4814,(0,3):C.GC_4818,(0,4):C.GC_7354,(0,1):C.GC_6186,(0,0):C.GC_4816})

V_1881 = Vertex(name = 'V_1881',
                particles = [ P.A, P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.Z, P.G0, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVSS13, L.VVVVVVSS23, L.VVVVVVSS34, L.VVVVVVSS36, L.VVVVVVSS9 ],
                couplings = {(0,2):C.GC_4831,(0,3):C.GC_4841,(0,4):C.GC_7364,(0,1):C.GC_6192,(0,0):C.GC_4835})

V_1882 = Vertex(name = 'V_1882',
                particles = [ P.A, P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.Z, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVSS13, L.VVVVVVSS23, L.VVVVVVSS34, L.VVVVVVSS36, L.VVVVVVSS9 ],
                couplings = {(0,2):C.GC_4832,(0,3):C.GC_4839,(0,4):C.GC_7366,(0,1):C.GC_6191,(0,0):C.GC_4836})

V_1883 = Vertex(name = 'V_1883',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.Z, P.G0, P.G0 ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVSS15, L.VVVVVVSS19, L.VVVVVVSS28, L.VVVVVVSS29, L.VVVVVVSS36 ],
                couplings = {(0,4):C.GC_1912,(0,2):C.GC_2334,(0,0):C.GC_3171,(0,1):C.GC_2336,(0,3):C.GC_3174})

V_1884 = Vertex(name = 'V_1884',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.Z, P.G0, P.G0 ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVSS36 ],
                couplings = {(0,0):C.GC_2302})

V_1885 = Vertex(name = 'V_1885',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.Z, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVSS15, L.VVVVVVSS29, L.VVVVVVSS36, L.VVVVVVSS41, L.VVVVVVSS64 ],
                couplings = {(0,0):C.GC_5075,(0,2):C.GC_1914,(0,3):C.GC_2335,(0,4):C.GC_2336,(0,1):C.GC_5078})

V_1886 = Vertex(name = 'V_1886',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.Z, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVSS36 ],
                couplings = {(0,0):C.GC_2302})

V_1887 = Vertex(name = 'V_1887',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.Z, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVS13, L.VVVVVVS17, L.VVVVVVS25, L.VVVVVVS26, L.VVVVVVS33 ],
                couplings = {(0,4):C.GC_1890,(0,2):C.GC_2327,(0,0):C.GC_3167,(0,1):C.GC_2328,(0,3):C.GC_3168})

V_1888 = Vertex(name = 'V_1888',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.Z, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVS33 ],
                couplings = {(0,0):C.GC_2270})

V_1889 = Vertex(name = 'V_1889',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.Z, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVSS15, L.VVVVVVSS19, L.VVVVVVSS28, L.VVVVVVSS29, L.VVVVVVSS36 ],
                couplings = {(0,4):C.GC_1912,(0,2):C.GC_2334,(0,0):C.GC_3171,(0,1):C.GC_2336,(0,3):C.GC_3174})

V_1890 = Vertex(name = 'V_1890',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.Z, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVSS36 ],
                couplings = {(0,0):C.GC_2302})

V_1891 = Vertex(name = 'V_1891',
                particles = [ P.A, P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.Z ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVVV11, L.VVVVVVVV3 ],
                couplings = {(0,1):C.GC_1917,(0,0):C.GC_1920})

V_1892 = Vertex(name = 'V_1892',
                particles = [ P.W__minus__, P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.W__plus__, P.Z, P.Z ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVVV1, L.VVVVVVVV17 ],
                couplings = {(0,0):C.GC_2338,(0,1):C.GC_2337})

V_1893 = Vertex(name = 'V_1893',
                particles = [ P.A, P.Z, P.Z, P.Z, P.G0, P.G0, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS13 ],
                couplings = {(0,0):C.GC_7369})

V_1894 = Vertex(name = 'V_1894',
                particles = [ P.A, P.Z, P.Z, P.Z, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS13 ],
                couplings = {(0,0):C.GC_7370})

V_1895 = Vertex(name = 'V_1895',
                particles = [ P.A, P.Z, P.Z, P.Z, P.G__minus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS13 ],
                couplings = {(0,0):C.GC_7368})

V_1896 = Vertex(name = 'V_1896',
                particles = [ P.A, P.Z, P.Z, P.Z, P.G__minus__, P.G__plus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS13 ],
                couplings = {(0,0):C.GC_7369})

V_1897 = Vertex(name = 'V_1897',
                particles = [ P.Z, P.Z, P.Z, P.G0, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVSSS78 ],
                couplings = {(0,0):C.GC_5088})

V_1898 = Vertex(name = 'V_1898',
                particles = [ P.Z, P.Z, P.Z, P.G0, P.G__minus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS208 ],
                couplings = {(0,0):C.GC_5093})

V_1899 = Vertex(name = 'V_1899',
                particles = [ P.Z, P.Z, P.Z, P.G0, P.G0, P.G0 ],
                color = [ '1' ],
                lorentz = [ L.VVVSSS194 ],
                couplings = {(0,0):C.GC_5087})

V_1900 = Vertex(name = 'V_1900',
                particles = [ P.Z, P.Z, P.Z, P.G0, P.G0, P.G0, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS178 ],
                couplings = {(0,0):C.GC_5092})

V_1901 = Vertex(name = 'V_1901',
                particles = [ P.Z, P.Z, P.Z, P.G0, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSS166 ],
                couplings = {(0,0):C.GC_5089})

V_1902 = Vertex(name = 'V_1902',
                particles = [ P.Z, P.Z, P.Z, P.G0, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS274 ],
                couplings = {(0,0):C.GC_5094})

V_1903 = Vertex(name = 'V_1903',
                particles = [ P.Z, P.Z, P.Z, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS229 ],
                couplings = {(0,0):C.GC_5091})

V_1904 = Vertex(name = 'V_1904',
                particles = [ P.Z, P.Z, P.Z, P.G0, P.G0, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS243 ],
                couplings = {(0,0):C.GC_5090})

V_1905 = Vertex(name = 'V_1905',
                particles = [ P.Z, P.Z, P.Z, P.G__minus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSS91 ],
                couplings = {(0,0):C.GC_5086})

V_1906 = Vertex(name = 'V_1906',
                particles = [ P.Z, P.Z, P.Z, P.G__minus__, P.G__plus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVSSSS112 ],
                couplings = {(0,0):C.GC_5090})

V_1907 = Vertex(name = 'V_1907',
                particles = [ P.W__minus__, P.Z, P.Z, P.Z, P.G__minus__, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS13 ],
                couplings = {(0,0):C.GC_5101})

V_1908 = Vertex(name = 'V_1908',
                particles = [ P.W__minus__, P.Z, P.Z, P.Z, P.G0, P.G__minus__, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS13 ],
                couplings = {(0,0):C.GC_5111})

V_1909 = Vertex(name = 'V_1909',
                particles = [ P.W__minus__, P.Z, P.Z, P.Z, P.G__minus__, P.G__plus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS13 ],
                couplings = {(0,0):C.GC_5108})

V_1910 = Vertex(name = 'V_1910',
                particles = [ P.W__minus__, P.Z, P.Z, P.Z, P.G0, P.G0, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS13 ],
                couplings = {(0,0):C.GC_5100})

V_1911 = Vertex(name = 'V_1911',
                particles = [ P.W__minus__, P.Z, P.Z, P.Z, P.G0, P.G0, P.G0, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS13 ],
                couplings = {(0,0):C.GC_5112})

V_1912 = Vertex(name = 'V_1912',
                particles = [ P.W__minus__, P.Z, P.Z, P.Z, P.G0, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS13 ],
                couplings = {(0,0):C.GC_5103})

V_1913 = Vertex(name = 'V_1913',
                particles = [ P.W__minus__, P.Z, P.Z, P.Z, P.G0, P.G0, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS13 ],
                couplings = {(0,0):C.GC_5107})

V_1914 = Vertex(name = 'V_1914',
                particles = [ P.W__minus__, P.Z, P.Z, P.Z, P.G__plus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS13 ],
                couplings = {(0,0):C.GC_5102})

V_1915 = Vertex(name = 'V_1915',
                particles = [ P.W__minus__, P.Z, P.Z, P.Z, P.G0, P.G__plus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS13 ],
                couplings = {(0,0):C.GC_5110})

V_1916 = Vertex(name = 'V_1916',
                particles = [ P.W__minus__, P.Z, P.Z, P.Z, P.G__plus__, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS13 ],
                couplings = {(0,0):C.GC_5109})

V_1917 = Vertex(name = 'V_1917',
                particles = [ P.W__plus__, P.Z, P.Z, P.Z, P.G__minus__, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS13 ],
                couplings = {(0,0):C.GC_5101})

V_1918 = Vertex(name = 'V_1918',
                particles = [ P.W__plus__, P.Z, P.Z, P.Z, P.G0, P.G__minus__, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS13 ],
                couplings = {(0,0):C.GC_5105})

V_1919 = Vertex(name = 'V_1919',
                particles = [ P.W__plus__, P.Z, P.Z, P.Z, P.G__minus__, P.G__minus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS13 ],
                couplings = {(0,0):C.GC_5108})

V_1920 = Vertex(name = 'V_1920',
                particles = [ P.W__plus__, P.Z, P.Z, P.Z, P.G0, P.G0, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS13 ],
                couplings = {(0,0):C.GC_5100})

V_1921 = Vertex(name = 'V_1921',
                particles = [ P.W__plus__, P.Z, P.Z, P.Z, P.G0, P.G0, P.G0, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS13 ],
                couplings = {(0,0):C.GC_5104})

V_1922 = Vertex(name = 'V_1922',
                particles = [ P.W__plus__, P.Z, P.Z, P.Z, P.G0, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS13 ],
                couplings = {(0,0):C.GC_5099})

V_1923 = Vertex(name = 'V_1923',
                particles = [ P.W__plus__, P.Z, P.Z, P.Z, P.G0, P.G0, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS13 ],
                couplings = {(0,0):C.GC_5107})

V_1924 = Vertex(name = 'V_1924',
                particles = [ P.W__plus__, P.Z, P.Z, P.Z, P.G__minus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS13 ],
                couplings = {(0,0):C.GC_5102})

V_1925 = Vertex(name = 'V_1925',
                particles = [ P.W__plus__, P.Z, P.Z, P.Z, P.G0, P.G__minus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS13 ],
                couplings = {(0,0):C.GC_5106})

V_1926 = Vertex(name = 'V_1926',
                particles = [ P.W__plus__, P.Z, P.Z, P.Z, P.G__minus__, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS13 ],
                couplings = {(0,0):C.GC_5109})

V_1927 = Vertex(name = 'V_1927',
                particles = [ P.Z, P.Z, P.Z, P.Z, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSS425, L.VVVVSS465, L.VVVVSS609, L.VVVVSS659, L.VVVVSS676 ],
                couplings = {(0,3):C.GC_6735,(0,0):C.GC_6701,(0,4):C.GC_6693,(0,2):C.GC_5116,(0,1):C.GC_6757})

V_1928 = Vertex(name = 'V_1928',
                particles = [ P.Z, P.Z, P.Z, P.Z, P.G0, P.G0, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS13 ],
                couplings = {(0,0):C.GC_5122})

V_1929 = Vertex(name = 'V_1929',
                particles = [ P.Z, P.Z, P.Z, P.Z, P.G__minus__, P.G__minus__, P.G__plus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS13 ],
                couplings = {(0,0):C.GC_5123})

V_1930 = Vertex(name = 'V_1930',
                particles = [ P.Z, P.Z, P.Z, P.Z, P.G__minus__, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS13 ],
                couplings = {(0,0):C.GC_5119})

V_1931 = Vertex(name = 'V_1931',
                particles = [ P.Z, P.Z, P.Z, P.Z, P.G__minus__, P.G__plus__, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS13 ],
                couplings = {(0,0):C.GC_5122})

V_1932 = Vertex(name = 'V_1932',
                particles = [ P.Z, P.Z, P.Z, P.Z, P.G0, P.G0 ],
                color = [ '1' ],
                lorentz = [ L.VVVVSS425, L.VVVVSS465, L.VVVVSS609, L.VVVVSS659, L.VVVVSS676 ],
                couplings = {(0,3):C.GC_6120,(0,0):C.GC_6118,(0,4):C.GC_6117,(0,2):C.GC_5115,(0,1):C.GC_3934})

V_1933 = Vertex(name = 'V_1933',
                particles = [ P.Z, P.Z, P.Z, P.Z, P.G0, P.G0, P.G0, P.G0 ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS13 ],
                couplings = {(0,0):C.GC_5124})

V_1934 = Vertex(name = 'V_1934',
                particles = [ P.Z, P.Z, P.Z, P.Z, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVS105, L.VVVVS175, L.VVVVS210, L.VVVVS217, L.VVVVS72 ],
                couplings = {(0,2):C.GC_6106,(0,4):C.GC_6104,(0,3):C.GC_6103,(0,1):C.GC_5114,(0,0):C.GC_3885})

V_1935 = Vertex(name = 'V_1935',
                particles = [ P.Z, P.Z, P.Z, P.Z, P.G0, P.G0, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS13 ],
                couplings = {(0,0):C.GC_5118})

V_1936 = Vertex(name = 'V_1936',
                particles = [ P.Z, P.Z, P.Z, P.Z, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSS425, L.VVVVSS465, L.VVVVSS609, L.VVVVSS659, L.VVVVSS676 ],
                couplings = {(0,3):C.GC_6120,(0,0):C.GC_6118,(0,4):C.GC_6117,(0,2):C.GC_5117,(0,1):C.GC_3934})

V_1937 = Vertex(name = 'V_1937',
                particles = [ P.Z, P.Z, P.Z, P.Z, P.G0, P.G0, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS13 ],
                couplings = {(0,0):C.GC_5121})

V_1938 = Vertex(name = 'V_1938',
                particles = [ P.Z, P.Z, P.Z, P.Z, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSS13 ],
                couplings = {(0,0):C.GC_5120})

V_1939 = Vertex(name = 'V_1939',
                particles = [ P.Z, P.Z, P.Z, P.Z, P.H, P.H, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSSSS13 ],
                couplings = {(0,0):C.GC_5124})

V_1940 = Vertex(name = 'V_1940',
                particles = [ P.A, P.A, P.Z, P.Z, P.G0, P.G0 ],
                color = [ '1' ],
                lorentz = [ L.VVVVSS316, L.VVVVSS350, L.VVVVSS422, L.VVVVSS617 ],
                couplings = {(0,1):C.GC_6121,(0,2):C.GC_6119,(0,3):C.GC_6116,(0,0):C.GC_3935})

V_1941 = Vertex(name = 'V_1941',
                particles = [ P.A, P.A, P.Z, P.Z, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVS181, L.VVVVS27, L.VVVVS55, L.VVVVS69 ],
                couplings = {(0,2):C.GC_6107,(0,3):C.GC_6105,(0,0):C.GC_6102,(0,1):C.GC_3886})

V_1942 = Vertex(name = 'V_1942',
                particles = [ P.A, P.A, P.Z, P.Z, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSS316, L.VVVVSS350, L.VVVVSS422, L.VVVVSS617 ],
                couplings = {(0,1):C.GC_6121,(0,2):C.GC_6119,(0,3):C.GC_6116,(0,0):C.GC_3935})

V_1943 = Vertex(name = 'V_1943',
                particles = [ P.A, P.Z, P.Z, P.Z, P.G0, P.G0 ],
                color = [ '1' ],
                lorentz = [ L.VVVVSS436, L.VVVVSS449, L.VVVVSS450, L.VVVVSS620, L.VVVVSS642 ],
                couplings = {(0,1):C.GC_1005,(0,2):C.GC_3118,(0,4):C.GC_6111,(0,0):C.GC_6115,(0,3):C.GC_6113})

V_1944 = Vertex(name = 'V_1944',
                particles = [ P.A, P.Z, P.Z, P.Z, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVS184, L.VVVVS198, L.VVVVS76, L.VVVVS89, L.VVVVS91 ],
                couplings = {(0,3):C.GC_891,(0,4):C.GC_3106,(0,1):C.GC_6099,(0,2):C.GC_6101,(0,0):C.GC_6100})

V_1945 = Vertex(name = 'V_1945',
                particles = [ P.A, P.Z, P.Z, P.Z, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVSS436, L.VVVVSS449, L.VVVVSS450, L.VVVVSS620, L.VVVVSS642 ],
                couplings = {(0,1):C.GC_1005,(0,2):C.GC_3118,(0,4):C.GC_6111,(0,0):C.GC_6115,(0,3):C.GC_6113})

V_1946 = Vertex(name = 'V_1946',
                particles = [ P.W__minus__, P.W__plus__, P.Z, P.Z, P.Z, P.G0, P.G0 ],
                color = [ '1' ],
                lorentz = [ L.VVVVVSS11, L.VVVVVSS120, L.VVVVVSS126, L.VVVVVSS13, L.VVVVVSS144, L.VVVVVSS149, L.VVVVVSS150, L.VVVVVSS158, L.VVVVVSS198, L.VVVVVSS201, L.VVVVVSS240, L.VVVVVSS242, L.VVVVVSS247, L.VVVVVSS86 ],
                couplings = {(0,6):C.GC_2092,(0,12):C.GC_6168,(0,7):C.GC_2763,(0,0):C.GC_2759,(0,11):C.GC_3044,(0,2):C.GC_3050,(0,13):C.GC_3053,(0,9):C.GC_3048,(0,5):C.GC_4092,(0,4):C.GC_7344,(0,3):C.GC_4793,(0,10):C.GC_7342,(0,1):C.GC_4879,(0,8):C.GC_7341})

V_1947 = Vertex(name = 'V_1947',
                particles = [ P.W__minus__, P.W__plus__, P.Z, P.Z, P.Z, P.G0, P.G0 ],
                color = [ '1' ],
                lorentz = [ L.VVVVVSS247 ],
                couplings = {(0,0):C.GC_2754})

V_1948 = Vertex(name = 'V_1948',
                particles = [ P.W__minus__, P.W__plus__, P.Z, P.Z, P.Z, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVSS112, L.VVVVVSS113, L.VVVVVSS120, L.VVVVVSS126, L.VVVVVSS144, L.VVVVVSS149, L.VVVVVSS150, L.VVVVVSS158, L.VVVVVSS164, L.VVVVVSS165, L.VVVVVSS198, L.VVVVVSS201, L.VVVVVSS205, L.VVVVVSS207, L.VVVVVSS240, L.VVVVVSS242, L.VVVVVSS243, L.VVVVVSS244, L.VVVVVSS246, L.VVVVVSS247, L.VVVVVSS248, L.VVVVVSS86 ],
                couplings = {(0,6):C.GC_2092,(0,19):C.GC_6170,(0,7):C.GC_2050,(0,9):C.GC_2114,(0,8):C.GC_2759,(0,17):C.GC_2108,(0,16):C.GC_2748,(0,15):C.GC_3044,(0,12):C.GC_2110,(0,13):C.GC_2750,(0,3):C.GC_3751,(0,21):C.GC_3056,(0,11):C.GC_3048,(0,5):C.GC_4091,(0,4):C.GC_7343,(0,1):C.GC_4127,(0,0):C.GC_4793,(0,18):C.GC_4790,(0,20):C.GC_4799,(0,14):C.GC_4881,(0,2):C.GC_4880,(0,10):C.GC_4878})

V_1949 = Vertex(name = 'V_1949',
                particles = [ P.W__minus__, P.W__plus__, P.Z, P.Z, P.Z, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVSS247 ],
                couplings = {(0,0):C.GC_6184})

V_1950 = Vertex(name = 'V_1950',
                particles = [ P.W__minus__, P.W__plus__, P.Z, P.Z, P.Z, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVVS10, L.VVVVVS104, L.VVVVVS109, L.VVVVVS110, L.VVVVVS118, L.VVVVVS12, L.VVVVVS144, L.VVVVVS147, L.VVVVVS180, L.VVVVVS182, L.VVVVVS184, L.VVVVVS67, L.VVVVVS88, L.VVVVVS93 ],
                couplings = {(0,4):C.GC_2732,(0,0):C.GC_2728,(0,10):C.GC_6159,(0,9):C.GC_3027,(0,13):C.GC_3031,(0,11):C.GC_3032,(0,7):C.GC_3029,(0,3):C.GC_2080,(0,1):C.GC_7336,(0,5):C.GC_4744,(0,8):C.GC_7335,(0,12):C.GC_4871,(0,6):C.GC_7334,(0,2):C.GC_4085})

V_1951 = Vertex(name = 'V_1951',
                particles = [ P.W__minus__, P.W__plus__, P.Z, P.Z, P.Z, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVVS184 ],
                couplings = {(0,0):C.GC_2726})

V_1952 = Vertex(name = 'V_1952',
                particles = [ P.W__minus__, P.W__plus__, P.Z, P.Z, P.Z, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVVSS11, L.VVVVVSS120, L.VVVVVSS126, L.VVVVVSS13, L.VVVVVSS144, L.VVVVVSS149, L.VVVVVSS150, L.VVVVVSS158, L.VVVVVSS198, L.VVVVVSS201, L.VVVVVSS240, L.VVVVVSS242, L.VVVVVSS247, L.VVVVVSS86 ],
                couplings = {(0,6):C.GC_2092,(0,12):C.GC_6168,(0,7):C.GC_2763,(0,0):C.GC_2759,(0,11):C.GC_3044,(0,2):C.GC_3050,(0,13):C.GC_3053,(0,9):C.GC_3048,(0,5):C.GC_4092,(0,4):C.GC_7344,(0,3):C.GC_4793,(0,10):C.GC_7342,(0,1):C.GC_4879,(0,8):C.GC_7341})

V_1953 = Vertex(name = 'V_1953',
                particles = [ P.W__minus__, P.W__plus__, P.Z, P.Z, P.Z, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVVSS247 ],
                couplings = {(0,0):C.GC_2754})

V_1954 = Vertex(name = 'V_1954',
                particles = [ P.W__minus__, P.W__plus__, P.Z, P.Z, P.Z, P.Z ],
                color = [ '1' ],
                lorentz = [ L.VVVVVV10, L.VVVVVV38, L.VVVVVV47, L.VVVVVV70, L.VVVVVV71, L.VVVVVV93 ],
                couplings = {(0,0):C.GC_1678,(0,1):C.GC_1681,(0,3):C.GC_1676,(0,2):C.GC_1680,(0,5):C.GC_1674,(0,4):C.GC_1427})

V_1955 = Vertex(name = 'V_1955',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.Z, P.Z ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVV19, L.VVVVVVV23, L.VVVVVVV4, L.VVVVVVV7 ],
                couplings = {(0,3):C.GC_2119,(0,1):C.GC_2117,(0,2):C.GC_2118,(0,0):C.GC_2116})

V_1956 = Vertex(name = 'V_1956',
                particles = [ P.A, P.W__minus__, P.W__plus__, P.Z, P.Z, P.Z, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVSS16, L.VVVVVVSS43, L.VVVVVVSS54, L.VVVVVVSS62 ],
                couplings = {(0,2):C.GC_6151,(0,3):C.GC_6865,(0,0):C.GC_6869,(0,1):C.GC_6142})

V_1957 = Vertex(name = 'V_1957',
                particles = [ P.W__minus__, P.W__plus__, P.Z, P.Z, P.Z, P.G0 ],
                color = [ '1' ],
                lorentz = [ L.VVVVVS120, L.VVVVVS124 ],
                couplings = {(0,1):C.GC_2046,(0,0):C.GC_2729})

V_1958 = Vertex(name = 'V_1958',
                particles = [ P.W__minus__, P.W__plus__, P.Z, P.Z, P.Z, P.G0, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVVSS160, L.VVVVVSS171 ],
                couplings = {(0,1):C.GC_2049,(0,0):C.GC_2760})

V_1959 = Vertex(name = 'V_1959',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.Z, P.Z, P.Z, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVS18 ],
                couplings = {(0,0):C.GC_2060})

V_1960 = Vertex(name = 'V_1960',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.Z, P.Z, P.Z, P.G0, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVSS20 ],
                couplings = {(0,0):C.GC_2064})

V_1961 = Vertex(name = 'V_1961',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.Z, P.Z, P.Z, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVSS20 ],
                couplings = {(0,0):C.GC_2065})

V_1962 = Vertex(name = 'V_1962',
                particles = [ P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.Z, P.Z, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVS35 ],
                couplings = {(0,0):C.GC_2060})

V_1963 = Vertex(name = 'V_1963',
                particles = [ P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.Z, P.Z, P.G0, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVSS38 ],
                couplings = {(0,0):C.GC_2066})

V_1964 = Vertex(name = 'V_1964',
                particles = [ P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.Z, P.Z, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVSS38 ],
                couplings = {(0,0):C.GC_2065})

V_1965 = Vertex(name = 'V_1965',
                particles = [ P.A, P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.Z, P.Z ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVVV8, L.VVVVVVVV9 ],
                couplings = {(0,0):C.GC_4073,(0,1):C.GC_4072})

V_1966 = Vertex(name = 'V_1966',
                particles = [ P.W__minus__, P.Z, P.Z, P.Z, P.Z, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVS168, L.VVVVVS84 ],
                couplings = {(0,1):C.GC_6789,(0,0):C.GC_6795})

V_1967 = Vertex(name = 'V_1967',
                particles = [ P.W__minus__, P.Z, P.Z, P.Z, P.Z, P.G0, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVSS114, L.VVVVVSS225 ],
                couplings = {(0,0):C.GC_6822,(0,1):C.GC_6834})

V_1968 = Vertex(name = 'V_1968',
                particles = [ P.W__minus__, P.Z, P.Z, P.Z, P.Z, P.G__plus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVVSS114, L.VVVVVSS225 ],
                couplings = {(0,0):C.GC_6820,(0,1):C.GC_6832})

V_1969 = Vertex(name = 'V_1969',
                particles = [ P.W__plus__, P.Z, P.Z, P.Z, P.Z, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVS168, L.VVVVVS84 ],
                couplings = {(0,1):C.GC_6790,(0,0):C.GC_6796})

V_1970 = Vertex(name = 'V_1970',
                particles = [ P.W__plus__, P.Z, P.Z, P.Z, P.Z, P.G0, P.G__minus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVSS114, L.VVVVVSS225 ],
                couplings = {(0,0):C.GC_6823,(0,1):C.GC_6834})

V_1971 = Vertex(name = 'V_1971',
                particles = [ P.W__plus__, P.Z, P.Z, P.Z, P.Z, P.G__minus__, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVVSS114, L.VVVVVSS225 ],
                couplings = {(0,0):C.GC_6821,(0,1):C.GC_6833})

V_1972 = Vertex(name = 'V_1972',
                particles = [ P.A, P.W__minus__, P.W__plus__, P.Z, P.Z, P.Z, P.G0, P.G0 ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVSS16, L.VVVVVVSS43 ],
                couplings = {(0,0):C.GC_4071,(0,1):C.GC_6142})

V_1973 = Vertex(name = 'V_1973',
                particles = [ P.A, P.W__minus__, P.W__plus__, P.Z, P.Z, P.Z, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVS14, L.VVVVVVS38 ],
                couplings = {(0,0):C.GC_4068,(0,1):C.GC_6136})

V_1974 = Vertex(name = 'V_1974',
                particles = [ P.A, P.W__minus__, P.W__plus__, P.Z, P.Z, P.Z, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVSS16, L.VVVVVVSS43 ],
                couplings = {(0,0):C.GC_4071,(0,1):C.GC_6142})

V_1975 = Vertex(name = 'V_1975',
                particles = [ P.W__minus__, P.W__plus__, P.Z, P.Z, P.Z, P.Z, P.G0, P.G0 ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVSS25 ],
                couplings = {(0,0):C.GC_1438})

V_1976 = Vertex(name = 'V_1976',
                particles = [ P.W__minus__, P.W__plus__, P.Z, P.Z, P.Z, P.Z, P.G__minus__, P.G__plus__ ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVSS25 ],
                couplings = {(0,0):C.GC_1908})

V_1977 = Vertex(name = 'V_1977',
                particles = [ P.W__minus__, P.W__plus__, P.Z, P.Z, P.Z, P.Z, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVS22 ],
                couplings = {(0,0):C.GC_1432})

V_1978 = Vertex(name = 'V_1978',
                particles = [ P.W__minus__, P.W__plus__, P.Z, P.Z, P.Z, P.Z, P.H, P.H ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVSS25 ],
                couplings = {(0,0):C.GC_1438})

V_1979 = Vertex(name = 'V_1979',
                particles = [ P.W__minus__, P.W__minus__, P.W__plus__, P.W__plus__, P.Z, P.Z, P.Z, P.Z ],
                color = [ '1' ],
                lorentz = [ L.VVVVVVVV15, L.VVVVVVVV5 ],
                couplings = {(0,1):C.GC_2068,(0,0):C.GC_2069})

V_1980 = Vertex(name = 'V_1980',
                particles = [ P.d__tilde__, P.d, P.A ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV1 ],
                couplings = {(0,0):C.GC_5177})

V_1981 = Vertex(name = 'V_1981',
                particles = [ P.d__tilde__, P.d, P.A ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV1 ],
                couplings = {(0,0):C.GC_5293})

V_1982 = Vertex(name = 'V_1982',
                particles = [ P.d__tilde__, P.d, P.A ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV1 ],
                couplings = {(0,0):C.GC_5286})

V_1983 = Vertex(name = 'V_1983',
                particles = [ P.s__tilde__, P.s, P.A ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV1 ],
                couplings = {(0,0):C.GC_5177})

V_1984 = Vertex(name = 'V_1984',
                particles = [ P.s__tilde__, P.s, P.A ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV1 ],
                couplings = {(0,0):C.GC_5293})

V_1985 = Vertex(name = 'V_1985',
                particles = [ P.s__tilde__, P.s, P.A ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV1 ],
                couplings = {(0,0):C.GC_5286})

V_1986 = Vertex(name = 'V_1986',
                particles = [ P.b__tilde__, P.b, P.A ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV1 ],
                couplings = {(0,0):C.GC_5177})

V_1987 = Vertex(name = 'V_1987',
                particles = [ P.b__tilde__, P.b, P.A ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV1 ],
                couplings = {(0,0):C.GC_5293})

V_1988 = Vertex(name = 'V_1988',
                particles = [ P.b__tilde__, P.b, P.A ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV1 ],
                couplings = {(0,0):C.GC_5286})

V_1989 = Vertex(name = 'V_1989',
                particles = [ P.e__plus__, P.e__minus__, P.A ],
                color = [ '1' ],
                lorentz = [ L.FFV1 ],
                couplings = {(0,0):C.GC_5180})

V_1990 = Vertex(name = 'V_1990',
                particles = [ P.e__plus__, P.e__minus__, P.A ],
                color = [ '1' ],
                lorentz = [ L.FFV1 ],
                couplings = {(0,0):C.GC_5297})

V_1991 = Vertex(name = 'V_1991',
                particles = [ P.e__plus__, P.e__minus__, P.A ],
                color = [ '1' ],
                lorentz = [ L.FFV1 ],
                couplings = {(0,0):C.GC_5289})

V_1992 = Vertex(name = 'V_1992',
                particles = [ P.mu__plus__, P.mu__minus__, P.A ],
                color = [ '1' ],
                lorentz = [ L.FFV1 ],
                couplings = {(0,0):C.GC_5180})

V_1993 = Vertex(name = 'V_1993',
                particles = [ P.mu__plus__, P.mu__minus__, P.A ],
                color = [ '1' ],
                lorentz = [ L.FFV1 ],
                couplings = {(0,0):C.GC_5297})

V_1994 = Vertex(name = 'V_1994',
                particles = [ P.mu__plus__, P.mu__minus__, P.A ],
                color = [ '1' ],
                lorentz = [ L.FFV1 ],
                couplings = {(0,0):C.GC_5289})

V_1995 = Vertex(name = 'V_1995',
                particles = [ P.ta__plus__, P.ta__minus__, P.A ],
                color = [ '1' ],
                lorentz = [ L.FFV1 ],
                couplings = {(0,0):C.GC_5180})

V_1996 = Vertex(name = 'V_1996',
                particles = [ P.ta__plus__, P.ta__minus__, P.A ],
                color = [ '1' ],
                lorentz = [ L.FFV1 ],
                couplings = {(0,0):C.GC_5297})

V_1997 = Vertex(name = 'V_1997',
                particles = [ P.ta__plus__, P.ta__minus__, P.A ],
                color = [ '1' ],
                lorentz = [ L.FFV1 ],
                couplings = {(0,0):C.GC_5289})

V_1998 = Vertex(name = 'V_1998',
                particles = [ P.u__tilde__, P.u, P.A ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV1 ],
                couplings = {(0,0):C.GC_5178})

V_1999 = Vertex(name = 'V_1999',
                particles = [ P.u__tilde__, P.u, P.A ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV1 ],
                couplings = {(0,0):C.GC_5298})

V_2000 = Vertex(name = 'V_2000',
                particles = [ P.u__tilde__, P.u, P.A ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV1 ],
                couplings = {(0,0):C.GC_5287})

V_2001 = Vertex(name = 'V_2001',
                particles = [ P.c__tilde__, P.c, P.A ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV1 ],
                couplings = {(0,0):C.GC_5178})

V_2002 = Vertex(name = 'V_2002',
                particles = [ P.c__tilde__, P.c, P.A ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV1 ],
                couplings = {(0,0):C.GC_5298})

V_2003 = Vertex(name = 'V_2003',
                particles = [ P.c__tilde__, P.c, P.A ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV1 ],
                couplings = {(0,0):C.GC_5287})

V_2004 = Vertex(name = 'V_2004',
                particles = [ P.t__tilde__, P.t, P.A ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV1 ],
                couplings = {(0,0):C.GC_5178})

V_2005 = Vertex(name = 'V_2005',
                particles = [ P.t__tilde__, P.t, P.A ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV1 ],
                couplings = {(0,0):C.GC_5298})

V_2006 = Vertex(name = 'V_2006',
                particles = [ P.t__tilde__, P.t, P.A ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV1 ],
                couplings = {(0,0):C.GC_5287})

V_2007 = Vertex(name = 'V_2007',
                particles = [ P.d__tilde__, P.d, P.g ],
                color = [ 'T(3,2,1)' ],
                lorentz = [ L.FFV1 ],
                couplings = {(0,0):C.GC_512})

V_2008 = Vertex(name = 'V_2008',
                particles = [ P.s__tilde__, P.s, P.g ],
                color = [ 'T(3,2,1)' ],
                lorentz = [ L.FFV1 ],
                couplings = {(0,0):C.GC_512})

V_2009 = Vertex(name = 'V_2009',
                particles = [ P.b__tilde__, P.b, P.g ],
                color = [ 'T(3,2,1)' ],
                lorentz = [ L.FFV1 ],
                couplings = {(0,0):C.GC_512})

V_2010 = Vertex(name = 'V_2010',
                particles = [ P.u__tilde__, P.u, P.g ],
                color = [ 'T(3,2,1)' ],
                lorentz = [ L.FFV1 ],
                couplings = {(0,0):C.GC_512})

V_2011 = Vertex(name = 'V_2011',
                particles = [ P.c__tilde__, P.c, P.g ],
                color = [ 'T(3,2,1)' ],
                lorentz = [ L.FFV1 ],
                couplings = {(0,0):C.GC_512})

V_2012 = Vertex(name = 'V_2012',
                particles = [ P.t__tilde__, P.t, P.g ],
                color = [ 'T(3,2,1)' ],
                lorentz = [ L.FFV1 ],
                couplings = {(0,0):C.GC_512})

V_2013 = Vertex(name = 'V_2013',
                particles = [ P.e__plus__, P.ve, P.W__minus__ ],
                color = [ '1' ],
                lorentz = [ L.FFV2 ],
                couplings = {(0,0):C.GC_7930})

V_2014 = Vertex(name = 'V_2014',
                particles = [ P.mu__plus__, P.ve, P.W__minus__ ],
                color = [ '1' ],
                lorentz = [ L.FFV2 ],
                couplings = {(0,0):C.GC_7933})

V_2015 = Vertex(name = 'V_2015',
                particles = [ P.ta__plus__, P.ve, P.W__minus__ ],
                color = [ '1' ],
                lorentz = [ L.FFV2 ],
                couplings = {(0,0):C.GC_7936})

V_2016 = Vertex(name = 'V_2016',
                particles = [ P.e__plus__, P.vm, P.W__minus__ ],
                color = [ '1' ],
                lorentz = [ L.FFV2 ],
                couplings = {(0,0):C.GC_7931})

V_2017 = Vertex(name = 'V_2017',
                particles = [ P.mu__plus__, P.vm, P.W__minus__ ],
                color = [ '1' ],
                lorentz = [ L.FFV2 ],
                couplings = {(0,0):C.GC_7934})

V_2018 = Vertex(name = 'V_2018',
                particles = [ P.ta__plus__, P.vm, P.W__minus__ ],
                color = [ '1' ],
                lorentz = [ L.FFV2 ],
                couplings = {(0,0):C.GC_7937})

V_2019 = Vertex(name = 'V_2019',
                particles = [ P.e__plus__, P.vt, P.W__minus__ ],
                color = [ '1' ],
                lorentz = [ L.FFV2 ],
                couplings = {(0,0):C.GC_7932})

V_2020 = Vertex(name = 'V_2020',
                particles = [ P.mu__plus__, P.vt, P.W__minus__ ],
                color = [ '1' ],
                lorentz = [ L.FFV2 ],
                couplings = {(0,0):C.GC_7935})

V_2021 = Vertex(name = 'V_2021',
                particles = [ P.ta__plus__, P.vt, P.W__minus__ ],
                color = [ '1' ],
                lorentz = [ L.FFV2 ],
                couplings = {(0,0):C.GC_7938})

V_2022 = Vertex(name = 'V_2022',
                particles = [ P.d__tilde__, P.u, P.W__minus__ ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV2 ],
                couplings = {(0,0):C.GC_519})

V_2023 = Vertex(name = 'V_2023',
                particles = [ P.s__tilde__, P.u, P.W__minus__ ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV2 ],
                couplings = {(0,0):C.GC_520})

V_2024 = Vertex(name = 'V_2024',
                particles = [ P.b__tilde__, P.u, P.W__minus__ ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV2 ],
                couplings = {(0,0):C.GC_521})

V_2025 = Vertex(name = 'V_2025',
                particles = [ P.d__tilde__, P.c, P.W__minus__ ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV2 ],
                couplings = {(0,0):C.GC_522})

V_2026 = Vertex(name = 'V_2026',
                particles = [ P.s__tilde__, P.c, P.W__minus__ ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV2 ],
                couplings = {(0,0):C.GC_523})

V_2027 = Vertex(name = 'V_2027',
                particles = [ P.b__tilde__, P.c, P.W__minus__ ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV2 ],
                couplings = {(0,0):C.GC_524})

V_2028 = Vertex(name = 'V_2028',
                particles = [ P.d__tilde__, P.t, P.W__minus__ ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV2 ],
                couplings = {(0,0):C.GC_525})

V_2029 = Vertex(name = 'V_2029',
                particles = [ P.s__tilde__, P.t, P.W__minus__ ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV2 ],
                couplings = {(0,0):C.GC_526})

V_2030 = Vertex(name = 'V_2030',
                particles = [ P.b__tilde__, P.t, P.W__minus__ ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV2 ],
                couplings = {(0,0):C.GC_527})

V_2031 = Vertex(name = 'V_2031',
                particles = [ P.u__tilde__, P.d, P.W__plus__ ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV2 ],
                couplings = {(0,0):C.GC_7921})

V_2032 = Vertex(name = 'V_2032',
                particles = [ P.c__tilde__, P.d, P.W__plus__ ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV2 ],
                couplings = {(0,0):C.GC_7924})

V_2033 = Vertex(name = 'V_2033',
                particles = [ P.t__tilde__, P.d, P.W__plus__ ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV2 ],
                couplings = {(0,0):C.GC_7927})

V_2034 = Vertex(name = 'V_2034',
                particles = [ P.u__tilde__, P.s, P.W__plus__ ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV2 ],
                couplings = {(0,0):C.GC_7922})

V_2035 = Vertex(name = 'V_2035',
                particles = [ P.c__tilde__, P.s, P.W__plus__ ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV2 ],
                couplings = {(0,0):C.GC_7925})

V_2036 = Vertex(name = 'V_2036',
                particles = [ P.t__tilde__, P.s, P.W__plus__ ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV2 ],
                couplings = {(0,0):C.GC_7928})

V_2037 = Vertex(name = 'V_2037',
                particles = [ P.u__tilde__, P.b, P.W__plus__ ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV2 ],
                couplings = {(0,0):C.GC_7923})

V_2038 = Vertex(name = 'V_2038',
                particles = [ P.c__tilde__, P.b, P.W__plus__ ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV2 ],
                couplings = {(0,0):C.GC_7926})

V_2039 = Vertex(name = 'V_2039',
                particles = [ P.t__tilde__, P.b, P.W__plus__ ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV2 ],
                couplings = {(0,0):C.GC_7929})

V_2040 = Vertex(name = 'V_2040',
                particles = [ P.ve__tilde__, P.e__minus__, P.W__plus__ ],
                color = [ '1' ],
                lorentz = [ L.FFV2 ],
                couplings = {(0,0):C.GC_769})

V_2041 = Vertex(name = 'V_2041',
                particles = [ P.vm__tilde__, P.e__minus__, P.W__plus__ ],
                color = [ '1' ],
                lorentz = [ L.FFV2 ],
                couplings = {(0,0):C.GC_770})

V_2042 = Vertex(name = 'V_2042',
                particles = [ P.vt__tilde__, P.e__minus__, P.W__plus__ ],
                color = [ '1' ],
                lorentz = [ L.FFV2 ],
                couplings = {(0,0):C.GC_771})

V_2043 = Vertex(name = 'V_2043',
                particles = [ P.ve__tilde__, P.mu__minus__, P.W__plus__ ],
                color = [ '1' ],
                lorentz = [ L.FFV2 ],
                couplings = {(0,0):C.GC_772})

V_2044 = Vertex(name = 'V_2044',
                particles = [ P.vm__tilde__, P.mu__minus__, P.W__plus__ ],
                color = [ '1' ],
                lorentz = [ L.FFV2 ],
                couplings = {(0,0):C.GC_773})

V_2045 = Vertex(name = 'V_2045',
                particles = [ P.vt__tilde__, P.mu__minus__, P.W__plus__ ],
                color = [ '1' ],
                lorentz = [ L.FFV2 ],
                couplings = {(0,0):C.GC_774})

V_2046 = Vertex(name = 'V_2046',
                particles = [ P.ve__tilde__, P.ta__minus__, P.W__plus__ ],
                color = [ '1' ],
                lorentz = [ L.FFV2 ],
                couplings = {(0,0):C.GC_775})

V_2047 = Vertex(name = 'V_2047',
                particles = [ P.vm__tilde__, P.ta__minus__, P.W__plus__ ],
                color = [ '1' ],
                lorentz = [ L.FFV2 ],
                couplings = {(0,0):C.GC_776})

V_2048 = Vertex(name = 'V_2048',
                particles = [ P.vt__tilde__, P.ta__minus__, P.W__plus__ ],
                color = [ '1' ],
                lorentz = [ L.FFV2 ],
                couplings = {(0,0):C.GC_777})

V_2049 = Vertex(name = 'V_2049',
                particles = [ P.d__tilde__, P.d, P.Z ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3, L.FFV4 ],
                couplings = {(0,1):C.GC_2383,(0,0):C.GC_2811})

V_2050 = Vertex(name = 'V_2050',
                particles = [ P.d__tilde__, P.d, P.Z ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3, L.FFV4 ],
                couplings = {(0,1):C.GC_5699,(0,0):C.GC_2819})

V_2051 = Vertex(name = 'V_2051',
                particles = [ P.d__tilde__, P.d, P.Z ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3, L.FFV4 ],
                couplings = {(0,1):C.GC_5731,(0,0):C.GC_3320})

V_2052 = Vertex(name = 'V_2052',
                particles = [ P.s__tilde__, P.s, P.Z ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3, L.FFV4 ],
                couplings = {(0,1):C.GC_2383,(0,0):C.GC_2811})

V_2053 = Vertex(name = 'V_2053',
                particles = [ P.s__tilde__, P.s, P.Z ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3, L.FFV4 ],
                couplings = {(0,1):C.GC_5699,(0,0):C.GC_2819})

V_2054 = Vertex(name = 'V_2054',
                particles = [ P.s__tilde__, P.s, P.Z ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3, L.FFV4 ],
                couplings = {(0,1):C.GC_5731,(0,0):C.GC_3320})

V_2055 = Vertex(name = 'V_2055',
                particles = [ P.b__tilde__, P.b, P.Z ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3, L.FFV4 ],
                couplings = {(0,1):C.GC_2383,(0,0):C.GC_2811})

V_2056 = Vertex(name = 'V_2056',
                particles = [ P.b__tilde__, P.b, P.Z ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3, L.FFV4 ],
                couplings = {(0,1):C.GC_5699,(0,0):C.GC_2819})

V_2057 = Vertex(name = 'V_2057',
                particles = [ P.b__tilde__, P.b, P.Z ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3, L.FFV4 ],
                couplings = {(0,1):C.GC_5731,(0,0):C.GC_3320})

V_2058 = Vertex(name = 'V_2058',
                particles = [ P.e__plus__, P.e__minus__, P.Z ],
                color = [ '1' ],
                lorentz = [ L.FFV4, L.FFV5 ],
                couplings = {(0,0):C.GC_2386,(0,1):C.GC_2812})

V_2059 = Vertex(name = 'V_2059',
                particles = [ P.e__plus__, P.e__minus__, P.Z ],
                color = [ '1' ],
                lorentz = [ L.FFV4, L.FFV5 ],
                couplings = {(0,0):C.GC_5703,(0,1):C.GC_2820})

V_2060 = Vertex(name = 'V_2060',
                particles = [ P.e__plus__, P.e__minus__, P.Z ],
                color = [ '1' ],
                lorentz = [ L.FFV4, L.FFV5 ],
                couplings = {(0,0):C.GC_5734,(0,1):C.GC_3321})

V_2061 = Vertex(name = 'V_2061',
                particles = [ P.mu__plus__, P.mu__minus__, P.Z ],
                color = [ '1' ],
                lorentz = [ L.FFV4, L.FFV5 ],
                couplings = {(0,0):C.GC_2386,(0,1):C.GC_2812})

V_2062 = Vertex(name = 'V_2062',
                particles = [ P.mu__plus__, P.mu__minus__, P.Z ],
                color = [ '1' ],
                lorentz = [ L.FFV4, L.FFV5 ],
                couplings = {(0,0):C.GC_5703,(0,1):C.GC_2820})

V_2063 = Vertex(name = 'V_2063',
                particles = [ P.mu__plus__, P.mu__minus__, P.Z ],
                color = [ '1' ],
                lorentz = [ L.FFV4, L.FFV5 ],
                couplings = {(0,0):C.GC_5734,(0,1):C.GC_3321})

V_2064 = Vertex(name = 'V_2064',
                particles = [ P.ta__plus__, P.ta__minus__, P.Z ],
                color = [ '1' ],
                lorentz = [ L.FFV4, L.FFV5 ],
                couplings = {(0,0):C.GC_2386,(0,1):C.GC_2812})

V_2065 = Vertex(name = 'V_2065',
                particles = [ P.ta__plus__, P.ta__minus__, P.Z ],
                color = [ '1' ],
                lorentz = [ L.FFV4, L.FFV5 ],
                couplings = {(0,0):C.GC_5703,(0,1):C.GC_2820})

V_2066 = Vertex(name = 'V_2066',
                particles = [ P.ta__plus__, P.ta__minus__, P.Z ],
                color = [ '1' ],
                lorentz = [ L.FFV4, L.FFV5 ],
                couplings = {(0,0):C.GC_5734,(0,1):C.GC_3321})

V_2067 = Vertex(name = 'V_2067',
                particles = [ P.u__tilde__, P.u, P.Z ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV4, L.FFV6 ],
                couplings = {(0,0):C.GC_2384,(0,1):C.GC_2811})

V_2068 = Vertex(name = 'V_2068',
                particles = [ P.u__tilde__, P.u, P.Z ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV4, L.FFV6 ],
                couplings = {(0,0):C.GC_5700,(0,1):C.GC_2819})

V_2069 = Vertex(name = 'V_2069',
                particles = [ P.u__tilde__, P.u, P.Z ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV4, L.FFV6 ],
                couplings = {(0,0):C.GC_5736,(0,1):C.GC_3320})

V_2070 = Vertex(name = 'V_2070',
                particles = [ P.c__tilde__, P.c, P.Z ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV4, L.FFV6 ],
                couplings = {(0,0):C.GC_2384,(0,1):C.GC_2811})

V_2071 = Vertex(name = 'V_2071',
                particles = [ P.c__tilde__, P.c, P.Z ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV4, L.FFV6 ],
                couplings = {(0,0):C.GC_5700,(0,1):C.GC_2819})

V_2072 = Vertex(name = 'V_2072',
                particles = [ P.c__tilde__, P.c, P.Z ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV4, L.FFV6 ],
                couplings = {(0,0):C.GC_5736,(0,1):C.GC_3320})

V_2073 = Vertex(name = 'V_2073',
                particles = [ P.t__tilde__, P.t, P.Z ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV4, L.FFV6 ],
                couplings = {(0,0):C.GC_2384,(0,1):C.GC_2811})

V_2074 = Vertex(name = 'V_2074',
                particles = [ P.t__tilde__, P.t, P.Z ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV4, L.FFV6 ],
                couplings = {(0,0):C.GC_5700,(0,1):C.GC_2819})

V_2075 = Vertex(name = 'V_2075',
                particles = [ P.t__tilde__, P.t, P.Z ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV4, L.FFV6 ],
                couplings = {(0,0):C.GC_5736,(0,1):C.GC_3320})

V_2076 = Vertex(name = 'V_2076',
                particles = [ P.ve__tilde__, P.ve, P.Z ],
                color = [ '1' ],
                lorentz = [ L.FFV2 ],
                couplings = {(0,0):C.GC_2812})

V_2077 = Vertex(name = 'V_2077',
                particles = [ P.ve__tilde__, P.ve, P.Z ],
                color = [ '1' ],
                lorentz = [ L.FFV2 ],
                couplings = {(0,0):C.GC_2820})

V_2078 = Vertex(name = 'V_2078',
                particles = [ P.ve__tilde__, P.ve, P.Z ],
                color = [ '1' ],
                lorentz = [ L.FFV2 ],
                couplings = {(0,0):C.GC_3321})

V_2079 = Vertex(name = 'V_2079',
                particles = [ P.vm__tilde__, P.vm, P.Z ],
                color = [ '1' ],
                lorentz = [ L.FFV2 ],
                couplings = {(0,0):C.GC_2812})

V_2080 = Vertex(name = 'V_2080',
                particles = [ P.vm__tilde__, P.vm, P.Z ],
                color = [ '1' ],
                lorentz = [ L.FFV2 ],
                couplings = {(0,0):C.GC_2820})

V_2081 = Vertex(name = 'V_2081',
                particles = [ P.vm__tilde__, P.vm, P.Z ],
                color = [ '1' ],
                lorentz = [ L.FFV2 ],
                couplings = {(0,0):C.GC_3321})

V_2082 = Vertex(name = 'V_2082',
                particles = [ P.vt__tilde__, P.vt, P.Z ],
                color = [ '1' ],
                lorentz = [ L.FFV2 ],
                couplings = {(0,0):C.GC_2812})

V_2083 = Vertex(name = 'V_2083',
                particles = [ P.vt__tilde__, P.vt, P.Z ],
                color = [ '1' ],
                lorentz = [ L.FFV2 ],
                couplings = {(0,0):C.GC_2820})

V_2084 = Vertex(name = 'V_2084',
                particles = [ P.vt__tilde__, P.vt, P.Z ],
                color = [ '1' ],
                lorentz = [ L.FFV2 ],
                couplings = {(0,0):C.GC_3321})

